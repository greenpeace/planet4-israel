<?php
/**
 * Plugin Name:       GP Donation Gifts
 * Description:       מציג מתנות לפי סכום תרומה חודשית. מופעל לפי Custom Field "gp_show_gifts" = 1 בעמוד.
 * Version:           0.2.3
 * Requires PHP:      8.0
 * Author:            Greenpeace Israel - Digital Team
 * Text Domain:       gp-donation-gifts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'wp_footer', function () {

    // בדוק אם הפלאגין מופעל לעמוד הזה
    if ( ! is_singular() ) return;
    if ( ! get_post_meta( get_the_ID(), 'gp_show_gifts', true ) ) return;
    if ( ! class_exists( 'GFForms' ) ) return;

    ?>
    <style>
    #gp-gift-display {
        margin: 16px 0 0 0;
        max-height: 0;
        overflow: hidden;
        opacity: 0;
        transition: max-height 0.35s ease, opacity 0.35s ease;
    }
    #gp-gift-display.gp-visible {
        max-height: 200px;
        opacity: 1;
    }
    .gp-gift-card {
        display: flex;
        align-items: center;
        gap: 14px;
        background: #f0ffe0;
        border: 2px solid #66cc00;
        border-radius: 4px;
        padding: 12px 14px;
        direction: rtl;
    }
    .gp-gift-card img {
        width: 68px;
        height: 68px;
        object-fit: contain;
        flex-shrink: 0;
        border-radius: 4px;
        background: #fff;
    }
    .gp-gift-text { flex: 1; }
    .gp-gift-label {
        font-size: 11px;
        font-weight: 700;
        color: #66cc00;
        margin-bottom: 3px;
        display: block;
    }
    .gp-gift-name {
        font-size: 15px;
        font-weight: 700;
        color: #1a1a1a;
        line-height: 1.3;
        display: block;
    }
    .gp-gift-sub {
        font-size: 12px;
        color: #555;
        margin-top: 3px;
        display: block;
    }
    </style>

    <script>
    (function () {
        var GIFTS = [
            {
                min: 1000,
                name: 'ספר "50 שנים של גרינפיס"',
                sub: 'לתורמים מעל 1,000 ₪ בחודש',
                img: 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/cb1160bf-1000.png'
            },
            {
                min: 168,
                name: 'מגנטים + עט + מחזיק מפתחות',
                sub: 'לתורמים מעל 168 ₪ בחודש',
                img: 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/1797c316-168.png'
            },
            {
                min: 100,
                name: 'בקבוק רב פעמי',
                sub: 'לתורמים מעל 100 ₪ בחודש',
                img: 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/3e7c7410-100.png'
            },
            {
                min: 85,
                name: 'תיק בד',
                sub: 'לתורמים מעל 85 ₪ בחודש',
                img: 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/b4b79777-68.png'
            }
        ];

        function getGift(amount) {
            for (var i = 0; i < GIFTS.length; i++) {
                if (amount >= GIFTS[i].min) return GIFTS[i];
            }
            return null;
        }

        function buildWidget(wrapper) {
            if (wrapper.querySelector('#gp-gift-display')) return;

            var radioField = wrapper.querySelector('.gfield_radio');
            if (!radioField) return;

            var gfield = radioField.closest('.gfield') || radioField.parentNode;

            var widget = document.createElement('div');
            widget.id = 'gp-gift-display';
            widget.innerHTML =
                '<div class="gp-gift-card">' +
                    '<img id="gp-gift-img" src="" alt="" />' +
                    '<div class="gp-gift-text">' +
                        '<span class="gp-gift-label">\uD83C\uDF81 המתנה שלך</span>' +
                        '<span class="gp-gift-name" id="gp-gift-name"></span>' +
                        '<span class="gp-gift-sub" id="gp-gift-sub"></span>' +
                    '</div>' +
                '</div>';

            gfield.parentNode.insertBefore(widget, gfield.nextSibling);

            wrapper.addEventListener('change', function (e) {
                if (e.target && e.target.type === 'radio') showGift(e.target.value);
            });

            var checked = wrapper.querySelector('.gfield_radio input[type="radio"]:checked');
            if (checked) {
                showGift(checked.value);
            } else {
                var allRadios = wrapper.querySelectorAll(
                    '.gfield_radio .gchoice:not(:has(.gchoice_other_control)) input[type="radio"]'
                );
                if (allRadios.length >= 2) showGift(allRadios[1].value);
            }
        }

        function showGift(rawValue) {
            var widget = document.getElementById('gp-gift-display');
            if (!widget) return;
            var amount = parseFloat(rawValue);
            if (isNaN(amount)) { widget.classList.remove('gp-visible'); return; }
            var gift = getGift(amount);
            if (!gift) { widget.classList.remove('gp-visible'); return; }
            document.getElementById('gp-gift-img').src = gift.img;
            document.getElementById('gp-gift-img').alt = gift.name;
            document.getElementById('gp-gift-name').textContent = gift.name;
            document.getElementById('gp-gift-sub').textContent = gift.sub;
            widget.classList.add('gp-visible');
        }

        function init() {
            // חפש wrapper לפי class הנכון או לפי קיום שדה radio
            var wrappers = document.querySelectorAll(
                '.gf-donation-active-wrapper, .gf-donation-active'
            );
            // אם לא נמצא לפי class, חפש כל wrapper עם radio
            if (!wrappers.length) {
                wrappers = document.querySelectorAll('.gform_wrapper');
            }
            wrappers.forEach(function(wrapper) {
                if (wrapper.querySelector('.gfield_radio')) {
                    buildWidget(wrapper);
                }
            });
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else {
            init();
        }
        setTimeout(init, 800);
        if (typeof jQuery !== 'undefined') {
            jQuery(document).on('gform_post_render', init);
        }
    })();
    </script>
    <?php
} );

/**
 * הוסף Custom Field פשוט לעורך העמוד עם checkbox
 */
add_action( 'add_meta_boxes', function () {
    $callback = function ( $post ) {
        $value = get_post_meta( $post->ID, 'gp_show_gifts', true );
        wp_nonce_field( 'gp_show_gifts_nonce', 'gp_gifts_nonce' );
        echo '<label style="font-size:14px;cursor:pointer;">';
        echo '<input type="checkbox" name="gp_show_gifts" value="1" ' . checked( $value, '1', false ) . ' style="margin-left:6px;" />';
        echo 'הצג מתנות לפי סכום תרומה בעמוד זה';
        echo '</label>';
    };
    foreach ( array( 'page', 'p4_action', 'campaign', 'post' ) as $pt ) {
        add_meta_box( 'gp_donation_gifts_box', '🎁 מתנות תרומה', $callback, $pt, 'side', 'default' );
    }
} );

add_action( 'save_post', function ( $post_id ) {
    if ( ! isset( $_POST['gp_gifts_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['gp_gifts_nonce'], 'gp_show_gifts_nonce' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['gp_show_gifts'] ) && $_POST['gp_show_gifts'] === '1' ) {
        update_post_meta( $post_id, 'gp_show_gifts', '1' );
    } else {
        delete_post_meta( $post_id, 'gp_show_gifts' );
    }
} );
