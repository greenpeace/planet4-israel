<?php
/**
 * Plugin Name:       GP Donation Gifts
 * Description:       מציג מתנות לפי סכום תרומה חודשית. מופעל לפי Custom Field "gp_show_gifts" = 1 בעמוד.
 * Version:           0.3.0
 * Requires PHP:      8.0
 * Author:            Greenpeace Israel - Digital Team
 * Text Domain:       gp-donation-gifts
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   DEFAULTS
   ============================================================ */
function gp_gifts_defaults() {
    return [
        'intro_text' => 'גובה תרומה מעל 85 ₪ יזכה אותך במתנה צנועה מאיתנו',
        'gifts' => [
            [
                'min'   => 85,
                'name'  => 'תיק בד',
                'desc'  => 'תיק בד איכותי עם לוגו גרינפיס',
                'img'   => 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/b4b79777-68.png',
            ],
            [
                'min'   => 100,
                'name'  => 'בקבוק רב פעמי',
                'desc'  => 'בקבוק רב פעמי עם לוגו גרינפיס',
                'img'   => 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/3e7c7410-100.png',
            ],
            [
                'min'   => 168,
                'name'  => 'מגנטים + עט + מחזיק מפתחות',
                'desc'  => 'סט מתנה מיוחד מגרינפיס',
                'img'   => 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/1797c316-168.png',
            ],
            [
                'min'   => 1000,
                'name'  => 'ספר "50 שנים של גרינפיס"',
                'desc'  => 'ספר מיוחד לציון 50 שנות פעילות',
                'img'   => 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/cb1160bf-1000.png',
            ],
        ],
    ];
}

function gp_gifts_settings() {
    $saved = get_option( 'gp_donation_gifts_settings', [] );
    $defaults = gp_gifts_defaults();
    return wp_parse_args( $saved, $defaults );
}

/* ============================================================
   SETTINGS PAGE
   ============================================================ */
add_action( 'admin_menu', function () {
    add_options_page(
        'הגדרות מתנות תרומה',
        '🎁 מתנות תרומה',
        'manage_options',
        'gp-donation-gifts',
        'gp_gifts_settings_page'
    );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
    if ( $hook !== 'settings_page_gp-donation-gifts' ) return;
    wp_enqueue_media();
    wp_enqueue_script( 'gp-gifts-admin', false, ['jquery'], null, true );
    add_action( 'admin_footer', 'gp_gifts_admin_js' );
} );

function gp_gifts_admin_js() { ?>
<script>
jQuery(function($){
    $(document).on('click', '.gp-upload-img', function(e){
        e.preventDefault();
        var btn = $(this);
        var frame = wp.media({ title: 'בחר תמונה', button: { text: 'בחר' }, multiple: false });
        frame.on('select', function(){
            var att = frame.state().get('selection').first().toJSON();
            btn.siblings('.gp-img-url').val(att.url);
            btn.siblings('.gp-img-preview').attr('src', att.url).show();
        });
        frame.open();
    });

    $(document).on('click', '.gp-add-gift', function(){
        var tpl = $('#gp-gift-template').html();
        var idx = $('.gp-gift-row').length;
        tpl = tpl.replace(/__IDX__/g, idx);
        $('#gp-gifts-list').append(tpl);
    });

    $(document).on('click', '.gp-remove-gift', function(){
        $(this).closest('.gp-gift-row').remove();
        // re-index
        $('.gp-gift-row').each(function(i){
            $(this).find('input,textarea').each(function(){
                var name = $(this).attr('name');
                if(name) $(this).attr('name', name.replace(/gifts\[\d+\]/, 'gifts['+i+']'));
            });
        });
    });
});
</script>
<?php }

function gp_gifts_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;

    if ( isset( $_POST['gp_gifts_nonce'] ) && wp_verify_nonce( $_POST['gp_gifts_nonce'], 'gp_gifts_save' ) ) {
        $data = [
            'intro_text' => sanitize_textarea_field( $_POST['intro_text'] ?? '' ),
            'gifts'      => [],
        ];
        if ( ! empty( $_POST['gifts'] ) && is_array( $_POST['gifts'] ) ) {
            foreach ( $_POST['gifts'] as $g ) {
                $data['gifts'][] = [
                    'min'  => absint( $g['min'] ?? 0 ),
                    'name' => sanitize_text_field( $g['name'] ?? '' ),
                    'desc' => sanitize_textarea_field( $g['desc'] ?? '' ),
                    'img'  => esc_url_raw( $g['img'] ?? '' ),
                ];
            }
            usort( $data['gifts'], fn($a,$b) => $a['min'] - $b['min'] );
        }
        update_option( 'gp_donation_gifts_settings', $data );
        echo '<div class="updated"><p>ההגדרות נשמרו!</p></div>';
    }

    $s = gp_gifts_settings();
    ?>
    <div class="wrap" dir="rtl">
    <h1>🎁 הגדרות מתנות תרומה</h1>
    <form method="post">
    <?php wp_nonce_field( 'gp_gifts_save', 'gp_gifts_nonce' ); ?>

    <table class="form-table">
        <tr>
            <th><label for="intro_text">טקסט פתיחה</label></th>
            <td>
                <textarea name="intro_text" id="intro_text" rows="3" style="width:100%;max-width:600px"><?php echo esc_textarea( $s['intro_text'] ); ?></textarea>
                <p class="description">מופיע לפני בחירת הסכום, מעל תמונות המתנות.</p>
            </td>
        </tr>
    </table>

    <h2>מתנות לפי סכום</h2>
    <p class="description">המתנה שתוצג היא הגבוהה ביותר שהסכום שנבחר זכאי לה. מיון לפי סכום מינימלי אוטומטי.</p>

    <div id="gp-gifts-list">
    <?php foreach ( $s['gifts'] as $i => $g ) : ?>
        <div class="gp-gift-row" style="background:#fff;border:1px solid #ddd;padding:16px;margin:0 0 12px;border-radius:4px;max-width:700px">
            <div style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap">
                <div style="flex:0 0 80px;text-align:center">
                    <img class="gp-img-preview" src="<?php echo esc_attr($g['img']); ?>" style="width:80px;height:80px;object-fit:contain;border:1px solid #eee;border-radius:4px;<?php echo $g['img'] ? '' : 'display:none'; ?>"><br>
                    <input type="hidden" class="gp-img-url" name="gifts[<?php echo $i; ?>][img]" value="<?php echo esc_attr($g['img']); ?>">
                    <button type="button" class="button gp-upload-img" style="margin-top:6px;font-size:11px">בחר תמונה</button>
                </div>
                <div style="flex:1;min-width:200px">
                    <p style="margin:0 0 8px">
                        <label style="font-weight:600">סכום מינימלי (₪)</label><br>
                        <input type="number" name="gifts[<?php echo $i; ?>][min]" value="<?php echo esc_attr($g['min']); ?>" style="width:100px">
                    </p>
                    <p style="margin:0 0 8px">
                        <label style="font-weight:600">שם המתנה</label><br>
                        <input type="text" name="gifts[<?php echo $i; ?>][name]" value="<?php echo esc_attr($g['name']); ?>" style="width:100%">
                    </p>
                    <p style="margin:0">
                        <label style="font-weight:600">תיאור קצר</label><br>
                        <textarea name="gifts[<?php echo $i; ?>][desc]" rows="2" style="width:100%"><?php echo esc_textarea($g['desc']); ?></textarea>
                    </p>
                </div>
                <div>
                    <button type="button" class="button gp-remove-gift" style="color:#a00">הסר</button>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    </div>

    <button type="button" class="button gp-add-gift">+ הוסף מתנה</button>

    <!-- Template for new gift row -->
    <script type="text/template" id="gp-gift-template">
        <div class="gp-gift-row" style="background:#fff;border:1px solid #ddd;padding:16px;margin:12px 0;border-radius:4px;max-width:700px">
            <div style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap">
                <div style="flex:0 0 80px;text-align:center">
                    <img class="gp-img-preview" src="" style="width:80px;height:80px;object-fit:contain;border:1px solid #eee;border-radius:4px;display:none"><br>
                    <input type="hidden" class="gp-img-url" name="gifts[__IDX__][img]" value="">
                    <button type="button" class="button gp-upload-img" style="margin-top:6px;font-size:11px">בחר תמונה</button>
                </div>
                <div style="flex:1;min-width:200px">
                    <p style="margin:0 0 8px">
                        <label style="font-weight:600">סכום מינימלי (₪)</label><br>
                        <input type="number" name="gifts[__IDX__][min]" value="" style="width:100px">
                    </p>
                    <p style="margin:0 0 8px">
                        <label style="font-weight:600">שם המתנה</label><br>
                        <input type="text" name="gifts[__IDX__][name]" value="" style="width:100%">
                    </p>
                    <p style="margin:0">
                        <label style="font-weight:600">תיאור קצר</label><br>
                        <textarea name="gifts[__IDX__][desc]" rows="2" style="width:100%"></textarea>
                    </p>
                </div>
                <div>
                    <button type="button" class="button gp-remove-gift" style="color:#a00">הסר</button>
                </div>
            </div>
        </div>
    </script>

    <br><br>
    <?php submit_button( 'שמור הגדרות' ); ?>
    </form>
    </div>
    <?php
}

/* ============================================================
   FRONTEND — meta box per page/action
   ============================================================ */
add_action( 'add_meta_boxes', function () {
    $cb = function ( $post ) {
        $value = get_post_meta( $post->ID, 'gp_show_gifts', true );
        wp_nonce_field( 'gp_show_gifts_nonce', 'gp_gifts_nonce' );
        echo '<label style="font-size:14px;cursor:pointer;">';
        echo '<input type="checkbox" name="gp_show_gifts" value="1" ' . checked( $value, '1', false ) . ' style="margin-left:6px;" />';
        echo 'הצג מתנות לפי סכום תרומה בעמוד זה';
        echo '</label>';
    };
    foreach ( [ 'page', 'p4_action', 'campaign', 'post' ] as $pt ) {
        add_meta_box( 'gp_donation_gifts_box', '🎁 מתנות תרומה', $cb, $pt, 'side', 'default' );
    }
} );

add_action( 'save_post', function ( $post_id ) {
    if ( ! isset( $_POST['gp_gifts_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['gp_gifts_nonce'], 'gp_show_gifts_nonce' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    if ( isset( $_POST['gp_show_gifts'] ) && $_POST['gp_show_gifts'] === '1' ) {
        update_post_meta( $post_id, 'gp_show_gifts', '1' );
    } else {
        delete_post_meta( $post_id, 'gp_show_gifts' );
    }
} );

/* ============================================================
   FRONTEND OUTPUT
   ============================================================ */
add_action( 'wp_footer', function () {
    if ( ! is_singular() ) return;
    if ( ! get_post_meta( get_the_ID(), 'gp_show_gifts', true ) ) return;
    if ( ! class_exists( 'GFForms' ) ) return;

    $s     = gp_gifts_settings();
    $gifts = $s['gifts'];
    usort( $gifts, fn($a,$b) => $b['min'] - $a['min'] ); // גבוה לנמוך לJS

    $intro    = esc_html( $s['intro_text'] );
    $gifts_js = wp_json_encode( $gifts );
    // build gallery items for PHP (sorted low→high for display)
    $gallery  = $s['gifts'];
    usort( $gallery, fn($a,$b) => $a['min'] - $b['min'] );
    ?>
    <style>
    /* ── Intro + gallery ── */
    #gp-gifts-intro {
        margin: 0 0 16px;
        padding: 14px 16px;
        background: #f0ffe0;
        border-right: 4px solid #66cc00;
        border-radius: 0 4px 4px 0;
        direction: rtl;
    }
    #gp-gifts-intro p {
        margin: 0 0 14px;
        font-weight: 700;
        font-size: 15px;
        color: #1a1a1a;
        line-height: 1.4;
    }
    .gp-gallery {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        direction: rtl;
    }
    .gp-gallery-item {
        flex: 1;
        min-width: 70px;
        text-align: center;
        padding: 8px 4px;
        border: 2px solid #ddd;
        border-radius: 4px;
        background: #fff;
        cursor: default;
        transition: border-color 0.2s, box-shadow 0.2s;
        box-sizing: border-box;
    }
    .gp-gallery-item.gp-active {
        border-color: #66cc00;
        box-shadow: 0 0 0 2px #66cc0044;
    }
    .gp-gallery-item img {
        width: 52px;
        height: 52px;
        object-fit: contain;
        display: block;
        margin: 0 auto 4px;
    }
    .gp-gallery-item .gp-gmin {
        font-size: 11px;
        font-weight: 700;
        color: #66cc00;
        display: block;
        margin-bottom: 2px;
    }
    .gp-gallery-item .gp-gname {
        font-size: 11px;
        color: #333;
        line-height: 1.3;
        display: block;
    }

    /* ── Selected gift card ── */
    #gp-gift-display { display: none; margin: 12px 0 8px; }
    #gp-gift-display.gp-visible { display: block; }
    .gp-gift-card {
        display: flex;
        align-items: center;
        gap: 12px;
        background: #f0ffe0;
        border: 2px solid #66cc00;
        border-radius: 4px;
        padding: 10px 12px;
        direction: rtl;
        box-sizing: border-box;
        width: 100%;
    }
    .gp-gift-card img {
        width: 56px; height: 56px;
        object-fit: contain; flex-shrink: 0;
        border-radius: 4px; background: #fff;
    }
    .gp-gift-text { flex: 1; min-width: 0; }
    .gp-gift-label { font-size: 10px; font-weight: 700; color: #66cc00; margin-bottom: 2px; display: block; }
    .gp-gift-name  { font-size: 14px; font-weight: 700; color: #1a1a1a; line-height: 1.3; display: block; white-space: normal; }
    .gp-gift-sub   { font-size: 11px; color: #555; margin-top: 2px; display: block; }
    </style>

    <script>
    (function () {
        var GIFTS = <?php echo $gifts_js; ?>; // sorted high→low

        function getGift(amount) {
            for (var i = 0; i < GIFTS.length; i++) {
                if (amount >= GIFTS[i].min) return GIFTS[i];
            }
            return null;
        }

        function buildWidget(wrapper) {
            if (wrapper.querySelector('#gp-gifts-intro')) return;

            var radioField = wrapper.querySelector('.gfield_radio');
            if (!radioField) return;

            /* ── Build intro + gallery ── */
            var intro = document.createElement('div');
            intro.id = 'gp-gifts-intro';
            intro.innerHTML = '<p><?php echo $intro; ?></p><div class="gp-gallery"><?php
                foreach ( $gallery as $g ) {
                    printf(
                        '<div class="gp-gallery-item" data-min="%d"><img src="%s" alt="%s"><span class="gp-gmin">מעל %d ₪</span><span class="gp-gname">%s</span></div>',
                        $g['min'],
                        esc_attr( $g['img'] ),
                        esc_attr( $g['name'] ),
                        $g['min'],
                        esc_html( $g['name'] )
                    );
                }
            ?></div>';

            radioField.parentNode.insertBefore(intro, radioField);

            /* ── Build selected gift card ── */
            var card = document.createElement('div');
            card.id = 'gp-gift-display';
            card.innerHTML =
                '<div class="gp-gift-card">' +
                    '<img id="gp-gift-img" src="" alt="">' +
                    '<div class="gp-gift-text">' +
                        '<span class="gp-gift-label">\uD83C\uDF81 המתנה שלך</span>' +
                        '<span class="gp-gift-name" id="gp-gift-name"></span>' +
                        '<span class="gp-gift-sub" id="gp-gift-sub"></span>' +
                    '</div>' +
                '</div>';
            radioField.parentNode.insertBefore(card, radioField.nextSibling);

            /* ── Listeners ── */
            wrapper.addEventListener('change', function (e) {
                if (e.target && e.target.type === 'radio') showGift(e.target.value);
            });
            wrapper.addEventListener('input', function (e) {
                if (e.target && e.target.classList.contains('gchoice_other_control')) {
                    showGift(e.target.value);
                }
            });

            /* initial */
            var checked = wrapper.querySelector('.gfield_radio input[type="radio"]:checked');
            if (checked) {
                showGift(checked.value);
            } else {
                var radios = wrapper.querySelectorAll('.gfield_radio .gchoice:not(:has(.gchoice_other_control)) input[type="radio"]');
                if (radios.length >= 2) showGift(radios[1].value);
            }
        }

        function showGift(rawValue) {
            var amount = parseFloat(rawValue);
            var card   = document.getElementById('gp-gift-display');
            var items  = document.querySelectorAll('.gp-gallery-item');

            /* Reset gallery highlights */
            items.forEach(function(el){ el.classList.remove('gp-active'); });

            if (!card) return;

            if (isNaN(amount)) { card.classList.remove('gp-visible'); return; }

            var gift = getGift(amount);

            /* Highlight matching gallery item */
            if (gift) {
                items.forEach(function(el){
                    if (parseInt(el.dataset.min) === gift.min) el.classList.add('gp-active');
                });
            }

            if (!gift) { card.classList.remove('gp-visible'); return; }

            document.getElementById('gp-gift-img').src  = gift.img;
            document.getElementById('gp-gift-img').alt  = gift.name;
            document.getElementById('gp-gift-name').textContent = gift.name;
            document.getElementById('gp-gift-sub').textContent  = gift.desc + ' (מעל ' + gift.min + ' ₪ בחודש)';
            card.classList.add('gp-visible');
        }

        function init() {
            var wrappers = document.querySelectorAll('.gf-donation-active-wrapper, .gf-donation-active');
            if (!wrappers.length) wrappers = document.querySelectorAll('.gform_wrapper');
            wrappers.forEach(function(w){ if (w.querySelector('.gfield_radio')) buildWidget(w); });
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else { init(); }
        setTimeout(init, 800);
        if (typeof jQuery !== 'undefined') jQuery(document).on('gform_post_render', init);
    })();
    </script>
    <?php
} );
