<?php
/**
 * Plugin Name:       GP Donation Gifts
 * Description:       מציג מתנות או בעל חיים לפי סכום תרומה חודשית. מצב התצוגה נבחר בכל עמוד בנפרד.
 * Version:           0.5.0
 * Requires PHP:      8.0
 * Author:            Greenpeace Israel - Digital Team
 * Text Domain:       gp-donation-gifts
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   DEFAULTS
   ============================================================ */
function gp_gifts_defaults() {
    return [
        'intro_text' => 'גובה תרומה מעל 85 ₪ יזכה אותך במתנה צנועה מאיתנו',
        'gifts' => [
            [
                'min'   => 85,
                'name'  => 'תיק בד',
                'desc'  => 'תיק בד איכותי עם לוגו גרינפיס',
                'img'   => 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/b4b79777-68.png',
            ],
            [
                'min'   => 100,
                'name'  => 'בקבוק רב פעמי',
                'desc'  => 'בקבוק רב פעמי עם לוגו גרינפיס',
                'img'   => 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/3e7c7410-100.png',
            ],
            [
                'min'   => 168,
                'name'  => 'מגנטים + עט + מחזיק מפתחות',
                'desc'  => 'סט מתנה מיוחד מגרינפיס',
                'img'   => 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/1797c316-168.png',
            ],
            [
                'min'   => 1000,
                'name'  => 'ספר "50 שנים של גרינפיס"',
                'desc'  => 'ספר מיוחד לציון 50 שנות פעילות',
                'img'   => 'https://www.greenpeace.org/static/planet4-israel-stateless/2026/09/cb1160bf-1000.png',
            ],
        ],
        'animals_intro' => 'כל תרומה מצילה בעל חיים אחר. בחרו סכום וגלו מי הוא',
        'animals'       => [],
    ];
}

function gp_gifts_settings() {
    $saved    = get_option( 'gp_donation_gifts_settings', [] );
    $defaults = gp_gifts_defaults();
    return wp_parse_args( $saved, $defaults );
}

/* ============================================================
   SETTINGS PAGE
   ============================================================ */
add_action( 'admin_menu', function () {
    add_options_page(
        'הגדרות מתנות תרומה',
        '🎁 מתנות תרומה',
        'manage_options',
        'gp-donation-gifts',
        'gp_gifts_settings_page'
    );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
    $on_settings = ( $hook === 'settings_page_gp-donation-gifts' );
    $on_editor   = in_array( $hook, [ 'post.php', 'post-new.php' ], true );
    if ( ! $on_settings && ! $on_editor ) return;
    wp_enqueue_media();
    wp_enqueue_script( 'gp-gifts-admin', false, ['jquery'], null, true );
    add_action( 'admin_footer', 'gp_gifts_admin_js' );
} );

function gp_gifts_admin_js() { ?>
<script>
jQuery(function($){
    $(document).on('click', '.gp-upload-img', function(e){
        e.preventDefault();
        var btn = $(this);
        var frame = wp.media({ title: 'בחר תמונה', button: { text: 'בחר' }, multiple: false });
        frame.on('select', function(){
            var att = frame.state().get('selection').first().toJSON();
            btn.siblings('.gp-img-url').val(att.url);
            btn.siblings('.gp-img-preview').attr('src', att.url).show();
        });
        frame.open();
    });

    function reindex(list) {
        list.find('.gp-gift-row').each(function(i){
            $(this).find('input,textarea').each(function(){
                var name = $(this).attr('name');
                if (name) $(this).attr('name', name.replace(/^([a-z_]+)\[\d+\]/, '$1[' + i + ']'));
            });
        });
    }

    $(document).on('click', '.gp-add-row', function(){
        var list = $($(this).data('list'));
        var tpl  = $($(this).data('template')).html();
        tpl = tpl.replace(/__IDX__/g, list.find('.gp-gift-row').length);
        list.append(tpl);
    });

    $(document).on('click', '.gp-remove-gift', function(){
        var list = $(this).closest('.gp-rows');
        $(this).closest('.gp-gift-row').remove();
        reindex(list);
    });
});
</script>
<?php }

/** Render one editable row (gift or animal). $key = "gifts" | "animals". */
function gp_gifts_render_row( $key, $i, $g ) {
    $g = wp_parse_args( $g, [ 'min' => '', 'name' => '', 'desc' => '', 'img' => '' ] );
    $n = $key . '[' . $i . ']';
    ?>
    <div class="gp-gift-row" style="background:#fff;border:1px solid #ddd;padding:16px;margin:0 0 12px;border-radius:4px;max-width:700px">
        <div style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap">
            <div style="flex:0 0 80px;text-align:center">
                <img class="gp-img-preview" src="<?php echo esc_attr( $g['img'] ); ?>" style="width:80px;height:80px;object-fit:contain;border:1px solid #eee;border-radius:4px;<?php echo $g['img'] ? '' : 'display:none'; ?>"><br>
                <input type="hidden" class="gp-img-url" name="<?php echo esc_attr( $n ); ?>[img]" value="<?php echo esc_attr( $g['img'] ); ?>">
                <button type="button" class="button gp-upload-img" style="margin-top:6px;font-size:11px">בחר תמונה</button>
            </div>
            <div style="flex:1;min-width:200px">
                <p style="margin:0 0 8px">
                    <label style="font-weight:600">סכום מינימלי (₪)</label><br>
                    <input type="number" name="<?php echo esc_attr( $n ); ?>[min]" value="<?php echo esc_attr( $g['min'] ); ?>" style="width:100px">
                </p>
                <p style="margin:0 0 8px">
                    <label style="font-weight:600"><?php echo strpos( $key, 'animals' ) !== false ? 'שם בעל החיים' : 'שם המתנה'; ?></label><br>
                    <input type="text" name="<?php echo esc_attr( $n ); ?>[name]" value="<?php echo esc_attr( $g['name'] ); ?>" style="width:100%">
                </p>
                <p style="margin:0">
                    <label style="font-weight:600">תיאור קצר</label><br>
                    <textarea name="<?php echo esc_attr( $n ); ?>[desc]" rows="2" style="width:100%"><?php echo esc_textarea( $g['desc'] ); ?></textarea>
                </p>
            </div>
            <div>
                <button type="button" class="button gp-remove-gift" style="color:#a00">הסר</button>
            </div>
        </div>
    </div>
    <?php
}

/** Sanitize a posted list of rows. */
function gp_gifts_clean_rows( $rows ) {
    $out = [];
    if ( is_array( $rows ) ) {
        foreach ( $rows as $g ) {
            if ( ! is_array( $g ) ) continue;
            $out[] = [
                'min'  => absint( $g['min'] ?? 0 ),
                'name' => sanitize_text_field( wp_unslash( $g['name'] ?? '' ) ),
                'desc' => sanitize_textarea_field( wp_unslash( $g['desc'] ?? '' ) ),
                'img'  => esc_url_raw( wp_unslash( $g['img'] ?? '' ) ),
            ];
        }
        usort( $out, fn( $a, $b ) => $a['min'] - $b['min'] );
    }
    return $out;
}

function gp_gifts_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;

    if ( isset( $_POST['gp_gifts_nonce'] ) && wp_verify_nonce( $_POST['gp_gifts_nonce'], 'gp_gifts_save' ) ) {
        $data = [
            'intro_text'    => sanitize_textarea_field( wp_unslash( $_POST['intro_text'] ?? '' ) ),
            'gifts'         => gp_gifts_clean_rows( $_POST['gifts'] ?? [] ),
            'animals_intro' => sanitize_textarea_field( wp_unslash( $_POST['animals_intro'] ?? '' ) ),
            'animals'       => gp_gifts_clean_rows( $_POST['animals'] ?? [] ),
        ];
        update_option( 'gp_donation_gifts_settings', $data );
        echo '<div class="updated"><p>ההגדרות נשמרו!</p></div>';
    }

    $s = gp_gifts_settings();
    ?>
    <div class="wrap" dir="rtl">
    <h1>🎁 הגדרות מתנות תרומה</h1>
    <p class="description">בכל עמוד בוחרים (בתיבה בצד העריכה) אם להציג <strong>מתנות</strong>, <strong>בעלי חיים</strong> או כלום. אי אפשר את שניהם יחד.</p>
    <form method="post">
    <?php wp_nonce_field( 'gp_gifts_save', 'gp_gifts_nonce' ); ?>

    <h2>🎁 מצב "מתנות"</h2>
    <table class="form-table">
        <tr>
            <th><label for="intro_text">טקסט פתיחה</label></th>
            <td>
                <textarea name="intro_text" id="intro_text" rows="3" style="width:100%;max-width:600px"><?php echo esc_textarea( $s['intro_text'] ); ?></textarea>
                <p class="description">מופיע לפני בחירת הסכום, מעל תמונות המתנות.</p>
            </td>
        </tr>
    </table>
    <p class="description">המתנה שתוצג היא הגבוהה ביותר שהסכום שנבחר זכאי לה. מיון לפי סכום מינימלי אוטומטי.</p>
    <div id="gp-gifts-list" class="gp-rows">
    <?php foreach ( array_values( $s['gifts'] ) as $i => $g ) gp_gifts_render_row( 'gifts', $i, $g ); ?>
    </div>
    <button type="button" class="button gp-add-row" data-list="#gp-gifts-list" data-template="#gp-gift-template">+ הוסף מתנה</button>

    <hr style="margin:32px 0">

    <h2>🐋 מצב "בעל חיים לפי סכום"</h2>
    <table class="form-table">
        <tr>
            <th><label for="animals_intro">טקסט פתיחה</label></th>
            <td>
                <textarea name="animals_intro" id="animals_intro" rows="3" style="width:100%;max-width:600px"><?php echo esc_textarea( $s['animals_intro'] ); ?></textarea>
                <p class="description">מופיע לפני בחירת הסכום, מעל תמונות בעלי החיים.</p>
            </td>
        </tr>
    </table>
    <p class="description">לכל סכום מינימלי בוחרים תמונה של בעל חיים (למשל לוויתן ל-250). יוצג בעל החיים של הסכום הגבוה ביותר שהסכום שנבחר מגיע אליו.</p>
    <div id="gp-animals-list" class="gp-rows">
    <?php foreach ( array_values( $s['animals'] ) as $i => $g ) gp_gifts_render_row( 'animals', $i, $g ); ?>
    </div>
    <button type="button" class="button gp-add-row" data-list="#gp-animals-list" data-template="#gp-animal-template">+ הוסף בעל חיים</button>

    <script type="text/template" id="gp-gift-template"><?php gp_gifts_render_row( 'gifts', '__IDX__', [] ); ?></script>
    <script type="text/template" id="gp-animal-template"><?php gp_gifts_render_row( 'animals', '__IDX__', [] ); ?></script>

    <br><br>
    <?php submit_button( 'שמור הגדרות' ); ?>
    </form>
    </div>
    <?php
}

/* ============================================================
   PER-PAGE MODE (meta box)
   gp_donation_mode: '' (off) | 'gifts' | 'animals'
   Legacy: gp_show_gifts = 1  → treated as 'gifts'
   ============================================================ */
function gp_gifts_get_mode( $post_id ) {
    $mode = get_post_meta( $post_id, 'gp_donation_mode', true );
    if ( $mode === 'gifts' || $mode === 'animals' ) return $mode;
    if ( $mode === 'none' ) return '';
    if ( get_post_meta( $post_id, 'gp_show_gifts', true ) ) return 'gifts';
    return '';
}

add_action( 'add_meta_boxes', function () {
    $cb = function ( $post ) {
        $mode = gp_gifts_get_mode( $post->ID );
        wp_nonce_field( 'gp_show_gifts_nonce', 'gp_gifts_nonce' );
        echo '<p style="margin:0 0 6px"><label for="gp_donation_mode">מה להציג לפי סכום התרומה?</label></p>';
        echo '<select name="gp_donation_mode" id="gp_donation_mode" style="width:100%">';
        printf( '<option value="none"%s>כלום</option>', selected( $mode, '', false ) );
        printf( '<option value="gifts"%s>🎁 מתנות לפי סכום</option>', selected( $mode, 'gifts', false ) );
        printf( '<option value="animals"%s>🐋 בעל חיים לפי סכום</option>', selected( $mode, 'animals', false ) );
        echo '</select>';
        echo '<p class="description" style="margin-top:6px">או מתנות או בעלי חיים, לא שניהם.</p>';
    };
    foreach ( [ 'page', 'p4_action', 'campaign', 'post' ] as $pt ) {
        add_meta_box( 'gp_donation_gifts_box', '🎁 מתנות / בעלי חיים לפי סכום', $cb, $pt, 'side', 'default' );
    }
} );

add_action( 'save_post', function ( $post_id ) {
    if ( ! isset( $_POST['gp_gifts_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['gp_gifts_nonce'], 'gp_show_gifts_nonce' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $mode = sanitize_key( wp_unslash( $_POST['gp_donation_mode'] ?? 'none' ) );
    if ( $mode !== 'gifts' && $mode !== 'animals' ) $mode = 'none';

    update_post_meta( $post_id, 'gp_donation_mode', $mode );
    // keep the legacy flag consistent so old data never overrides the new choice
    if ( $mode === 'gifts' ) {
        update_post_meta( $post_id, 'gp_show_gifts', '1' );
    } else {
        delete_post_meta( $post_id, 'gp_show_gifts' );
    }

    // per-page animals (empty list = use the global list)
    $rows = gp_gifts_clean_rows( $_POST['gp_page_animals'] ?? [] );
    $rows = array_values( array_filter( $rows, fn( $g ) => $g['img'] !== '' ) );
    if ( $rows ) {
        update_post_meta( $post_id, 'gp_page_animals', $rows );
    } else {
        delete_post_meta( $post_id, 'gp_page_animals' );
    }
} );

/* ============================================================
   PER-PAGE ANIMALS (second meta box) — overrides the global list
   ============================================================ */
add_action( 'add_meta_boxes', function () {
    $cb = function ( $post ) {
        $rows = get_post_meta( $post->ID, 'gp_page_animals', true );
        if ( ! is_array( $rows ) ) $rows = [];
        ?>
        <div dir="rtl">
        <p class="description" style="margin-top:0">
            רלוונטי כשבתיבה "מתנות / בעלי חיים לפי סכום" נבחר <strong>בעל חיים לפי סכום</strong>.
            לכל סכום מינימלי בוחרים תמונה (למשל לוויתן ל-250). הכפתורים של הסכומים בטופס יוחלפו בתמונות האלה.
            אם לא מגדירים כאן כלום, העמוד ישתמש ברשימה הכללית (הגדרות ← 🎁 מתנות תרומה).
        </p>
        <div id="gp-page-animals-list" class="gp-rows">
        <?php foreach ( array_values( $rows ) as $i => $g ) gp_gifts_render_row( 'gp_page_animals', $i, $g ); ?>
        </div>
        <button type="button" class="button gp-add-row" data-list="#gp-page-animals-list" data-template="#gp-page-animal-template">+ הוסף בעל חיים</button>
        <script type="text/template" id="gp-page-animal-template"><?php gp_gifts_render_row( 'gp_page_animals', '__IDX__', [] ); ?></script>
        </div>
        <?php
    };
    foreach ( [ 'page', 'p4_action', 'campaign', 'post' ] as $pt ) {
        add_meta_box( 'gp_donation_animals_box', '🐋 בעלי חיים בעמוד זה', $cb, $pt, 'normal', 'default' );
    }
} );

/* ============================================================
   FRONTEND OUTPUT
   ============================================================ */
add_action( 'wp_footer', function () {
    if ( ! is_singular() ) return;
    $mode = gp_gifts_get_mode( get_the_ID() );
    if ( ! $mode ) return;
    if ( ! class_exists( 'GFForms' ) ) return;

    $s = gp_gifts_settings();
    if ( $mode === 'animals' ) {
        $page_items = get_post_meta( get_the_ID(), 'gp_page_animals', true );
        $page_items = ( is_array( $page_items ) && $page_items ) ? $page_items : [];
        $items = $page_items ?: ( is_array( $s['animals'] ) ? $s['animals'] : [] );
        $intro = (string) $s['animals_intro'];
        $label = "\u{1F43E} " . 'בעל החיים שלך';
    } else {
        $items = is_array( $s['gifts'] ) ? $s['gifts'] : [];
        $intro = (string) $s['intro_text'];
        $label = "\u{1F381} " . 'המתנה שלך';
    }
    $items = array_values( array_filter( $items, fn( $g ) => ! empty( $g['img'] ) ) );
    if ( ! $items ) return;

    usort( $items, fn( $a, $b ) => $a['min'] - $b['min'] ); // low → high

    $cfg = [
        'mode'  => $mode,
        'intro' => $intro,
        'label' => $label,
        'items' => $items,
    ];
    $json = wp_json_encode( $cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
    // very specific prefix so it wins over the form style block (which uses !important)
    $P = 'html body .gform_wrapper.gform_wrapper.gform_wrapper .gfield_radio.gp-am.gp-am.gp-am';
    ?>
    <style>
    /* ── Intro + gallery ── */
    #gp-gifts-intro {
        margin: 0 0 16px;
        padding: 14px 16px;
        background: #f0ffe0;
        border-right: 4px solid #66cc00;
        border-radius: 0 4px 4px 0;
        direction: rtl;
    }
    #gp-gifts-intro p { margin: 0; font-weight: 700; font-size: 15px; color: #1a1a1a; line-height: 1.4; }
    #gp-gifts-intro p + .gp-gallery { margin-top: 14px; }
    .gp-gallery { display: flex; gap: 8px; flex-wrap: wrap; direction: rtl; }
    .gp-gallery-item {
        flex: 1; min-width: 70px; text-align: center; padding: 8px 4px;
        border: 2px solid #ddd; border-radius: 4px; background: #fff; cursor: default;
        transition: border-color 0.2s, box-shadow 0.2s; box-sizing: border-box;
    }
    .gp-gallery-item.gp-active { border-color: #66cc00; box-shadow: 0 0 0 2px #66cc0044; }
    .gp-gallery-item img { width: 52px; height: 52px; object-fit: contain; display: block; margin: 0 auto 4px; }
    .gp-gallery-item .gp-gmin  { font-size: 11px; font-weight: 700; color: #66cc00; display: block; margin-bottom: 2px; }
    .gp-gallery-item .gp-gname { font-size: 11px; color: #333; line-height: 1.3; display: block; }

    /* ── Selected card ── */
    #gp-gift-display { display: none; margin: 12px 0 8px; }
    #gp-gift-display.gp-visible { display: block; }
    .gp-gift-card {
        display: flex; align-items: center; gap: 12px;
        background: #f0ffe0; border: 2px solid #66cc00; border-radius: 4px;
        padding: 10px 12px; direction: rtl; box-sizing: border-box; width: 100%;
    }
    .gp-gift-card img { width: 56px; height: 56px; object-fit: contain; flex-shrink: 0; border-radius: 4px; background: #fff; }
    .gp-gift-card.gp-round img { border-radius: 50%; object-fit: cover; }
    .gp-gift-text { flex: 1; min-width: 0; }
    .gp-gift-label { font-size: 10px; font-weight: 700; color: #66cc00; margin-bottom: 2px; display: block; }
    .gp-gift-name  { font-size: 14px; font-weight: 700; color: #1a1a1a; line-height: 1.3; display: block; white-space: normal; }
    .gp-gift-sub   { font-size: 11px; color: #555; margin-top: 2px; display: block; }

    <?php if ( $mode === 'animals' ) : ?>
    /* ── Animals mode: amount buttons become round pictures ── */
    <?php echo $P; ?> .gchoice.gp-ch { flex: 1 1 0 !important; min-width: 0 !important; }
    <?php echo $P; ?> .gchoice.gp-ch label {
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important;
        justify-content: flex-start !important;
        gap: 10px !important;
        background: transparent !important;
        border: 0 !important;
        border-bottom: 4px solid transparent !important;
        box-shadow: none !important;
        color: #1a1a1a !important;
        font-size: 26px !important;
        font-weight: 800 !important;
        line-height: 1 !important;
        padding: 6px 0 8px !important;
        text-align: center !important;
        cursor: pointer !important;
    }
    <?php echo $P; ?> .gp-am-img {
        display: block !important;
        width: 100% !important;
        max-width: 96px !important;
        height: auto !important;
        aspect-ratio: 1 / 1 !important;
        margin: 0 !important;
        border-radius: 50% !important;
        object-fit: cover !important;
        border: 4px solid #e3e3e3 !important;
        background: #fff !important;
        box-sizing: border-box !important;
        transition: border-color .2s, box-shadow .2s !important;
    }
    <?php echo $P; ?> .gchoice.gp-ch.gp-sel label {
        background: transparent !important;
        color: #1a1a1a !important;
        border-bottom-color: #66cc00 !important;
    }
    <?php echo $P; ?> .gchoice.gp-ch.gp-sel .gp-am-img {
        border-color: #66cc00 !important;
        box-shadow: 0 0 0 4px #66cc0044 !important;
    }
    <?php endif; ?>
    </style>

    <script>
    (function () {
        var CFG     = <?php echo $json; ?>;
        var ANIMALS = CFG.mode === 'animals';
        var ITEMS   = CFG.items.slice().sort(function (a, b) { return b.min - a.min; }); // high → low

        function el(tag, cls, text) {
            var e = document.createElement(tag);
            if (cls)  e.className = cls;
            if (text) e.textContent = text;
            return e;
        }

        function getItem(amount) {
            for (var i = 0; i < ITEMS.length; i++) {
                if (amount >= ITEMS[i].min) return ITEMS[i];
            }
            return null;
        }

        function markSelected(wrapper) {
            if (!ANIMALS) return;
            var field = wrapper.querySelector('.gfield_radio');
            if (!field) return;
            var chs = field.querySelectorAll('.gchoice.gp-ch');
            chs.forEach(function (c) { c.classList.remove('gp-sel'); });
            var checked = field.querySelector('input[type="radio"]:checked');
            if (checked) {
                var gc = checked.closest('.gchoice');
                if (gc && gc.classList.contains('gp-ch')) gc.classList.add('gp-sel');
            } else if (chs.length >= 2) {
                chs[1].classList.add('gp-sel'); // middle option is the visual default
            }
        }

        function buildWidget(wrapper) {
            if (wrapper.querySelector('#gp-gifts-intro')) return;
            var radioField = wrapper.querySelector('.gfield_radio');
            if (!radioField) return;

            /* intro (+ gallery in gifts mode) */
            var intro = el('div');
            intro.id = 'gp-gifts-intro';
            if (CFG.intro) intro.appendChild(el('p', '', CFG.intro));
            if (!ANIMALS) {
                var gallery = el('div', 'gp-gallery');
                CFG.items.forEach(function (it) {
                    var item = el('div', 'gp-gallery-item');
                    item.setAttribute('data-min', it.min);
                    var img = el('img');
                    img.src = it.img; img.alt = it.name;
                    item.appendChild(img);
                    item.appendChild(el('span', 'gp-gmin', 'מעל ' + it.min + ' ₪'));
                    item.appendChild(el('span', 'gp-gname', it.name));
                    gallery.appendChild(item);
                });
                intro.appendChild(gallery);
            }
            if (intro.childNodes.length) radioField.parentNode.insertBefore(intro, radioField);
            else { intro.style.display = 'none'; radioField.parentNode.insertBefore(intro, radioField); }

            /* animals: put a round picture in every amount button */
            if (ANIMALS) {
                radioField.classList.add('gp-am');
                radioField.querySelectorAll('.gchoice').forEach(function (gc) {
                    var input = gc.querySelector('input[type="radio"]');
                    if (!input || gc.querySelector('.gchoice_other_control')) return;
                    var amt = parseFloat(input.value);
                    if (isNaN(amt)) return;
                    var label = gc.querySelector('label');
                    if (!label || label.querySelector('.gp-am-img')) return;
                    var it  = getItem(amt) || ITEMS[ITEMS.length - 1];
                    var img = el('img', 'gp-am-img');
                    img.src = it.img; img.alt = it.name;
                    label.insertBefore(img, label.firstChild);
                    gc.classList.add('gp-ch');
                });
            }

            /* selected card */
            var card = el('div');
            card.id = 'gp-gift-display';
            var inner = el('div', 'gp-gift-card' + (ANIMALS ? ' gp-round' : ''));
            var cimg = el('img'); cimg.id = 'gp-gift-img'; cimg.alt = '';
            var text = el('div', 'gp-gift-text');
            text.appendChild(el('span', 'gp-gift-label', CFG.label));
            var nm = el('span', 'gp-gift-name'); nm.id = 'gp-gift-name';
            var sb = el('span', 'gp-gift-sub');  sb.id = 'gp-gift-sub';
            text.appendChild(nm); text.appendChild(sb);
            inner.appendChild(cimg); inner.appendChild(text);
            card.appendChild(inner);
            radioField.parentNode.insertBefore(card, radioField.nextSibling);

            /* listeners */
            wrapper.addEventListener('change', function (e) {
                if (e.target && e.target.type === 'radio') { showItem(e.target.value); markSelected(wrapper); }
            });
            wrapper.addEventListener('input', function (e) {
                if (e.target && e.target.classList.contains('gchoice_other_control')) {
                    showItem(e.target.value); markSelected(wrapper);
                }
            });

            /* initial */
            var checked = wrapper.querySelector('.gfield_radio input[type="radio"]:checked');
            if (checked) {
                showItem(checked.value);
            } else {
                var radios = wrapper.querySelectorAll('.gfield_radio .gchoice:not(:has(.gchoice_other_control)) input[type="radio"]');
                if (radios.length >= 2) showItem(radios[1].value);
            }
            markSelected(wrapper);
        }

        function showItem(rawValue) {
            var amount = parseFloat(rawValue);
            var card   = document.getElementById('gp-gift-display');
            var tiles  = document.querySelectorAll('.gp-gallery-item');
            tiles.forEach(function (t) { t.classList.remove('gp-active'); });
            if (!card) return;
            if (isNaN(amount)) { card.classList.remove('gp-visible'); return; }

            var it = getItem(amount);
            if (!it) { card.classList.remove('gp-visible'); return; }

            tiles.forEach(function (t) {
                if (parseInt(t.getAttribute('data-min'), 10) === it.min) t.classList.add('gp-active');
            });

            var img = document.getElementById('gp-gift-img');
            img.src = it.img; img.alt = it.name;
            document.getElementById('gp-gift-name').textContent = it.name;
            document.getElementById('gp-gift-sub').textContent  =
                (it.desc ? it.desc + ' ' : '') + (ANIMALS ? '' : '(מעל ' + it.min + ' ₪ בחודש)');
            card.classList.add('gp-visible');
        }

        function init() {
            var wrappers = document.querySelectorAll('.gf-donation-active-wrapper, .gf-donation-active');
            if (!wrappers.length) wrappers = document.querySelectorAll('.gform_wrapper');
            wrappers.forEach(function (w) { if (w.querySelector('.gfield_radio')) buildWidget(w); });
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else { init(); }
        setTimeout(init, 800);
        if (typeof jQuery !== 'undefined') jQuery(document).on('gform_post_render', init);
    })();
    </script>
    <?php
} );
