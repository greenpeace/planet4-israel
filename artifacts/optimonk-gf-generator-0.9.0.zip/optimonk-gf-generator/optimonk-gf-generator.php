<?php
/**
 * Plugin Name: OptiMonk GF Code Generator
 * Description: מייצר קוד HTML מותאם להטמעה ב-OptiMonk מתוך טפסי Gravity Forms
 * Version: 1.8
 * Author: Greenpeace Israel
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class OptiMonk_GF_Generator {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
        add_action( 'wp_ajax_omgf_get_form', [ $this, 'ajax_get_form' ] );
        add_action( 'wp_ajax_omgf_get_forms', [ $this, 'ajax_get_forms' ] );
    }

    public function add_menu() {
        add_submenu_page(
            'tools.php',
            'OptiMonk Code Generator',
            'OptiMonk Generator',
            'manage_options',
            'optimonk-gf-generator',
            [ $this, 'render_page' ]
        );
    }

    public function enqueue_scripts( $hook ) {
        if ( $hook !== 'tools_page_optimonk-gf-generator' ) return;
        wp_enqueue_style( 'omgf-style', false );
    }

    // שליפת כל הטפסים מ-GF REST API
    public function ajax_get_forms() {
        check_ajax_referer( 'omgf_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        $response = wp_remote_get( rest_url( 'gf/v2/forms' ), [
            'headers' => [
                'X-WP-Nonce' => wp_create_nonce( 'wp_rest' ),
            ],
            'cookies' => $_COOKIE,
        ]);

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( $response->get_error_message() );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        wp_send_json_success( $body );
    }

    // שליפת טופס ספציפי עם כל השדות וה-confirmations
    public function ajax_get_form() {
        check_ajax_referer( 'omgf_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        $form_id = intval( $_POST['form_id'] );
        if ( ! $form_id ) wp_send_json_error( 'Invalid form ID' );

        // שליפת הטופס
        $response = wp_remote_get( rest_url( "gf/v2/forms/{$form_id}" ), [
            'headers' => [ 'X-WP-Nonce' => wp_create_nonce( 'wp_rest' ) ],
            'cookies' => $_COOKIE,
        ]);

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( $response->get_error_message() );
        }

        $form = json_decode( wp_remote_retrieve_body( $response ), true );

        // שליפת ה-confirmations
        $conf_response = wp_remote_get( rest_url( "gf/v2/forms/{$form_id}/confirmations" ), [
            'headers' => [ 'X-WP-Nonce' => wp_create_nonce( 'wp_rest' ) ],
            'cookies' => $_COOKIE,
        ]);

        $confirmations = [];
        if ( ! is_wp_error( $conf_response ) ) {
            $confirmations = json_decode( wp_remote_retrieve_body( $conf_response ), true );
        }

        wp_send_json_success( [
            'form'          => $form,
            'confirmations' => $confirmations,
        ]);
    }

    public function render_page() {
        $nonce = wp_create_nonce( 'omgf_nonce' );
        $ajax_url = admin_url( 'admin-ajax.php' );
        $site_url = get_site_url();
        ?>
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Assistant:wght@400;600;700&display=swap');
        * { box-sizing: border-box; font-family: 'Assistant', sans-serif; }
        body { background: #f0f0f1; }
        .omgf-wrap { max-width: 900px; margin: 30px auto; padding: 0 20px; direction: rtl; }
        h1 { font-size: 24px; color: #1d2327; margin-bottom: 20px; }
        .omgf-card { background: #fff; border-radius: 8px; padding: 24px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .omgf-card h2 { font-size: 16px; margin: 0 0 16px; color: #1d2327; border-bottom: 1px solid #eee; padding-bottom: 10px; }
        label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; color: #444; }
        select, input[type="text"], input[type="url"] {
            width: 100%; padding: 8px 12px; border: 1px solid #ccc; border-radius: 6px;
            font-size: 14px; margin-bottom: 14px; background: #fff;
        }
        select:focus, input:focus { outline: none; border-color: #2271b1; box-shadow: 0 0 0 2px rgba(34,113,177,0.15); }
        .omgf-btn {
            background: #2271b1; color: #fff; border: none; border-radius: 6px;
            padding: 10px 20px; font-size: 14px; font-weight: 600; cursor: pointer;
        }
        .omgf-btn:hover { background: #135e96; }
        .omgf-btn-yellow {
            background: #f5c800; color: #000; border: none; border-radius: 6px;
            padding: 10px 20px; font-size: 14px; font-weight: 700; cursor: pointer;
        }
        .omgf-btn-yellow:hover { background: #e0b800; }
        .omgf-btn-copy {
            background: #00a32a; color: #fff; border: none; border-radius: 6px;
            padding: 10px 20px; font-size: 14px; font-weight: 600; cursor: pointer;
            margin-top: 12px;
        }
        .omgf-btn-copy:hover { background: #008a20; }
        .omgf-fields-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px; }
        .omgf-field-row { background: #f8f9fa; border-radius: 6px; padding: 10px 14px; border: 1px solid #e0e0e0; }
        .omgf-field-row .field-name { font-weight: 700; font-size: 13px; color: #1d2327; }
        .omgf-field-row .field-meta { font-size: 11px; color: #666; margin-top: 2px; }
        .omgf-field-row .field-input { margin-top: 8px; }
        .omgf-field-row .field-input input { margin-bottom: 0; }
        .omgf-tag { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; margin-right: 4px; }
        .tag-utm { background: #e8f4fd; color: #2271b1; }
        .tag-static { background: #fef3cd; color: #856404; }
        .tag-visible { background: #d1e7dd; color: #0a3622; }
        .tag-radio { background: #f8d7da; color: #842029; }
        .omgf-code { background: #1e1e1e; color: #d4d4d4; border-radius: 8px; padding: 16px; font-size: 12px; font-family: 'Courier New', monospace; overflow-x: auto; white-space: pre; max-height: 400px; overflow-y: auto; direction: ltr; text-align: left; }
        .omgf-loading { text-align: center; padding: 30px; color: #666; }
        .omgf-error { background: #fde8e8; border: 1px solid #f5c6c6; border-radius: 6px; padding: 12px; color: #c0392b; margin-bottom: 16px; }
        .omgf-success-msg { background: #d1e7dd; border-radius: 6px; padding: 10px 14px; color: #0a3622; font-size: 13px; margin-top: 8px; display: none; }
        .omgf-section-title { font-size: 13px; font-weight: 700; color: #555; margin: 16px 0 8px; text-transform: uppercase; letter-spacing: 0.5px; }
        .omgf-redirect-info { background: #f0f6fc; border: 1px solid #c8e1f9; border-radius: 6px; padding: 10px 14px; font-size: 13px; color: #2271b1; margin-bottom: 14px; }
        #omgf-form-details { display: none; }
        </style>
        </head>
        <body class="wp-core-ui">
        <div class="omgf-wrap">
            <h1>🎯 OptiMonk Code Generator</h1>

            <!-- שלב 1: בחירת טופס -->
            <div class="omgf-card">
                <h2>שלב 1 — בחר טופס</h2>
                <label>טופס Gravity Forms</label>
                <select id="omgf-form-select">
                    <option value="">— טוען טפסים —</option>
                </select>
                <button class="omgf-btn" onclick="omgfLoadForm()">טען טופס</button>
            </div>

            <!-- שלב 2: פרטי הטופס -->
            <div id="omgf-form-details">
                <div class="omgf-card">
                    <h2>שלב 2 — הגדר שדות</h2>
                    <div id="omgf-fields-container"></div>
                </div>

                <!-- שלב 3: הגדרות נוספות -->
                <div class="omgf-card">
                    <h2>שלב 3 — הגדרות נוספות</h2>
                    <label>Redirect URL (נשלף מ-GF Confirmation)</label>
                    <div id="omgf-redirect-info" class="omgf-redirect-info">טוען...</div>
                    <input type="url" id="omgf-redirect-url" placeholder="https://www.greenpeace.org/israel/campaign/thankyou/" />
                    <label>טקסט כפתור</label>
                    <input type="text" id="omgf-btn-text" value="אני רוצה לחתום" />
                    <label>טקסט מתחת לכפתור (אופציונלי)</label>
                    <input type="text" id="omgf-btn-note" value="אנחנו נתקשר לוודא אותנטיות" />
                    <br>
                    <button class="omgf-btn-yellow" onclick="omgfGenerateCode()">⚡ צור קוד</button>
                </div>

                <!-- שלב 4: קוד מוכן -->
                <div class="omgf-card" id="omgf-output-card" style="display:none;">
                    <h2>שלב 4 — קוד להטמעה ב-OptiMonk</h2>
                    <p style="font-size:13px;color:#666;margin-bottom:12px;">העתק את הקוד הבא והדבק ב-Custom HTML element בפופאפ של OptiMonk.</p>
                    <div id="omgf-code-output" class="omgf-code"></div>
                    <button class="omgf-btn-copy" onclick="omgfCopyCode()">📋 העתק קוד</button>
                    <div class="omgf-success-msg" id="omgf-copy-msg">✅ הקוד הועתק ללוח!</div>
                </div>
            </div>

            <div id="omgf-error" class="omgf-error" style="display:none;"></div>
        </div>

        <script>
        const AJAX_URL = '<?php echo esc_js( $ajax_url ); ?>';
        const NONCE    = '<?php echo esc_js( $nonce ); ?>';
        const SITE_URL = '<?php echo esc_js( $site_url ); ?>';

        let currentFormData = null;
        let staticFieldValues = {};

        // טעינת רשימת הטפסים
        async function omgfInit() {
            const res = await omgfAjax('omgf_get_forms', {});
            if (!res.success) { omgfShowError('שגיאה בטעינת הטפסים: ' + res.data); return; }
            const forms = Array.isArray(res.data) ? res.data : Object.values(res.data);
            const select = document.getElementById('omgf-form-select');
            select.innerHTML = '<option value="">— בחר טופס —</option>';
            forms.forEach(f => {
                const opt = document.createElement('option');
                opt.value = f.id;
                opt.textContent = `${f.title} (ID: ${f.id})`;
                select.appendChild(opt);
            });
        }

        // טעינת טופס ספציפי
        async function omgfLoadForm() {
            const formId = document.getElementById('omgf-form-select').value;
            if (!formId) { omgfShowError('אנא בחר טופס'); return; }
            omgfHideError();

            const container = document.getElementById('omgf-fields-container');
            container.innerHTML = '<div class="omgf-loading">⏳ טוען שדות...</div>';
            document.getElementById('omgf-form-details').style.display = 'block';
            document.getElementById('omgf-output-card').style.display = 'none';

            const res = await omgfAjax('omgf_get_form', { form_id: formId });
            if (!res.success) { omgfShowError('שגיאה: ' + res.data); return; }

            currentFormData = res.data;
            omgfRenderFields(res.data.form, res.data.confirmations);
        }

        // רינדור השדות
        function omgfRenderFields(form, confirmations) {
            const fields = form.fields || [];
            const container = document.getElementById('omgf-fields-container');
            
            const utmNames = ['utm_source', 'utm_campaign', 'utm_medium', 'utm_term', 'utm_content'];
            
            let visibleFields = [];
            let utmFields = [];
            let staticFields = [];
            let radioFields = [];

            const sortedFields = [...fields].sort((a, b) => (a.orderNumber || a.id) - (b.orderNumber || b.id));
            sortedFields.forEach(f => {
                const adminLabel = (f.adminLabel || f.label || '').toLowerCase().trim();
                const isHidden = f.type === 'hidden' || f.inputType === 'hidden' || f.visibility === 'hidden' || f.cssClass?.includes('gform_hidden');
                const isUTM = utmNames.includes(adminLabel);

                if (isUTM) {
                    utmFields.push(f);
                } else if (f.type === 'html') {
                    // HTML block — מוסתר מה-UI, מתעלמים ממנו
                } else if (isHidden && !isUTM) {
                    staticFields.push(f);
                } else if (f.type === 'radio') {
                    radioFields.push(f);
                    f._choiceLabel = f.choices?.[0]?.text || f.choices?.[0]?.value || f.label;
                } else if (f.type === 'checkbox' || f.type === 'consent') {
                    // Checkbox/Consent — מטפלים כמו radio
                    radioFields.push(f);
                    // consent: label נמצא ב-checkboxLabel, לא ב-choices
                    f._choiceLabel = f.checkboxLabel || f.choices?.[0]?.text || f.label;
                    f._isCheckbox = true;
                } else if (!isHidden) {
                    visibleFields.push(f);
                }
            });

            // Redirect URL מה-confirmations
            let redirectUrl = '';
            if (confirmations) {
                const confs = Array.isArray(confirmations) ? confirmations : Object.values(confirmations);
                const redirectConf = confs.find(c => c.type === 'redirect');
                if (redirectConf) redirectUrl = redirectConf.url || '';
            }
            document.getElementById('omgf-redirect-url').value = redirectUrl;
            document.getElementById('omgf-redirect-info').textContent = redirectUrl
                ? `✅ נמצא Redirect: ${redirectUrl}`
                : '⚠️ לא נמצא Redirect confirmation — הזן URL ידנית';

            let html = '';

            // שדות גלויים
            if (visibleFields.length) {
                html += `<div class="omgf-section-title">שדות גלויים</div><div class="omgf-fields-grid">`;
                visibleFields.forEach(f => {
                    html += `<div class="omgf-field-row">
                        <div class="field-name">${f.label || f.adminLabel}</div>
                        <div class="field-meta">
                            <span class="omgf-tag tag-visible">גלוי</span>
                            input_${f.id} | סוג: ${f.type}
                            ${f.isRequired ? ' | <strong>חובה</strong>' : ''}
                        </div>
                    </div>`;
                });
                html += `</div>`;
            }

            // Radio fields
            if (radioFields.length) {
                html += `<div class="omgf-section-title">שדות Radio</div><div class="omgf-fields-grid">`;
                radioFields.forEach(f => {
                    const choices = (f.choices || []).map(c => c.text || c.value).join(', ');
                    html += `<div class="omgf-field-row">
                        <div class="field-name">${f.label || f.adminLabel}</div>
                        <div class="field-meta">
                            <span class="omgf-tag tag-radio">radio</span>
                            input_${f.id}
                        </div>
                        <div class="field-meta" style="margin-top:4px;">ערכים: ${choices}</div>
                    </div>`;
                });
                html += `</div>`;
            }

            // UTM fields
            if (utmFields.length) {
                html += `<div class="omgf-section-title">שדות UTM (מולאו אוטומטית)</div><div class="omgf-fields-grid">`;
                utmFields.forEach(f => {
                    html += `<div class="omgf-field-row">
                        <div class="field-name">${f.adminLabel || f.label}</div>
                        <div class="field-meta">
                            <span class="omgf-tag tag-utm">UTM</span>
                            input_${f.id}
                        </div>
                    </div>`;
                });
                html += `</div>`;
            }

            // Static fields
            if (staticFields.length) {
                html += `<div class="omgf-section-title">שדות סטטיים — הגדר ערכים</div><div class="omgf-fields-grid">`;
                staticFields.forEach(f => {
                    const existingVal = f.defaultValue || '';
                    html += `<div class="omgf-field-row">
                        <div class="field-name">${f.adminLabel || f.label}</div>
                        <div class="field-meta">
                            <span class="omgf-tag tag-static">סטטי</span>
                            input_${f.id}
                        </div>
                        <div class="field-input">
                            <input type="text" 
                                id="static-field-${f.id}" 
                                value="${existingVal}"
                                placeholder="הזן ערך סטטי..."
                                data-field-id="${f.id}" />
                        </div>
                    </div>`;
                });
                html += `</div>`;
            }

            container.innerHTML = html;
        }

        // יצירת הקוד
        function omgfGenerateCode() {
            if (!currentFormData) { omgfShowError('אנא טען טופס קודם'); return; }

            const form = currentFormData.form;
            const formId = form.id;
            const fields = form.fields || [];
            const redirectUrl = document.getElementById('omgf-redirect-url').value.trim();
            const btnText = document.getElementById('omgf-btn-text').value.trim() || 'שליחה';
            const btnNote = document.getElementById('omgf-btn-note').value.trim();

            const utmNames = ['utm_source', 'utm_campaign', 'utm_medium', 'utm_term', 'utm_content'];

            let visibleFields = [];
            let utmFields = [];
            let staticFields = [];
            let radioField = null;

            // מיין לפי סדר השדות בטופס
            const sortedFields = [...fields].sort((a, b) => (a.orderNumber || a.id) - (b.orderNumber || b.id));

            sortedFields.forEach(f => {
                const adminLabel = (f.adminLabel || f.label || '').toLowerCase().trim();
                const isHidden = f.type === 'hidden' || f.inputType === 'hidden' || f.visibility === 'hidden';
                const isUTM = utmNames.includes(adminLabel);

                if (isUTM) utmFields.push({ ...f, utmParam: adminLabel });
                else if (f.type === 'html') { /* HTML block — skip */ }
                else if (f.type === 'radio') radioField = f;
                else if (f.type === 'checkbox' || f.type === 'consent') { radioField = f; f._isCheckbox = true; }
                else if (isHidden) {
                    const val = document.getElementById(`static-field-${f.id}`)?.value || f.defaultValue || '';
                    staticFields.push({ ...f, staticValue: val });
                } else {
                    visibleFields.push(f);
                }
            });

            // בנה את ה-input fields ב-HTML
            // שורה 1: 3 שדות ראשונים, שורה 2: השאר + radio + כפתור
            const row1Fields = visibleFields.slice(0, 3);
            const row2Fields = visibleFields.slice(3);

            const makeFieldHtml = f => {
                const type = f.type === 'email' ? 'email' : f.type === 'phone' ? 'tel' : 'text';
                const placeholder = f.placeholder || '';
                return `    <div class="om-field">
      <label>${f.label}<span>(חובה)</span></label>
      <input type="${type}" id="om-input-${f.id}"${placeholder ? ` placeholder="${placeholder}"` : ''} />
    </div>`;
            };

            const inputsRow1Html = row1Fields.map(makeFieldHtml).join('\n');
            const inputsRow2Html = row2Fields.map(makeFieldHtml).join('\n');

            // Radio/Checkbox — use first choice text as label, not admin label
            // consent: label נמצא ב-checkboxLabel
            const radioChoiceLabel = radioField ? (radioField.checkboxLabel || radioField.choices?.[0]?.text || radioField.choices?.[0]?.value || radioField.label) : '';
            // Checkbox: GF uses input_X.1 naming, radio uses input_X
            const radioInputId = radioField ? (radioField._isCheckbox ? `${radioField.id}_1` : radioField.id) : '';
            const radioInputName = radioField ? (radioField._isCheckbox ? `input_${radioField.id}.1` : `input_${radioField.id}`) : '';
            const radioValue = radioField ? (radioField._isCheckbox ? (radioField.choices?.[0]?.value || '1') : (radioField.choices?.[0]?.value || 'yes')) : '';
            const radioHtml = radioField ? `    <div class="om-field" style="justify-content:flex-end;padding-bottom:2px;">
      <div class="om-checkbox-row" style="margin-bottom:0;">
        <input type="checkbox" id="om-input-${radioField.id}" value="yes" />
        <label for="om-input-${radioField.id}">${radioChoiceLabel}</label>
      </div>
    </div>` : '';

            // בנה את שורות ה-JS לשדות
            const jsVisibleFields = visibleFields.map(f =>
                `  form.querySelector('[name="input_${f.id}"]').value = document.getElementById('om-input-${f.id}').value.trim();`
            ).join('\n');

            const jsUtmFields = utmFields.map(f =>
                `  form.querySelector('[name="input_${f.id}"]').value = window.omGetUtm('${f.utmParam}');`
            ).join('\n');

            const jsStaticFields = staticFields.map(f =>
                `  form.querySelector('[name="input_${f.id}"]').value = '${f.staticValue}';`
            ).join('\n');

            // בנה את ה-selector בזמן יצירת הקוד (לא ב-runtime)
            const radioSelector = radioField 
              ? (radioField._isCheckbox 
                  ? `input[name="input_${radioField.id}.1"]`
                  : `input[name="input_${radioField.id}"][value="${radioField.choices?.[0]?.value || 'yes'}"]`)
              : '';
            const jsRadio = radioField ? `
  var radioBtn = form.querySelector('${radioSelector}');
  if (radioBtn) radioBtn.checked = true;` : '';

            const jsValidation = visibleFields.map(f =>
                `document.getElementById('om-input-${f.id}').value.trim()`
            ).join(' || \n      !');

            const jsRadioValidation = radioField ? `
  if (!document.getElementById('om-input-${radioField.id}').checked) {
    errorEl.innerText = 'יש לאשר את תנאי הטופס';
    errorEl.style.display = 'block';
    return;
  }` : '';

            const code = `<style>
@import url('https://fonts.googleapis.com/css2?family=Assistant:wght@400;600;700&display=swap');
#om-gf-form, #om-gf-form * { box-sizing: border-box; font-family: 'Assistant', sans-serif; }
#om-gf-form { direction: rtl; padding: 8px; }
.om-row { display: flex; gap: 6px; margin-bottom: 8px; }
.om-field { display: flex; flex-direction: column; flex: 1; min-width: 0; }
.om-field label { font-size: 12px; margin-bottom: 2px; color: #222; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.om-field label span { color: #e8441c; font-size: 10px; margin-right: 2px; }
.om-field input[type="text"],
.om-field input[type="email"],
.om-field input[type="tel"] {
  border: 1.5px solid #ccc; border-radius: 6px; padding: 6px 6px;
  font-size: 12px; outline: none; background: #fff; width: 100%;
}
.om-field input:focus { border-color: #888; }
.om-checkbox-row { display: flex; align-items: center; gap: 4px; direction: rtl; }
.om-checkbox-row input[type="checkbox"] { width: 14px; height: 14px; accent-color: #f5c800; flex-shrink: 0; }
.om-checkbox-row label { font-size: 12px; cursor: pointer; white-space: nowrap; }
#om-submit-btn {
  background: #f5c800; color: #000; border: none; border-radius: 6px;
  padding: 8px 10px; font-size: 13px; font-weight: 700; cursor: pointer;
  display: block; margin-bottom: 3px; text-align: center; width: 100%;
  white-space: nowrap;
}
#om-submit-btn:hover { background: #e0b800; }
.om-note { font-size: 10px; color: #666; margin: 0; text-align: center; white-space: nowrap; }
#om-error { color: #e8441c; font-size: 11px; margin-top: 4px; }
</style>

<div id="om-gf-form">
  <div class="om-row">
${inputsRow1Html}
  </div>
  <div class="om-row" style="align-items:flex-end;">
${inputsRow2Html}
${radioHtml}
    <div class="om-field" style="justify-content:flex-end;">
      <p id="om-submit-btn" onclick="window.omSubmitGF_${formId}()" style="margin:0 0 4px 0;">${btnText}</p>
      ${btnNote ? `<p class="om-note">${btnNote}</p>` : ''}
    </div>
  </div>
  <p id="om-error" style="display:none;"></p>
</div>
<p id="om-success" style="color:green;display:none;font-family:Assistant,sans-serif;">תודה! פרטייך נשמרו.</p>

<script>
var OM_REDIRECT_URL_${formId} = '${redirectUrl}';

window.omGetUtm = window.omGetUtm || function(param) {
  try {
    var pageUrl = (typeof OptiMonk !== 'undefined' && OptiMonk.Vars && OptiMonk.Vars.parentUrl)
      ? OptiMonk.Vars.parentUrl : window.location.href;
    return new URLSearchParams(new URL(pageUrl).search).get(param) || '';
  } catch(e) { return ''; }
};

window.omFindEl = window.omFindEl || function(id) {
  var el = document.getElementById(id);
  if (el) return el;
  try { el = window.top.document.getElementById(id); if (el) return el; } catch(e) {}
  try {
    var iframes = window.top.document.querySelectorAll('iframe');
    for (var i = 0; i < iframes.length; i++) {
      try { el = iframes[i].contentDocument.getElementById(id); if (el) return el; } catch(e) {}
    }
  } catch(e) {}
  return null;
};

window.omSubmitGF_${formId} = function() {
  var errorEl = document.getElementById('om-error');
  var btnEl   = document.getElementById('om-submit-btn');

  errorEl.style.display = 'none';

  if (!${jsValidation}) {
    errorEl.innerText = 'אנא מלא את כל השדות החובה';
    errorEl.style.display = 'block';
    return;
  }${jsRadioValidation}

  var form = window.top._gfForm${formId}
    || (function(){ try { return window.top.document.querySelector('#gform_${formId}'); } catch(e){ return null; } })()
    || document.querySelector('#gform_${formId}');

  if (!form) {
    errorEl.innerText = 'שגיאת אתחול, נסה לרענן את הדף';
    errorEl.style.display = 'block';
    return;
  }

  var observerTarget = null;
  try { observerTarget = window.top.document.body; } catch(e) {}
  if (!observerTarget) observerTarget = document.body;

  btnEl.style.opacity = '0.6';
  btnEl.style.pointerEvents = 'none';
  btnEl.innerText = 'שולח...';

${jsVisibleFields}
${jsUtmFields}
${jsStaticFields}${jsRadio}

  var observer = new MutationObserver(function() {
    try {
      var confirmEl = window.top.document.querySelector('[id^="gform_confirmation_wrapper"]')
                   || window.top.document.querySelector('[id^="gform_confirmation_message"]');
      if (confirmEl) {
        observer.disconnect();
        var src = window.omGetUtm('utm_source'), med = window.omGetUtm('utm_medium'), camp = window.omGetUtm('utm_campaign');
        var utm = (src || med || camp) ? '?utm_source=' + encodeURIComponent(src) + '&utm_medium=' + encodeURIComponent(med) + '&utm_campaign=' + encodeURIComponent(camp) : '';
        window.top.location.href = OM_REDIRECT_URL_${formId} + utm;
        return;
      }
      var validationError = window.top.document.querySelector('.gform_validation_error');
      if (validationError) {
        observer.disconnect();
        var omErr = window.omFindEl('om-error');
        var omBtn = window.omFindEl('om-submit-btn');
        if (omErr) { omErr.innerText = 'אירעה שגיאה, נסה שוב'; omErr.style.display = 'block'; }
        if (omBtn) { omBtn.style.opacity = '1'; omBtn.style.pointerEvents = 'auto'; omBtn.innerText = '${btnText}'; }
      }
    } catch(e) {}
  });

  observer.observe(observerTarget, { childList: true, subtree: true });

  setTimeout(function() {
    observer.disconnect();
    var omErr = window.omFindEl('om-error');
    var omBtn = window.omFindEl('om-submit-btn');
    if (omErr) { omErr.innerText = 'תם הזמן, נסה שוב'; omErr.style.display = 'block'; }
    if (omBtn) { omBtn.style.opacity = '1'; omBtn.style.pointerEvents = 'auto'; omBtn.innerText = '${btnText}'; }
  }, 10000);

  var submitBtn = form.querySelector('input[type="submit"], button[type="submit"]');
  if (submitBtn) submitBtn.click(); else form.submit();
};
<\/script>

<!-- הוסף גם את זה לדף WordPress (HTML block נפרד, מחוץ לפופאפ): -->
<!-- <div style="position:absolute;left:-9999px;top:-9999px;width:1px;height:1px;overflow:hidden;visibility:hidden;">[gravityforms id="${formId}"]</div> -->
<!-- <script>document.addEventListener('DOMContentLoaded',function(){window._gfForm${formId}=document.querySelector('#gform_${formId}');});<\/script> -->`;

            document.getElementById('omgf-code-output').textContent = code;
            document.getElementById('omgf-output-card').style.display = 'block';
            document.getElementById('omgf-output-card').scrollIntoView({ behavior: 'smooth' });
        }

        async function omgfCopyCode() {
            const code = document.getElementById('omgf-code-output').textContent;
            await navigator.clipboard.writeText(code);
            const msg = document.getElementById('omgf-copy-msg');
            msg.style.display = 'block';
            setTimeout(() => msg.style.display = 'none', 3000);
        }

        async function omgfAjax(action, data) {
            const formData = new FormData();
            formData.append('action', action);
            formData.append('nonce', NONCE);
            Object.keys(data).forEach(k => formData.append(k, data[k]));
            const res = await fetch(AJAX_URL, { method: 'POST', body: formData, credentials: 'same-origin' });
            return res.json();
        }

        function omgfShowError(msg) {
            const el = document.getElementById('omgf-error');
            el.textContent = msg;
            el.style.display = 'block';
        }

        function omgfHideError() {
            document.getElementById('omgf-error').style.display = 'none';
        }

        omgfInit();
        </script>
        </body>
        </html>
        <?php
    }
}

new OptiMonk_GF_Generator();
