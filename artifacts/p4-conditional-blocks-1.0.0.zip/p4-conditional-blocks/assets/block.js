/* global wp */
(function () {
	'use strict';

	var el              = wp.element.createElement;
	var Fragment        = wp.element.Fragment;
	var registerBlock   = wp.blocks.registerBlockType;
	var InnerBlocks     = wp.blockEditor.InnerBlocks;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var useBlockProps   = wp.blockEditor.useBlockProps;
	var PanelBody       = wp.components.PanelBody;
	var TextControl     = wp.components.TextControl;
	var SelectControl   = wp.components.SelectControl;

	var OPERATORS = [
		{ label: 'Equals (=)',       value: 'equals'    },
		{ label: 'Contains (∋)',     value: 'contains'  },
		{ label: 'Not equals (≠)',   value: 'not_equals'},
		{ label: 'Not empty',        value: 'not_empty' },
	];

	function operatorSymbol( op ) {
		var found = OPERATORS.find( function ( o ) { return o.value === op; } );
		return found ? found.label : op;
	}

	registerBlock( 'p4-conditional-blocks/conditional-block', {
		title:       'Conditional Block',
		description: 'Show or hide inner blocks based on a post meta value.',
		category:    'layout',
		icon:        'visibility',

		edit: function ( props ) {
			var attrs = props.attributes;
			var set   = props.setAttributes;

			var blockProps = useBlockProps( { className: 'p4cb-editor-wrapper' } );

			var badge = el(
				'div',
				{ className: 'p4cb-badge' },
				el( 'span', { className: 'p4cb-badge__icon' }, '👁' ),
				' Show when ',
				el( 'code', null, attrs.conditionKey || '(key)' ),
				' ',
				el( 'em', null, operatorSymbol( attrs.conditionOperator ) ),
				' ',
				attrs.conditionOperator !== 'not_empty'
					? el( 'code', null, '"' + ( attrs.conditionValue || '' ) + '"' )
					: null
			);

			return el(
				Fragment,
				null,
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: 'Visibility Condition', initialOpen: true },
						el( TextControl, {
							label:   'Meta Key',
							value:   attrs.conditionKey,
							onChange: function ( v ) { set( { conditionKey: v } ); },
							help:    'Post meta field name (e.g. p4_israel_donation_type)',
						} ),
						el( SelectControl, {
							label:   'Operator',
							value:   attrs.conditionOperator,
							options:  OPERATORS,
							onChange: function ( v ) { set( { conditionOperator: v } ); },
						} ),
						attrs.conditionOperator !== 'not_empty' && el( TextControl, {
							label:   'Value',
							value:   attrs.conditionValue,
							onChange: function ( v ) { set( { conditionValue: v } ); },
							help:    'Value to compare the meta field against',
						} )
					)
				),
				el(
					'div',
					blockProps,
					badge,
					el( 'div', { className: 'p4cb-inner' },
						el( InnerBlocks, null )
					)
				)
			);
		},

		save: function () {
			return el( InnerBlocks.Content, null );
		},
	} );
})();
