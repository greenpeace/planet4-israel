<?php
/**
 * Plugin Name: P4 Conditional Blocks
 * Description: Show or hide blocks based on post meta parameters
 * Version: 1.0.0
 * Author: Greenpeace Israel
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'init', 'p4cb_register_block' );

function p4cb_register_block() {
	wp_register_script(
		'p4-conditional-blocks-editor',
		plugins_url( 'assets/block.js', __FILE__ ),
		[ 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components' ],
		'1.0.0',
		true
	);

	wp_register_style(
		'p4-conditional-blocks-editor-style',
		plugins_url( 'assets/editor.css', __FILE__ ),
		[],
		'1.0.0'
	);

	register_block_type( 'p4-conditional-blocks/conditional-block', [
		'editor_script' => 'p4-conditional-blocks-editor',
		'editor_style'  => 'p4-conditional-blocks-editor-style',
		'attributes'    => [
			'conditionKey' => [
				'type'    => 'string',
				'default' => 'p4_israel_donation_type',
			],
			'conditionOperator' => [
				'type'    => 'string',
				'default' => 'equals',
			],
			'conditionValue' => [
				'type'    => 'string',
				'default' => 'oneoff',
			],
		],
		'render_callback' => 'p4cb_render',
	] );
}

function p4cb_render( $attributes, $content ) {
	$key      = sanitize_key( $attributes['conditionKey'] ?? '' );
	$operator = $attributes['conditionOperator'] ?? 'equals';
	$value    = $attributes['conditionValue'] ?? '';

	if ( ! $key ) {
		return $content;
	}

	$post_id    = get_the_ID();
	$meta_value = (string) get_post_meta( $post_id, $key, true );

	$show = false;
	switch ( $operator ) {
		case 'equals':
			$show = ( $meta_value === $value );
			break;
		case 'contains':
			$show = ( '' !== $value && false !== strpos( $meta_value, $value ) );
			break;
		case 'not_equals':
			$show = ( $meta_value !== $value );
			break;
		case 'not_empty':
			$show = ( '' !== $meta_value );
			break;
	}

	return $show ? $content : '';
}

// Allow this block on planet4.test (theme whitelist override).
add_filter( 'allowed_block_types_all', 'p4cb_allow_block', 20, 2 );

function p4cb_allow_block( $allowed, $context ) {
	if ( true === $allowed || ! is_array( $allowed ) ) {
		return $allowed;
	}
	$allowed[] = 'p4-conditional-blocks/conditional-block';
	return $allowed;
}
