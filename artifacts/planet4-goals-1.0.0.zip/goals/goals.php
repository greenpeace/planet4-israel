<?php
/**
 * Plugin Name: Goals
 * Description: בלוק Goal להצגת התקדמות לעבר יעד — חתימות על עצומה או סכום שגויס בתרומות (Gravity Forms).
 * Version: 1.0.0
 * Requires at least: 6.3
 * Requires PHP: 8.0
 * Text Domain: goals
 */

defined( 'ABSPATH' ) || exit;

define( 'GOALS_DIR', plugin_dir_path( __FILE__ ) );
define( 'GOALS_URL', plugin_dir_url( __FILE__ ) );
define( 'GOALS_VERSION', '1.0.0' );

require_once GOALS_DIR . 'includes/class-goals-tracker.php';
require_once GOALS_DIR . 'includes/class-goals-rest.php';

add_action(
	'init',
	function () {
		register_block_type( GOALS_DIR . 'build' );
	}
);

Goals_Tracker::init();
Goals_REST::init();
