<?php
/**
 * REST routes used by the block editor: list of Gravity Forms for the
 * Petition Goal form picker, a live preview of the current progress, and a
 * resync action to true up the stored counter from live GF entries.
 */

defined( 'ABSPATH' ) || exit;

class Goals_REST {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route(
			'goals/v1',
			'/forms',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
				'callback'            => array( __CLASS__, 'get_forms' ),
			)
		);

		register_rest_route(
			'goals/v1',
			'/preview',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
				'args'                => array(
					'goalType'       => array(
						'type'    => 'string',
						'default' => 'petition',
					),
					'formId'         => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'goalName'       => array(
						'type'    => 'string',
						'default' => '',
					),
					'target'         => array(
						'type'    => 'number',
						'default' => 0,
					),
					'startingOffset' => array(
						'type'    => 'number',
						'default' => 0,
					),
				),
				'callback'            => array( __CLASS__, 'get_preview' ),
			)
		);

		register_rest_route(
			'goals/v1',
			'/resync',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
				'args'                => array(
					'goalType' => array(
						'type'    => 'string',
						'default' => 'petition',
					),
					'formId'   => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'goalName' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
				'callback'            => array( __CLASS__, 'post_resync' ),
			)
		);
	}

	public static function get_forms() {
		if ( ! Goals_Tracker::is_gf_active() ) {
			return new WP_REST_Response(
				array(
					'active' => false,
					'forms'  => array(),
				),
				200
			);
		}

		$forms = array_map(
			function ( $form ) {
				return array(
					'id'    => (int) $form['id'],
					'title' => $form['title'],
				);
			},
			GFAPI::get_forms()
		);

		return new WP_REST_Response(
			array(
				'active' => true,
				'forms'  => $forms,
			),
			200
		);
	}

	public static function get_preview( WP_REST_Request $request ) {
		$goal_type = 'donation' === $request->get_param( 'goalType' ) ? 'donation' : 'petition';
		$target    = (float) $request->get_param( 'target' );
		$offset    = (float) $request->get_param( 'startingOffset' );

		if ( 'donation' === $goal_type ) {
			$count = Goals_Tracker::get_donation_total( $request->get_param( 'goalName' ), $offset );
		} else {
			$count = Goals_Tracker::get_petition_count( (int) $request->get_param( 'formId' ), $offset );
		}

		$percent = $target > 0 ? min( 100, ( $count / $target ) * 100 ) : 0;

		return new WP_REST_Response(
			array(
				'count'   => $count,
				'target'  => $target,
				'percent' => round( $percent, 1 ),
			),
			200
		);
	}

	public static function post_resync( WP_REST_Request $request ) {
		$goal_type = 'donation' === $request->get_param( 'goalType' ) ? 'donation' : 'petition';

		if ( ! Goals_Tracker::is_gf_active() ) {
			return new WP_REST_Response( array( 'error' => 'gravity_forms_inactive' ), 400 );
		}

		if ( 'donation' === $goal_type ) {
			$count = Goals_Tracker::resync_donation_total( $request->get_param( 'goalName' ) );
		} else {
			$count = Goals_Tracker::resync_petition_count( (int) $request->get_param( 'formId' ) );
		}

		return new WP_REST_Response( array( 'count' => $count ), 200 );
	}
}
