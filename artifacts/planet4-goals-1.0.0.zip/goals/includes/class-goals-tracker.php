<?php
/**
 * Persistent progress tracking for Goal blocks.
 *
 * Gravity Forms entries on this site are purged after a limited time, so
 * counts can't be derived by querying entries at render time — a petition
 * that reached 50,000 signatures last year would read as far lower (or
 * zero) once those entries age out. Instead, every submission bumps a
 * persistent counter stored in wp_options, which only ever grows.
 */

defined( 'ABSPATH' ) || exit;

class Goals_Tracker {

	const PETITION_OPTION = 'goals_petition_counts';
	const DONATION_OPTION = 'goals_donation_totals';

	public static function init() {
		add_action( 'gform_after_submission', array( __CLASS__, 'on_submission' ), 10, 2 );
	}

	public static function is_gf_active() {
		return class_exists( 'GFAPI' );
	}

	public static function donation_form_id() {
		return (int) apply_filters( 'goals_donation_form_id', 60 );
	}

	public static function donation_amount_field_id() {
		return (int) apply_filters( 'goals_donation_amount_field_id', 25 );
	}

	public static function donation_goal_field_id() {
		return (int) apply_filters( 'goals_donation_goal_field_id', 12 );
	}

	/**
	 * Every submission bumps the per-form petition counter (any form can be
	 * used as a Petition Goal). Submissions to the donation form additionally
	 * add their amount to a per-goal-name total (the same form is reused for
	 * multiple campaigns, distinguished by the last_petition field).
	 */
	public static function on_submission( $entry, $form ) {
		$form_id = (int) $form['id'];

		self::bump_petition_count( $form_id );

		if ( $form_id === self::donation_form_id() ) {
			$goal_key = self::normalize_goal_key( rgar( $entry, (string) self::donation_goal_field_id() ) );
			$amount   = (float) rgar( $entry, (string) self::donation_amount_field_id() );

			if ( '' !== $goal_key && $amount > 0 ) {
				self::add_donation_amount( $goal_key, $amount );
			}
		}
	}

	private static function bump_petition_count( $form_id ) {
		$counts              = get_option( self::PETITION_OPTION, array() );
		$counts[ $form_id ]  = (int) ( $counts[ $form_id ] ?? 0 ) + 1;
		update_option( self::PETITION_OPTION, $counts, false );
	}

	private static function add_donation_amount( $goal_key, $amount ) {
		$totals              = get_option( self::DONATION_OPTION, array() );
		$totals[ $goal_key ] = (float) ( $totals[ $goal_key ] ?? 0 ) + $amount;
		update_option( self::DONATION_OPTION, $totals, false );
	}

	public static function normalize_goal_key( $value ) {
		return trim( (string) $value );
	}

	public static function get_petition_count( $form_id, $offset = 0 ) {
		$counts = get_option( self::PETITION_OPTION, array() );
		return (int) ( $counts[ (int) $form_id ] ?? 0 ) + (int) $offset;
	}

	public static function get_donation_total( $goal_key, $offset = 0 ) {
		$totals   = get_option( self::DONATION_OPTION, array() );
		$goal_key = self::normalize_goal_key( $goal_key );
		return (float) ( $totals[ $goal_key ] ?? 0 ) + (float) $offset;
	}

	/**
	 * Re-derives a count from whichever Gravity Forms entries still exist
	 * right now and raises the stored counter to match if the fresh number
	 * is higher. Never lowers it: entries get purged over time, so a fresh
	 * count can only undercount what actually happened. This is for seeding
	 * a baseline (e.g. entries that existed before the block was added) or
	 * truing up after a gap, not a substitute for the live hook.
	 */
	public static function resync_petition_count( $form_id ) {
		if ( ! self::is_gf_active() ) {
			return self::get_petition_count( $form_id );
		}

		$form_id = (int) $form_id;
		$fresh   = (int) GFAPI::count_entries( $form_id, array( 'status' => 'active' ) );

		$counts             = get_option( self::PETITION_OPTION, array() );
		$counts[ $form_id ] = max( (int) ( $counts[ $form_id ] ?? 0 ), $fresh );
		update_option( self::PETITION_OPTION, $counts, false );

		return $counts[ $form_id ];
	}

	public static function resync_donation_total( $goal_key ) {
		$goal_key = self::normalize_goal_key( $goal_key );

		if ( ! self::is_gf_active() || '' === $goal_key ) {
			return self::get_donation_total( $goal_key );
		}

		$form_id         = self::donation_form_id();
		$goal_field_id   = (string) self::donation_goal_field_id();
		$amount_field_id = (string) self::donation_amount_field_id();

		$search = array(
			'status'        => 'active',
			'field_filters' => array(
				array(
					'key'   => $goal_field_id,
					'value' => $goal_key,
				),
			),
		);

		$fresh = 0.0;
		$page  = 0;

		do {
			$entries = (array) GFAPI::get_entries(
				$form_id,
				$search,
				null,
				array(
					'offset'    => $page * 200,
					'page_size' => 200,
				)
			);

			foreach ( $entries as $entry ) {
				$fresh += (float) rgar( $entry, $amount_field_id );
			}

			$page++;
		} while ( count( $entries ) === 200 );

		$totals              = get_option( self::DONATION_OPTION, array() );
		$totals[ $goal_key ] = max( (float) ( $totals[ $goal_key ] ?? 0 ), $fresh );
		update_option( self::DONATION_OPTION, $totals, false );

		return $totals[ $goal_key ];
	}
}
