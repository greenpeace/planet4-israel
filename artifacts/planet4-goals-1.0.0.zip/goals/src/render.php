<?php
/**
 * Server-side render for goals/goal.
 *
 * @var array    $attributes Block attributes.
 * @var string   $content    Unused (dynamic block).
 * @var WP_Block $block      Block instance.
 */

defined( 'ABSPATH' ) || exit;

$goal_type       = isset( $attributes['goalType'] ) && 'donation' === $attributes['goalType'] ? 'donation' : 'petition';
$language        = isset( $attributes['language'] ) && 'en' === $attributes['language'] ? 'en' : 'he';
$target          = isset( $attributes['target'] ) ? (float) $attributes['target'] : 0;
$currency        = isset( $attributes['currency'] ) ? $attributes['currency'] : '₪';
$starting_offset = isset( $attributes['startingOffset'] ) ? (float) $attributes['startingOffset'] : 0;

if ( 'donation' === $goal_type ) {
	$goal_name = isset( $attributes['goalName'] ) ? trim( $attributes['goalName'] ) : '';

	if ( '' === $goal_name ) {
		return;
	}

	$count = Goals_Tracker::get_donation_total( $goal_name, $starting_offset );
} else {
	$form_id = isset( $attributes['formId'] ) ? (int) $attributes['formId'] : 0;

	if ( ! $form_id ) {
		return;
	}

	$count = Goals_Tracker::get_petition_count( $form_id, $starting_offset );
}

if ( $target <= 0 ) {
	return;
}

$percent = min( 100, ( $count / $target ) * 100 );

$type_labels = array(
	'petition' => array(
		'he' => 'חתימות שהושגו',
		'en' => 'SIGNATURES REACHED',
	),
	'donation' => array(
		'he' => 'גויס',
		'en' => 'RAISED',
	),
);

$type_label       = $type_labels[ $goal_type ][ $language ];
$currency_prefix  = 'donation' === $goal_type ? $currency : '';
$count_formatted  = $currency_prefix . number_format( $count, 0 );
$target_formatted = $currency_prefix . number_format( $target, 0 );

$dir = 'he' === $language ? 'rtl' : 'ltr';

$wrapper_attributes = get_block_wrapper_attributes(
	array(
		'dir'  => $dir,
		'lang' => $language,
	)
);
?>
<div <?php echo $wrapper_attributes; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
	<div class="goals-goal__row">
		<span class="goals-goal__count"><?php echo esc_html( $count_formatted ); ?></span>
		<span class="goals-goal__label"><?php echo esc_html( $type_label . ' / ' . $target_formatted ); ?></span>
	</div>
	<div class="goals-goal__bar">
		<div class="goals-goal__bar-fill" style="width: <?php echo esc_attr( round( $percent, 1 ) ); ?>%;"></div>
	</div>
</div>
