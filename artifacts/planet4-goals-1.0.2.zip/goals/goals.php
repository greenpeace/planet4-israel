<?php
/**
 * Plugin Name: Goals
 * Description: בלוק Goal להצגת התקדמות לעבר יעד — חתימות על עצומה או סכום שגויס בתרומות (Gravity Forms).
 * Version: 1.0.2
 * Requires at least: 6.3
 * Requires PHP: 8.0
 * Text Domain: goals
 */

defined( 'ABSPATH' ) || exit;

define( 'GOALS_DIR', plugin_dir_path( __FILE__ ) );
define( 'GOALS_URL', plugin_dir_url( __FILE__ ) );
define( 'GOALS_VERSION', '1.0.2' );

require_once GOALS_DIR . 'includes/class-goals-tracker.php';
require_once GOALS_DIR . 'includes/class-goals-rest.php';

add_action(
	'init',
	function () {
		register_block_type( GOALS_DIR . 'build' );
	}
);

// Run after the Planet4 theme's allowed_block_types_all filter (priority 10) so we can append our block.
add_filter( 'allowed_block_types_all', 'goals_allow_block', 20 );
function goals_allow_block( $allowed ) {
	if ( ! is_array( $allowed ) ) {
		return $allowed; // true = all blocks already allowed
	}
	return array_merge( $allowed, [ 'goals/goal' ] );
}

Goals_Tracker::init();
Goals_REST::init();
