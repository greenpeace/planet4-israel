import { __ } from '@wordpress/i18n';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import {
	PanelBody,
	SelectControl,
	TextControl,
	Placeholder,
	Notice,
	Spinner,
	Button,
} from '@wordpress/components';
import { useEffect, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { addQueryArgs } from '@wordpress/url';

const TYPE_LABELS = {
	petition: { he: 'חתימות שהושגו', en: 'SIGNATURES REACHED' },
	donation: { he: 'גויס', en: 'RAISED' },
};

function formatNumber( value ) {
	return Number( value || 0 ).toLocaleString( 'en-US', {
		maximumFractionDigits: 0,
	} );
}

export default function Edit( { attributes, setAttributes } ) {
	const {
		goalType,
		formId,
		goalName,
		target,
		currency,
		startingOffset,
		language,
	} = attributes;

	const [ forms, setForms ] = useState( [] );
	const [ gfActive, setGfActive ] = useState( true );
	const [ loadingForms, setLoadingForms ] = useState( true );
	const [ preview, setPreview ] = useState( null );
	const [ loadingPreview, setLoadingPreview ] = useState( false );
	const [ resyncing, setResyncing ] = useState( false );
	const [ resyncNotice, setResyncNotice ] = useState( '' );

	useEffect( () => {
		apiFetch( { path: '/goals/v1/forms' } )
			.then( ( res ) => {
				setGfActive( res.active );
				setForms( res.forms || [] );
			} )
			.catch( () => setGfActive( false ) )
			.finally( () => setLoadingForms( false ) );
	}, [] );

	const isConfigured =
		'donation' === goalType ? !! goalName.trim() : !! formId;

	useEffect( () => {
		if ( ! isConfigured ) {
			setPreview( null );
			return;
		}

		setLoadingPreview( true );

		apiFetch( {
			path: addQueryArgs( '/goals/v1/preview', {
				goalType,
				formId,
				goalName,
				target,
				startingOffset,
			} ),
		} )
			.then( ( res ) => setPreview( res ) )
			.catch( () => setPreview( null ) )
			.finally( () => setLoadingPreview( false ) );
	}, [ goalType, formId, goalName, target, startingOffset, isConfigured ] );

	const handleResync = () => {
		setResyncing( true );
		setResyncNotice( '' );

		apiFetch( {
			path: '/goals/v1/resync',
			method: 'POST',
			data: { goalType, formId, goalName },
		} )
			.then( ( res ) => {
				setResyncNotice(
					__( 'הערך המעודכן: ', 'goals' ) + formatNumber( res.count )
				);
				setPreview( ( prev ) =>
					prev
						? {
								...prev,
								count: res.count,
								percent:
									target > 0
										? Math.min(
												100,
												( res.count / target ) * 100
										  )
										: 0,
						  }
						: prev
				);
			} )
			.catch( () =>
				setResyncNotice( __( 'הסנכרון נכשל.', 'goals' ) )
			)
			.finally( () => setResyncing( false ) );
	};

	const dir = 'he' === language ? 'rtl' : 'ltr';
	const blockProps = useBlockProps( { dir } );
	const typeLabel = TYPE_LABELS[ goalType ][ language ];
	const currencyPrefix = 'donation' === goalType ? currency : '';

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'הגדרות יעד', 'goals' ) }>
					<SelectControl
						label={ __( 'סוג היעד', 'goals' ) }
						value={ goalType }
						options={ [
							{ value: 'petition', label: __( 'עצומה', 'goals' ) },
							{ value: 'donation', label: __( 'תרומה', 'goals' ) },
						] }
						onChange={ ( value ) =>
							setAttributes( { goalType: value } )
						}
					/>

					{ 'petition' === goalType && (
						<>
							{ ! loadingForms && ! gfActive && (
								<Notice status="error" isDismissible={ false }>
									{ __(
										'Gravity Forms אינו פעיל באתר זה.',
										'goals'
									) }
								</Notice>
							) }
							<SelectControl
								label={ __( 'טופס העצומה', 'goals' ) }
								value={ formId }
								options={ [
									{
										label: __(
											'— בחר/י טופס —',
											'goals'
										),
										value: 0,
									},
									...forms.map( ( form ) => ( {
										label: form.title,
										value: form.id,
									} ) ),
								] }
								onChange={ ( value ) =>
									setAttributes( { formId: Number( value ) } )
								}
								disabled={ loadingForms }
							/>
						</>
					) }

					{ 'donation' === goalType && (
						<>
							<Notice status="info" isDismissible={ false }>
								{ __(
									'תמיד טופס "תרומה (בפיתוח)", מזהה 60.',
									'goals'
								) }
							</Notice>
							<TextControl
								label={ __(
									'מטרה (ערך שדה last_petition בטופס)',
									'goals'
								) }
								help={ __(
									'חייב להתאים בדיוק לערך שנשלח בשדה last_petition עבור התרומות שאמורות להיספר ליעד הזה.',
									'goals'
								) }
								value={ goalName }
								onChange={ ( value ) =>
									setAttributes( { goalName: value } )
								}
							/>
							<TextControl
								label={ __( 'מטבע', 'goals' ) }
								value={ currency }
								onChange={ ( value ) =>
									setAttributes( { currency: value } )
								}
							/>
						</>
					) }

					<TextControl
						type="number"
						label={
							'donation' === goalType
								? __( 'יעד גיוס', 'goals' )
								: __( 'יעד חתימות', 'goals' )
						}
						value={ target }
						onChange={ ( value ) =>
							setAttributes( { target: Number( value ) || 0 } )
						}
					/>

					<TextControl
						type="number"
						label={ __(
							'כמות התחלתית (לפני תחילת המעקב)',
							'goals'
						) }
						help={ __(
							'לשימוש עבור חתימות/תרומות שנאספו לפני הוספת הבלוק, או שכבר נמחקו מגרביטי פורמס.',
							'goals'
						) }
						value={ startingOffset }
						onChange={ ( value ) =>
							setAttributes( {
								startingOffset: Number( value ) || 0,
							} )
						}
					/>

					{ gfActive && isConfigured && (
						<Button
							variant="secondary"
							isBusy={ resyncing }
							disabled={ resyncing }
							onClick={ handleResync }
						>
							{ __(
								'סנכרון מחדש מהנתונים הקיימים בטופס',
								'goals'
							) }
						</Button>
					) }
					{ resyncNotice && (
						<Notice status="info" isDismissible={ false }>
							{ resyncNotice }
						</Notice>
					) }
				</PanelBody>

				<PanelBody title={ __( 'שפה', 'goals' ) }>
					<SelectControl
						label={ __( 'שפת הבלוק', 'goals' ) }
						value={ language }
						options={ [
							{ value: 'he', label: __( 'עברית', 'goals' ) },
							{ value: 'en', label: __( 'English', 'goals' ) },
						] }
						onChange={ ( value ) =>
							setAttributes( { language: value } )
						}
					/>
				</PanelBody>
			</InspectorControls>

			<div { ...blockProps }>
				{ ! isConfigured && (
					<Placeholder
						icon="chart-bar"
						label={ __( 'Goal', 'goals' ) }
						instructions={
							'donation' === goalType
								? __(
										'הזן/י מטרה (ערך שדה last_petition) בהגדרות הבלוק.',
										'goals'
								  )
								: __(
										'בחר/י טופס עצומה בהגדרות הבלוק.',
										'goals'
								  )
						}
					/>
				) }
				{ isConfigured && loadingPreview && <Spinner /> }
				{ isConfigured && ! loadingPreview && preview && (
					<>
						<div className="goals-goal__row">
							<span className="goals-goal__count">
								{ currencyPrefix }
								{ formatNumber( preview.count ) }
							</span>
							<span className="goals-goal__label">
								{ typeLabel } / { currencyPrefix }
								{ formatNumber( target ) }
							</span>
						</div>
						<div className="goals-goal__bar">
							<div
								className="goals-goal__bar-fill"
								style={ { width: `${ preview.percent }%` } }
							/>
						</div>
					</>
				) }
			</div>
		</>
	);
}
