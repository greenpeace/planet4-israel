<?php
/**
 * Plugin Name: Greenpeace Publisher Center Connector
 * Description: Solves Google Publisher Center / Google News verification & feed issues for a Planet4 site that lives under a subdirectory (e.g. greenpeace.org/israel) of a domain you do not control the root of. Adds per-path Search Console verification, a Google News XML sitemap scoped to this site only, and NewsArticle structured data on every post.
 * Version: 1.0.0
 * Author: Greenpeace Israel
 * Text Domain: gpc
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GPC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GPC_PLUGIN_FILE', __FILE__ );

require_once GPC_PLUGIN_DIR . 'includes/class-gpc-verification.php';
require_once GPC_PLUGIN_DIR . 'includes/class-gpc-news-sitemap.php';
require_once GPC_PLUGIN_DIR . 'includes/class-gpc-structured-data.php';
require_once GPC_PLUGIN_DIR . 'includes/class-gpc-admin.php';

function gpc_init() {
	GPC_Verification::instance();
	GPC_News_Sitemap::instance();
	GPC_Structured_Data::instance();
	GPC_Admin::instance();
}
add_action( 'plugins_loaded', 'gpc_init' );

register_activation_hook( __FILE__, array( 'GPC_News_Sitemap', 'on_activation' ) );
register_deactivation_hook( __FILE__, array( 'GPC_News_Sitemap', 'on_deactivation' ) );
