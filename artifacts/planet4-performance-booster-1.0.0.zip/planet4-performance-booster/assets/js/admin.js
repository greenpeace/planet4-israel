( function ( $ ) {
	'use strict';

	$( function () {
		var $regenBtn    = $( '#p4pb-regen-webp' );
		var $progressBox = $( '#p4pb-regen-progress' );
		var $bar          = $( '#p4pb-regen-bar' );
		var $status        = $( '#p4pb-regen-status' );

		$regenBtn.on( 'click', function () {
			$regenBtn.prop( 'disabled', true );
			$progressBox.show();
			$status.text( p4pbAdmin.i18n.converting );
			runBatch( 0, 0 );
		} );

		function runBatch( offset, totalConverted ) {
			$.post( p4pbAdmin.ajaxUrl, {
				action: 'p4pb_regenerate_webp_batch',
				nonce: p4pbAdmin.nonce,
				offset: offset
			} ).done( function ( response ) {
				if ( ! response.success ) {
					$status.text( 'שגיאה' );
					$regenBtn.prop( 'disabled', false );
					return;
				}

				var data = response.data;
				totalConverted += data.converted;

				if ( data.done ) {
					$bar.attr( 'value', 100 );
					$status.text( p4pbAdmin.i18n.done + ' (' + totalConverted + ' תמונות הומרו)' );
					$regenBtn.prop( 'disabled', false );
					return;
				}

				// We don't know the total count up front, so just show a
				// rolling "processed so far" indicator instead of a real %.
				$bar.removeAttr( 'value' ); // indeterminate
				$status.text( totalConverted + ' תמונות הומרו עד כה...' );

				runBatch( data.next_offset, totalConverted );
			} ).fail( function () {
				$status.text( 'שגיאת רשת - נסה שוב' );
				$regenBtn.prop( 'disabled', false );
			} );
		}

		$( '#p4pb-insert-htaccess' ).on( 'click', function () {
			var $btn = $( this );
			var $result = $( '#p4pb-htaccess-status' );
			$btn.prop( 'disabled', true );
			$result.text( '...' );

			$.post( p4pbAdmin.ajaxUrl, {
				action: 'p4pb_insert_htaccess_rule',
				nonce: p4pbAdmin.nonce
			} ).done( function ( response ) {
				$result.text( response.success ? p4pbAdmin.i18n.htaccessOk : p4pbAdmin.i18n.htaccessError );
			} ).fail( function () {
				$result.text( p4pbAdmin.i18n.htaccessError );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	} );
} )( jQuery );
