<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class P4PB_Admin_Page {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'maybe_save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function add_menu() {
		add_options_page(
			'Performance Booster',
			'Performance Booster',
			'manage_options',
			'p4-perf-booster',
			array( $this, 'render_page' )
		);
	}

	public function enqueue_assets( $hook ) {
		if ( 'settings_page_p4-perf-booster' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'p4pb-admin', P4PB_PLUGIN_URL . 'assets/css/admin.css', array(), P4PB_VERSION );
		wp_enqueue_script( 'p4pb-admin', P4PB_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), P4PB_VERSION, true );
		wp_localize_script( 'p4pb-admin', 'p4pbAdmin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'p4pb_admin' ),
			'i18n'    => array(
				'converting'    => 'ממיר תמונות...',
				'done'          => 'הושלם!',
				'htaccessOk'    => 'הכלל נוסף בהצלחה ל-.htaccess',
				'htaccessError' => 'לא הצלחתי לכתוב ל-.htaccess - תוכל להוסיף את זה ידנית (ראה למטה)',
			),
		) );
	}

	public function maybe_save() {
		if ( ! isset( $_POST['p4pb_save'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( 'p4pb_save_settings' );

		$posted = wp_unslash( $_POST );

		$services = array();
		foreach ( array_keys( P4PB_Settings::known_services() ) as $key ) {
			$mode = isset( $posted['services'][ $key ] ) ? sanitize_key( $posted['services'][ $key ] ) : 'normal';
			$services[ $key ] = in_array( $mode, array( 'normal', 'delay', 'block' ), true ) ? $mode : 'normal';
		}

		P4PB_Settings::update( array(
			'services'          => $services,
			'gtm_blocked_ids'   => isset( $posted['gtm_blocked_ids'] ) ? sanitize_text_field( $posted['gtm_blocked_ids'] ) : '',
			'delay_timeout'     => isset( $posted['delay_timeout'] ) ? max( 1, (int) $posted['delay_timeout'] ) : 8,
			'lcp_fix_enabled'   => ! empty( $posted['lcp_fix_enabled'] ),
			'webp_enabled'      => ! empty( $posted['webp_enabled'] ),
			'webp_quality'      => isset( $posted['webp_quality'] ) ? min( 100, max( 1, (int) $posted['webp_quality'] ) ) : 82,
			'font_swap_enabled' => ! empty( $posted['font_swap_enabled'] ),
			'font_swap_handles' => isset( $posted['font_swap_handles'] ) ? sanitize_textarea_field( $posted['font_swap_handles'] ) : '',
		) );

		add_settings_error( 'p4pb', 'saved', 'ההגדרות נשמרו.', 'success' );
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$settings = P4PB_Settings::get();
		$services = P4PB_Settings::known_services();
		settings_errors( 'p4pb' );
		?>
		<div class="wrap p4pb-wrap" dir="rtl">
			<h1>Planet4 Performance Booster</h1>
			<p class="description">
				מטפל בממצאי בדיקת הביצועים (PageSpeed Insights, יולי 2026): עומס סקריפטי צד-שלישי, עדיפות טעינת תמונת ה-LCP, משקל תמונות, ו-font-display.
			</p>

			<form method="post">
				<?php wp_nonce_field( 'p4pb_save_settings' ); ?>

				<h2 class="p4pb-section-title">1. סקריפטי צד-שלישי</h2>
				<p class="description">
					<strong>רגיל</strong> = נטען כרגיל, בלי שינוי &nbsp;|&nbsp;
					<strong>דחייה</strong> = נטען רק אחרי אינטראקציה ראשונה של המשתמש (גלילה/קליק/מגע) או אחרי X שניות &nbsp;|&nbsp;
					<strong>חסימה</strong> = לא נטען בכלל
				</p>
				<table class="widefat p4pb-services-table">
					<thead>
						<tr>
							<th>שירות</th>
							<th>רגיל</th>
							<th>דחייה</th>
							<th>חסימה</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $services as $key => $svc ) :
						$current = isset( $settings['services'][ $key ] ) ? $settings['services'][ $key ] : $svc['default'];
						?>
						<tr>
							<td><?php echo esc_html( $svc['label'] ); ?></td>
							<?php foreach ( array( 'normal' => 'רגיל', 'delay' => 'דחייה', 'block' => 'חסימה' ) as $mode => $mode_label ) : ?>
								<td class="p4pb-radio-cell">
									<input type="radio"
										   name="services[<?php echo esc_attr( $key ); ?>]"
										   value="<?php echo esc_attr( $mode ); ?>"
										   <?php checked( $current, $mode ); ?> />
								</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<table class="form-table">
					<tr>
						<th scope="row"><label for="delay_timeout">Timeout לטעינה אוטומטית (שניות)</label></th>
						<td>
							<input type="number" min="1" max="60" id="delay_timeout" name="delay_timeout" value="<?php echo esc_attr( $settings['delay_timeout'] ); ?>" class="small-text" />
							<p class="description">אם אין אינטראקציה מהמשתמש, הסקריפטים ה"דחויים" ייטענו בכל מקרה אחרי כמות השניות הזו - כדי לא לאבד מדידות ממבקרים פסיביים.</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="gtm_blocked_ids">חסימת מזהי GTM ספציפיים (מתקדם)</label></th>
						<td>
							<input type="text" id="gtm_blocked_ids" name="gtm_blocked_ids" value="<?php echo esc_attr( $settings['gtm_blocked_ids'] ); ?>" class="regular-text" placeholder="G-0VYVGB08Q0, G-0CCB1GTVV6" />
							<p class="description">
								רשימה מופרדת בפסיקים של מזהי מדידה/המרה (G-... או AW-...) שרוצים לחסום לגמרי, גם אם GTM עצמו לא חסום. שימושי אם יש כפילויות (כמו כמה סטרימי GA4 באותו אתר).
							</p>
						</td>
					</tr>
				</table>

				<h2 class="p4pb-section-title">2. עדיפות תמונת LCP (הקרוסלה בדף הבית)</h2>
				<table class="form-table">
					<tr>
						<th scope="row">הפעלה</th>
						<td>
							<label>
								<input type="checkbox" name="lcp_fix_enabled" value="1" <?php checked( ! empty( $settings['lcp_fix_enabled'] ) ); ?> />
								הוסף fetchpriority="high" + &lt;link rel=preload&gt; לתמונת הסליידר הפעילה, והסר ממנה loading="lazy" אם קיים
							</label>
						</td>
					</tr>
				</table>

				<h2 class="p4pb-section-title">3. המרת תמונות ל-WebP</h2>
				<table class="form-table">
					<tr>
						<th scope="row">הפעלה</th>
						<td>
							<label>
								<input type="checkbox" name="webp_enabled" value="1" <?php checked( ! empty( $settings['webp_enabled'] ) ); ?> />
								המר אוטומטית כל תמונה חדשה שמועלית (JPG/PNG) לגרסת WebP מקבילה
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="webp_quality">איכות WebP</label></th>
						<td>
							<input type="number" min="1" max="100" id="webp_quality" name="webp_quality" value="<?php echo esc_attr( $settings['webp_quality'] ); ?>" class="small-text" />
							<p class="description">82 הוא איזון טוב בין גודל קובץ לאיכות ויזואלית.</p>
						</td>
					</tr>
				</table>

				<p class="submit">
					<button type="submit" name="p4pb_save" value="1" class="button button-primary">שמור הגדרות</button>
				</p>
			</form>

			<hr />

			<h2 class="p4pb-section-title">כלים נוספים</h2>

			<div class="p4pb-tool-box">
				<h3>המרת תמונות קיימות</h3>
				<p class="description">ממיר את כל התמונות שכבר קיימות בספריית המדיה (לא רק חדשות). זה יכול לקחת כמה דקות באתר גדול.</p>
				<button type="button" id="p4pb-regen-webp" class="button">התחל המרה</button>
				<div id="p4pb-regen-progress" class="p4pb-progress" style="display:none;">
					<progress id="p4pb-regen-bar" value="0" max="100"></progress>
					<span id="p4pb-regen-status"></span>
				</div>
			</div>

			<div class="p4pb-tool-box">
				<h3>הגשת WebP ברמת השרת (Apache)</h3>
				<p class="description">
					מוסיף כלל ל-.htaccess שגורם לשרת להגיש אוטומטית את קובץ ה-.webp במקום ה-jpg/png המקורי, לכל דפדפן שתומך בכך - בלי לשנות שורת HTML אחת. עובד רק אם השרת הוא Apache עם mod_rewrite.
				</p>
				<button type="button" id="p4pb-insert-htaccess" class="button">הוסף כלל ל-.htaccess אוטומטית</button>
				<p class="description">אם זה נכשל (הרשאות כתיבה), אפשר להוסיף ידנית בין השורות <code># BEGIN P4PB WebP</code> ל-<code># END P4PB WebP</code> את הכללים המתאימים - פנה לצוות הפיתוח אם צריך עזרה.</p>
				<span id="p4pb-htaccess-status"></span>
			</div>

			<div class="p4pb-tool-box">
				<h3>4. Font-display:swap לפונטים עצמיים</h3>
				<p class="description">
					זה חל רק על CSS <strong>מתארח אצלכם</strong> (לא על Google Fonts - כבר מוגדר שם, ולא על ivrita.alefalefalef.co.il - שירות חיצוני שאין לנו שליטה עליו).
					כדי למצוא את שם ה-handle: פתח את מקור הדף (View Source), חפש קובץ ה-CSS הרלוונטי (למשל gravity-forms), ותמצא <code>id="השם-css"</code> ליד תגית ה-&lt;link&gt; שלו - השתמש בחלק לפני "-css".
				</p>
				<label>
					<input type="checkbox" name="font_swap_enabled" value="1" form="p4pb-font-form" <?php checked( ! empty( $settings['font_swap_enabled'] ) ); ?> />
					הפעלה
				</label>
				<form method="post" id="p4pb-font-form">
					<?php wp_nonce_field( 'p4pb_save_settings' ); ?>
					<textarea name="font_swap_handles" rows="4" class="large-text code" placeholder="gravity-forms-theme&#10;planet4-master-theme-fonts"><?php echo esc_textarea( $settings['font_swap_handles'] ); ?></textarea>
					<p class="description">handle אחד בכל שורה.</p>
					<button type="submit" name="p4pb_save" value="1" class="button">שמור</button>
				</form>
			</div>

		</div>
		<?php
	}
}
