<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PageSpeed flagged self-hosted @font-face declarations (Gravity Forms'
 * icon font, the theme's icon font) that don't set font-display, so text
 * using them can stay invisible while the font downloads. Google Fonts
 * already has &display=swap baked into its URL, so this module only needs
 * to handle self-hosted stylesheets.
 *
 * font-display is a descriptor that only means anything INSIDE an
 * @font-face block, so the only correct fix is to patch the actual CSS -
 * this reads each configured stylesheet handle's physical file once,
 * injects `font-display: swap;` into any @font-face rule that's missing
 * it, caches the patched copy under /wp-content/uploads/p4pb-fonts/, and
 * swaps WordPress's enqueued URL to point at the patched copy instead.
 */
class P4PB_Font_Display {

	private $settings;
	private $handles = array();

	public function __construct( array $settings ) {
		$this->settings = $settings;

		if ( empty( $settings['font_swap_enabled'] ) || empty( $settings['font_swap_handles'] ) ) {
			return;
		}

		$this->handles = array_filter( array_map( 'trim', explode( "\n", $settings['font_swap_handles'] ) ) );
		if ( empty( $this->handles ) ) {
			return;
		}

		add_filter( 'style_loader_src', array( $this, 'maybe_swap_to_patched_css' ), 20, 2 );
	}

	public function maybe_swap_to_patched_css( $src, $handle ) {
		if ( ! in_array( $handle, $this->handles, true ) ) {
			return $src;
		}

		$local_path = $this->url_to_path( $src );
		if ( ! $local_path || ! file_exists( $local_path ) ) {
			return $src; // Can't safely patch a file we can't read locally (e.g. it's on a CDN).
		}

		$patched_path = $this->get_or_create_patched_file( $local_path );
		if ( ! $patched_path ) {
			return $src;
		}

		$upload_dir = wp_get_upload_dir();
		return trailingslashit( $upload_dir['baseurl'] ) . 'p4pb-fonts/' . basename( $patched_path ) . '?v=' . filemtime( $patched_path );
	}

	private function url_to_path( $url ) {
		$url      = strtok( $url, '?' ); // Drop ?ver= etc.
		$site_url = untrailingslashit( site_url() );
		if ( 0 !== strpos( $url, $site_url ) && 0 !== strpos( $url, '/' ) ) {
			return false; // Off-site URL, e.g. a CDN we can't read from disk.
		}
		$relative = str_replace( $site_url, '', $url );
		return untrailingslashit( ABSPATH ) . $relative;
	}

	private function get_or_create_patched_file( $local_path ) {
		$upload_dir = wp_get_upload_dir();
		$cache_dir  = trailingslashit( $upload_dir['basedir'] ) . 'p4pb-fonts/';

		if ( ! is_dir( $cache_dir ) ) {
			wp_mkdir_p( $cache_dir );
		}

		$cache_file = $cache_dir . md5( $local_path ) . '-' . basename( $local_path );

		if ( file_exists( $cache_file ) && filemtime( $cache_file ) >= filemtime( $local_path ) ) {
			return $cache_file;
		}

		$css = file_get_contents( $local_path ); // phpcs:ignore
		if ( false === $css ) {
			return false;
		}

		$patched = preg_replace_callback(
			'/@font-face\s*\{([^}]*)\}/i',
			array( $this, 'patch_font_face_block' ),
			$css
		);

		if ( null === $patched ) {
			return false; // Regex failure - bail rather than ship a broken file.
		}

		$written = file_put_contents( $cache_file, $patched ); // phpcs:ignore
		return $written ? $cache_file : false;
	}

	private function patch_font_face_block( $matches ) {
		$block = $matches[1];
		if ( false !== stripos( $block, 'font-display' ) ) {
			return $matches[0]; // Already set - leave it alone.
		}
		return '@font-face{' . rtrim( $block ) . ';font-display:swap;}';
	}
}
