<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fixes the LCP (Largest Contentful Paint) issue flagged by PageSpeed Insights:
 * the homepage carousel's hero image was discoverable in the HTML but had no
 * fetchpriority hint and no <link rel=preload>, so the browser only started
 * downloading it late and only rendered it ~1.5s after it finished loading.
 *
 * This class:
 *   1. Finds the first (active) carousel slide's <img> tag in the final HTML.
 *   2. Removes loading="lazy" from it if present (it must never lazy-load).
 *   3. Adds fetchpriority="high".
 *   4. Injects a matching <link rel="preload" as="image"> into <head>, so the
 *      browser can start the download before it even reaches that point in
 *      the body.
 */
class P4PB_LCP_Fix {

	private $settings;
	private $preload_markup = '';

	public function __construct( array $settings ) {
		$this->settings = $settings;

		if ( empty( $settings['lcp_fix_enabled'] ) ) {
			return;
		}

		// Only worth doing on the homepage, where the carousel with the
		// large hero image lives.
		add_action( 'template_redirect', array( $this, 'maybe_start_buffer' ), 1 );
	}

	public function maybe_start_buffer() {
		if ( ! is_front_page() && ! is_home() ) {
			return;
		}
		ob_start( array( $this, 'process_buffer' ) );
	}

	public function process_buffer( $html ) {
		if ( empty( $html ) ) {
			return $html;
		}

		// Find the first slide marked active inside the header carousel and
		// grab its <img ...> tag.
		if ( preg_match( '/<li[^>]*class="[^"]*carousel-item active[^"]*"[^>]*>.*?(<img\b[^>]*>)/is', $html, $matches ) ) {
			$original_img = $matches[1];
			$fixed_img    = $this->fix_img_tag( $original_img );

			if ( $fixed_img !== $original_img ) {
				$html = substr_replace( $html, $fixed_img, strpos( $html, $original_img ), strlen( $original_img ) );
			}

			$this->build_preload_tag( $fixed_img );

			if ( $this->preload_markup ) {
				$html = str_replace( '</head>', $this->preload_markup . "\n</head>", $html );
			}
		}

		return $html;
	}

	private function fix_img_tag( $img_tag ) {
		// Strip loading="lazy" (case-insensitive, single or double quotes).
		$img_tag = preg_replace( '/\sloading=["\']lazy["\']/i', '', $img_tag );

		// Add fetchpriority="high" if it isn't already set.
		if ( false === stripos( $img_tag, 'fetchpriority' ) ) {
			$img_tag = preg_replace( '/<img\s/i', '<img fetchpriority="high" ', $img_tag, 1 );
		}

		// Force decoding="async" -> keep as is if present, otherwise leave;
		// not touching decoding since it's already correct in the source markup.

		return $img_tag;
	}

	private function build_preload_tag( $img_tag ) {
		if ( ! preg_match( '/\ssrc=["\']([^"\']+)["\']/i', $img_tag, $src_match ) ) {
			return;
		}
		$src = esc_url( $src_match[1] );

		$srcset_attr = '';
		if ( preg_match( '/\ssrcset=["\']([^"\']+)["\']/i', $img_tag, $srcset_match ) ) {
			$srcset_attr = ' imagesrcset="' . esc_attr( $srcset_match[1] ) . '"';
		}

		$sizes_attr = '';
		if ( preg_match( '/\ssizes=["\']([^"\']+)["\']/i', $img_tag, $sizes_match ) ) {
			$sizes_attr = ' imagesizes="' . esc_attr( $sizes_match[1] ) . '"';
		}

		$this->preload_markup = sprintf(
			'<link rel="preload" as="image" href="%s" fetchpriority="high"%s%s>',
			$src,
			$srcset_attr,
			$sizes_attr
		);
	}
}
