<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Blocks or delays third-party scripts based on saved settings.
 *
 * Two complementary mechanisms are used:
 *
 * 1. RUNTIME GUARD (JS, printed inline as the very first thing in <head>,
 *    synchronous so it can never lose the race against async/defer trackers).
 *    It overrides appendChild/insertBefore/the "src" setter so that ANY
 *    <script> matching a "block" pattern is silently dropped - whether it
 *    was written directly into the page HTML, enqueued by WordPress, or
 *    injected dynamically by another script at runtime (this is how it
 *    catches individual GTM tags/pixels that Google Tag Manager injects
 *    itself after gtm.js loads, which a server-side filter can never see).
 *
 * 2. SERVER-SIDE DELAY (output buffering + `script_loader_tag`) for
 *    scripts in the "delay" list. These get their type swapped to a
 *    non-executable placeholder and their src moved to data-p4pb-src, so
 *    the browser downloads nothing until the inline loader printed by
 *    print_delay_loader() re-activates them (on first user interaction,
 *    or after a timeout). It's printed inline rather than as a separate
 *    file on purpose: an external file would itself need to be exempt
 *    from every delay/block rule, which defeats the point.
 */
class P4PB_Script_Guard {

	private $settings;
	private $block_patterns  = array();
	private $delay_patterns  = array();

	public function __construct( array $settings ) {
		$this->settings = $settings;
		$this->build_pattern_lists();

		if ( empty( $this->block_patterns ) && empty( $this->delay_patterns ) ) {
			return; // Nothing configured - don't touch output at all.
		}

		// 1) The synchronous runtime guard - as early as physically possible.
		add_action( 'wp_head', array( $this, 'print_runtime_guard' ), 1 );

		// 2) Server-side delay for WP-enqueued scripts.
		add_filter( 'script_loader_tag', array( $this, 'filter_enqueued_script_tag' ), 10, 3 );

		// 3) Server-side delay/strip for hardcoded <script src> tags that never
		//    go through WordPress's enqueue system (theme snippets, etc.).
		if ( ! is_admin() ) {
			add_action( 'template_redirect', array( $this, 'start_output_buffer' ), 0 );
		}

		// 4) The reactivation script that brings delayed scripts back to life.
		add_action( 'wp_footer', array( $this, 'print_delay_loader' ), 99 );
	}

	private function build_pattern_lists() {
		$services = P4PB_Settings::known_services();

		foreach ( $services as $key => $svc ) {
			$mode = isset( $this->settings['services'][ $key ] ) ? $this->settings['services'][ $key ] : $svc['default'];

			if ( 'block' === $mode ) {
				$this->block_patterns = array_merge( $this->block_patterns, $svc['patterns'] );
			} elseif ( 'delay' === $mode ) {
				$this->delay_patterns = array_merge( $this->delay_patterns, $svc['patterns'] );
			}
		}

		// Advanced: specific GTM measurement/conversion IDs to always block,
		// even if the GTM service itself is set to "normal" or "delay".
		if ( ! empty( $this->settings['gtm_blocked_ids'] ) ) {
			$ids = array_filter( array_map( 'trim', explode( ',', $this->settings['gtm_blocked_ids'] ) ) );
			foreach ( $ids as $id ) {
				$this->block_patterns[] = 'id=' . $id;
			}
		}
	}

	/**
	 * Prints the synchronous JS guard. Deliberately tiny and dependency-free
	 * so it costs virtually nothing even though it's render-blocking.
	 */
	public function print_runtime_guard() {
		if ( empty( $this->block_patterns ) ) {
			return;
		}
		$patterns_json = wp_json_encode( array_values( array_unique( $this->block_patterns ) ) );
		?>
		<script id="p4pb-guard">
		(function(){
			var blocked = <?php echo $patterns_json; // phpcs:ignore ?>;
			function isBlocked(url){
				if(!url) return false;
				for(var i=0;i<blocked.length;i++){
					if(url.indexOf(blocked[i]) !== -1) return true;
				}
				return false;
			}
			function guard(node){
				try{
					if(node && node.tagName === 'SCRIPT'){
						var src = node.src || node.getAttribute('src') || '';
						if(isBlocked(src)) return true;
					}
				}catch(e){}
				return false;
			}
			var origAppend = Element.prototype.appendChild;
			var origInsert = Element.prototype.insertBefore;
			Element.prototype.appendChild = function(node){
				if (guard(node)) { return node; }
				return origAppend.call(this, node);
			};
			Element.prototype.insertBefore = function(node, ref){
				if (guard(node)) { return node; }
				return origInsert.call(this, node, ref);
			};
			// Belt-and-suspenders: also catch `script.src = "..."` assignment
			// on nodes that were created before being appended.
			try {
				var desc = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
				if (desc && desc.set) {
					Object.defineProperty(HTMLScriptElement.prototype, 'src', {
						get: desc.get,
						set: function(val){
							if (isBlocked(val)) { return; }
							desc.set.call(this, val);
						},
						configurable: true
					});
				}
			} catch(e){}
		})();
		</script>
		<?php
	}

	/**
	 * Delays (does not block) individually WP-enqueued scripts by rewriting
	 * their <script> tag so the browser never requests the file until the
	 * delay-loader reactivates it.
	 */
	public function filter_enqueued_script_tag( $tag, $handle, $src ) {
		if ( empty( $this->delay_patterns ) || empty( $src ) ) {
			return $tag;
		}
		foreach ( $this->delay_patterns as $pattern ) {
			if ( false !== strpos( $src, $pattern ) ) {
				return $this->delayify_tag( $tag );
			}
		}
		return $tag;
	}

	/**
	 * Rewrites a <script ... src="..." ...></script> tag into an inert
	 * placeholder: type is swapped so the browser won't execute it, and
	 * src is moved to data-p4pb-src so nothing downloads yet either.
	 */
	private function delayify_tag( $tag ) {
		$tag = preg_replace( '/\stype=["\'][^"\']*["\']/i', '', $tag );
		$tag = preg_replace( '/\ssrc=/i', ' data-p4pb-src=', $tag, 1 );
		$tag = preg_replace( '/<script\s/i', '<script type="text/p4pb-delay" ', $tag, 1 );
		return $tag;
	}

	/**
	 * Catches hardcoded third-party <script src="..."> tags that never go
	 * through WordPress's enqueue system, by scanning the fully rendered
	 * page HTML once at the very end of the request.
	 */
	public function start_output_buffer() {
		ob_start( array( $this, 'process_buffer' ) );
	}

	public function process_buffer( $html ) {
		if ( empty( $html ) ) {
			return $html;
		}

		$html = preg_replace_callback(
			'/<script\b[^>]*\ssrc=["\']([^"\']+)["\'][^>]*><\/script>/i',
			array( $this, 'process_script_match' ),
			$html
		);

		return $html;
	}

	private function process_script_match( $matches ) {
		$full_tag = $matches[0];
		$src      = $matches[1];

		foreach ( $this->block_patterns as $pattern ) {
			if ( false !== strpos( $src, $pattern ) ) {
				return ''; // Strip entirely - the runtime guard would have
				           // caught it too, but no reason to ship the bytes.
			}
		}

		foreach ( $this->delay_patterns as $pattern ) {
			if ( false !== strpos( $src, $pattern ) ) {
				return $this->delayify_tag( $full_tag );
			}
		}

		return $full_tag;
	}

	/**
	 * Prints the footer script that "wakes up" delayed scripts on first
	 * user interaction (scroll, click, keydown, touch, mousemove) or after
	 * a fallback timeout, in original document order.
	 */
	public function print_delay_loader() {
		if ( empty( $this->delay_patterns ) ) {
			return;
		}
		$timeout_ms = max( 1, (int) $this->settings['delay_timeout'] ) * 1000;
		?>
		<script id="p4pb-delay-loader">
		(function(){
			var loaded = false;
			var events = ['mousemove','scroll','keydown','touchstart','click'];
			function loadAll(){
				if (loaded) return;
				loaded = true;
				events.forEach(function(evt){
					window.removeEventListener(evt, loadAll, { passive: true });
				});
				clearTimeout(timer);
				var nodes = document.querySelectorAll('script[type="text/p4pb-delay"]');
				nodes.forEach(function(oldNode){
					var newNode = document.createElement('script');
					for (var i = 0; i < oldNode.attributes.length; i++) {
						var attr = oldNode.attributes[i];
						if (attr.name === 'type') continue;
						if (attr.name === 'data-p4pb-src') {
							newNode.setAttribute('src', attr.value);
						} else {
							newNode.setAttribute(attr.name, attr.value);
						}
					}
					if (!newNode.getAttribute('src') && oldNode.textContent) {
						newNode.textContent = oldNode.textContent;
					}
					oldNode.parentNode.replaceChild(newNode, oldNode);
				});
			}
			var timer = setTimeout(loadAll, <?php echo (int) $timeout_ms; ?>);
			events.forEach(function(evt){
				window.addEventListener(evt, loadAll, { passive: true, once: true });
			});
		})();
		</script>
		<?php
	}
}
