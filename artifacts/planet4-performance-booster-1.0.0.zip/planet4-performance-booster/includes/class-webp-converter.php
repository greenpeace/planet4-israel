<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generates WebP copies of uploaded images (original + every registered
 * intermediate size) and can insert an .htaccess rule so Apache serves the
 * .webp file automatically to browsers that support it, with zero HTML
 * changes needed - which keeps things safe with full-page caching (adds
 * `Vary: Accept` so Cloudflare/proxies cache the right variant per browser).
 */
class P4PB_Webp_Converter {

	private $settings;

	const HTACCESS_MARKER = 'P4PB WebP';

	public function __construct( array $settings ) {
		$this->settings = $settings;

		if ( empty( $settings['webp_enabled'] ) ) {
			return;
		}

		add_filter( 'wp_generate_attachment_metadata', array( $this, 'generate_webp_for_attachment' ), 20, 2 );

		add_action( 'wp_ajax_p4pb_regenerate_webp_batch', array( $this, 'ajax_regenerate_batch' ) );
		add_action( 'wp_ajax_p4pb_insert_htaccess_rule', array( $this, 'ajax_insert_htaccess_rule' ) );
	}

	/**
	 * Hooked into the standard WP metadata pipeline, so this runs right
	 * after core generates the various thumbnail sizes for a new upload.
	 */
	public function generate_webp_for_attachment( $metadata, $attachment_id ) {
		$file = get_attached_file( $attachment_id );
		if ( ! $file || ! $this->is_convertible( $file ) ) {
			return $metadata;
		}

		$this->convert_file_to_webp( $file );

		if ( ! empty( $metadata['sizes'] ) && ! empty( $metadata['file'] ) ) {
			$base_dir = trailingslashit( dirname( $file ) );
			foreach ( $metadata['sizes'] as $size ) {
				if ( empty( $size['file'] ) ) {
					continue;
				}
				$size_file = $base_dir . $size['file'];
				if ( $this->is_convertible( $size_file ) ) {
					$this->convert_file_to_webp( $size_file );
				}
			}
		}

		return $metadata;
	}

	private function is_convertible( $file ) {
		if ( ! file_exists( $file ) ) {
			return false;
		}
		$ext = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
		return in_array( $ext, array( 'jpg', 'jpeg', 'png' ), true );
	}

	/**
	 * Converts a single image file to a sibling .webp file. Prefers Imagick
	 * (better compression/quality control) and falls back to GD, which
	 * ships with virtually every PHP install.
	 *
	 * @return bool True on success.
	 */
	public function convert_file_to_webp( $file ) {
		$webp_path = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );

		if ( file_exists( $webp_path ) && filemtime( $webp_path ) >= filemtime( $file ) ) {
			return true; // Already converted and up to date.
		}

		$quality = isset( $this->settings['webp_quality'] ) ? (int) $this->settings['webp_quality'] : 82;

		if ( class_exists( 'Imagick' ) ) {
			try {
				$image = new Imagick( $file );
				$image->setImageFormat( 'webp' );
				$image->setImageCompressionQuality( $quality );
				$image->stripImage(); // Drop EXIF/metadata - smaller file, same as most optimizers.
				$result = $image->writeImage( $webp_path );
				$image->clear();
				$image->destroy();
				return (bool) $result;
			} catch ( Exception $e ) {
				// Fall through to GD attempt below.
			}
		}

		if ( function_exists( 'imagewebp' ) ) {
			$ext = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
			$src = null;

			if ( in_array( $ext, array( 'jpg', 'jpeg' ), true ) && function_exists( 'imagecreatefromjpeg' ) ) {
				$src = @imagecreatefromjpeg( $file ); // phpcs:ignore
			} elseif ( 'png' === $ext && function_exists( 'imagecreatefrompng' ) ) {
				$src = @imagecreatefrompng( $file ); // phpcs:ignore
				if ( $src ) {
					imagepalettetotruecolor( $src );
					imagealphablending( $src, true );
					imagesavealpha( $src, true );
				}
			}

			if ( $src ) {
				$result = imagewebp( $src, $webp_path, $quality );
				imagedestroy( $src );
				return (bool) $result;
			}
		}

		return false;
	}

	/**
	 * AJAX: converts a batch of already-uploaded media library images that
	 * predate this plugin. Called repeatedly from admin JS with a rolling
	 * offset until it reports done=true.
	 */
	public function ajax_regenerate_batch() {
		check_ajax_referer( 'p4pb_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'forbidden', 403 );
		}

		$offset     = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
		$batch_size = 10;

		$attachments = get_posts( array(
			'post_type'      => 'attachment',
			'post_mime_type' => array( 'image/jpeg', 'image/png' ),
			'post_status'    => 'inherit',
			'posts_per_page' => $batch_size,
			'offset'         => $offset,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
		) );

		$converted = 0;
		foreach ( $attachments as $attachment_id ) {
			$file = get_attached_file( $attachment_id );
			if ( $file && $this->is_convertible( $file ) ) {
				if ( $this->convert_file_to_webp( $file ) ) {
					$converted++;
				}
				$metadata = wp_get_attachment_metadata( $attachment_id );
				if ( ! empty( $metadata['sizes'] ) ) {
					$base_dir = trailingslashit( dirname( $file ) );
					foreach ( $metadata['sizes'] as $size ) {
						if ( ! empty( $size['file'] ) ) {
							$size_file = $base_dir . $size['file'];
							if ( $this->is_convertible( $size_file ) ) {
								$this->convert_file_to_webp( $size_file );
							}
						}
					}
				}
			}
		}

		wp_send_json_success( array(
			'processed' => count( $attachments ),
			'converted' => $converted,
			'done'      => count( $attachments ) < $batch_size,
			'next_offset' => $offset + count( $attachments ),
		) );
	}

	/**
	 * AJAX: safely inserts (or updates) the Apache rewrite block that
	 * serves .webp automatically, using WP core's insert_with_markers()
	 * so re-running it never duplicates or corrupts the file.
	 */
	public function ajax_insert_htaccess_rule() {
		check_ajax_referer( 'p4pb_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'forbidden', 403 );
		}

		if ( ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}

		$htaccess_path = trailingslashit( ABSPATH ) . '.htaccess';

		if ( ! is_writable( dirname( $htaccess_path ) ) && ! ( file_exists( $htaccess_path ) && is_writable( $htaccess_path ) ) ) {
			wp_send_json_error( 'not_writable' );
		}

		// Serves sibling "file.webp" instead of "file.jpg"/"file.png" whenever
		// the browser sends "Accept: image/webp" AND the .webp file exists -
		// falls straight through to the original file otherwise, so nothing
		// breaks for images that haven't been converted yet.
		$rules = array(
			'<IfModule mod_rewrite.c>',
			'RewriteEngine On',
			'RewriteCond %{HTTP_ACCEPT} image/webp',
			'RewriteCond %{REQUEST_FILENAME} \.(jpe?g|png)$',
			'RewriteCond %{REQUEST_FILENAME}.webp -f',
			'RewriteRule ^(.*)\.(jpe?g|png)$ $1.webp [T=image/webp,L]',
			'</IfModule>',
			'<IfModule mod_headers.c>',
			'<FilesMatch "\.(jpe?g|png)$">',
			'Header append Vary Accept',
			'</FilesMatch>',
			'</IfModule>',
		);

		$ok = insert_with_markers( $htaccess_path, self::HTACCESS_MARKER, $rules );

		if ( $ok ) {
			wp_send_json_success();
		}
		wp_send_json_error( 'write_failed' );
	}
}
