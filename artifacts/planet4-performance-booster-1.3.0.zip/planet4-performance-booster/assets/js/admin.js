( function ( $ ) {
	'use strict';

	$( function () {
		var $regenBtn    = $( '#p4pb-regen-webp' );
		var $resumeBtn   = $( '#p4pb-resume-webp' );
		var $stopBtn     = $( '#p4pb-stop-webp' );
		var $progressBox = $( '#p4pb-regen-progress' );
		var $bar         = $( '#p4pb-regen-bar' );
		var $status      = $( '#p4pb-regen-status' );

		var running = false;
		var stopRequested = false;

		// On page load: check for interrupted batch and show Resume option.
		if ( p4pbAdmin.batchProgress && p4pbAdmin.batchProgress.status === 'running' ) {
			$progressBox.show();
			$resumeBtn.show();
			$stopBtn.show();
			$regenBtn.hide();
			$bar.removeAttr( 'value' );
			$status.text( p4pbAdmin.i18n.interrupted + ' (' + p4pbAdmin.batchProgress.converted + p4pbAdmin.i18n.convertedSoFar + ')' );
		}

		$regenBtn.on( 'click', function () {
			startBatch( 0, 0 );
		} );

		$resumeBtn.on( 'click', function () {
			var progress = p4pbAdmin.batchProgress || {};
			startBatch( progress.offset || 0, progress.converted || 0 );
		} );

		$stopBtn.on( 'click', function () {
			stopRequested = true;
			$stopBtn.prop( 'disabled', true );
			$status.text( p4pbAdmin.i18n.stopping );

			$.post( p4pbAdmin.ajaxUrl, {
				action: 'p4pb_reset_webp_batch',
				nonce:  p4pbAdmin.nonce
			} ).always( function () {
				running = false;
				$bar.attr( 'value', 0 );
				$status.text( p4pbAdmin.i18n.stopped );
				$stopBtn.hide().prop( 'disabled', false );
				$resumeBtn.hide();
				$regenBtn.show().prop( 'disabled', false );
			} );
		} );

		function startBatch( offset, totalConverted ) {
			running       = true;
			stopRequested = false;
			$regenBtn.hide();
			$resumeBtn.hide();
			$stopBtn.show().prop( 'disabled', false );
			$progressBox.show();
			$bar.removeAttr( 'value' );
			$status.text( p4pbAdmin.i18n.converting );
			runBatch( offset, totalConverted );
		}

		function runBatch( offset, totalConverted ) {
			if ( stopRequested ) return;

			$.post( p4pbAdmin.ajaxUrl, {
				action:          'p4pb_regenerate_webp_batch',
				nonce:           p4pbAdmin.nonce,
				offset:          offset,
				total_converted: totalConverted
			} ).done( function ( response ) {
				if ( stopRequested ) return;

				if ( ! response.success ) {
					$status.text( p4pbAdmin.i18n.genericError );
					resetUI();
					return;
				}

				var data = response.data;
				totalConverted += data.converted;

				if ( data.done ) {
					$bar.attr( 'value', 100 );
					$status.text( p4pbAdmin.i18n.done + ' (' + totalConverted + p4pbAdmin.i18n.convertedTotal + ')' );
					resetUI();
					return;
				}

				$bar.removeAttr( 'value' );
				$status.text( totalConverted + p4pbAdmin.i18n.convertedSoFar );
				runBatch( data.next_offset, totalConverted );
			} ).fail( function () {
				if ( stopRequested ) return;
				$status.text( p4pbAdmin.i18n.networkError );
				resetUI();
			} );
		}

		function resetUI() {
			running = false;
			$stopBtn.hide();
			$resumeBtn.hide();
			$regenBtn.show().prop( 'disabled', false );
		}

		$( '#p4pb-insert-htaccess' ).on( 'click', function () {
			var $btn    = $( this );
			var $result = $( '#p4pb-htaccess-status' );
			$btn.prop( 'disabled', true );
			$result.text( '...' );

			$.post( p4pbAdmin.ajaxUrl, {
				action: 'p4pb_insert_htaccess_rule',
				nonce:  p4pbAdmin.nonce
			} ).done( function ( response ) {
				$result.text( response.success ? p4pbAdmin.i18n.htaccessOk : p4pbAdmin.i18n.htaccessError );
			} ).fail( function () {
				$result.text( p4pbAdmin.i18n.htaccessError );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	} );
} )( jQuery );
