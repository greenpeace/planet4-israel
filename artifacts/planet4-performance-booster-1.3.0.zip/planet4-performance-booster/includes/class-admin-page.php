<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class P4PB_Admin_Page {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'maybe_save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function add_menu() {
		add_options_page(
			'Performance Booster',
			'Performance Booster',
			'manage_options',
			'p4-perf-booster',
			array( $this, 'render_page' )
		);
	}

	public function enqueue_assets( $hook ) {
		if ( 'settings_page_p4-perf-booster' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'p4pb-admin', P4PB_PLUGIN_URL . 'assets/css/admin.css', array(), P4PB_VERSION );
		wp_enqueue_script( 'p4pb-admin', P4PB_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), P4PB_VERSION, true );
		wp_localize_script( 'p4pb-admin', 'p4pbAdmin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'p4pb_admin' ),
			'i18n'    => array(
				'converting'    => 'Converting images...',
				'done'          => 'Done!',
				'convertedSoFar'=> ' image(s) converted so far...',
				'convertedTotal'=> ' image(s) converted',
				'genericError'  => 'Error - please try again',
				'networkError'  => 'Network error - please try again',
				'htaccessOk'    => 'Rule added to .htaccess successfully',
				'htaccessError' => "Couldn't write to .htaccess - you can add it manually (see below)",
			),
		) );
	}

	public function maybe_save() {
		if ( ! isset( $_POST['p4pb_save'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( 'p4pb_save_settings' );

		$posted = wp_unslash( $_POST );

		$services = array();
		foreach ( array_keys( P4PB_Settings::known_services() ) as $key ) {
			$mode = isset( $posted['services'][ $key ] ) ? sanitize_key( $posted['services'][ $key ] ) : 'normal';
			$services[ $key ] = in_array( $mode, array( 'normal', 'delay', 'block' ), true ) ? $mode : 'normal';
		}

		P4PB_Settings::update( array(
			'services'               => $services,
			'gtm_blocked_ids'        => isset( $posted['gtm_blocked_ids'] ) ? sanitize_text_field( $posted['gtm_blocked_ids'] ) : '',
			'delay_timeout'          => isset( $posted['delay_timeout'] ) ? max( 1, (int) $posted['delay_timeout'] ) : 8,
			'lcp_fix_enabled'        => ! empty( $posted['lcp_fix_enabled'] ),
			'lcp_all_pages'          => ! empty( $posted['lcp_all_pages'] ),
			'webp_enabled'           => ! empty( $posted['webp_enabled'] ),
			'webp_quality'           => isset( $posted['webp_quality'] ) ? min( 100, max( 1, (int) $posted['webp_quality'] ) ) : 82,
			'preconnect_enabled'     => ! empty( $posted['preconnect_enabled'] ),
			'preconnect_domains'     => isset( $posted['preconnect_domains'] ) ? sanitize_textarea_field( $posted['preconnect_domains'] ) : '',
			'dimensions_fix_enabled' => ! empty( $posted['dimensions_fix_enabled'] ),
			'font_swap_enabled'      => ! empty( $posted['font_swap_enabled'] ),
			'font_swap_handles'      => isset( $posted['font_swap_handles'] ) ? sanitize_textarea_field( $posted['font_swap_handles'] ) : '',
		) );

		add_settings_error( 'p4pb', 'saved', 'Settings saved.', 'success' );
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$settings       = P4PB_Settings::get();
		$services       = P4PB_Settings::known_services();
		$offload_plugin = P4PB_Webp_Converter::detect_offload_plugin();
		settings_errors( 'p4pb' );
		?>
		<div class="wrap p4pb-wrap" dir="ltr">
			<h1>Planet4 Performance Booster</h1>
			<p class="description">
				Addresses the performance audit findings (PageSpeed Insights, July 2026): third-party script overhead, LCP image loading priority, image weight, CLS, and font-display.
				<strong>Always test on dev first.</strong> Clear any page cache after saving settings.
			</p>

			<form method="post">
				<?php wp_nonce_field( 'p4pb_save_settings' ); ?>

				<!-- ===== SECTION 1: SCRIPTS ===== -->
				<h2 class="p4pb-section-title">1. Third-party scripts</h2>
				<div class="p4pb-tip">
					<strong>💡 How it works:</strong>
					<ul>
						<li><strong>Delay</strong> — script loads on first user interaction (scroll / click / touch) <em>or</em> after the auto-load timeout, whichever comes first. Good for tracking pixels: events fire a few seconds late but attribution is intact.</li>
						<li><strong>Block</strong> — script never loads. Use for known duplicates or scripts you've confirmed are unnecessary. Check GTM Preview Mode before blocking anything important.</li>
						<li><strong>Normal</strong> — no change.</li>
					</ul>
					<strong>⚠️ Before changing anything:</strong> open GTM Preview Mode, verify all events still fire (especially form submissions and conversion events), and check GA4 Realtime for ~30 minutes after saving.
					If conversion data disappears, set that service back to Normal.
				</div>
				<table class="widefat p4pb-services-table">
					<thead>
						<tr>
							<th>Service</th>
							<th>Normal</th>
							<th>Delay</th>
							<th>Block</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $services as $key => $svc ) :
						$current = isset( $settings['services'][ $key ] ) ? $settings['services'][ $key ] : $svc['default'];
						?>
						<tr>
							<td><?php echo esc_html( $svc['label'] ); ?></td>
							<?php foreach ( array( 'normal', 'delay', 'block' ) as $mode ) : ?>
								<td class="p4pb-radio-cell">
									<input type="radio"
										   name="services[<?php echo esc_attr( $key ); ?>]"
										   value="<?php echo esc_attr( $mode ); ?>"
										   <?php checked( $current, $mode ); ?> />
								</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<table class="form-table">
					<tr>
						<th scope="row"><label for="delay_timeout">Auto-load timeout (seconds)</label></th>
						<td>
							<input type="number" min="1" max="60" id="delay_timeout" name="delay_timeout"
								   value="<?php echo esc_attr( $settings['delay_timeout'] ); ?>" class="small-text" />
							<p class="description">
								If there's no user interaction, "delayed" scripts load anyway after this many seconds —
								so completely passive visitors (who never scroll) aren't permanently lost from measurement.
								<strong>Recommended: 8 s.</strong> Setting it lower reduces the performance gain; setting it
								higher risks losing passive visitor data.
							</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="gtm_blocked_ids">Block specific GTM IDs (advanced)</label></th>
						<td>
							<input type="text" id="gtm_blocked_ids" name="gtm_blocked_ids"
								   value="<?php echo esc_attr( $settings['gtm_blocked_ids'] ); ?>"
								   class="regular-text" placeholder="G-0VYVGB08Q0, AW-123456789" />
							<p class="description">
								Comma-separated IDs (G-… or AW-…) to block entirely — even if GTM itself is on Delay or Normal.
								Useful as a stopgap when duplicates haven't been cleaned up in the GTM container yet.
								The real fix is always cleaning the container in the GTM interface.
							</p>
						</td>
					</tr>
				</table>

				<!-- ===== SECTION 2: LCP ===== -->
				<h2 class="p4pb-section-title">2. LCP image priority</h2>
				<div class="p4pb-tip">
					<strong>💡 What is LCP?</strong> Largest Contentful Paint — the time until the biggest visible element
					appears. For this site it's usually the hero / carousel image. By default the browser treats it as a
					normal low-priority image; adding <code>fetchpriority="high"</code> + a <code>&lt;link rel=preload&gt;</code>
					tells it to download the hero image immediately, before anything else.
					<br><br>
					<strong>How to verify:</strong> View Source and confirm the first carousel <code>&lt;img&gt;</code> has
					<code>fetchpriority="high"</code>. In Chrome DevTools → Network tab, the hero image should show
					Priority: <em>Highest</em>.
					<br><br>
					<strong>⚠️ "Apply to all pages":</strong> when enabled the fix also runs on article and campaign pages,
					where it looks for the first image with class <code>size-full</code>, <code>size-large</code>, or
					<code>wp-post-image</code> (the featured image). If a page's LCP element is something unusual
					(e.g. a CSS background) this won't help — check PageSpeed per-page.
				</div>
				<table class="form-table">
					<tr>
						<th scope="row">Enable</th>
						<td>
							<label>
								<input type="checkbox" name="lcp_fix_enabled" value="1"
									   <?php checked( ! empty( $settings['lcp_fix_enabled'] ) ); ?> />
								Add <code>fetchpriority="high"</code> + <code>&lt;link rel=preload&gt;</code> to the active
								carousel/hero image and remove <code>loading="lazy"</code> from it
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row">Apply to all pages</th>
						<td>
							<label>
								<input type="checkbox" name="lcp_all_pages" value="1"
									   <?php checked( ! empty( $settings['lcp_all_pages'] ) ); ?> />
								Also fix LCP on non-homepage pages (article, campaign, about pages) — falls back to the
								first <code>size-full / size-large / wp-post-image</code> image when there's no carousel
							</label>
						</td>
					</tr>
				</table>

				<!-- ===== SECTION 3: WEBP ===== -->
				<h2 class="p4pb-section-title">3. WebP image conversion</h2>
				<div class="p4pb-tip">
					<strong>💡 What it does:</strong> WebP is a modern image format that's typically 25–35% smaller than
					JPEG at the same visual quality. This module converts every uploaded JPG / PNG to a sibling <code>.webp</code>
					file and wraps content images in a <code>&lt;picture&gt;&lt;source type="image/webp"&gt;</code> element,
					so WebP-capable browsers (all modern ones) get the smaller file while older browsers silently fall back
					to the original.
					<br><br>
					<?php if ( $offload_plugin ) : ?>
					<strong>🔗 Detected offload:</strong> <strong><?php echo esc_html( $offload_plugin ); ?></strong>.
					Generated WebP files are synced to Google Cloud Storage automatically (they're injected into the
					attachment's <code>sizes</code> metadata that WP-Stateless reads). The Apache <code>.htaccess</code>
					tool below has no effect on stateless media — ignore it.
					The "Convert existing images" tool below now downloads files from GCS when they're not on local disk,
					so it works in stateless mode too.
					<?php else : ?>
					<strong>Requires:</strong> Imagick or GD extension (both ship with virtually every WordPress host).
					<?php endif; ?>
					<br><br>
					<strong>⚠️ After enabling:</strong> use "Convert existing images" below to process images already in
					the library. New uploads are converted automatically from this point on.
					For very large libraries (&gt;500 images), use the WP-CLI command instead of the browser tool to
					avoid timeout issues: <code>wp p4pb convert-webp</code>
				</div>
				<table class="form-table">
					<tr>
						<th scope="row">Enable</th>
						<td>
							<label>
								<input type="checkbox" name="webp_enabled" value="1"
									   <?php checked( ! empty( $settings['webp_enabled'] ) ); ?> />
								Convert newly uploaded JPG/PNG images to WebP and serve them via
								<code>&lt;picture&gt;</code> to supporting browsers
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="webp_quality">WebP quality</label></th>
						<td>
							<input type="number" min="1" max="100" id="webp_quality" name="webp_quality"
								   value="<?php echo esc_attr( $settings['webp_quality'] ); ?>" class="small-text" />
							<p class="description">
								<strong>82</strong> is the sweet spot for most editorial photography (indistinguishable
								from 90–95 to most eyes, but 15–20% smaller). Go lower (70–75) for very high-volume
								media where file size matters most; go higher (90+) for detailed infographics or text-heavy images.
							</p>
						</td>
					</tr>
				</table>

				<!-- ===== SECTION 4: PRECONNECT ===== -->
				<h2 class="p4pb-section-title">4. Preconnect / DNS prefetch hints</h2>
				<div class="p4pb-tip">
					<strong>💡 What it does:</strong> Every time the browser opens a new connection to a third-party domain
					it pays a DNS lookup + TLS handshake cost of roughly <strong>150–300 ms</strong>. A
					<code>&lt;link rel="preconnect"&gt;</code> hint tells the browser to open that connection in advance,
					during the HTML parse, so the cost is already paid by the time the actual request is made.
					<br><br>
					<strong>Only add domains the page will definitely use on every visit</strong> — speculative preconnects
					for rarely-used origins waste connections. The defaults cover the most common ones for this site.
					You can paste full URLs (e.g. <code>https://fonts.googleapis.com</code>) or just the hostname.
					<br><br>
					<strong>How to verify:</strong> View Source → check that <code>&lt;link rel="preconnect"&gt;</code> tags
					appear near the top of <code>&lt;head&gt;</code>, before any stylesheet or script references.
				</div>
				<table class="form-table">
					<tr>
						<th scope="row">Enable</th>
						<td>
							<label>
								<input type="checkbox" name="preconnect_enabled" value="1"
									   <?php checked( ! empty( $settings['preconnect_enabled'] ) ); ?> />
								Print <code>&lt;link rel="preconnect"&gt;</code> + <code>&lt;link rel="dns-prefetch"&gt;</code>
								hints for the domains below
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="preconnect_domains">Domains</label></th>
						<td>
							<textarea id="preconnect_domains" name="preconnect_domains" rows="5"
									  class="large-text code"><?php echo esc_textarea( $settings['preconnect_domains'] ); ?></textarea>
							<p class="description">One hostname per line. Scheme is optional.</p>
						</td>
					</tr>
				</table>

				<!-- ===== SECTION 5: DIMENSIONS / CLS ===== -->
				<h2 class="p4pb-section-title">5. Image dimensions (CLS fix)</h2>
				<div class="p4pb-tip">
					<strong>💡 What is CLS?</strong> Cumulative Layout Shift — unexpected page jumps as content loads.
					Images without explicit <code>width</code> and <code>height</code> attributes cause layout shifts
					because the browser doesn't know how much space to reserve while the image is downloading.
					<br><br>
					This module injects the correct dimensions into <code>&lt;img&gt;</code> tags that are missing them,
					using WordPress's attachment metadata (from the media library). It uses a pre-warmed cache so it
					adds only one extra DB query per page, not one per image.
					<br><br>
					<strong>How to verify:</strong> In Chrome DevTools → Rendering → Layout Shift Regions, check that
					images no longer cause highlighted shifts. Or run a PageSpeed report and look for the CLS score.
					<br><br>
					<strong>⚠️ Note:</strong> setting dimensions doesn't break responsive CSS (
					<code>img { width: 100%; }</code> still works) — the browser uses the aspect ratio from the
					dimensions, not the literal pixel size. But if you have custom CSS that manually sets
					<code>height</code> on images and you need a specific value, verify the result.
				</div>
				<table class="form-table">
					<tr>
						<th scope="row">Enable</th>
						<td>
							<label>
								<input type="checkbox" name="dimensions_fix_enabled" value="1"
									   <?php checked( ! empty( $settings['dimensions_fix_enabled'] ) ); ?> />
								Inject <code>width</code> + <code>height</code> attributes into content images that are
								missing them, to prevent layout shifts
							</label>
						</td>
					</tr>
				</table>

				<!-- ===== SECTION 6: FONTS ===== -->
				<h2 class="p4pb-section-title">6. font-display: swap for self-hosted fonts</h2>
				<div class="p4pb-tip">
					<strong>💡 What it does:</strong> Without <code>font-display: swap</code>, a browser that downloads
					a custom font will keep text invisible until the font arrives — this is called FOIT (Flash of
					Invisible Text). <code>swap</code> tells it to show the text in a fallback font immediately and
					swap to the custom font when it's ready, which massively improves perceived load time.
					<br><br>
					This only applies to CSS <strong>hosted on this site</strong> — Google Fonts already has
					<code>&display=swap</code> in its URL. External font services (e.g. ivrita.alefalefalef.co.il)
					can't be patched from here.
					<br><br>
					<strong>How to find the handle name:</strong> View Page Source → find the stylesheet's
					<code>&lt;link&gt;</code> tag → look for <code>id="HANDLE-css"</code> → the handle is everything
					before <code>-css</code>. Example: <code>id="gravity-forms-theme-css"</code> → handle is
					<code>gravity-forms-theme</code>.
				</div>
				<table class="form-table">
					<tr>
						<th scope="row">Enable</th>
						<td>
							<label>
								<input type="checkbox" name="font_swap_enabled" value="1"
									   <?php checked( ! empty( $settings['font_swap_enabled'] ) ); ?> />
								Patch <code>@font-face</code> rules in the stylesheets listed below to add
								<code>font-display: swap</code>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="font_swap_handles">Stylesheet handles</label></th>
						<td>
							<textarea id="font_swap_handles" name="font_swap_handles" rows="4"
									  class="large-text code"
									  placeholder="gravity-forms-theme&#10;planet4-master-theme-fonts"><?php echo esc_textarea( $settings['font_swap_handles'] ); ?></textarea>
							<p class="description">One WordPress stylesheet handle per line.</p>
						</td>
					</tr>
				</table>

				<p class="submit">
					<button type="submit" name="p4pb_save" value="1" class="button button-primary">Save settings</button>
				</p>
			</form>

			<hr />
			<h2 class="p4pb-section-title">Tools</h2>

			<!-- Convert existing images -->
			<div class="p4pb-tool-box">
				<h3>Convert existing images to WebP</h3>
				<p class="description">
					Converts every image already in the media library (not just new uploads).
					Runs in batches of 5 so it shouldn't time out on most hosts.
					For very large libraries use the CLI command instead: <code>wp p4pb convert-webp</code>
					(add <code>--limit=N</code> to process in chunks, <code>--dry-run</code> to preview).
				</p>
				<button type="button" id="p4pb-regen-webp" class="button">Start conversion</button>
				<div id="p4pb-regen-progress" class="p4pb-progress" style="display:none;">
					<progress id="p4pb-regen-bar" value="0" max="100"></progress>
					<span id="p4pb-regen-status"></span>
				</div>
			</div>

			<!-- Apache .htaccess tool -->
			<div class="p4pb-tool-box">
				<h3>Server-level WebP delivery (Apache only)</h3>
				<p class="description">
					Adds a rewrite rule to <code>.htaccess</code> that serves <code>.webp</code> files automatically
					to supporting browsers. <strong>Only useful when media is served from this server's local disk</strong>
					— it has no effect on media offloaded to cloud / CDN storage (WP-Stateless etc.), which is already
					handled by the <code>&lt;picture&gt;</code> element this plugin adds. Safe to ignore on this site
					if a media offload plugin is active (see detection notice above).
				</p>
				<button type="button" id="p4pb-insert-htaccess" class="button">Add rule to .htaccess</button>
				<span id="p4pb-htaccess-status"></span>
			</div>

		</div><!-- .p4pb-wrap -->
		<?php
	}
}
