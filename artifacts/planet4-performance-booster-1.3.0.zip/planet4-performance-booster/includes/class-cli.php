<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP-CLI command for bulk WebP conversion without the AJAX timeout risk.
 *
 * Usage:
 *   wp p4pb convert-webp
 *   wp p4pb convert-webp --limit=100
 *   wp p4pb convert-webp --dry-run
 *   wp p4pb convert-webp --offset=200 --limit=100
 *
 * This is the recommended approach for large sites (thousands of images)
 * where the browser-based "Convert existing images" tool times out.
 */
class P4PB_CLI extends WP_CLI_Command {

	/**
	 * Convert existing media library images to WebP.
	 *
	 * ## OPTIONS
	 *
	 * [--limit=<number>]
	 * : Maximum number of images to process. Default: all.
	 *
	 * [--offset=<number>]
	 * : Number of images to skip (for chunked runs). Default: 0.
	 *
	 * [--dry-run]
	 * : Show what would be converted without actually doing it.
	 *
	 * ## EXAMPLES
	 *
	 *     wp p4pb convert-webp
	 *     wp p4pb convert-webp --limit=500 --dry-run
	 *     wp p4pb convert-webp --offset=500 --limit=500
	 *
	 * @when after_wp_load
	 */
	public function convert_webp( $args, $assoc_args ) {
		$settings = P4PB_Settings::get();

		if ( empty( $settings['webp_enabled'] ) ) {
			WP_CLI::error( 'WebP conversion is disabled in Settings > Performance Booster.' );
		}

		$converter = new P4PB_Webp_Converter( $settings );

		$limit   = isset( $assoc_args['limit'] )  ? (int) $assoc_args['limit']  : 0;
		$offset  = isset( $assoc_args['offset'] ) ? (int) $assoc_args['offset'] : 0;
		$dry_run = ! empty( $assoc_args['dry-run'] );

		$query_args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => array( 'image/jpeg', 'image/png' ),
			'post_status'    => 'inherit',
			'posts_per_page' => $limit > 0 ? $limit : -1,
			'offset'         => $offset,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
		);

		$attachments = get_posts( $query_args );
		$total       = count( $attachments );

		if ( ! $total ) {
			WP_CLI::success( 'No images found to convert.' );
			return;
		}

		WP_CLI::log( sprintf(
			'%s%d image(s) to process (offset %d).',
			$dry_run ? '[dry-run] ' : '',
			$total,
			$offset
		) );

		$progress  = WP_CLI\Utils\make_progress_bar( 'Converting', $total );
		$converted = 0;
		$skipped   = 0;
		$errors    = 0;

		foreach ( $attachments as $attachment_id ) {
			$progress->tick();

			if ( $dry_run ) {
				$url = wp_get_attachment_url( $attachment_id );
				WP_CLI::log( "  [dry-run] Would convert: $url" );
				continue;
			}

			try {
				$file        = $this->get_file( $converter, $attachment_id );
				$temp_files  = array();

				if ( ! $file || ! file_exists( $file ) ) {
					$file = $this->download_file( $attachment_id, $file );
					if ( $file ) {
						$temp_files[] = $file;
					}
				}

				if ( ! $file ) {
					$skipped++;
					continue;
				}

				$converted_files = array();
				$method          = new ReflectionMethod( $converter, 'convert_file_to_webp' );
				$method->setAccessible( true );

				if ( $method->invoke( $converter, $file ) ) {
					$converted_files[] = basename( $file );
					$converted++;
				}

				$metadata = wp_get_attachment_metadata( $attachment_id );
				if ( ! empty( $metadata['sizes'] ) ) {
					$base_dir = trailingslashit( dirname( $file ) );
					foreach ( $metadata['sizes'] as $size_key => $size ) {
						if ( empty( $size['file'] ) || false !== strpos( $size_key, '-webp' ) ) {
							continue;
						}
						$size_file = $base_dir . $size['file'];
						if ( ! file_exists( $size_file ) ) {
							$size_url = trailingslashit( dirname( wp_get_attachment_url( $attachment_id ) ) ) . $size['file'];
							$dl       = $this->fetch_to_path( $size_url, $size_file );
							if ( $dl ) {
								$temp_files[] = $size_file;
							}
						}
						if ( file_exists( $size_file ) && $method->invoke( $converter, $size_file ) ) {
							$converted_files[] = basename( $size_file );
						}
					}
				}

				if ( ! empty( $converted_files ) && is_array( $metadata ) ) {
					$remember = new ReflectionMethod( $converter, 'remember_webp_files' );
					$remember->setAccessible( true );
					$remember->invoke( $converter, $attachment_id, $converted_files );

					$inject = new ReflectionMethod( $converter, 'inject_webp_size_entries' );
					$inject->setAccessible( true );
					$metadata = $inject->invoke( $converter, $metadata, $file, $converted_files );

					wp_update_attachment_metadata( $attachment_id, $metadata );
				}

				foreach ( $temp_files as $tmp ) {
					if ( file_exists( $tmp ) ) {
						@unlink( $tmp ); // phpcs:ignore
					}
				}
			} catch ( \Throwable $e ) {
				$errors++;
				WP_CLI::warning( "Error on attachment $attachment_id: " . $e->getMessage() );
			}
		}

		$progress->finish();

		if ( $dry_run ) {
			WP_CLI::success( "Dry run complete. $total image(s) would be processed." );
			return;
		}

		WP_CLI::success( sprintf(
			'Done. Converted: %d | Skipped: %d | Errors: %d',
			$converted,
			$skipped,
			$errors
		) );
	}

	private function get_file( $converter, $attachment_id ) {
		$relative = get_post_meta( $attachment_id, '_wp_attached_file', true );
		if ( ! $relative ) {
			return false;
		}
		if ( path_is_absolute( $relative ) ) {
			return $relative;
		}
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['basedir'] ) . $relative;
	}

	private function download_file( $attachment_id, $expected_path ) {
		$url = wp_get_attachment_url( $attachment_id );
		if ( ! $url ) {
			return false;
		}
		if ( ! $expected_path ) {
			$relative     = get_post_meta( $attachment_id, '_wp_attached_file', true );
			$upload_dir   = wp_upload_dir();
			$expected_path = trailingslashit( $upload_dir['basedir'] ) . $relative;
		}
		return $this->fetch_to_path( $url, $expected_path );
	}

	private function fetch_to_path( $url, $path ) {
		$dir = dirname( $path );
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		$response = wp_remote_get( $url, array( 'timeout' => 60 ) );
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}
		$written = file_put_contents( $path, wp_remote_retrieve_body( $response ) ); // phpcs:ignore
		return $written ? $path : false;
	}
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command( 'p4pb', 'P4PB_CLI' );
}
