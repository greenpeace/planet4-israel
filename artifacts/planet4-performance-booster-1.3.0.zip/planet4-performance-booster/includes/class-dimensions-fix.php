<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Injects explicit width/height attributes into <img> tags that are missing
 * them, using WordPress attachment metadata as the source of truth.
 *
 * WHY: images without explicit dimensions cause Cumulative Layout Shift (CLS)
 * because the browser doesn't know how much space to reserve while the image
 * downloads, so the page "jumps" as the image loads. Browsers reserve the
 * correct space when width + height are present (even if CSS resizes the
 * image later - the aspect ratio is used, not the literal pixel values).
 *
 * HOW: we run a regex over the_content output looking for
 * <img class="... wp-image-{ID} ..."> tags that lack width= or height=.
 * For each one, we look up the attachment metadata (using a pre-warmed
 * object cache to avoid N+1 queries), find the size entry that matches the
 * src filename, and inject the correct dimensions. Runs at priority 19,
 * just before the WebP converter wraps the same img at priority 20.
 *
 * NOTE: if your theme resizes images with CSS (e.g. img { width: 100%; })
 * and you rely on the browser letting the image be taller than the reserved
 * height, verify that CLS doesn't get worse after enabling this. In practice,
 * setting width/height never breaks responsive CSS - aspect-ratio is always
 * used, not the raw pixel value.
 */
class P4PB_Dimensions_Fix {

	private $settings;

	public function __construct( array $settings ) {
		$this->settings = $settings;

		if ( empty( $settings['dimensions_fix_enabled'] ) ) {
			return;
		}

		// Priority 19: runs just before the WebP converter (priority 20) so
		// the dimensions are on the img before it gets wrapped in <picture>.
		add_filter( 'the_content',        array( $this, 'inject_dimensions' ), 19 );
		add_filter( 'post_thumbnail_html', array( $this, 'inject_dimensions' ), 19 );
	}

	public function inject_dimensions( $html ) {
		if ( false === strpos( $html, 'wp-image-' ) ) {
			return $html;
		}

		// Pre-warm the object cache with all attachment IDs found in this HTML
		// so each get_post_meta() below is a cache hit, not a DB query.
		$this->prime_meta_cache( $html );

		return preg_replace_callback(
			'/<img\b[^>]*>/i',
			array( $this, 'maybe_inject_dimensions' ),
			$html
		);
	}

	private function maybe_inject_dimensions( $matches ) {
		$tag = $matches[0];

		// Skip images that already have both dimensions.
		$has_width  = (bool) preg_match( '/\bwidth=["\'\d]/i', $tag );
		$has_height = (bool) preg_match( '/\bheight=["\'\d]/i', $tag );
		if ( $has_width && $has_height ) {
			return $tag;
		}

		if ( ! preg_match( '/\bwp-image-(\d+)\b/', $tag, $id_match ) ) {
			return $tag;
		}

		$attachment_id = (int) $id_match[1];
		$meta          = wp_get_attachment_metadata( $attachment_id );

		if ( empty( $meta ) ) {
			return $tag;
		}

		// Try to find the size that matches the src URL's filename.
		$width  = 0;
		$height = 0;

		if ( preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $tag, $src_match ) ) {
			$basename = basename( wp_parse_url( $src_match[1], PHP_URL_PATH ) );

			// Check registered sizes first.
			if ( ! empty( $meta['sizes'] ) ) {
				foreach ( $meta['sizes'] as $size ) {
					if ( isset( $size['file'] ) && $size['file'] === $basename
						&& ! empty( $size['width'] ) && ! empty( $size['height'] ) ) {
						$width  = (int) $size['width'];
						$height = (int) $size['height'];
						break;
					}
				}
			}

			// Fallback: full-size dimensions if src matches the original file.
			if ( ! $width && ! empty( $meta['file'] ) && basename( $meta['file'] ) === $basename ) {
				$width  = isset( $meta['width'] )  ? (int) $meta['width']  : 0;
				$height = isset( $meta['height'] ) ? (int) $meta['height'] : 0;
			}

			// Last resort: full-size dimensions unconditionally (avoids CLS
			// even if the exact size can't be matched - browser uses aspect
			// ratio, not literal pixel values, when CSS resizes the image).
			if ( ! $width && ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) {
				$width  = (int) $meta['width'];
				$height = (int) $meta['height'];
			}
		}

		if ( ! $width || ! $height ) {
			return $tag;
		}

		if ( ! $has_width ) {
			$tag = preg_replace( '/<img\s/i', '<img width="' . $width . '" ', $tag, 1 );
		}
		if ( ! $has_height ) {
			$tag = preg_replace( '/<img\s/i', '<img height="' . $height . '" ', $tag, 1 );
		}

		return $tag;
	}

	/**
	 * Primes the WP object cache with attachment post-meta for every
	 * wp-image-{ID} found in the HTML, so subsequent get_post_meta() calls
	 * within the same request are served from cache instead of hitting MySQL.
	 */
	private function prime_meta_cache( $html ) {
		preg_match_all( '/\bwp-image-(\d+)\b/', $html, $id_matches );
		if ( empty( $id_matches[1] ) ) {
			return;
		}
		$ids = array_map( 'intval', array_unique( $id_matches[1] ) );
		update_meta_cache( 'post', $ids );
	}
}
