<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fixes the LCP (Largest Contentful Paint) issue: the hero/carousel image has
 * no fetchpriority hint and no <link rel=preload>, so the browser starts
 * downloading it late. This class:
 *   1. Finds the LCP candidate image in the rendered HTML (carousel first, then
 *      a large-class fallback when lcp_all_pages is enabled).
 *   2. Removes loading="lazy" from it (it must never lazy-load).
 *   3. Adds fetchpriority="high".
 *   4. Injects a matching <link rel="preload" as="image"> into <head>.
 */
class P4PB_LCP_Fix {

	private $settings;
	private $preload_markup = '';

	public function __construct( array $settings ) {
		$this->settings = $settings;

		if ( empty( $settings['lcp_fix_enabled'] ) ) {
			return;
		}

		add_action( 'template_redirect', array( $this, 'maybe_start_buffer' ), 1 );
	}

	public function maybe_start_buffer() {
		$all_pages = ! empty( $this->settings['lcp_all_pages'] );

		if ( ! $all_pages && ! is_front_page() && ! is_home() ) {
			return;
		}

		ob_start( array( $this, 'process_buffer' ) );
	}

	public function process_buffer( $html ) {
		if ( empty( $html ) ) {
			return $html;
		}

		$img_tag = $this->find_lcp_image( $html );

		if ( ! $img_tag ) {
			return $html;
		}

		$fixed_img = $this->fix_img_tag( $img_tag );

		if ( $fixed_img !== $img_tag ) {
			$html = substr_replace( $html, $fixed_img, strpos( $html, $img_tag ), strlen( $img_tag ) );
		}

		$this->build_preload_tag( $fixed_img );

		if ( $this->preload_markup ) {
			$html = str_replace( '</head>', $this->preload_markup . "\n</head>", $html );
		}

		return $html;
	}

	/**
	 * Returns the raw <img> tag of the most likely LCP candidate.
	 * Strategy 1: active carousel slide (homepage / pages with a header carousel).
	 * Strategy 2 (lcp_all_pages only): first <img> with a WP "large" size class.
	 *
	 * @param string $html Full page HTML.
	 * @return string|false
	 */
	private function find_lcp_image( $html ) {
		// Strategy 1: carousel active item.
		if ( preg_match( '/<li[^>]*class="[^"]*carousel-item active[^"]*"[^>]*>.*?(<img\b[^>]*>)/is', $html, $m ) ) {
			return $m[1];
		}

		// Strategy 2: any page - first image with full/large/hero size class.
		if ( ! empty( $this->settings['lcp_all_pages'] ) ) {
			if ( preg_match( '/<img\b[^>]*class="[^"]*\b(?:size-full|size-large|wp-post-image|hero-image)\b[^"]*"[^>]*>/i', $html, $m ) ) {
				return $m[0];
			}
		}

		return false;
	}

	private function fix_img_tag( $img_tag ) {
		// Strip loading="lazy" (case-insensitive, single or double quotes).
		$img_tag = preg_replace( '/\sloading=["\']lazy["\']/i', '', $img_tag );

		// Add fetchpriority="high" if it isn't already set.
		if ( false === stripos( $img_tag, 'fetchpriority' ) ) {
			$img_tag = preg_replace( '/<img\s/i', '<img fetchpriority="high" ', $img_tag, 1 );
		}

		// Force decoding="async" -> keep as is if present, otherwise leave;
		// not touching decoding since it's already correct in the source markup.

		return $img_tag;
	}

	private function build_preload_tag( $img_tag ) {
		if ( ! preg_match( '/\ssrc=["\']([^"\']+)["\']/i', $img_tag, $src_match ) ) {
			return;
		}
		$src = esc_url( $src_match[1] );

		$srcset_attr = '';
		if ( preg_match( '/\ssrcset=["\']([^"\']+)["\']/i', $img_tag, $srcset_match ) ) {
			$srcset_attr = ' imagesrcset="' . esc_attr( $srcset_match[1] ) . '"';
		}

		$sizes_attr = '';
		if ( preg_match( '/\ssizes=["\']([^"\']+)["\']/i', $img_tag, $sizes_match ) ) {
			$sizes_attr = ' imagesizes="' . esc_attr( $sizes_match[1] ) . '"';
		}

		$this->preload_markup = sprintf(
			'<link rel="preload" as="image" href="%s" fetchpriority="high"%s%s>',
			$src,
			$srcset_attr,
			$sizes_attr
		);
	}
}
