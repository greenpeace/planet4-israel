<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prints <link rel="preconnect"> + <link rel="dns-prefetch"> hints for
 * configured third-party domains in the <head> of every front-end page.
 *
 * A preconnect hint eliminates the DNS + TLS round-trip (~150-300 ms per
 * domain) for origins the browser will definitely need but hasn't connected
 * to yet. dns-prefetch is the lighter fallback for browsers that don't
 * support preconnect.
 *
 * Only add domains here that will definitely be used on every (or nearly
 * every) page - speculative preconnects for rarely-used domains waste
 * connections and can slightly slow things down.
 */
class P4PB_Preconnect {

	private $settings;

	public function __construct( array $settings ) {
		$this->settings = $settings;

		if ( empty( $settings['preconnect_enabled'] ) || empty( $settings['preconnect_domains'] ) ) {
			return;
		}

		add_action( 'wp_head', array( $this, 'print_hints' ), 2 );
	}

	public function print_hints() {
		$raw     = $this->settings['preconnect_domains'];
		$domains = array_filter( array_map( 'trim', explode( "\n", $raw ) ) );

		if ( empty( $domains ) ) {
			return;
		}

		foreach ( $domains as $domain ) {
			// Normalise: strip scheme if the user pasted a full URL.
			$domain = preg_replace( '#^https?://#i', '', $domain );
			$domain = rtrim( $domain, '/' );

			if ( ! $domain ) {
				continue;
			}

			$origin = 'https://' . $domain;
			printf(
				'<link rel="preconnect" href="%s" crossorigin>' . "\n",
				esc_url( $origin )
			);
			printf(
				'<link rel="dns-prefetch" href="%s">' . "\n",
				esc_url( '//' . $domain )
			);
		}
	}
}
