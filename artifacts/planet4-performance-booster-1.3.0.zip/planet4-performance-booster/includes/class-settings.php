<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central settings store. Everything is kept in a single wp_options row
 * (option name: p4pb_settings) so activation/export/import stays simple.
 */
class P4PB_Settings {

	const OPTION_KEY = 'p4pb_settings';

	private static $cache = null;

	/**
	 * Known third-party services detected on the Israel homepage via HAR/PageSpeed
	 * analysis (July 2026). "patterns" match against the script's src URL.
	 * Mode default is what we recommend out of the box - conservative (delay,
	 * not block) for anything the team may still want data from.
	 */
	public static function known_services() {
		return array(
			'gtm'       => array(
				'label'    => 'Google Tag Manager (incl. gtag.js, Google Ads, GA4)',
				'patterns' => array( 'googletagmanager.com' ),
				'default'  => 'delay',
			),
			'hotjar'    => array(
				'label'    => 'Hotjar',
				'patterns' => array( 'hotjar.com' ),
				'default'  => 'delay',
			),
			'facebook'  => array(
				'label'    => 'Facebook Pixel',
				'patterns' => array( 'connect.facebook.net', 'facebook.com/tr' ),
				'default'  => 'delay',
			),
			'tiktok'    => array(
				'label'    => 'TikTok Pixel',
				'patterns' => array( 'analytics.tiktok.com' ),
				'default'  => 'delay',
			),
			'twitter'   => array(
				'label'    => 'Twitter / X Ads',
				'patterns' => array( 'ads-twitter.com', 'analytics.twitter.com', 't.co/i/adsct' ),
				'default'  => 'delay',
			),
			'clarity'   => array(
				'label'    => 'Microsoft Clarity',
				'patterns' => array( 'clarity.ms' ),
				'default'  => 'delay',
			),
			'optimonk'  => array(
				'label'    => 'OptiMonk (popups)',
				'patterns' => array( 'optimonk.com' ),
				'default'  => 'delay',
			),
			'hubspot'   => array(
				'label'    => 'HubSpot (tracking + forms)',
				'patterns' => array( 'hubspot.com', 'hs-scripts.com', 'hs-banner.com', 'hsadspixel.net', 'hsforms.com', 'hubapi.com' ),
				'default'  => 'delay',
			),
			'outbrain'  => array(
				'label'    => 'Outbrain',
				'patterns' => array( 'outbrain.com' ),
				'default'  => 'delay',
			),
			'vwo'       => array(
				'label'    => 'VWO (Visual Website Optimizer)',
				'patterns' => array( 'visualwebsiteoptimizer.com' ),
				'default'  => 'delay',
			),
			'doubleclick' => array(
				'label'    => 'Google Ads / DoubleClick remarketing',
				'patterns' => array( 'doubleclick.net', 'google.com/pagead', 'google.com/ccm', 'googleadservices.com' ),
				'default'  => 'delay',
			),
			'sentry'    => array(
				'label'    => 'Sentry (error monitoring) - recommended to leave active',
				'patterns' => array( 'sentry.io' ),
				'default'  => 'normal',
			),
			'tabnav'    => array(
				'label'    => 'TabNav widget',
				'patterns' => array( 'tabnav.com' ),
				'default'  => 'delay',
			),
		);
	}

	public static function defaults() {
		$services = array();
		foreach ( self::known_services() as $key => $svc ) {
			$services[ $key ] = $svc['default'];
		}

		return array(
			// Third-party scripts
			'services'               => $services,
			'gtm_blocked_ids'        => '',
			'delay_timeout'          => 8,

			// LCP fix
			'lcp_fix_enabled'        => true,
			'lcp_all_pages'          => false,

			// WebP
			'webp_enabled'           => true,
			'webp_quality'           => 82,

			// Preconnect hints (new in 1.3.0)
			'preconnect_enabled'     => true,
			'preconnect_domains'     => "fonts.googleapis.com\nfonts.gstatic.com\ngoogletagmanager.com\nconnect.facebook.net",

			// Image dimensions / CLS fix (new in 1.3.0)
			'dimensions_fix_enabled' => true,

			// Font display
			'font_swap_enabled'      => true,
			'font_swap_handles'      => '',
		);
	}

	public static function get() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}
		$saved       = get_option( self::OPTION_KEY, array() );
		self::$cache = wp_parse_args( $saved, self::defaults() );
		return self::$cache;
	}

	public static function update( array $new_values ) {
		$current     = self::get();
		$merged      = array_merge( $current, $new_values );
		update_option( self::OPTION_KEY, $merged );
		self::$cache = $merged;
		return $merged;
	}

	public static function on_activate() {
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			update_option( self::OPTION_KEY, self::defaults() );
		}
	}
}
