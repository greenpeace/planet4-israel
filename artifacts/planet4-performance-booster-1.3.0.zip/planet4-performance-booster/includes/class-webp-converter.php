<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generates WebP copies of uploaded images (original + every registered
 * intermediate size) and serves them to browsers that support WebP.
 *
 * IMPORTANT (v1.1.0): The Israel site offloads media to Google Cloud
 * Storage (WP-Stateless) and serves it from a separate static/CDN domain
 * (www.greenpeace.org/static/...), not from this server's own Apache. That
 * means:
 *   - A `.htaccess` rewrite rule has ZERO effect on those requests - it only
 *     controls what this server does, and this server never receives the
 *     request for an offloaded image. The manual "insert .htaccess rule"
 *     tool is kept for the (rare) case media isn't offloaded, but WebP
 *     delivery no longer depends on it.
 *   - Reading files through the filtered `get_attached_file()` can trigger
 *     the offload plugin's own remote-lookup logic, which is slow and, for
 *     a batch of many images, can exceed PHP's execution time limit and
 *     surface to the admin as a generic AJAX "network error". We instead
 *     resolve the on-disk path ourselves from `_wp_attached_file` + the raw
 *     (unfiltered) uploads base dir, which is fast and side-effect free.
 *   - Because the offloaded copy - not the local disk copy - is what
 *     actually gets served, a locally generated `.webp` file is invisible
 *     to visitors until it's synced to storage too. We piggyback on that
 *     sync by injecting synthetic entries into the attachment's `sizes`
 *     metadata (offload/CDN-sync plugins upload whatever is listed there),
 *     and by re-saving metadata via `wp_update_attachment_metadata()` for
 *     images processed through the "convert existing images" batch tool.
 *   - Delivery itself uses a `<picture>` + `<source type="image/webp">`
 *     wrapper around content images, so the browser - not the server or a
 *     rewrite rule - decides which file to request. This works identically
 *     whether images live on local disk or on a CDN/bucket domain.
 *   - The original <img> tag (including its alt attribute) is always kept
 *     verbatim as the last child of the <picture>, so alt text and
 *     accessibility are fully preserved. The <source> element does not carry
 *     alt (only <img> does - that is correct HTML).
 *   - For the batch "convert existing images" tool: when a local file is
 *     absent (WP-Stateless in stateless mode deletes local copies after
 *     syncing to GCS), the batch handler downloads the image from its public
 *     CDN URL, converts it in a temporary location, then saves the .webp
 *     next to where the original would live and calls
 *     wp_update_attachment_metadata() to trigger the offload plugin's
 *     normal GCS sync. The downloaded original is deleted afterwards.
 */
class P4PB_Webp_Converter {

	private $settings;

	const HTACCESS_MARKER  = 'P4PB WebP';
	const WEBP_FILES_META  = '_p4pb_webp_files';

	public function __construct( array $settings ) {
		$this->settings = $settings;

		if ( empty( $settings['webp_enabled'] ) ) {
			return;
		}

		// Priority 5: run before WP-Stateless (priority 10) so the local file
		// still exists when we convert it. On new uploads WP-Stateless deletes
		// the local copy after syncing; at priority 20 we would arrive too late.
		add_filter( 'wp_generate_attachment_metadata', array( $this, 'generate_webp_for_attachment' ), 5, 2 );

		add_action( 'wp_ajax_p4pb_regenerate_webp_batch', array( $this, 'ajax_regenerate_batch' ) );
		add_action( 'wp_ajax_p4pb_insert_htaccess_rule', array( $this, 'ajax_insert_htaccess_rule' ) );

		// Front-end (and REST-rendered) delivery via <picture>, independent
		// of how/where the image is actually hosted.
		add_filter( 'the_content', array( $this, 'filter_the_content' ), 20 );
		add_filter( 'post_thumbnail_html', array( $this, 'filter_post_thumbnail_html' ), 20 );

		// JS fallback: when a <source type="image/webp"> fails to load (e.g.
		// the file wasn't synced to CDN yet), Chrome sometimes doesn't fall
		// back to the <img> on its own. This inline script detects the failure
		// and swaps the <picture> back to just the <img>.
		add_action( 'wp_footer', array( $this, 'print_fallback_script' ) );
	}

	/**
	 * Best-effort detection of a cloud storage offload plugin, used only to
	 * show an accurate hint in the admin UI (the actual conversion/serving
	 * logic below works correctly whether or not one is detected).
	 */
	public static function detect_offload_plugin() {
		if ( function_exists( 'ud_get_stateless_media' ) || defined( 'WP_STATELESS_MEDIA_VERSION' ) ) {
			return 'WP-Stateless (Google Cloud Storage)';
		}
		if ( defined( 'AS3CF_SETTINGS' ) || class_exists( 'DeliciousBrains\\WP_Offload_Media\\Items\\Item' ) ) {
			return 'WP Offload Media';
		}
		return false;
	}

	/**
	 * Hooked into the standard WP metadata pipeline, so this runs right
	 * after core generates the various thumbnail sizes for a new upload -
	 * and, importantly, BEFORE WordPress calls wp_update_attachment_metadata()
	 * a moment later, which is what triggers most offload plugins' sync to
	 * remote storage. Any synthetic "sizes" entries we add here get synced
	 * automatically as part of that normal flow.
	 */
	public function generate_webp_for_attachment( $metadata, $attachment_id ) {
		$file     = $this->get_raw_attached_file( $attachment_id );
		$tmp_files = array(); // temp downloads to clean up after conversion.

		if ( ! $file ) {
			return $metadata;
		}

		// In WP-Stateless "stateless" mode the local file is never written to
		// disk - files go straight to GCS during the upload handler, before this
		// filter fires. If the local file is absent, download it from its public
		// URL to a temp path so we can convert it, then clean up afterwards.
		if ( ! file_exists( $file ) ) {
			$url = wp_get_attachment_url( $attachment_id );
			if ( $url && $this->is_image_url( $url ) ) {
				$fetched = $this->fetch_to_expected_path( $attachment_id, $file );
				if ( $fetched ) {
					$tmp_files[] = $file;
				}
			}
		}

		if ( ! $this->is_convertible( $file ) ) {
			return $metadata;
		}

		$converted_files = array();

		if ( $this->convert_file_to_webp( $file ) ) {
			$converted_files[] = basename( $file );
		}

		if ( ! empty( $metadata['sizes'] ) && ! empty( $metadata['file'] ) ) {
			$base_dir = trailingslashit( dirname( $file ) );
			foreach ( $metadata['sizes'] as $size_key => $size ) {
				if ( empty( $size['file'] ) || false !== strpos( $size_key, '-webp' ) ) {
					continue;
				}
				$size_file = $base_dir . $size['file'];

				// Download size file too if absent (stateless mode).
				if ( ! file_exists( $size_file ) && isset( $size['mime-type'] ) ) {
					$size_url = $this->get_size_url( $attachment_id, $size );
					if ( $size_url ) {
						$fetched = $this->fetch_file_to_path( $size_url, $size_file );
						if ( $fetched ) {
							$tmp_files[] = $size_file;
						}
					}
				}

				if ( $this->is_convertible( $size_file ) && $this->convert_file_to_webp( $size_file ) ) {
					$converted_files[] = basename( $size_file );
				}
			}
		}

		// Clean up any temp originals we downloaded (keep the .webp files).
		$this->cleanup_temp_files( $tmp_files );

		if ( empty( $converted_files ) ) {
			return $metadata;
		}

		$this->remember_webp_files( $attachment_id, $converted_files );
		$metadata = $this->inject_webp_size_entries( $metadata, $file, $converted_files );

		return $metadata;
	}

	private function is_image_url( $url ) {
		$ext = strtolower( pathinfo( parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
		return in_array( $ext, array( 'jpg', 'jpeg', 'png' ), true );
	}

	private function is_convertible( $file ) {
		if ( ! file_exists( $file ) ) {
			return false;
		}
		$ext = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
		return in_array( $ext, array( 'jpg', 'jpeg', 'png' ), true );
	}

	/**
	 * Converts a single image file to a sibling .webp file. Prefers Imagick
	 * (better compression/quality control) and falls back to GD, which
	 * ships with virtually every PHP install.
	 *
	 * @return bool True on success.
	 */
	public function convert_file_to_webp( $file ) {
		$webp_path = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );

		if ( file_exists( $webp_path ) && filemtime( $webp_path ) >= filemtime( $file ) ) {
			return true; // Already converted and up to date.
		}

		$quality = isset( $this->settings['webp_quality'] ) ? (int) $this->settings['webp_quality'] : 82;

		if ( class_exists( 'Imagick' ) ) {
			try {
				$image = new Imagick( $file );
				$image->setImageFormat( 'webp' );
				$image->setImageCompressionQuality( $quality );
				$image->stripImage(); // Drop EXIF/metadata - smaller file, same as most optimizers.
				$result = $image->writeImage( $webp_path );
				$image->clear();
				$image->destroy();
				return (bool) $result;
			} catch ( Exception $e ) {
				// Fall through to GD attempt below.
			}
		}

		if ( function_exists( 'imagewebp' ) ) {
			$ext = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
			$src = null;

			if ( in_array( $ext, array( 'jpg', 'jpeg' ), true ) && function_exists( 'imagecreatefromjpeg' ) ) {
				$src = @imagecreatefromjpeg( $file ); // phpcs:ignore
			} elseif ( 'png' === $ext && function_exists( 'imagecreatefrompng' ) ) {
				$src = @imagecreatefrompng( $file ); // phpcs:ignore
				if ( $src ) {
					imagepalettetotruecolor( $src );
					imagealphablending( $src, true );
					imagesavealpha( $src, true );
				}
			}

			if ( $src ) {
				$result = imagewebp( $src, $webp_path, $quality );
				imagedestroy( $src );
				return (bool) $result;
			}
		}

		return false;
	}

	/**
	 * Resolves an attachment's on-disk path directly from `_wp_attached_file`
	 * and the raw (unfiltered) uploads base dir, bypassing the
	 * `get_attached_file` filter chain entirely. Offload plugins commonly
	 * hook that filter to check/download from remote storage, which is
	 * unnecessary overhead here (we only care whether a local copy exists
	 * right now) and, at batch scale, is the likely cause of AJAX requests
	 * timing out ("network error") in the "convert existing images" tool.
	 */
	private function get_raw_attached_file( $attachment_id ) {
		$relative = get_post_meta( $attachment_id, '_wp_attached_file', true );
		if ( ! $relative ) {
			return false;
		}
		if ( path_is_absolute( $relative ) ) {
			return $relative;
		}
		return trailingslashit( $this->get_raw_uploads_basedir() ) . $relative;
	}

	/**
	 * Same as wp_upload_dir()'s basedir, but with every 'upload_dir' filter
	 * temporarily removed - so offload plugins (which commonly remap this)
	 * can't change the answer. Uses WP core's own resolution logic (so
	 * multisite subdirectories etc. are still handled correctly), just
	 * without third-party interference.
	 */
	private function get_raw_uploads_basedir() {
		global $wp_filter;

		$saved = null;
		if ( isset( $wp_filter['upload_dir'] ) ) {
			$saved                     = $wp_filter['upload_dir'];
			$wp_filter['upload_dir']   = new WP_Hook();
		}

		$dir = wp_upload_dir( null, false );

		if ( null !== $saved ) {
			$wp_filter['upload_dir'] = $saved;
		}

		return $dir['basedir'];
	}

	private function remember_webp_files( $attachment_id, array $new_files ) {
		$existing = get_post_meta( $attachment_id, self::WEBP_FILES_META, true );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}
		$merged = array_values( array_unique( array_merge( $existing, $new_files ) ) );
		update_post_meta( $attachment_id, self::WEBP_FILES_META, $merged );
	}

	/**
	 * Adds synthetic `sizes` entries (mime-type image/webp) for every
	 * successfully converted file, so any code that walks $metadata['sizes']
	 * to sync files to remote/CDN storage - which is exactly how offload
	 * plugins decide what to upload - picks up the WebP copies too, without
	 * needing any offload-plugin-specific integration code.
	 */
	private function inject_webp_size_entries( array $metadata, $original_file, array $converted_files ) {
		$original_basename = basename( $original_file );

		foreach ( $converted_files as $filename ) {
			$webp_filename = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $filename );

			if ( $filename === $original_basename ) {
				$size_key = 'full-webp';
				$width    = isset( $metadata['width'] ) ? $metadata['width'] : 0;
				$height   = isset( $metadata['height'] ) ? $metadata['height'] : 0;
			} else {
				$size_key = false;
				$width    = 0;
				$height   = 0;
				if ( ! empty( $metadata['sizes'] ) ) {
					foreach ( $metadata['sizes'] as $key => $size ) {
						if ( isset( $size['file'] ) && $size['file'] === $filename ) {
							$size_key = $key . '-webp';
							$width    = isset( $size['width'] ) ? $size['width'] : 0;
							$height   = isset( $size['height'] ) ? $size['height'] : 0;
							break;
						}
					}
				}
				if ( ! $size_key ) {
					continue; // Couldn't map it back to a known size - skip rather than guess.
				}
			}

			$webp_path = trailingslashit( dirname( $original_file ) ) . $webp_filename;

			$metadata['sizes'][ $size_key ] = array(
				'file'      => $webp_filename,
				'width'     => $width,
				'height'    => $height,
				'mime-type' => 'image/webp',
				'filesize'  => file_exists( $webp_path ) ? filesize( $webp_path ) : 0,
			);
		}

		return $metadata;
	}

	/**
	 * AJAX: converts a batch of already-uploaded media library images that
	 * predate this plugin. Called repeatedly from admin JS with a rolling
	 * offset until it reports done=true.
	 */
	public function ajax_regenerate_batch() {
		check_ajax_referer( 'p4pb_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		// Give ourselves headroom on slower hosts, but never crash the
		// whole request if the host doesn't allow changing it.
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 60 ); // phpcs:ignore
		}

		$offset     = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
		$batch_size = 5; // Kept small on purpose - see class docblock re: AJAX timeouts.

		$attachments = get_posts( array(
			'post_type'      => 'attachment',
			'post_mime_type' => array( 'image/jpeg', 'image/png' ),
			'post_status'    => 'inherit',
			'posts_per_page' => $batch_size,
			'offset'         => $offset,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
		) );

		$converted = 0;
		$errors    = array();

		foreach ( $attachments as $attachment_id ) {
			try {
				$file         = $this->get_raw_attached_file( $attachment_id );
				$temp_files   = array(); // Track any temp downloads to clean up.

				// Local file is absent - this is normal in WP-Stateless "stateless"
				// mode where local copies are deleted after GCS sync. Fall back to
				// downloading the full-size image from its public CDN URL so we can
				// convert it. The download is saved to the expected on-disk path
				// (creating the directory if needed) so that inject_webp_size_entries
				// can place the .webp alongside it and wp_update_attachment_metadata
				// triggers WP-Stateless's normal GCS sync for the new .webp file.
				if ( ! $file || ! file_exists( $file ) ) {
					$file = $this->fetch_to_expected_path( $attachment_id, $file );
					if ( $file ) {
						$temp_files[] = $file; // Remember to delete the downloaded original.
					}
				}

				if ( ! $file || ! $this->is_convertible( $file ) ) {
					$this->cleanup_temp_files( $temp_files );
					continue;
				}

				$converted_files = array();
				if ( $this->convert_file_to_webp( $file ) ) {
					$converted_files[] = basename( $file );
					$converted++;
				}

				$metadata = wp_get_attachment_metadata( $attachment_id );
				if ( ! empty( $metadata['sizes'] ) ) {
					$base_dir = trailingslashit( dirname( $file ) );
					foreach ( $metadata['sizes'] as $size_key => $size ) {
						if ( empty( $size['file'] ) || false !== strpos( $size_key, '-webp' ) ) {
							continue;
						}
						$size_file = $base_dir . $size['file'];

						// Size file also absent (stateless) — download it too.
						if ( ! file_exists( $size_file ) ) {
							$size_url      = $this->get_size_url( $attachment_id, $size );
							$downloaded    = $size_url ? $this->fetch_file_to_path( $size_url, $size_file ) : false;
							if ( $downloaded ) {
								$temp_files[] = $size_file;
							}
						}

						if ( $this->is_convertible( $size_file ) && $this->convert_file_to_webp( $size_file ) ) {
							$converted_files[] = basename( $size_file );
						}
					}
				}

				if ( ! empty( $converted_files ) && is_array( $metadata ) ) {
					$this->remember_webp_files( $attachment_id, $converted_files );
					$metadata = $this->inject_webp_size_entries( $metadata, $file, $converted_files );
					// Existing attachments already went through their one-time
					// wp_generate_attachment_metadata pass long ago, so we must
					// explicitly re-save metadata to trigger any offload/CDN
					// plugin's sync-to-remote-storage hook for the new WebP files.
					wp_update_attachment_metadata( $attachment_id, $metadata );
				}

				// Remove any temporarily downloaded originals (keep the .webp files
				// so WP-Stateless can finish syncing them to GCS asynchronously).
				$this->cleanup_temp_files( $temp_files );

			} catch ( \Throwable $e ) {
				$errors[] = $attachment_id;
				continue; // Never let one bad image fail the whole batch/response.
			}
		}

		wp_send_json_success( array(
			'processed'   => count( $attachments ),
			'converted'   => $converted,
			'errors'      => count( $errors ),
			'done'        => count( $attachments ) < $batch_size,
			'next_offset' => $offset + count( $attachments ),
		) );
	}

	/**
	 * AJAX: safely inserts (or updates) the Apache rewrite block that
	 * serves .webp automatically, using WP core's insert_with_markers()
	 * so re-running it never duplicates or corrupts the file.
	 *
	 * NOTE: this only has any effect when images are served directly by
	 * this server from local disk. It does nothing for media served from a
	 * cloud storage / CDN domain (e.g. via WP-Stateless) - the <picture>
	 * based delivery below handles that case instead, automatically.
	 */
	public function ajax_insert_htaccess_rule() {
		check_ajax_referer( 'p4pb_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'forbidden', 403 );
		}

		if ( ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}

		$htaccess_path = trailingslashit( ABSPATH ) . '.htaccess';

		if ( ! is_writable( dirname( $htaccess_path ) ) && ! ( file_exists( $htaccess_path ) && is_writable( $htaccess_path ) ) ) {
			wp_send_json_error( 'not_writable' );
		}

		// Serves sibling "file.webp" instead of "file.jpg"/"file.png" whenever
		// the browser sends "Accept: image/webp" AND the .webp file exists -
		// falls straight through to the original file otherwise, so nothing
		// breaks for images that haven't been converted yet.
		$rules = array(
			'<IfModule mod_rewrite.c>',
			'RewriteEngine On',
			'RewriteCond %{HTTP_ACCEPT} image/webp',
			'RewriteCond %{REQUEST_FILENAME} \.(jpe?g|png)$',
			'RewriteCond %{REQUEST_FILENAME}.webp -f',
			'RewriteRule ^(.*)\.(jpe?g|png)$ $1.webp [T=image/webp,L]',
			'</IfModule>',
			'<IfModule mod_headers.c>',
			'<FilesMatch "\.(jpe?g|png)$">',
			'Header append Vary Accept',
			'</FilesMatch>',
			'</IfModule>',
		);

		$ok = insert_with_markers( $htaccess_path, self::HTACCESS_MARKER, $rules );

		if ( $ok ) {
			wp_send_json_success();
		}
		wp_send_json_error( 'write_failed' );
	}

	/**
	 * Wraps <img class="... wp-image-{ID} ..."> tags in post content with a
	 * <picture><source type="image/webp" ...> element, letting the browser
	 * itself choose which file to request. This is what actually makes the
	 * generated WebP files reach visitors on this site: it doesn't matter
	 * whether the image URL points at this server or at an offloaded
	 * CDN/bucket domain, since we only ever rewrite the *extension* of
	 * whatever URL is already in the markup.
	 */
	public function filter_the_content( $html ) {
		return $this->convert_images_to_picture( $html );
	}

	public function filter_post_thumbnail_html( $html ) {
		return $this->convert_images_to_picture( $html );
	}

	public function print_fallback_script() {
		?>
<script>
(function(){
	var pics = document.querySelectorAll('picture.p4pb-webp-picture');
	if (!pics.length) return;
	pics.forEach(function(p) {
		var src = p.querySelector('source[type="image/webp"]');
		var img = p.querySelector('img');
		if (!src || !img) return;
		var url = (src.getAttribute('srcset') || '').split(',')[0].trim().split(/\s+/)[0];
		if (!url) return;
		var probe = new Image();
		probe.onerror = function() {
			if (p.parentNode) p.parentNode.replaceChild(img, p);
		};
		probe.src = url;
	});
})();
</script>
		<?php
	}

	private function convert_images_to_picture( $html ) {
		if ( ( is_admin() && ! wp_doing_ajax() ) || false === strpos( $html, 'wp-image-' ) ) {
			return $html;
		}

		return preg_replace_callback(
			'/<img\b[^>]*>/i',
			array( $this, 'maybe_wrap_picture_tag' ),
			$html
		);
	}

	private function maybe_wrap_picture_tag( $matches ) {
		$tag = $matches[0];

		if ( ! preg_match( '/\bwp-image-(\d+)\b/', $tag, $id_match ) ) {
			return $tag;
		}

		$attachment_id = (int) $id_match[1];
		$webp_files    = get_post_meta( $attachment_id, self::WEBP_FILES_META, true );

		if ( empty( $webp_files ) || ! is_array( $webp_files ) ) {
			return $tag; // No known WebP variants for this attachment.
		}

		$webp_srcset = '';
		if ( preg_match( '/\ssrcset=(["\'])(.*?)\1/i', $tag, $srcset_match ) ) {
			$webp_candidates = array();
			foreach ( array_map( 'trim', explode( ',', $srcset_match[2] ) ) as $candidate ) {
				if ( '' === $candidate ) {
					continue;
				}
				$parts = preg_split( '/\s+/', $candidate );
				$url   = $parts[0];
				$descr = isset( $parts[1] ) ? ' ' . $parts[1] : '';
				if ( $this->url_has_webp( $url, $webp_files ) ) {
					$webp_candidates[] = $this->to_webp_url( $url ) . $descr;
				}
			}
			if ( ! empty( $webp_candidates ) ) {
				$webp_srcset = implode( ', ', $webp_candidates );
			}
		}

		$webp_src = '';
		if ( preg_match( '/\ssrc=(["\'])(.*?)\1/i', $tag, $src_match ) && $this->url_has_webp( $src_match[2], $webp_files ) ) {
			$webp_src = $this->to_webp_url( $src_match[2] );
		}

		if ( '' === $webp_srcset && '' === $webp_src ) {
			return $tag; // Nothing we can confidently serve as WebP - leave it alone.
		}

		$sizes_attr = '';
		if ( preg_match( '/\ssizes=(["\'])(.*?)\1/i', $tag, $sizes_match ) ) {
			$sizes_attr = ' sizes="' . esc_attr( $sizes_match[2] ) . '"';
		}

		$source = sprintf(
			'<source type="image/webp" srcset="%s"%s>',
			esc_attr( $webp_srcset ? $webp_srcset : $webp_src ),
			$sizes_attr
		);

		// display:contents makes the <picture> box-model-invisible: the browser
		// treats the <img> inside as if the <picture> wrapper doesn't exist, so
		// CSS rules that rely on the <img> being a direct child (e.g. float,
		// margin, block/flex layout) keep working without any theme changes.
		return '<picture class="p4pb-webp-picture" style="display:contents">' . $source . $tag . '</picture>';
	}

	private function url_has_webp( $url, array $webp_files ) {
		$path = wp_parse_url( $url, PHP_URL_PATH );
		if ( ! $path ) {
			return false;
		}
		return in_array( basename( $path ), $webp_files, true );
	}

	private function to_webp_url( $url ) {
		return preg_replace( '/\.(jpe?g|png)(\?.*)?$/i', '.webp$2', $url );
	}

	// -------------------------------------------------------------------------
	// Stateless / remote-file helpers
	// -------------------------------------------------------------------------

	/**
	 * Downloads an attachment's full-size image from its public URL to the
	 * expected on-disk path (creating the directory if needed). Returns the
	 * path on success, false on failure. Used by the batch tool when the local
	 * file is absent (e.g. WP-Stateless stateless mode).
	 *
	 * @param int         $attachment_id
	 * @param string|false $expected_path  Result of get_raw_attached_file(), may be false.
	 * @return string|false
	 */
	private function fetch_to_expected_path( $attachment_id, $expected_path ) {
		$url = wp_get_attachment_url( $attachment_id );
		if ( ! $url ) {
			return false;
		}

		// Resolve expected path from attachment meta if get_raw_attached_file() failed.
		if ( ! $expected_path ) {
			$relative = get_post_meta( $attachment_id, '_wp_attached_file', true );
			if ( ! $relative ) {
				return false;
			}
			$expected_path = trailingslashit( $this->get_raw_uploads_basedir() ) . $relative;
		}

		return $this->fetch_file_to_path( $url, $expected_path );
	}

	/**
	 * Downloads $url and writes the body to $dest_path (creating parent dirs).
	 * Returns $dest_path on success, false on any error.
	 *
	 * @param string $url
	 * @param string $dest_path
	 * @return string|false
	 */
	private function fetch_file_to_path( $url, $dest_path ) {
		$dir = dirname( $dest_path );
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		$response = wp_remote_get( $url, array(
			'timeout'   => 30,
			'sslverify' => true,
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== (int) $code ) {
			return false;
		}

		$body    = wp_remote_retrieve_body( $response );
		$written = file_put_contents( $dest_path, $body ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $written ) {
			return false;
		}

		return $dest_path;
	}

	/**
	 * Returns the public URL for a specific registered size of an attachment,
	 * suitable for downloading when the size file is not on local disk.
	 *
	 * @param int   $attachment_id
	 * @param array $size  One entry from $metadata['sizes'].
	 * @return string|false
	 */
	private function get_size_url( $attachment_id, array $size ) {
		if ( empty( $size['file'] ) ) {
			return false;
		}
		$full_url = wp_get_attachment_url( $attachment_id );
		if ( ! $full_url ) {
			return false;
		}
		return trailingslashit( dirname( $full_url ) ) . $size['file'];
	}

	/**
	 * Deletes a list of temporary files silently. WebP counterparts are NOT
	 * deleted — they must stay on disk until WP-Stateless syncs them to GCS.
	 *
	 * @param string[] $paths
	 */
	private function cleanup_temp_files( array $paths ) {
		foreach ( $paths as $path ) {
			if ( $path && file_exists( $path ) ) {
				@unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}
		}
	}
}
