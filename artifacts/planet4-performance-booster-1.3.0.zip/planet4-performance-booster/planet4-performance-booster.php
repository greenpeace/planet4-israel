<?php
/**
 * Plugin Name: Planet4 Performance Booster
 * Plugin URI: https://www.greenpeace.org/israel/
 * Description: Addresses performance issues on Planet4 - Israel: defers/blocks third-party scripts, fixes LCP priority, converts images to WebP, adds preconnect hints, fixes CLS via image dimensions, and patches font-display for self-hosted fonts.
 * Version: 1.3.0
 * Author: Greenpeace Israel Digital Team
 * Text Domain: p4-perf-booster
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'P4PB_VERSION', '1.3.0' );
define( 'P4PB_PLUGIN_FILE', __FILE__ );
define( 'P4PB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'P4PB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once P4PB_PLUGIN_DIR . 'includes/class-settings.php';
require_once P4PB_PLUGIN_DIR . 'includes/class-script-guard.php';
require_once P4PB_PLUGIN_DIR . 'includes/class-lcp-fix.php';
require_once P4PB_PLUGIN_DIR . 'includes/class-webp-converter.php';
require_once P4PB_PLUGIN_DIR . 'includes/class-font-display.php';
require_once P4PB_PLUGIN_DIR . 'includes/class-preconnect.php';
require_once P4PB_PLUGIN_DIR . 'includes/class-dimensions-fix.php';
require_once P4PB_PLUGIN_DIR . 'includes/class-cli.php';
require_once P4PB_PLUGIN_DIR . 'includes/class-admin-page.php';

/**
 * Main plugin bootstrap class. Instantiates all sub-modules based on saved
 * settings, so nothing runs unless it's actually configured to.
 */
final class P4_Performance_Booster {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );

		register_activation_hook( P4PB_PLUGIN_FILE, array( 'P4PB_Settings', 'on_activate' ) );
	}

	public function init() {
		$settings = P4PB_Settings::get();

		// Admin settings screen - always loaded in wp-admin.
		if ( is_admin() ) {
			new P4PB_Admin_Page();
		}

		// Front-end modules - each module checks its own "enabled" flag internally,
		// but we avoid instantiating anything unnecessary on the admin side.
		if ( ! is_admin() ) {
			new P4PB_Script_Guard( $settings );
			new P4PB_LCP_Fix( $settings );
			new P4PB_Font_Display( $settings );
			new P4PB_Preconnect( $settings );
			new P4PB_Dimensions_Fix( $settings );
		}

		// WebP conversion hooks into the media upload pipeline, needed everywhere
		// uploads can happen (admin + REST API), so it's not gated by is_admin().
		new P4PB_Webp_Converter( $settings );
	}
}

P4_Performance_Booster::instance();
