=== Planet4 Performance Booster ===
Version: 1.3.0
Built for: Greenpeace Israel (Planet4 / WordPress)
Based on: PageSpeed Insights + HAR analysis from 12.7.2026 (www-dev.greenpeace.org/israel)

Addresses six Core Web Vitals issues:
1. Third-party script overhead (GTM with 7 duplicate tags, Hotjar, Facebook,
   TikTok, Clarity, OptiMonk, HubSpot, Outbrain, VWO and more) causing a TBT
   of 1.7s and a mobile LCP render delay of 1.56s.
2. The LCP image (homepage slider and hero images) had no loading priority.
3. Heavy, non-modern-format images (up to 3.7MB of potential desktop savings).
4. Missing preconnect hints for key third-party origins (150-300ms DNS penalty).
5. Images without width/height attributes causing Cumulative Layout Shift (CLS).
6. Self-hosted fonts without font-display:swap (Flash of Invisible Text).


== Installation ==
1. Upload the `planet4-performance-booster` folder to `wp-content/plugins/`
   (or upload as a ZIP via Plugins > Add New > Upload Plugin).
2. Activate the plugin.
3. Go to Settings > Performance Booster.


== Modules (all individually enable/disable) ==

=== 1. Third-party scripts ===
Each service can be set to Normal / Delay / Block.
- **Delay**: script loads on first user interaction or after the configured
  timeout (default 8s). Tracking events are delayed but not lost.
- **Block**: script never loads. Use only after confirming it's unnecessary.
- Blocking also catches scripts injected dynamically by GTM after it loads
  (via a synchronous JS guard in <head> that overrides appendChild).

**Important**: always verify in GTM Preview Mode + GA4 Realtime that events
are still firing correctly after changing script modes.

=== 2. LCP image priority ===
Adds fetchpriority="high" and <link rel=preload> to the hero/carousel image,
and removes loading="lazy" from it. Prevents the browser from de-prioritising
the page's most important visual element.

- **Homepage mode** (default): targets the active carousel slide.
- **All pages mode**: additionally targets the first image with class
  size-full / size-large / wp-post-image on non-homepage pages.

=== 3. WebP image conversion ===
Converts every uploaded JPG/PNG to a sibling .webp file. Content images are
wrapped in <picture><source type="image/webp"> so WebP-capable browsers get
the smaller file while older browsers fall back to the original.

Works with WP-Stateless / Google Cloud Storage:
- New uploads: hook runs at priority 5, before WP-Stateless deletes the local
  copy (priority 10), so conversion always has the file available.
- Existing images: the "Convert existing images" tool (admin UI) or
  `wp p4pb convert-webp` (CLI) downloads files from GCS when not present
  locally, converts, then triggers WP-Stateless's normal GCS sync.
- The <picture> wrapper uses display:contents so it's box-model-invisible:
  it doesn't break any CSS that targets <img> directly.
- alt text is fully preserved: the original <img> (including its alt) is
  always kept inside <picture>; <source> elements don't carry alt (correct HTML).

=== 4. Preconnect / DNS prefetch hints ===
Prints <link rel="preconnect"> + <link rel="dns-prefetch"> for configured
domains at the top of <head>. Eliminates the DNS + TLS setup cost
(~150-300ms per domain) for origins the page will definitely use.

Default domains: fonts.googleapis.com, fonts.gstatic.com,
googletagmanager.com, connect.facebook.net. Configurable; add or remove as needed.

=== 5. Image dimensions (CLS fix) ===
Injects width and height attributes into <img> tags that are missing them.
Uses WordPress attachment metadata as the source of truth, with a pre-warmed
object cache so it adds one extra DB query per page (not one per image).

Browsers use the declared dimensions to compute the image's aspect ratio and
reserve the correct space before the image loads, preventing layout shifts.
Responsive CSS (img { width: 100%; }) still works correctly.

=== 6. font-display: swap ===
Patches @font-face rules in configured stylesheets to add font-display:swap,
preventing invisible text (FOIT) while custom fonts load. Only applies to
CSS hosted on this site; Google Fonts already has &display=swap.


== WP-CLI commands ==

  wp p4pb convert-webp
  wp p4pb convert-webp --limit=500
  wp p4pb convert-webp --offset=500 --limit=500
  wp p4pb convert-webp --dry-run

Recommended for large libraries where the browser-based batch tool times out.


== Important technical notes ==

- **Always test on dev first** before applying to production.
- Clear any page cache (Cloudflare, WP Super Cache, etc.) after saving settings.
- The block/delay JS guard catches dynamically injected scripts too (GTM tags,
  pixels added via code - not just statically rendered script tags).
- On offload / CDN setups, .htaccess rewrite rules have no effect on media
  URLs served from external domains. The <picture> element handles delivery
  transparently in both local and CDN scenarios.


== What's intentionally left out (and why) ==

- **Actually cleaning up duplicate GTM tags**: must be done in the GTM
  interface. This plugin provides a temporary server-side workaround only.
- **Server TTFB / object cache**: a missing Redis/Memcached setup means every
  page load hits MySQL for all queries. That's an infrastructure change, not
  something a front-end plugin can fix.
- **Brotli / gzip compression**: set at the server / CDN level, not in PHP.
- **Critical path CSS inlining**: would require deep theme integration; out
  of scope for a generic performance plugin.


== Changelog ==

= 1.3.0 =
- New: Preconnect hints module — configurable list of domains to preconnect
  to in <head>, eliminating DNS+TLS latency for key third-party origins.
- New: Image dimensions fix — injects width/height attributes into <img> tags
  missing them, using attachment metadata (batch-cached), to prevent CLS.
- New: LCP fix now supports all pages (not just homepage) via a new
  "Apply to all pages" setting, with a fallback selector for hero images.
- New: WP-CLI command `wp p4pb convert-webp` for bulk WebP conversion
  without the AJAX timeout risk.
- New: Settings page now includes inline documentation and tips for each
  feature, including how to verify it's working and what to watch out for.
- Improved: P4PB_Settings::get() now caches the result in a static variable,
  avoiding repeated get_option() calls within the same request.

= 1.2.0 =
- Fixed: WebP converter now runs at hook priority 5 (was 20) so it fires
  before WP-Stateless deletes the local file copy after GCS sync.
- Fixed: Batch conversion now downloads files from the CDN/stateless URL
  when the local file is absent (WP-Stateless stateless mode), so existing
  images can be converted without needing a local copy.
- Fixed: <picture> wrapper now uses display:contents so it is box-model-
  invisible and doesn't break CSS rules targeting <img> directly.

= 1.1.0 =
- Fixed: WebP conversion/delivery was broken on sites where media is
  offloaded to cloud storage (WP-Stateless / Google Cloud Storage).
- Fixed: "convert existing images" batch tool could time out - now resolves
  file paths directly, bypassing slow offload-plugin filter chains.
- New: WebP delivered via <picture>+<source>, working for both local and CDN.
- New: offload plugin detection notice in admin.
- Admin interface now in English.

= 1.0.0 =
- Initial release.
