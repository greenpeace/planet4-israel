<?php
/**
 * Converts a Shorthand.com zip export into a WordPress Page built entirely
 * out of this plugin's own blocks.
 *
 * Shorthand's exported article.html uses a stable, documented set of BEM-ish
 * class names per section type (Theme-TitleSection, Theme-TextOverMediaSection,
 * Theme-TwoColumnScrollmationSection, Theme-ScrollpointsSection) that map
 * almost 1:1 onto this plugin's own blocks (Hero, Text Over Media,
 * Scrollmation, Scrollpoints respectively) — which makes sense, since this
 * plugin's blocks were explicitly designed as a Shorthand replacement.
 *
 * This is a best-effort, heuristic converter, not a pixel-perfect one:
 * Shorthand supports many more section types (3D galleries, charts, serial
 * lists, custom embeds) than this plugin has equivalents for. Anything not
 * recognised falls back to Reveal (if it has a background image/video) or
 * Section Text (plain prose).
 *
 * IMPORTANT: every generate_*() method below must produce HTML that
 * byte-for-byte matches what the corresponding block's save.js would
 * produce given the same attributes — that's what makes the result a
 * VALID, editable Gutenberg block rather than "invalid content" the first
 * time someone opens the imported page in the editor. There is no
 * "approximately right" here; re-check the relevant save.js if you change
 * one of these.
 */

defined( 'ABSPATH' ) || exit;

class ST_Shorthand_Importer {

	/** @var string Absolute path to the directory the zip was extracted into. */
	private $extract_dir = '';

	/** @var bool Whether the source story is right-to-left. */
	private $is_rtl = false;

	/** @var array<string,array> relative asset path => ['id'=>, 'url'=>] upload cache. */
	private $asset_cache = [];

	/** @var array<string> Human-readable notes collected during import (skipped sections, fallbacks used, etc). */
	public $notes = [];

	/**
	 * @param string $zip_path     Absolute path to the uploaded Shorthand zip.
	 * @param string $page_title   Optional override; otherwise taken from the story's <title>.
	 * @return int|WP_Error        New page ID, or WP_Error on failure.
	 */
	public function import( $zip_path, $page_title = '' ) {
		$extract_dir = $this->extract_zip( $zip_path );
		if ( is_wp_error( $extract_dir ) ) {
			return $extract_dir;
		}
		$this->extract_dir = $extract_dir;

		$html_path = $this->extract_dir . '/article.html';
		if ( ! file_exists( $html_path ) ) {
			$html_path = $this->extract_dir . '/index.html';
		}
		if ( ! file_exists( $html_path ) ) {
			$this->cleanup();
			return new WP_Error( 'st_import_no_html', __( 'Could not find article.html or index.html in this zip — is it a Shorthand export?', 'scrollytelling' ) );
		}

		// article.html is a body fragment with no <meta charset> of its own,
		// and DOMDocument's charset auto-detection has nothing to go on
		// without one — it silently falls back to Latin-1, which mangles
		// Hebrew/Arabic/any non-ASCII text. The standard workaround: feed it
		// an explicit UTF-8 XML processing instruction; libxml consumes it
		// without adding a node, so it doesn't affect the resulting DOM.
		$html_content = file_get_contents( $html_path );
		$dom = new DOMDocument();
		libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html_content, LIBXML_NOERROR | LIBXML_NOWARNING );
		libxml_clear_errors();

		$this->is_rtl = $this->detect_rtl( $dom );

		$xpath    = new DOMXPath( $dom );
		$sections = $this->get_top_level_sections( $xpath );

		if ( ! $sections ) {
			$this->cleanup();
			return new WP_Error( 'st_import_no_sections', __( 'No Shorthand sections were found in this export.', 'scrollytelling' ) );
		}

		$blocks = [];
		foreach ( $sections as $section ) {
			$type = $this->classify_section( $section );
			switch ( $type ) {
				case 'hero':
					$blocks[] = $this->generate_hero( $section, $xpath );
					break;
				case 'tom':
					foreach ( $this->generate_tom( $section, $xpath ) as $b ) {
						$blocks[] = $b;
					}
					break;
				case 'scrollmation':
					$blocks[] = $this->generate_scrollmation( $section, $xpath );
					break;
				case 'scrollpoints':
					$blocks[] = $this->generate_scrollpoints( $section, $xpath );
					break;
				default:
					foreach ( $this->generate_fallback( $section, $xpath ) as $b ) {
						$blocks[] = $b;
					}
					break;
			}
		}

		$blocks  = array_filter( $blocks ); // drop any null/empty results
		$content = implode( "\n\n", $blocks );

		if ( ! $page_title ) {
			$page_title = $this->extract_story_title( $dom );
		}

		$page_id = wp_insert_post(
			wp_slash(
				[
					'post_title'   => $page_title ?: __( 'Imported Shorthand Story', 'scrollytelling' ),
					'post_content' => $content,
					'post_type'    => 'page',
					'post_status'  => 'draft',
				]
			),
			true
		);

		$this->cleanup();

		return $page_id;
	}

	/* ────────────────────────── Zip + DOM setup ────────────────────────── */

	private function extract_zip( $zip_path ) {
		if ( ! file_exists( $zip_path ) ) {
			return new WP_Error( 'st_import_no_file', __( 'Uploaded file not found.', 'scrollytelling' ) );
		}

		$upload_dir = wp_upload_dir();
		$target     = trailingslashit( $upload_dir['basedir'] ) . 'scrollytelling-import-' . wp_generate_password( 8, false );

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
		WP_Filesystem();

		$unzip_result = unzip_file( $zip_path, $target );
		if ( is_wp_error( $unzip_result ) ) {
			return $unzip_result;
		}

		return $target;
	}

	private function cleanup() {
		if ( $this->extract_dir && is_dir( $this->extract_dir ) ) {
			$this->rrmdir( $this->extract_dir );
		}
		$this->extract_dir = '';
	}

	private function rrmdir( $dir ) {
		$items = @scandir( $dir );
		if ( ! $items ) {
			return;
		}
		foreach ( $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}
			$path = $dir . '/' . $item;
			is_dir( $path ) ? $this->rrmdir( $path ) : @unlink( $path );
		}
		@rmdir( $dir );
	}

	private function detect_rtl( DOMDocument $dom ) {
		$html = $dom->getElementsByTagName( 'html' )->item( 0 );
		if ( $html && 'rtl' === strtolower( $html->getAttribute( 'dir' ) ) ) {
			return true;
		}

		// article.html is a fragment with no <html> tag of its own (so the
		// check above never matches there) — head.html/index.html carry the
		// real <html lang="..."> instead.
		$rtl_langs = [ 'he', 'ar', 'fa', 'ur' ];
		foreach ( [ 'head.html', 'index.html' ] as $candidate ) {
			$path = $this->extract_dir . '/' . $candidate;
			if ( ! file_exists( $path ) ) {
				continue;
			}
			$content = file_get_contents( $path );
			if ( preg_match( '/<html[^>]*\blang="([a-z]{2})/i', $content, $m ) && in_array( strtolower( $m[1] ), $rtl_langs, true ) ) {
				return true;
			}
			if ( preg_match( '/<html[^>]*\bdir="rtl"/i', $content ) ) {
				return true;
			}
		}

		// Last resort: a rough Hebrew/Arabic character sniff over the body text.
		$text = $dom->textContent ?? '';
		return (bool) preg_match( '/[\x{0590}-\x{08FF}]/u', mb_substr( $text, 0, 2000 ) );
	}

	/**
	 * article.html is a body fragment with no <title> of its own — Shorthand
	 * puts that in head.html (or the full index.html) instead. A plain
	 * regex is enough here and avoids parsing the much larger index.html
	 * as a second DOM just for one string.
	 */
	private function extract_story_title( DOMDocument $dom ) {
		$title_tag = $dom->getElementsByTagName( 'title' )->item( 0 );
		if ( $title_tag && trim( $title_tag->textContent ) ) {
			return trim( $title_tag->textContent );
		}

		foreach ( [ 'head.html', 'index.html' ] as $candidate ) {
			$path = $this->extract_dir . '/' . $candidate;
			if ( ! file_exists( $path ) ) {
				continue;
			}
			$content = file_get_contents( $path );
			if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $content, $m ) ) {
				return trim( html_entity_decode( wp_strip_all_tags( $m[1] ), ENT_QUOTES, 'UTF-8' ) );
			}
		}
		return '';
	}

	/**
	 * Top-level Shorthand sections: any element with the exact class token
	 * "Theme-Section" (not "Theme-Section-Custom" etc — token match), minus
	 * the fixed header/nav chrome, minus any such element that is itself
	 * nested inside another match (keeps only the outermost section per group).
	 */
	private function get_top_level_sections( DOMXPath $xpath ) {
		$all = $xpath->query(
			"//*[contains(concat(' ', normalize-space(@class), ' '), ' Theme-Section ')" .
			" and not(contains(concat(' ', normalize-space(@class), ' '), ' Theme-HeaderContainer '))]"
		);

		$matched = [];
		foreach ( $all as $el ) {
			$matched[] = $el;
		}

		$top = [];
		foreach ( $matched as $el ) {
			$ancestor_matches = false;
			$parent           = $el->parentNode;
			while ( $parent instanceof DOMElement ) {
				$cls = ' ' . $parent->getAttribute( 'class' ) . ' ';
				if ( false !== strpos( $cls, ' Theme-Section ' ) ) {
					$ancestor_matches = true;
					break;
				}
				$parent = $parent->parentNode;
			}
			if ( ! $ancestor_matches ) {
				$top[] = $el;
			}
		}
		return $top;
	}

	private function classify_section( DOMElement $section ) {
		$class = ' ' . $section->getAttribute( 'class' ) . ' ';
		if ( false !== strpos( $class, ' Theme-TitleSection ' ) ) {
			return 'hero';
		}
		if ( false !== strpos( $class, ' Theme-TwoColumnScrollmationSection ' ) ) {
			return 'scrollmation';
		}
		if ( false !== strpos( $class, ' Theme-ScrollpointsSection ' ) ) {
			return 'scrollpoints';
		}
		if ( false !== strpos( $class, ' Theme-TextOverMediaSection ' ) ) {
			return 'tom';
		}
		return 'fallback';
	}

	/* ────────────────────────── Shared HTML helpers ────────────────────────── */

	/** Mirrors useBlockProps.save()'s class/attribute output exactly. */
	private function block_props( $block_slug, $extra_class, $attrs = [] ) {
		$class = 'wp-block-scrollytelling-' . $block_slug;
		if ( $extra_class ) {
			$class .= ' ' . $extra_class;
		}
		$out = ' class="' . esc_attr( $class ) . '"';
		foreach ( $attrs as $name => $value ) {
			if ( null === $value || false === $value || '' === $value ) {
				continue;
			}
			$out .= ' ' . $name . '="' . esc_attr( $value ) . '"';
		}
		return $out;
	}

	private function style_attr( array $pairs ) {
		$parts = [];
		foreach ( $pairs as $prop => $value ) {
			if ( null === $value || '' === $value ) {
				continue;
			}
			$parts[] = $prop . ':' . $value;
		}
		return $parts ? ' style="' . esc_attr( implode( ';', $parts ) ) . '"' : '';
	}

	private function hex_to_rgb( $hex ) {
		if ( ! $hex || strlen( $hex ) < 7 ) {
			return '0, 0, 0';
		}
		return sprintf( '%d, %d, %d', hexdec( substr( $hex, 1, 2 ) ), hexdec( substr( $hex, 3, 2 ) ), hexdec( substr( $hex, 5, 2 ) ) );
	}

	/** Builds the <!-- wp:name {attrs} --> opening comment. */
	private function open_comment( $name, array $attributes ) {
		return '<!-- wp:' . $name . ' ' . wp_json_encode( $attributes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ' -->';
	}

	private function close_comment( $name ) {
		return '<!-- /wp:' . $name . ' -->';
	}

	private function text_align() {
		return $this->is_rtl ? 'right' : 'start';
	}

	/* ────────────────────────── Media resolution ────────────────────────── */

	/** Largest entry from a <picture>'s data-srcset sources. Returns a relative asset path or null. */
	private function find_picture_path( DOMElement $context, DOMXPath $xpath, $picture_class = null ) {
		$query   = $picture_class
			? ".//picture[contains(concat(' ', normalize-space(@class), ' '), ' " . $picture_class . " ')]"
			: './/picture';
		$picture = $xpath->query( $query, $context )->item( 0 );
		if ( ! $picture ) {
			$picture = $xpath->query( './/picture', $context )->item( 0 );
		}
		if ( ! $picture ) {
			return null;
		}

		$best_url = null;
		$best_w   = 0;
		foreach ( $xpath->query( './/source', $picture ) as $source ) {
			$srcset = $source->getAttribute( 'data-srcset' );
			if ( ! $srcset ) {
				continue;
			}
			foreach ( explode( ',', $srcset ) as $entry ) {
				if ( preg_match( '/^\s*(\S+)\s+(\d+)w\s*$/', $entry, $m ) ) {
					$w = (int) $m[2];
					if ( $w > $best_w ) {
						$best_w   = $w;
						$best_url = $m[1];
					}
				}
			}
		}
		return $best_url;
	}

	/** Returns [path, focal] for a <video>'s best <source> (prefers mp4), or null. */
	private function find_video_source( DOMElement $context, DOMXPath $xpath ) {
		$video = $xpath->query( './/video', $context )->item( 0 );
		if ( ! $video ) {
			return null;
		}
		$mp4 = null;
		$any = null;
		foreach ( $xpath->query( './/source', $video ) as $source ) {
			$path = $source->getAttribute( 'data-landscape' ) ?: $source->getAttribute( 'src' );
			if ( ! $path ) {
				continue;
			}
			if ( 'video/mp4' === $source->getAttribute( 'type' ) ) {
				$mp4 = $path;
			}
			if ( ! $any ) {
				$any = $path;
			}
		}
		$path = $mp4 ?: $any;
		if ( ! $path ) {
			return null;
		}
		$focal = $video->getAttribute( 'data-landscape-focal' ); // e.g. "50% 62%"
		return [ 'path' => $path, 'focal' => $focal ];
	}

	/** Resolves a relative Shorthand asset path to a WP media library URL, uploading it on first use. */
	private function resolve_asset( $relative_path ) {
		if ( ! $relative_path ) {
			return null;
		}
		if ( isset( $this->asset_cache[ $relative_path ] ) ) {
			return $this->asset_cache[ $relative_path ]['url'];
		}

		$clean = preg_replace( '#^\./#', '', $relative_path );
		$full  = $this->extract_dir . '/' . $clean;
		if ( ! file_exists( $full ) ) {
			$this->notes[] = sprintf( __( 'Asset not found in zip: %s', 'scrollytelling' ), $clean );
			return null;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$upload_dir = wp_upload_dir();
		$filename   = wp_unique_filename( $upload_dir['path'], basename( $full ) );
		$new_path   = trailingslashit( $upload_dir['path'] ) . $filename;

		if ( ! copy( $full, $new_path ) ) {
			$this->notes[] = sprintf( __( 'Could not copy asset: %s', 'scrollytelling' ), $clean );
			return null;
		}

		$filetype   = wp_check_filetype( $filename );
		$attachment = [
			'post_mime_type' => $filetype['type'],
			'post_title'     => sanitize_file_name( pathinfo( $filename, PATHINFO_FILENAME ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		];
		$attach_id = wp_insert_attachment( $attachment, $new_path );
		if ( ! $attach_id || is_wp_error( $attach_id ) ) {
			$this->notes[] = sprintf( __( 'Could not create attachment for: %s', 'scrollytelling' ), $clean );
			return null;
		}

		if ( false !== strpos( $filetype['type'], 'image/' ) ) {
			$meta = wp_generate_attachment_metadata( $attach_id, $new_path );
			wp_update_attachment_metadata( $attach_id, $meta );
		}

		$url = wp_get_attachment_url( $attach_id );
		$this->asset_cache[ $relative_path ] = [ 'id' => $attach_id, 'url' => $url ];
		return $url;
	}

	/** "50% 62%" -> {x:0.5,y:0.62}; falls back to centre. */
	private function parse_focal( $focal_str ) {
		if ( $focal_str && preg_match( '/([\d.]+)%\s+([\d.]+)%/', $focal_str, $m ) ) {
			return [ 'x' => round( $m[1] / 100, 3 ), 'y' => round( $m[2] / 100, 3 ) ];
		}
		return [ 'x' => 0.5, 'y' => 0.5 ];
	}

	/** Collects an element's direct text from h1-h4 and p children, in document order. */
	private function collect_text_nodes( DOMElement $el, DOMXPath $xpath ) {
		$headings = [];
		foreach ( $xpath->query( './/h1 | .//h2 | .//h3 | .//h4 | .//h5', $el ) as $h ) {
			$t = trim( preg_replace( '/\s+/u', ' ', $h->textContent ) );
			if ( $t ) {
				$headings[] = $t;
			}
		}
		$paragraphs = [];
		foreach ( $xpath->query( './/p', $el ) as $p ) {
			$t = trim( preg_replace( '/\s+/u', ' ', $p->textContent ) );
			if ( $t ) {
				$paragraphs[] = $t;
			}
		}
		return [ 'headings' => $headings, 'paragraphs' => $paragraphs ];
	}

	/** Finds a video OR picture inside a section; returns the resolved WP URL + type. */
	private function resolve_section_media( DOMElement $section, DOMXPath $xpath, $picture_class = null ) {
		$video = $this->find_video_source( $section, $xpath );
		if ( $video ) {
			$url = $this->resolve_asset( $video['path'] );
			if ( $url ) {
				return [ 'url' => $url, 'type' => 'video', 'focal' => $this->parse_focal( $video['focal'] ) ];
			}
		}
		$img_path = $this->find_picture_path( $section, $xpath, $picture_class );
		if ( $img_path ) {
			$url = $this->resolve_asset( $img_path );
			if ( $url ) {
				return [ 'url' => $url, 'type' => 'image', 'focal' => [ 'x' => 0.5, 'y' => 0.5 ] ];
			}
		}
		return [ 'url' => null, 'type' => 'image', 'focal' => [ 'x' => 0.5, 'y' => 0.5 ] ];
	}

	/** heading (optional) + paragraphs -> the HTML string RichText.Content expects as its `value`. */
	private function paragraphs_to_richtext( array $paragraphs, $heading = '' ) {
		$html = '';
		if ( $heading ) {
			$html .= '<h2>' . esc_html( $heading ) . '</h2>';
		}
		foreach ( $paragraphs as $p ) {
			$html .= '<p>' . esc_html( $p ) . '</p>';
		}
		return $html;
	}

	private function position_class( $key ) {
		$map = [
			'top-left' => 'st-pos--top-left', 'top-center' => 'st-pos--top-center', 'top-right' => 'st-pos--top-right',
			'middle-left' => 'st-pos--middle-left', 'middle-center' => 'st-pos--middle-center', 'center' => 'st-pos--center',
			'middle-right' => 'st-pos--middle-right', 'bottom-left' => 'st-pos--bottom-left', 'bottom-center' => 'st-pos--bottom-center',
			'bottom-right' => 'st-pos--bottom-right',
		];
		return $map[ $key ] ?? 'st-pos--center';
	}

	/* ════════════════════════ HERO (Theme-TitleSection) ════════════════════════ */

	private function generate_hero( DOMElement $section, DOMXPath $xpath ) {
		$texts = $this->collect_text_nodes( $section, $xpath );

		$title = $texts['headings'][0] ?? ( $texts['paragraphs'][0] ?? '' );
		$subtitle = '';
		if ( isset( $texts['headings'][1] ) ) {
			$subtitle = $texts['headings'][1];
		} elseif ( $texts['paragraphs'] ) {
			$subtitle = $texts['paragraphs'][0];
		}

		$media = $this->resolve_section_media( $section, $xpath );

		$attributes = [
			'mediaUrl'         => $media['url'] ?: '',
			'mediaType'        => $media['type'],
			'title'            => $title,
			'subtitle'         => $subtitle,
			'byline'           => '',
			'titleColor'       => '#ffffff',
			'subtitleColor'    => '#ffffff',
			'bylineColor'      => '#ffffff',
			'textPosition'     => 'center',
			'textAlign'        => $this->text_align(),
			'overlayColor'     => '#000000',
			'overlayOpacity'   => 40,
			'minHeight'        => '100vh',
			'isRtl'            => $this->is_rtl,
			'fixedBackground'  => false,
			'logoUrl'          => '',
			'logoPosition'     => 'before-title',
			'logoSize'         => 120,
			'zoomedBackground' => false,
			'backgroundBlur'   => 0,
		];
		return $this->render_hero( $attributes );
	}

	/** Must byte-match src/blocks/hero/save.js. */
	private function render_hero( array $a ) {
		$pos_class   = $this->position_class( $a['textPosition'] );
		$align_class = $a['textAlign'] ? 'st-align--' . $a['textAlign'] : '';
		$class       = trim( "st-hero $pos_class $align_class" );

		$html  = '<section' . $this->block_props( 'hero', $class, [
			'data-blur' => $a['backgroundBlur'] > 0 ? $a['backgroundBlur'] : null,
			'dir'       => $a['isRtl'] ? 'rtl' : null,
		] );
		$html .= $this->style_attr( [ '--st-min-height' => $a['minHeight'] ] );
		$html .= '>';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-hero__bg st-lazy-video" data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none" aria-hidden="true"></video>';
		} elseif ( $a['mediaUrl'] ) {
			$html .= '<img class="st-hero__bg" src="' . esc_url( $a['mediaUrl'] ) . '" alt="" aria-hidden="true"/>';
		}

		$html .= '<div class="st-hero__overlay"' . $this->style_attr( [
			'--st-overlay-color' => $a['overlayColor'],
			'background'         => 'rgba(' . $this->hex_to_rgb( $a['overlayColor'] ) . ', ' . ( $a['overlayOpacity'] / 100 ) . ')',
		] ) . ' aria-hidden="true"></div>';

		$html .= '<div class="st-hero__content">';
		if ( $a['title'] ) {
			$html .= '<h1 class="st-hero__title"' . $this->style_attr( [ 'color' => $a['titleColor'] ] ) . '>' . esc_html( $a['title'] ) . '</h1>';
		}
		if ( $a['subtitle'] ) {
			$html .= '<p class="st-hero__subtitle"' . $this->style_attr( [ 'color' => $a['subtitleColor'] ] ) . '>' . esc_html( $a['subtitle'] ) . '</p>';
		}
		if ( $a['byline'] ) {
			$html .= '<p class="st-hero__byline"' . $this->style_attr( [ 'color' => $a['bylineColor'] ] ) . '>' . esc_html( $a['byline'] ) . '</p>';
		}
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/hero', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/hero' );
	}

	/* ═══════════════════ TEXT OVER MEDIA (Theme-TextOverMediaSection) ═══════════════════ */

	/**
	 * Long-form prose doesn't fit a single overlay caption well, so sections
	 * with more than ~220 characters of body text are split into a
	 * full-screen Reveal (image) + Section Text (the prose) pair instead of
	 * a single text-over-media block. Short CTA-style sections stay as one
	 * text-over-media block. Returns an array of 1-2 rendered blocks.
	 */
	private function generate_tom( DOMElement $section, DOMXPath $xpath ) {
		$texts     = $this->collect_text_nodes( $section, $xpath );
		$heading   = $texts['headings'][0] ?? '';
		$body_text = implode( ' ', $texts['paragraphs'] );

		$media = $this->resolve_section_media( $section, $xpath, 'Theme-BackgroundImage' );

		if ( mb_strlen( $body_text ) > 220 ) {
			$blocks = [];
			if ( $media['url'] ) {
				$blocks[] = $this->render_reveal( [
					'mediaUrl'         => $media['url'],
					'mediaType'        => $media['type'],
					'caption'          => $heading,
					'height'           => 'full',
					'objectFit'        => 'cover',
					'isRtl'            => $this->is_rtl,
					'fixedBackground'  => false,
				] );
			}
			$blocks[] = $this->render_section_text( [
				'content'         => $this->paragraphs_to_richtext( $texts['paragraphs'], $heading ),
				'backgroundColor' => '#ffffff',
				'textColor'       => '#1a1a1a',
				'maxWidth'        => '680px',
				'paddingY'        => 80,
			] );
			return $blocks;
		}

		// Shorthand's left/right "Landscape" layout hint tells us which side
		// the image visually leans toward, so the text reads naturally on
		// the other side.
		$class         = ' ' . $section->getAttribute( 'class' ) . ' ';
		$text_position = 'middle-center';
		if ( false !== strpos( $class, ' Theme-Section-Layout--Landscapeleft ' ) ) {
			$text_position = 'middle-right';
		} elseif ( false !== strpos( $class, ' Theme-Section-Layout--Landscaperight ' ) ) {
			$text_position = 'middle-left';
		}

		$attributes = [
			'mediaUrl'        => $media['url'] ?: '',
			'mediaType'       => $media['type'],
			'title'           => $heading,
			'body'            => $body_text,
			'titleColor'      => '#ffffff',
			'bodyColor'       => '#ffffff',
			'textPosition'    => $text_position,
			'textAlign'       => $this->text_align(),
			'overlayColor'    => '#000000',
			'overlayOpacity'  => 45,
			'minHeight'       => '80vh',
			'textTheme'       => 'light',
			'isRtl'           => $this->is_rtl,
			'fixedBackground' => false,
		];
		return [ $this->render_tom( $attributes ) ];
	}

	/** Must byte-match src/blocks/text-over-media/save.js. */
	private function render_tom( array $a ) {
		$pos_class   = $this->position_class( $a['textPosition'] );
		$align_class = $a['textAlign'] ? 'st-align--' . $a['textAlign'] : '';
		$theme_class = $a['textTheme'] ? 'st-tom--' . $a['textTheme'] : '';
		$class       = trim( preg_replace( '/\s+/', ' ', "st-tom $pos_class $align_class $theme_class" ) );

		$html  = '<section' . $this->block_props( 'text-over-media', $class, [ 'dir' => $a['isRtl'] ? 'rtl' : null ] );
		$html .= $this->style_attr( [ '--st-min-height' => $a['minHeight'] ] );
		$html .= '>';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-tom__bg st-lazy-video' . ( $a['fixedBackground'] ? ' st-video-fixed' : '' ) . '" data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none" aria-hidden="true"></video>';
		} elseif ( $a['mediaUrl'] ) {
			if ( $a['fixedBackground'] ) {
				$html .= '<div class="st-tom__bg st-bg-fixed"' . $this->style_attr( [ 'background-image' => 'url(' . $a['mediaUrl'] . ')' ] ) . ' aria-hidden="true"></div>';
			} else {
				$html .= '<img class="st-tom__bg" src="' . esc_url( $a['mediaUrl'] ) . '" alt="" aria-hidden="true"/>';
			}
		}

		$html .= '<div class="st-tom__overlay"' . $this->style_attr( [
			'background' => 'rgba(' . $this->hex_to_rgb( $a['overlayColor'] ) . ', ' . ( $a['overlayOpacity'] / 100 ) . ')',
		] ) . ' aria-hidden="true"></div>';

		$html .= '<div class="st-tom__content">';
		if ( $a['title'] ) {
			$html .= '<h2 class="st-tom__title"' . $this->style_attr( [ 'color' => $a['titleColor'] ] ) . '>' . esc_html( $a['title'] ) . '</h2>';
		}
		if ( $a['body'] ) {
			$html .= '<p class="st-tom__body"' . $this->style_attr( [ 'color' => $a['bodyColor'] ] ) . '>' . esc_html( $a['body'] ) . '</p>';
		}
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/text-over-media', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/text-over-media' );
	}

	/* ═══════════════ SCROLLMATION (Theme-TwoColumnScrollmationSection) ═══════════════ */

	private function generate_scrollmation( DOMElement $section, DOMXPath $xpath ) {
		$texts   = $this->collect_text_nodes( $section, $xpath );
		$content = $this->paragraphs_to_richtext( $texts['paragraphs'], $texts['headings'][0] ?? '' );

		$class      = ' ' . $section->getAttribute( 'class' ) . ' ';
		$image_side = ( false !== strpos( $class, ' Theme-BodyTextColumn-Left ' ) ) ? 'right' : 'left';

		$frames = [];
		foreach ( $xpath->query( ".//*[contains(concat(' ', normalize-space(@class), ' '), ' CardCanvasItem ')]", $section ) as $item ) {
			$img_path = $this->find_picture_path( $item, $xpath );
			if ( ! $img_path ) {
				continue;
			}
			$url = $this->resolve_asset( $img_path );
			if ( ! $url ) {
				continue;
			}
			$caption_node = $xpath->query( ".//*[contains(concat(' ', normalize-space(@class), ' '), ' Theme-Caption ')]", $item )->item( 0 );
			$frames[]     = [
				'id'         => 'frame-' . count( $frames ),
				'url'        => $url,
				'alt'        => '',
				'caption'    => $caption_node ? trim( preg_replace( '/\s+/u', ' ', $caption_node->textContent ) ) : '',
				'focalPoint' => [ 'x' => 0.5, 'y' => 0.5 ],
			];
		}
		if ( ! $frames ) {
			$this->notes[] = __( 'A Scrollmation section had no usable images and was skipped.', 'scrollytelling' );
			return null;
		}

		$attributes = [
			'frames'          => $frames,
			'content'         => $content,
			'imageSide'       => $image_side,
			'textColor'       => '#1a1a1a',
			'bgColor'         => '#ffffff',
			'objectFit'       => 'cover',
			'imageBg'         => '#000000',
			'imageFullHeight' => true,
			'isRtl'           => $this->is_rtl,
			'textAlign'       => $this->is_rtl ? 'right' : 'start',
		];
		return $this->render_scrollmation( $attributes );
	}

	/** Must byte-match src/blocks/scrollmation/save.js. */
	private function render_scrollmation( array $a ) {
		$classes = array_filter( [
			'st-scrollmation',
			'st-scrollmation--img-' . $a['imageSide'],
			! $a['imageFullHeight'] ? 'st-scrollmation--natural' : '',
		] );
		$class = implode( ' ', $classes );

		$html  = '<section' . $this->block_props( 'scrollmation', $class );
		$html .= $this->style_attr( [ 'background' => $a['bgColor'] ] );
		$html .= '>';

		$html .= '<div class="st-scrollmation__text-col"' . ( $a['isRtl'] ? ' dir="rtl"' : '' ) . '>';
		$html .= '<div class="st-scrollmation__text-inner">';
		$text_style = [];
		if ( $a['textColor'] ) {
			$text_style['color'] = $a['textColor'];
		}
		if ( $a['textAlign'] && 'start' !== $a['textAlign'] ) {
			$text_style['text-align'] = $a['textAlign'];
		}
		$html .= '<div class="st-scrollmation__text-content"' . $this->style_attr( $text_style ) . '>' . $a['content'] . '</div>';
		$html .= '</div></div>';

		$media_col_bg = $a['imageFullHeight'] ? $a['imageBg'] : $a['bgColor'];
		$html .= '<div class="st-scrollmation__media-col"' . $this->style_attr( [ 'background' => $media_col_bg ] ) . ' aria-hidden="true">';
		$html .= '<div class="st-scrollmation__stage">';
		foreach ( $a['frames'] as $i => $frame ) {
			$focal     = $frame['focalPoint'] ?? [ 'x' => 0.5, 'y' => 0.5 ];
			$focal_pos = round( $focal['x'] * 100 ) . '% ' . round( $focal['y'] * 100 ) . '%';
			$html .= '<img class="st-scrollmation__frame" src="' . esc_url( $frame['url'] ) . '" alt="' . esc_attr( $frame['alt'] ?? '' ) . '"'
				. ' data-frame="' . (int) $i . '" data-caption="' . esc_attr( $frame['caption'] ?? '' ) . '" data-fit="' . esc_attr( $a['objectFit'] ) . '"'
				. $this->style_attr( [ 'object-position' => $focal_pos ] )
				. ( 0 !== $i ? ' aria-hidden="true"' : '' )
				. '/>';
		}
		$html .= '</div><p class="st-scrollmation__caption"></p></div>';
		$html .= '</section>';

		return $this->open_comment( 'scrollytelling/scrollmation', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/scrollmation' );
	}

	/* ═══════════════════ SCROLLPOINTS (Theme-ScrollpointsSection) ═══════════════════ */

	private function generate_scrollpoints( DOMElement $section, DOMXPath $xpath ) {
		$media_node      = $xpath->query( ".//*[contains(concat(' ', normalize-space(@class), ' '), ' Scrollpoints__media ')]", $section )->item( 0 );
		$image_url       = '';
		$overlay_color   = '#000000';
		$overlay_opacity = 0;
		if ( $media_node ) {
			$image_url       = $this->resolve_asset( $media_node->getAttribute( 'data-media' ) ) ?: '';
			$overlay_color   = $media_node->getAttribute( 'data-color' ) ?: '#000000';
			$overlay_opacity = (int) ( $media_node->getAttribute( 'data-opacity' ) ?: 0 );
		}

		$points = [];
		foreach ( $xpath->query( ".//*[contains(concat(' ', normalize-space(@class), ' '), ' Scrollpoints__point ')]", $section ) as $point_el ) {
			$texts     = $this->collect_text_nodes( $point_el, $xpath );
			$text_html = $this->paragraphs_to_richtext( $texts['paragraphs'], $texts['headings'][0] ?? '' );
			if ( ! $text_html ) {
				continue;
			}

			// Derive focal point + zoom from Shorthand's highlight box
			// (percentages of the image). Zoom is a rough heuristic — a
			// smaller highlighted region implies more zoom — clamped to a
			// modest 1-3x range rather than trusting the box dimensions
			// literally, since narrow/tall highlight boxes (e.g. for a text
			// label) would otherwise produce unusably extreme zoom values.
			$focus_x  = 50;
			$focus_y  = 50;
			$zoom     = 1.4;
			$box_node = $xpath->query( './/*[@data-box]', $point_el )->item( 0 );
			if ( $box_node ) {
				$box = json_decode( $box_node->getAttribute( 'data-box' ), true );
				$h   = $box['highlights'][0] ?? null;
				if ( $h ) {
					$focus_x = round( $h['x'] + $h['width'] / 2, 1 );
					$focus_y = round( $h['y'] + $h['height'] / 2, 1 );
					$dim     = max( $h['width'], $h['height'] );
					$zoom    = $dim > 0 ? round( max( 1, min( 3, 1 + ( 100 - $dim ) / 100 * 2 ) ), 2 ) : 1.4;
				}
			}

			$points[] = [
				'id'         => 'point-' . count( $points ),
				'text'       => $text_html,
				'focalPoint' => [ 'x' => round( $focus_x / 100, 3 ), 'y' => round( $focus_y / 100, 3 ) ],
				'zoom'       => $zoom,
			];
		}
		if ( ! $points ) {
			$this->notes[] = __( 'A Scrollpoints section had no usable points and was skipped.', 'scrollytelling' );
			return null;
		}

		$attributes = [
			'imageUrl'       => $image_url,
			'imageAlt'       => '',
			'points'         => $points,
			'textPosition'   => 'right',
			'panelWidth'     => 38,
			'textColor'      => '#1a1a1a',
			'bgColor'        => '#ffffff',
			'bgOpacity'      => 92,
			'overlayColor'   => $overlay_color,
			'overlayOpacity' => $overlay_opacity,
			'isRtl'          => $this->is_rtl,
		];
		return $this->render_scrollpoints( $attributes );
	}

	/** Must byte-match src/blocks/scrollpoints/save.js. */
	private function render_scrollpoints( array $a ) {
		$class = 'st-scrollpoints st-panel-pos--' . $a['textPosition'];
		$html  = '<section' . $this->block_props( 'scrollpoints', $class, [
			'data-text-color'      => $a['textColor'],
			'data-bg-color'        => $a['bgColor'],
			'data-bg-opacity'      => $a['bgOpacity'],
			'data-overlay-color'   => $a['overlayColor'],
			'data-overlay-opacity' => $a['overlayOpacity'],
			'dir'                  => $a['isRtl'] ? 'rtl' : null,
		] ) . '>';

		$html .= '<div class="st-scrollpoints__sticky" aria-hidden="true">';
		if ( $a['imageUrl'] ) {
			$html .= '<img class="st-scrollpoints__image" src="' . esc_url( $a['imageUrl'] ) . '" alt="' . esc_attr( $a['imageAlt'] ) . '"/>';
		}
		$html .= '<div class="st-scrollpoints__overlay"></div></div>';

		$html .= '<div class="st-scrollpoints__panels">';
		foreach ( $a['points'] as $point ) {
			$focal = $point['focalPoint'] ?? [ 'x' => 0.5, 'y' => 0.5 ];
			$x     = round( $focal['x'] * 100 );
			$y     = round( $focal['y'] * 100 );
			$zoom  = $point['zoom'] ?? 1;
			$html .= '<div class="st-scrollpoints__panel" data-focus-x="' . $x . '" data-focus-y="' . $y . '" data-zoom="' . $zoom . '">';
			$html .= '<div class="st-scrollpoints__panel-inner"' . $this->style_attr( [ 'width' => $a['panelWidth'] . '%' ] ) . '>';
			if ( ! empty( $point['text'] ) ) {
				$html .= '<div class="st-scrollpoints__text">' . $point['text'] . '</div>';
			}
			$html .= '</div></div>';
		}
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/scrollpoints', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/scrollpoints' );
	}

	/* ═══════════════════════ FALLBACK (anything unrecognised) ═══════════════════════ */

	/** Reveal (if there's a background image/video) and/or Section Text (the prose). */
	private function generate_fallback( DOMElement $section, DOMXPath $xpath ) {
		$texts = $this->collect_text_nodes( $section, $xpath );
		$media = $this->resolve_section_media( $section, $xpath );

		$blocks = [];
		if ( $media['url'] ) {
			$blocks[] = $this->render_reveal( [
				'mediaUrl'        => $media['url'],
				'mediaType'       => $media['type'],
				'caption'         => $texts['headings'][0] ?? '',
				'height'          => 'full',
				'objectFit'       => 'cover',
				'isRtl'           => $this->is_rtl,
				'fixedBackground' => false,
			] );
			$this->notes[] = __( 'A section type with no direct equivalent was converted to a Reveal block.', 'scrollytelling' );
		}
		if ( $texts['paragraphs'] || ( ! $media['url'] && $texts['headings'] ) ) {
			$blocks[] = $this->render_section_text( [
				'content'         => $this->paragraphs_to_richtext( $texts['paragraphs'], $media['url'] ? '' : ( $texts['headings'][0] ?? '' ) ),
				'backgroundColor' => '#ffffff',
				'textColor'       => '#1a1a1a',
				'maxWidth'        => '680px',
				'paddingY'        => 80,
			] );
			if ( ! $media['url'] ) {
				$this->notes[] = __( 'A section type with no direct equivalent was converted to a Section Text block.', 'scrollytelling' );
			}
		}
		return $blocks;
	}

	/** Must byte-match src/blocks/reveal/save.js. */
	private function render_reveal( array $a ) {
		$class = 'st-reveal st-reveal--' . $a['height'];
		$html  = '<div' . $this->block_props( 'reveal', $class, [ 'dir' => $a['isRtl'] ? 'rtl' : null ] );
		$html .= $this->style_attr( [ '--st-object-fit' => $a['objectFit'] ] );
		$html .= '>';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-reveal__media st-lazy-video' . ( $a['fixedBackground'] ? ' st-video-fixed' : '' ) . '"'
				. ' data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none"'
				. $this->style_attr( [ 'object-fit' => $a['objectFit'] ] ) . ' aria-hidden="true"></video>';
		} elseif ( $a['mediaUrl'] ) {
			if ( $a['fixedBackground'] ) {
				$html .= '<div class="st-reveal__media st-bg-fixed"' . $this->style_attr( [ 'background-image' => 'url(' . $a['mediaUrl'] . ')' ] ) . ' aria-hidden="true"></div>';
			} else {
				$html .= '<img class="st-reveal__media" src="' . esc_url( $a['mediaUrl'] ) . '" alt=""' . $this->style_attr( [ 'object-fit' => $a['objectFit'] ] ) . ' aria-hidden="true"/>';
			}
		}
		if ( $a['caption'] ) {
			$html .= '<p class="st-reveal__caption">' . esc_html( $a['caption'] ) . '</p>';
		}
		$html .= '</div>';

		return $this->open_comment( 'scrollytelling/reveal', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/reveal' );
	}

	/** Must byte-match src/blocks/section-text/save.js. */
	private function render_section_text( array $a ) {
		$html  = '<section' . $this->block_props( 'section-text', 'st-section-text' );
		$html .= $this->style_attr( [ 'background' => $a['backgroundColor'], 'padding' => $a['paddingY'] . 'px 20px' ] );
		$html .= '>';
		$html .= '<div' . $this->style_attr( [ 'max-width' => $a['maxWidth'], 'margin' => '0 auto' ] ) . '>';
		$html .= '<div class="st-section-text__content"' . $this->style_attr( [ 'color' => $a['textColor'] ] ) . '>' . $a['content'] . '</div>';
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/section-text', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/section-text' );
	}
}
