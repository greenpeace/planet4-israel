# Scrollytelling

A WordPress plugin that adds a set of Gutenberg blocks for building long-form, scroll-driven story pages — sticky backgrounds, pan/zoom timelines, image sequences, video scrubbing, and more — entirely with native blocks, with no external SaaS dependency.

**Created by Elad Aybes (Greenpeace MED).**

## Why this plugin exists

It was built as a self-hosted replacement for [Shorthand](https://shorthand.com), a paid scrollytelling SaaS product. It covers the same core storytelling patterns — full-bleed hero sections, sticky pan/zoom timelines, image sequences synced to scroll, text-over-media overlays — as native Gutenberg blocks that live in WordPress itself, with no subscription, no external embed, and full editorial control inside the block editor.

It also includes a one-click **importer** that converts an existing Shorthand `.zip` export directly into a WordPress page built entirely from this plugin's own blocks (see [Importing from Shorthand](#importing-from-shorthand) below).

## Requirements

- WordPress 6.3+
- PHP 8.0+
- Node.js + npm (only needed if you're building the plugin from source — see [Development](#development))

## Installation

1. Copy (or clone) this plugin into `wp-content/plugins/scrollytelling`.
2. Run `npm install && npm run build` if the `build/` directory isn't already present (see [Development](#development)).
3. Activate **Scrollytelling** from the WordPress admin Plugins screen.
4. A new **Scrollytelling** block category appears in the block inserter, and a **Scrollytelling** admin menu item is added for the Shorthand importer.

## Blocks

All blocks live under the **Scrollytelling** category in the block inserter. Most support RTL content (an "RTL" toggle mirrors text alignment and layout direction) and full-width/wide alignment.

| Block | What it does |
|---|---|
| **Hero Section** | Full-screen cover with a background image/video, title, subtitle, byline, and optional logo. Supports a fixed (parallax) background, a zoomed background, and a scroll-driven background blur. |
| **Text Over Media** | Full-width image or video background with a positioned text overlay (title + body), a tintable overlay, and light/dark text theme. |
| **Background Scroll** | A sticky full-bleed background image or video with one or more scrolling text panels on top. Panels can be styled (background, border, opacity) and positioned left/right. Includes an optional **directional gradient overlay** (top/bottom/left/right, with its own color and opacity) layered on top of the flat tint. |
| **Scrollmation** | A two-column layout: scrolling text in one column, a sticky sequence of images in the other. The visible image advances as the reader scrolls past each text block — like a manually-driven slideshow keyed to scroll position. |
| **Scrollpoints** | A single large image that pans and zooms between several focal points as the reader scrolls past a sequence of text panels — built for timelines and maps. Each point defines its own focal point and zoom level; the image animates continuously between them rather than jumping. |
| **Reveal** | A full-screen image or video that fades and scales into view as the reader scrolls to it. Supports a fixed (parallax) background. |
| **Slideshow** | An image/video carousel with prev/next navigation and optional per-slide captions. |
| **Video Scrubbing** | A video whose current frame is driven by mouse position instead of normal playback. **Background mode** takes over the full viewport; **Block mode** is a horizontal strip within the page. Configurable scrub axis/direction. On mobile, scrubbing falls back to scroll position. |
| **Text Section** | A clean, centered text column for long-form prose between visual sections. |
| **Custom CSS** | A free-text CSS field. Applies site-wide on the page it's placed on, regardless of where in the page the block sits — useful for one-off tweaks without a child theme. |

### Block extensions (apply to *any* block)

Two additional features are added as **block filters** rather than standalone blocks, so they can be applied to *any* block — core WordPress blocks (paragraph, image, group, …) as well as this plugin's own blocks. Each appears as its own panel in the block's Inspector Controls sidebar:

- **Ease In & Out Animation** — adds a scroll-triggered entrance and/or exit animation (fade, slide from any direction, zoom) to the selected block, with configurable duration, delay, and travel distance. Useful for staggering several blocks in sequence.
- **Floating Effect** — makes the selected block drift independently of normal scroll speed (vertical, horizontal, or both), for a parallax-drift effect. Speed can be negative to reverse direction.

Both are designed to be fully inert by default: a block that has never touched either feature renders exactly the same markup as before, so nothing on an existing site can be affected by their mere presence.

## Frontend behavior

A single `frontend.js` is enqueued only on pages that actually use a Scrollytelling block (or one of the two block extensions above), so sites that don't use this plugin pay no JS cost. It's dependency-free — native `IntersectionObserver` and scroll listeners only — and drives:

- Reading **progress bar** and **section navigation dots** injected automatically for every Scrollytelling section on the page.
- Per-block scroll-linked behavior (sticky panels, scrollmation frame sequencing, scrollpoints pan/zoom interpolation, hero zoom/blur/text entrance, content fade-ins, video scrubbing).
- **Lazy-loaded video**: every video across the plugin is saved without `src` or `autoplay`; an `IntersectionObserver` starts loading it only once it's near the viewport, then plays it once enough has buffered — avoiding upfront bandwidth cost for videos the reader never scrolls to.
- **`prefers-reduced-motion` support**: users with this OS/browser setting get transitions disabled (handled in CSS) and continuously-recalculated scroll-coupled effects (hero blur, fixed-video parallax, the floating/parallax extension) skipped entirely, rather than just sped up.
- Scroll handlers are throttled to at most one update per animation frame to avoid jank on mobile.

## Importing from Shorthand

If you have an existing [Shorthand](https://shorthand.com) story, you can convert its `.zip` export into a WordPress page built entirely from this plugin's blocks — no manual rebuilding required.

### From the WordPress admin

1. Go to **Scrollytelling** in the admin menu.
2. Upload the Shorthand `.zip` export and optionally set a page title (defaults to the story's own title).
3. Submit. A new **draft** page is created, built from this plugin's blocks, ready for review before publishing.

### From WP-CLI

```bash
wp scrollytelling import_shorthand /path/to/story.zip --title="Optional override title"
```

This is the same importer the admin page uses, useful for batch conversions or testing.

### How the conversion works

The importer maps Shorthand's own section types onto the closest matching block in this plugin:

| Shorthand section | Becomes |
|---|---|
| Title section | Hero Section |
| Text Over Media section | Text Over Media (or split into Reveal + Text Section, for long body copy) |
| Two-column scrollmation section | Scrollmation |
| Scrollpoints section | Scrollpoints |
| Anything else | Falls back to Reveal and/or Text Section |

Media (images/videos) referenced in the export are uploaded into the WordPress media library, and RTL stories are detected automatically from the export's own language/direction metadata.

This is a **best-effort conversion, not pixel-perfect** — the importer's own admin screen surfaces any notes/warnings produced during conversion, and the resulting page is always created as a draft so it can be reviewed (and adjusted with the regular block editor) before publishing.

## Development

```bash
npm install
npm run start   # watch mode, for local development
npm run build    # production build into build/
npm run format   # run wp-scripts format
```

The plugin is built on `@wordpress/scripts`. Source lives in `src/` (one folder per block, plus `src/extensions/` for the two block filters and `src/frontend.js` for all scroll-driven runtime behavior); compiled output goes to `build/`, which is what's actually enqueued by `scrollytelling.php`.

## License

No license is currently declared for this plugin.
