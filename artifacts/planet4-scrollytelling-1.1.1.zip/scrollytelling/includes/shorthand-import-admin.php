<?php
/**
 * Admin page: "Import from Shorthand" — upload a Shorthand zip export and
 * convert it into a draft Page built from this plugin's blocks.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', 'st_register_shorthand_import_page' );
function st_register_shorthand_import_page() {
	add_menu_page(
		__( 'Import from Shorthand', 'scrollytelling' ),
		__( 'Scrollytelling', 'scrollytelling' ),
		'manage_options',
		'scrollytelling-import',
		'st_render_shorthand_import_page',
		'dashicons-controls-play'
	);
}

function st_render_shorthand_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'scrollytelling' ) );
	}

	$result_page_id = null;
	$error_message  = '';
	$notes          = [];

	if ( isset( $_POST['st_import_nonce'] ) && wp_verify_nonce( $_POST['st_import_nonce'], 'st_import_shorthand' ) ) {
		if ( empty( $_FILES['st_shorthand_zip'] ) || UPLOAD_ERR_NO_FILE === $_FILES['st_shorthand_zip']['error'] ) {
			$error_message = __( 'Please choose a Shorthand .zip export to upload.', 'scrollytelling' );
		} elseif ( UPLOAD_ERR_OK !== $_FILES['st_shorthand_zip']['error'] ) {
			$error_message = __( 'The upload failed — please try again.', 'scrollytelling' );
		} else {
			$file = $_FILES['st_shorthand_zip'];
			if ( ! preg_match( '/\.zip$/i', $file['name'] ) ) {
				$error_message = __( 'Please upload a .zip file.', 'scrollytelling' );
			} else {
				$title    = sanitize_text_field( wp_unslash( $_POST['st_page_title'] ?? '' ) );
				$importer = new ST_Shorthand_Importer();
				$result   = $importer->import( $file['tmp_name'], $title );
				$notes    = $importer->notes;

				if ( is_wp_error( $result ) ) {
					$error_message = $result->get_error_message();
				} else {
					$result_page_id = $result;
				}
			}
		}
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Import from Shorthand', 'scrollytelling' ); ?></h1>
		<p>
			<?php esc_html_e( 'Upload a Shorthand.com zip export and this will convert it into a new draft Page built entirely from this plugin\'s own blocks (Hero, Text Over Media, Scrollmation, Scrollpoints, Reveal, Section Text) — matched by Shorthand\'s own section types where possible, with a best-effort fallback for anything else.', 'scrollytelling' ); ?>
		</p>
		<p>
			<em><?php esc_html_e( 'This is a best-effort conversion, not pixel-perfect — review the result before publishing.', 'scrollytelling' ); ?></em>
		</p>

		<?php if ( $error_message ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( $error_message ); ?></p></div>
		<?php endif; ?>

		<?php if ( $result_page_id ) : ?>
			<div class="notice notice-success">
				<p>
					<?php
					printf(
						/* translators: %s: edit link */
						esc_html__( 'Done! Created a draft page: %s', 'scrollytelling' ),
						'<a href="' . esc_url( get_edit_post_link( $result_page_id, 'raw' ) ) . '">' . esc_html( get_the_title( $result_page_id ) ) . '</a>'
					);
					?>
				</p>
			</div>
		<?php endif; ?>

		<?php if ( $notes ) : ?>
			<div class="notice notice-warning">
				<p><strong><?php esc_html_e( 'Notes from the conversion:', 'scrollytelling' ); ?></strong></p>
				<ul style="margin-left:20px;list-style:disc;">
					<?php foreach ( $notes as $note ) : ?>
						<li><?php echo esc_html( $note ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<form method="post" enctype="multipart/form-data" style="max-width:600px;margin-top:20px;">
			<?php wp_nonce_field( 'st_import_shorthand', 'st_import_nonce' ); ?>
			<table class="form-table">
				<tr>
					<th scope="row"><label for="st_shorthand_zip"><?php esc_html_e( 'Shorthand export (.zip)', 'scrollytelling' ); ?></label></th>
					<td><input type="file" name="st_shorthand_zip" id="st_shorthand_zip" accept=".zip" required /></td>
				</tr>
				<tr>
					<th scope="row"><label for="st_page_title"><?php esc_html_e( 'Page title', 'scrollytelling' ); ?></label></th>
					<td>
						<input type="text" name="st_page_title" id="st_page_title" class="regular-text" placeholder="<?php esc_attr_e( 'Leave blank to use the story\'s own title', 'scrollytelling' ); ?>" />
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Convert to a Scrollytelling page', 'scrollytelling' ) ); ?>
		</form>
	</div>
	<?php
}
