import { __ } from '@wordpress/i18n';
import {
	InspectorControls,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
	useSettings,
} from '@wordpress/block-editor';
import {
	Button,
	ColorPalette,
	FocalPointPicker,
	PanelBody,
	RangeControl,
	SelectControl,
	TextareaControl,
	TextControl,
	ColorPicker,
	ToggleControl,
} from '@wordpress/components';
import { useState } from '@wordpress/element';
import { AlignPicker } from '../../components/PositionPicker';

const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0,0,0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

const GRADIENT_OPTIONS = [
	{ label: __( 'None', 'scrollytelling' ),        value: 'none' },
	{ label: __( 'From Bottom ↑', 'scrollytelling' ), value: 'bottom' },
	{ label: __( 'From Top ↓', 'scrollytelling' ),    value: 'top' },
	{ label: __( 'From Left →', 'scrollytelling' ),   value: 'left' },
	{ label: __( 'From Right ←', 'scrollytelling' ),  value: 'right' },
];

const PANEL_POSITION_OPTIONS = [
	{ label: __( 'Block default', 'scrollytelling' ), value: '' },
	{ label: __( 'Right', 'scrollytelling' ),         value: 'right' },
	{ label: __( 'Left', 'scrollytelling' ),          value: 'left' },
	{ label: __( 'Center', 'scrollytelling' ),        value: 'center' },
];

const MEDIA_HEIGHT_OPTIONS = [
	{ label: __( 'Full screen (100%)', 'scrollytelling' ), value: 'full'  },
	{ label: __( 'Half screen (50%)', 'scrollytelling' ),  value: 'half'  },
	{ label: __( 'Small (30%)', 'scrollytelling' ),        value: 'small' },
];

export default function Edit( { attributes, setAttributes } ) {
	const {
		mediaUrl,
		mediaType,
		mediaHeight,
		focalPoint,
		overlayColor,
		overlayOpacity,
		panels,
		panelPosition,
		panelWidth,
		panelTitleColor,
		panelBodyColor,
		panelTextAlign,
		panelBgColor,
		panelBgOpacity,
		panelBorderColor,
		panelBorderWidth,
		gradientStyle,
		gradientColor,
		gradientOpacity,
		isRtl,
		fixedBackground,
	} = attributes;

	const [ themeColors ] = useSettings( 'color.palette' );
	const colors = themeColors || [];

	const [ activePanel, setActivePanel ] = useState( 0 );
	const blockProps = useBlockProps( { className: 'st-bg-scroll-editor' } );

	const updatePanel = ( index, key, value ) => {
		const updated = panels.map( ( p, i ) =>
			i === index ? { ...p, [ key ]: value } : p
		);
		setAttributes( { panels: updated } );
	};

	const addPanel = () => {
		const newPanel = { id: `panel-${ Date.now() }`, title: '', body: '', position: '' };
		setAttributes( { panels: [ ...panels, newPanel ] } );
		setActivePanel( panels.length );
	};

	const removePanel = ( index ) => {
		const updated = panels.filter( ( _, i ) => i !== index );
		setAttributes( { panels: updated } );
		setActivePanel( Math.max( 0, activePanel - 1 ) );
	};

	const effectivePos = ( panel ) => panel.position || panelPosition;

	const panelStyle = ( panel ) => {
		const pos = effectivePos( panel );
		return {
			width: `${ panelWidth }%`,
			marginLeft: pos === 'right' ? 'auto' : pos === 'center' ? 'auto' : '0',
			marginRight: pos === 'left' ? 'auto' : pos === 'center' ? 'auto' : '0',
		};
	};

	const panelInnerBg = `rgba(${ hexToRgb( panelBgColor ) }, ${ panelBgOpacity / 100 })`;
	const panelInnerBorder = panelBorderWidth > 0
		? `${ panelBorderWidth }px solid ${ panelBorderColor }`
		: 'none';

	// Compute gradient CSS for preview
	const buildGradient = ( style, color, opacity ) => {
		if ( style === 'none' ) return null;
		const col = `rgba(${ hexToRgb( color ) }, ${ opacity / 100 })`;
		const map = {
			bottom: `linear-gradient(to top, ${ col } 0%, transparent 65%)`,
			top:    `linear-gradient(to bottom, ${ col } 0%, transparent 65%)`,
			left:   `linear-gradient(to right, ${ col } 0%, transparent 65%)`,
			right:  `linear-gradient(to left, ${ col } 0%, transparent 65%)`,
		};
		return map[ style ] || null;
	};
	const gradientCss = buildGradient( gradientStyle, gradientColor, gradientOpacity );
	const focalPos = focalPoint
		? `${ Math.round( focalPoint.x * 100 ) }% ${ Math.round( focalPoint.y * 100 ) }%`
		: '50% 50%';

	return (
		<>
			<InspectorControls>

				{ /* ── Background Media ── */ }
				<PanelBody title={ __( 'Background Media', 'scrollytelling' ) } initialOpen>
					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( media ) =>
								setAttributes( {
									mediaUrl: media.url,
									mediaId: media.id,
									mediaType: media.type === 'video' ? 'video' : 'image',
								} )
							}
							allowedTypes={ [ 'image', 'video' ] }
							value={ attributes.mediaId }
							render={ ( { open } ) => (
								<Button variant="secondary" onClick={ open } style={ { width: '100%', marginBottom: '8px' } }>
									{ mediaUrl ? __( 'Replace Media', 'scrollytelling' ) : __( 'Upload / Select Media', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>
					{ mediaUrl && (
						<Button isDestructive variant="link" onClick={ () => setAttributes( { mediaUrl: '', mediaId: undefined } ) } style={ { marginBottom: '12px' } }>
							{ __( 'Remove', 'scrollytelling' ) }
						</Button>
					) }

					<SelectControl
						label={ __( 'Section height', 'scrollytelling' ) }
						help={ __( 'How much of the screen the sticky image fills, on every device.', 'scrollytelling' ) }
						value={ mediaHeight }
						options={ MEDIA_HEIGHT_OPTIONS }
						onChange={ ( v ) => setAttributes( { mediaHeight: v } ) }
					/>

					{ mediaUrl && (
						<div style={ { marginTop: '12px' } }>
							<p style={ { fontSize: '11px', fontWeight: 600, margin: '0 0 8px', color: '#333' } }>
								{ __( 'Focal point (crop centre)', 'scrollytelling' ) }
							</p>
							<FocalPointPicker
								url={ mediaUrl }
								value={ focalPoint || { x: 0.5, y: 0.5 } }
								onChange={ ( fp ) => setAttributes( { focalPoint: fp } ) }
							/>
						</div>
					) }
				</PanelBody>

				{ /* ── Overlay ── */ }
				<PanelBody title={ __( 'Overlay', 'scrollytelling' ) } initialOpen={ false }>
					<p style={ { fontSize: '11px', fontWeight: 600, color: '#555', margin: '0 0 8px' } }>
						{ __( 'Solid Tint', 'scrollytelling' ) }
					</p>
					<p style={ { fontSize: '11px', color: '#757575', marginBottom: '8px' } }>{ __( 'Color', 'scrollytelling' ) }</p>
					<ColorPicker color={ overlayColor } onChange={ ( v ) => setAttributes( { overlayColor: v } ) } enableAlpha={ false } />
					<RangeControl
						label={ __( 'Tint Opacity (%)', 'scrollytelling' ) }
						value={ overlayOpacity }
						onChange={ ( v ) => setAttributes( { overlayOpacity: v } ) }
						min={ 0 } max={ 90 }
					/>

					<hr style={ { margin: '16px 0', borderColor: '#e0e0e0' } } />

					<p style={ { fontSize: '11px', fontWeight: 600, color: '#555', margin: '0 0 8px' } }>
						{ __( 'Gradient Overlay', 'scrollytelling' ) }
					</p>
					<SelectControl
						label={ __( 'Gradient Direction', 'scrollytelling' ) }
						value={ gradientStyle }
						options={ GRADIENT_OPTIONS }
						onChange={ ( v ) => setAttributes( { gradientStyle: v } ) }
					/>
					{ gradientStyle !== 'none' && (
						<>
							<p style={ { fontSize: '11px', color: '#757575', margin: '8px 0 6px' } }>{ __( 'Gradient Color', 'scrollytelling' ) }</p>
							<ColorPicker
								color={ gradientColor }
								onChange={ ( v ) => setAttributes( { gradientColor: v } ) }
								enableAlpha={ false }
							/>
							<RangeControl
								label={ __( 'Gradient Opacity (%)', 'scrollytelling' ) }
								value={ gradientOpacity }
								onChange={ ( v ) => setAttributes( { gradientOpacity: v } ) }
								min={ 0 } max={ 100 }
							/>
						</>
					) }
				</PanelBody>

				{ /* ── Panels ── */ }
				<PanelBody title={ __( 'Panels', 'scrollytelling' ) } initialOpen>

					{ /* Colors */ }
					<p style={ { fontSize: '11px', color: '#757575', margin: '0 0 6px' } }>{ __( 'Panel Title Color', 'scrollytelling' ) }</p>
					<ColorPalette colors={ colors } value={ panelTitleColor } onChange={ ( v ) => setAttributes( { panelTitleColor: v || panelTitleColor } ) } clearable={ false } />
					<p style={ { fontSize: '11px', color: '#757575', margin: '12px 0 6px' } }>{ __( 'Panel Body Color', 'scrollytelling' ) }</p>
					<ColorPalette colors={ colors } value={ panelBodyColor } onChange={ ( v ) => setAttributes( { panelBodyColor: v || panelBodyColor } ) } clearable={ false } />
					<AlignPicker value={ panelTextAlign } onChange={ ( v ) => setAttributes( { panelTextAlign: v } ) } />

					<hr style={ { margin: '12px 0', borderColor: '#e0e0e0' } } />

					{ /* Panel background */ }
					<p style={ { fontSize: '11px', fontWeight: 600, color: '#555', margin: '0 0 8px' } }>
						{ __( 'Panel Background', 'scrollytelling' ) }
					</p>
					<p style={ { fontSize: '11px', color: '#757575', margin: '0 0 6px' } }>{ __( 'Background Color', 'scrollytelling' ) }</p>
					<ColorPalette colors={ colors } value={ panelBgColor } onChange={ ( v ) => setAttributes( { panelBgColor: v || panelBgColor } ) } clearable={ false } />
					<RangeControl
						label={ __( 'Background Opacity (%)', 'scrollytelling' ) }
						value={ panelBgOpacity }
						onChange={ ( v ) => setAttributes( { panelBgOpacity: v } ) }
						min={ 0 } max={ 100 }
					/>

					<hr style={ { margin: '12px 0', borderColor: '#e0e0e0' } } />

					{ /* Panel border */ }
					<p style={ { fontSize: '11px', fontWeight: 600, color: '#555', margin: '0 0 8px' } }>
						{ __( 'Panel Border', 'scrollytelling' ) }
					</p>
					<p style={ { fontSize: '11px', color: '#757575', margin: '0 0 6px' } }>{ __( 'Border Color', 'scrollytelling' ) }</p>
					<ColorPalette colors={ colors } value={ panelBorderColor } onChange={ ( v ) => setAttributes( { panelBorderColor: v || panelBorderColor } ) } clearable={ false } />
					<RangeControl
						label={ __( 'Border Width (px)', 'scrollytelling' ) }
						value={ panelBorderWidth }
						onChange={ ( v ) => setAttributes( { panelBorderWidth: v } ) }
						min={ 0 } max={ 8 }
					/>

					<hr style={ { margin: '12px 0', borderColor: '#e0e0e0' } } />

					{ /* Default panel layout */ }
					<SelectControl
						label={ __( 'Default Panel Side', 'scrollytelling' ) }
						value={ panelPosition }
						options={ [
							{ label: 'Right', value: 'right' },
							{ label: 'Left', value: 'left' },
							{ label: 'Center', value: 'center' },
						] }
						onChange={ ( v ) => setAttributes( { panelPosition: v } ) }
					/>
					<RangeControl
						label={ __( 'Panel Width (%)', 'scrollytelling' ) }
						value={ panelWidth }
						onChange={ ( v ) => setAttributes( { panelWidth: v } ) }
						min={ 25 } max={ 60 }
					/>

					{ /* Individual panels */ }
					{ panels.map( ( panel, i ) => (
						<div
							key={ panel.id }
							style={ {
								border: `2px solid ${ i === activePanel ? '#007cba' : '#e0e0e0' }`,
								borderRadius: '4px',
								padding: '8px',
								marginBottom: '8px',
								cursor: 'pointer',
							} }
							onClick={ () => setActivePanel( i ) }
						>
							<div style={ { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' } }>
								<strong style={ { fontSize: '12px' } }>{ __( 'Panel', 'scrollytelling' ) } { i + 1 }</strong>
								{ panels.length > 1 && (
									<Button
										isDestructive
										variant="link"
										style={ { fontSize: '11px' } }
										onClick={ ( e ) => { e.stopPropagation(); removePanel( i ); } }
									>
										{ __( 'Remove', 'scrollytelling' ) }
									</Button>
								) }
							</div>
							{ i === activePanel && (
								<>
									<SelectControl
										label={ __( 'Position (this panel)', 'scrollytelling' ) }
										value={ panel.position || '' }
										options={ PANEL_POSITION_OPTIONS }
										onChange={ ( v ) => updatePanel( i, 'position', v ) }
									/>
									<TextControl
										label={ __( 'Panel Title', 'scrollytelling' ) }
										value={ panel.title }
										onChange={ ( v ) => updatePanel( i, 'title', v ) }
									/>
									<TextareaControl
										label={ __( 'Panel Body', 'scrollytelling' ) }
										value={ panel.body }
										onChange={ ( v ) => updatePanel( i, 'body', v ) }
										rows={ 4 }
									/>
								</>
							) }
						</div>
					) ) }

					<Button variant="secondary" onClick={ addPanel } style={ { width: '100%' } }>
						{ __( '+ Add Panel', 'scrollytelling' ) }
					</Button>
				</PanelBody>

				{ /* ── Layout ── */ }
				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<ToggleControl
						label={ __( 'Fixed background (parallax)', 'scrollytelling' ) }
						checked={ fixedBackground }
						onChange={ ( v ) => setAttributes( { fixedBackground: v } ) }
					/>
					<ToggleControl
						label={ __( 'Right-to-left text (RTL / Hebrew)', 'scrollytelling' ) }
						checked={ isRtl }
						onChange={ ( v ) => setAttributes( { isRtl: v } ) }
					/>
				</PanelBody>
			</InspectorControls>

			{ /* ── Editor Preview ── */ }
			<div
				{ ...blockProps }
				style={ {
					position: 'relative',
					minHeight: `${ panels.length * 80 }vh`,
					background: '#1a1a2e',
					overflow: 'hidden',
				} }
			>
				{ /* Background */ }
				{ mediaUrl && (
					mediaType === 'video' ? (
						<video src={ mediaUrl } autoPlay muted loop playsInline
							style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: focalPos, zIndex: 0 } } />
					) : (
						<img src={ mediaUrl } alt=""
							style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: focalPos, zIndex: 0 } } />
					)
				) }

				{ /* Solid overlay */ }
				<div
					style={ {
						position: 'absolute', inset: 0,
						background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })`,
						zIndex: 1,
					} }
				/>

				{ /* Gradient overlay */ }
				{ gradientCss && (
					<div style={ { position: 'absolute', inset: 0, background: gradientCss, zIndex: 2 } } />
				) }

				{ ! mediaUrl && (
					<div style={ {
						position: 'absolute', inset: 0, display: 'flex', alignItems: 'center',
						justifyContent: 'center', color: '#555', fontSize: '14px', zIndex: 3,
					} }>
						{ __( 'Upload a background image in the sidebar →', 'scrollytelling' ) }
					</div>
				) }

				{ /* Panel previews */ }
				<div style={ { position: 'relative', zIndex: 3, padding: '40px 5%' } }>
					{ panels.map( ( panel, i ) => (
						<div
							key={ panel.id }
							style={ {
								...panelStyle( panel ),
								background: panelInnerBg,
								border: panelInnerBorder,
								borderRadius: '8px',
								padding: '32px',
								marginBottom: '60vh',
								cursor: 'pointer',
								outline: i === activePanel ? '3px solid #007cba' : 'none',
								textAlign: panelTextAlign,
							} }
							onClick={ () => setActivePanel( i ) }
						>
							{ panel.title && <h2 style={ { fontSize: '1.6rem', fontWeight: 700, marginBottom: '12px', color: panelTitleColor } }>{ panel.title }</h2> }
							{ panel.body ? (
								<p style={ { fontSize: '1rem', lineHeight: 1.7, color: panelBodyColor } }>{ panel.body }</p>
							) : (
								<p style={ { color: '#aaa', fontStyle: 'italic' } }>{ __( 'Select this panel in the sidebar to add content.', 'scrollytelling' ) }</p>
							) }
							<p style={ { fontSize: '11px', color: '#999', marginTop: '8px' } }>
								{ __( 'Panel', 'scrollytelling' ) } { i + 1 } / { panels.length }
								{ panel.position ? ` · ${ panel.position }` : '' }
							</p>
						</div>
					) ) }
				</div>
			</div>
		</>
	);
}
