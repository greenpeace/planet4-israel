import { useBlockProps } from '@wordpress/block-editor';

const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0,0,0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

/** Build the gradient CSS string for the overlay layer. */
function buildGradient( style, color, opacity ) {
	if ( ! style || style === 'none' ) return null;
	const col = `rgba(${ hexToRgb( color ) }, ${ opacity / 100 })`;
	const map = {
		bottom: `linear-gradient(to top, ${ col } 0%, transparent 65%)`,
		top:    `linear-gradient(to bottom, ${ col } 0%, transparent 65%)`,
		left:   `linear-gradient(to right, ${ col } 0%, transparent 65%)`,
		right:  `linear-gradient(to left, ${ col } 0%, transparent 65%)`,
	};
	return map[ style ] || null;
}

const MEDIA_HEIGHT_VH = { full: 100, half: 50, small: 30 };

export default function Save( { attributes } ) {
	const {
		mediaUrl,
		mediaType,
		mediaHeight,
		focalPoint,
		overlayColor,
		overlayOpacity,
		panels,
		panelPosition,
		panelWidth,
		panelTitleColor,
		panelBodyColor,
		panelTextAlign,
		panelBgColor,
		panelBgOpacity,
		panelBorderColor,
		panelBorderWidth,
		gradientStyle,
		gradientColor,
		gradientOpacity,
		isRtl,
		fixedBackground,
	} = attributes;

	const gradient = buildGradient( gradientStyle, gradientColor, gradientOpacity );
	const heightVh = MEDIA_HEIGHT_VH[ mediaHeight ] || 100;
	const focalPos = focalPoint
		? `${ Math.round( focalPoint.x * 100 ) }% ${ Math.round( focalPoint.y * 100 ) }%`
		: '50% 50%';

	const blockProps = useBlockProps.save( {
		className: `st-bg-scroll st-panel-pos--${ panelPosition }`,
		// These data-* attributes are read by frontend.js at runtime
		'data-panel-position':   panelPosition,
		'data-panel-bg-color':   panelBgColor,
		'data-panel-bg-opacity': panelBgOpacity,
		'data-panel-border-color': panelBorderColor,
		'data-panel-border-width': panelBorderWidth,
		'data-media-height': heightVh,
		dir: isRtl ? 'rtl' : undefined,
	} );

	return (
		<section { ...blockProps }>
			<div className="st-bg-scroll__sticky" aria-hidden="true">
				{ /* ── Background media ── */ }
				{ mediaUrl && mediaType === 'video' ? (
					<video
						className={ `st-bg-scroll__media st-lazy-video${ fixedBackground ? ' st-video-fixed' : '' }` }
						data-src={ mediaUrl }
						muted loop playsInline preload="none"
						style={ { objectPosition: focalPos } }
					/>
				) : mediaUrl ? (
					fixedBackground ? (
						<div
							className="st-bg-scroll__media st-bg-fixed"
							style={ { backgroundImage: `url(${ mediaUrl })`, backgroundPosition: focalPos } }
						/>
					) : (
						<img className="st-bg-scroll__media" src={ mediaUrl } alt="" style={ { objectPosition: focalPos } } />
					)
				) : null }

				{ /* ── Solid colour tint ── */ }
				<div
					className="st-bg-scroll__overlay"
					style={ { background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })` } }
					aria-hidden="true"
				/>

				{ /* ── Directional gradient overlay ── */ }
				{ gradient && (
					<div
						className="st-bg-scroll__gradient"
						style={ { background: gradient } }
						aria-hidden="true"
					/>
				) }
			</div>

			<div className="st-bg-scroll__panels">
				{ panels.map( ( panel, i ) => (
					<div
						key={ panel.id }
						className="st-bg-scroll__panel"
						style={ { '--panel-width': `${ panelWidth }%` } }
						data-panel-index={ i }
						data-panel-pos={ panel.position || '' }
					>
						<div
							className="st-bg-scroll__panel-inner"
							style={ panelTextAlign ? { textAlign: panelTextAlign } : undefined }
						>
							{ panel.title && (
								<h2 className="st-bg-scroll__panel-title"
									style={ panelTitleColor ? { color: panelTitleColor } : undefined }>
									{ panel.title }
								</h2>
							) }
							{ panel.body && (
								<p className="st-bg-scroll__panel-body"
									style={ panelBodyColor ? { color: panelBodyColor } : undefined }>
									{ panel.body }
								</p>
							) }
						</div>
					</div>
				) ) }
			</div>
		</section>
	);
}
