import { __ } from '@wordpress/i18n';
import { useBlockProps, PlainText } from '@wordpress/block-editor';
import { useEffect, useRef } from '@wordpress/element';

export default function Edit( { attributes, setAttributes } ) {
	const { css } = attributes;
	const wrapperRef = useRef( null );
	const blockProps = useBlockProps( { className: 'st-css-handler-editor', ref: wrapperRef } );

	/*
	 * Live preview: inject the CSS into the editor canvas's own document
	 * (correctly targets the editor iframe, not the outer wp-admin page) so
	 * authors can see the effect of their styles while editing. Always via
	 * `textContent` — a DOM text-node write, never HTML/CSS parsed from a
	 * string — so there's no path for the CSS text to be read as markup.
	 */
	useEffect( () => {
		const doc = wrapperRef.current?.ownerDocument;
		if ( ! doc ) return;

		const styleEl = doc.createElement( 'style' );
		styleEl.setAttribute( 'data-st-css-handler-preview', '' );
		styleEl.textContent = css;
		doc.head.appendChild( styleEl );

		return () => styleEl.remove();
	}, [ css ] );

	return (
		<div { ...blockProps }>
			<div style={ { display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 14px', background: '#1e1e1e', borderRadius: '4px 4px 0 0' } }>
				<span style={ { fontSize: '11px', fontWeight: 600, color: '#9ca3af', letterSpacing: '0.05em', textTransform: 'uppercase' } }>
					{ __( 'Custom CSS', 'scrollytelling' ) }
				</span>
			</div>
			<PlainText
				value={ css }
				onChange={ ( v ) => setAttributes( { css: v } ) }
				placeholder={ __( '.my-class { color: red; }', 'scrollytelling' ) }
				aria-label={ __( 'Custom CSS', 'scrollytelling' ) }
				style={ {
					display: 'block',
					width: '100%',
					minHeight: '160px',
					padding: '14px',
					margin: 0,
					background: '#1e1e1e',
					color: '#d4d4d4',
					fontFamily: 'Menlo, Consolas, "Courier New", monospace',
					fontSize: '13px',
					lineHeight: 1.6,
					border: 'none',
					borderRadius: '0 0 4px 4px',
					resize: 'vertical',
					boxSizing: 'border-box',
				} }
			/>
			<p style={ { fontSize: '12px', color: '#757575', margin: '8px 2px 0' } }>
				{ __( 'Applies to the whole page, regardless of where this block is placed.', 'scrollytelling' ) }
			</p>
		</div>
	);
}
