import { useBlockProps } from '@wordpress/block-editor';

/*
 * Security note: the CSS is stored ONLY in a `data-css` HTML attribute, never
 * placed inside a literal <style>...</style> tag in this static markup.
 * Attribute values use plain, universally-safe HTML entity-escaping (no
 * ambiguity) — unlike <style>/<script> content, which the HTML5 spec parses
 * as "raw text" and which some serializers can get wrong, opening a path to
 * break out of the tag with a literal `</style>` in the CSS text.
 *
 * frontend.js reads this attribute and creates the real <style> element at
 * runtime using `styleEl.textContent = css`, which is a DOM text-node write,
 * not HTML/CSS parsing of a string — there is no way for the CSS content to
 * be interpreted as markup.
 */
export default function Save( { attributes } ) {
	const { css } = attributes;

	const blockProps = useBlockProps.save( {
		className: 'st-css-handler',
		'data-css': css,
		style: { display: 'none' },
		'aria-hidden': 'true',
	} );

	return <div { ...blockProps } />;
}
