import { useBlockProps } from '@wordpress/block-editor';
import { POSITION_CLASS } from '../../components/PositionPicker';

const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0,0,0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

function bgClass( fixedBackground, zoomedBackground, mediaType ) {
	const classes = [ 'st-hero__bg' ];
	if ( fixedBackground && mediaType === 'video' ) classes.push( 'st-video-fixed' );
	if ( fixedBackground && mediaType !== 'video' ) classes.push( 'st-bg-fixed' );
	if ( zoomedBackground ) classes.push( 'st-zoom' );
	return classes.join( ' ' );
}

/* Pre-lazy-loading markup: <video> had src + autoplay directly, no
   data-src/preload/st-lazy-video. Kept so existing saved posts with a
   video background still validate against this shape instead of the
   current save() — without this, "Block contains unexpected or invalid
   content" would appear for every such post after this update. */
export default function SaveV1( { attributes } ) {
	const {
		mediaUrl, mediaType,
		title, subtitle, byline,
		titleColor, subtitleColor, bylineColor,
		textPosition, textAlign,
		overlayColor, overlayOpacity,
		minHeight, isRtl,
		fixedBackground, zoomedBackground, backgroundBlur,
		logoUrl, logoPosition, logoSize,
	} = attributes;

	const posClass   = POSITION_CLASS[ textPosition ] || 'st-pos--center';
	const alignClass = textAlign ? `st-align--${ textAlign }` : '';

	const sectionStyle = { '--st-min-height': minHeight };

	const blockProps = useBlockProps.save( {
		className: `st-hero ${ posClass } ${ alignClass }`.trim(),
		style: sectionStyle,
		'data-blur': backgroundBlur > 0 ? backgroundBlur : undefined,
		dir: isRtl ? 'rtl' : undefined,
	} );

	const bgClassName = bgClass( fixedBackground, zoomedBackground, mediaType );

	const logoImg = logoUrl ? (
		<img
			className={ `st-hero__logo st-hero__logo--${ logoPosition }` }
			src={ logoUrl }
			alt=""
			style={ { width: logoSize + 'px' } }
		/>
	) : null;

	return (
		<section { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video
					className={ bgClassName }
					src={ mediaUrl }
					autoPlay muted loop playsInline
					aria-hidden="true"
				/>
			) : mediaUrl ? (
				fixedBackground ? (
					<div className={ bgClassName } style={ { backgroundImage: `url(${ mediaUrl })` } } aria-hidden="true" />
				) : (
					<img className={ bgClassName } src={ mediaUrl } alt="" aria-hidden="true" />
				)
			) : null }

			<div
				className="st-hero__overlay"
				style={ {
					'--st-overlay-color': overlayColor,
					background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })`,
				} }
				aria-hidden="true"
			/>

			{ logoUrl && logoPosition === 'bottom-right' && logoImg }

			<div className="st-hero__content">
				{ logoUrl && logoPosition === 'before-title' && logoImg }
				{ title && <h1 className="st-hero__title" style={ { color: titleColor } }>{ title }</h1> }
				{ subtitle && <p className="st-hero__subtitle" style={ { color: subtitleColor } }>{ subtitle }</p> }
				{ logoUrl && logoPosition === 'after-subtitle' && logoImg }
				{ byline && <p className="st-hero__byline" style={ { color: bylineColor } }>{ byline }</p> }
			</div>
		</section>
	);
}
