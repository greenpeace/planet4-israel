import { useBlockProps } from '@wordpress/block-editor';

/* Pre-lazy-loading markup: <video> had src + autoplay directly, no
   data-src/preload/st-lazy-video. Kept so existing saved posts with a
   video background still validate against this shape instead of the
   current save(). */
export default function SaveV1( { attributes } ) {
	const { mediaUrl, mediaType, caption, height, objectFit, isRtl, fixedBackground } = attributes;
	const blockProps = useBlockProps.save( {
		className: `st-reveal st-reveal--${ height }`,
		dir: isRtl ? 'rtl' : undefined,
		style: { '--st-object-fit': objectFit },
	} );

	return (
		<div { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video className={ `st-reveal__media${ fixedBackground ? ' st-video-fixed' : '' }` }
					src={ mediaUrl } autoPlay muted loop playsInline
					style={ { objectFit } } aria-hidden="true" />
			) : mediaUrl ? (
				fixedBackground ? (
					<div className="st-reveal__media st-bg-fixed"
						style={ { backgroundImage: `url(${ mediaUrl })` } }
						aria-hidden="true" />
				) : (
					<img className="st-reveal__media" src={ mediaUrl } alt=""
						style={ { objectFit } } aria-hidden="true" />
				)
			) : null }
			{ caption && <p className="st-reveal__caption">{ caption }</p> }
		</div>
	);
}
