import { __ } from '@wordpress/i18n';
import { InspectorControls, MediaUpload, MediaUploadCheck, useBlockProps } from '@wordpress/block-editor';
import { Button, PanelBody, SelectControl, TextControl, ToggleControl } from '@wordpress/components';

const HEIGHT_MAP = { full: '100vh', half: '50vh', third: '34vh' };

export default function Edit( { attributes, setAttributes } ) {
	const { mediaUrl, mediaType, caption, height, objectFit, isRtl, fixedBackground } = attributes;
	const blockProps = useBlockProps( { className: 'st-reveal-editor' } );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Media', 'scrollytelling' ) } initialOpen>
					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( m ) => setAttributes( { mediaUrl: m.url, mediaId: m.id, mediaType: m.type === 'video' ? 'video' : 'image' } ) }
							allowedTypes={ [ 'image', 'video' ] }
							value={ attributes.mediaId }
							render={ ( { open } ) => (
								<Button variant="secondary" onClick={ open } style={ { width: '100%', marginBottom: '8px' } }>
									{ mediaUrl ? __( 'Replace Media', 'scrollytelling' ) : __( 'Upload / Select Media', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>
					{ mediaUrl && <Button isDestructive variant="link" onClick={ () => setAttributes( { mediaUrl: '', mediaId: undefined } ) }>{ __( 'Remove', 'scrollytelling' ) }</Button> }
				</PanelBody>
				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<SelectControl
						label={ __( 'Section Height', 'scrollytelling' ) }
						value={ height }
						options={ [
							{ label: __( 'Full screen (100vh)', 'scrollytelling' ), value: 'full' },
							{ label: __( 'Half screen (50vh)', 'scrollytelling' ),  value: 'half' },
							{ label: __( 'One third (34vh)', 'scrollytelling' ),    value: 'third' },
						] }
						onChange={ ( v ) => setAttributes( { height: v } ) }
					/>
					<SelectControl
						label={ __( 'Image Fit', 'scrollytelling' ) }
						value={ objectFit }
						options={ [
							{ label: __( 'Cover (fill & crop)', 'scrollytelling' ), value: 'cover' },
							{ label: __( 'Contain (show all)', 'scrollytelling' ), value: 'contain' },
						] }
						onChange={ ( v ) => setAttributes( { objectFit: v } ) }
					/>
					<TextControl
						label={ __( 'Caption (optional)', 'scrollytelling' ) }
						value={ caption }
						onChange={ ( v ) => setAttributes( { caption: v } ) }
					/>
					<ToggleControl
						label={ __( 'Fixed background (parallax)', 'scrollytelling' ) }
						checked={ fixedBackground }
						onChange={ ( v ) => setAttributes( { fixedBackground: v } ) }
					/>
				</PanelBody>
				<PanelBody title={ __( 'Accessibility', 'scrollytelling' ) } initialOpen={ false }>
					<ToggleControl
						label={ __( 'Right-to-left text (RTL)', 'scrollytelling' ) }
						checked={ isRtl }
						onChange={ ( v ) => setAttributes( { isRtl: v } ) }
					/>
				</PanelBody>
			</InspectorControls>

			<div
				{ ...blockProps }
				style={ { position: 'relative', overflow: 'hidden', background: '#111', minHeight: HEIGHT_MAP[ height ] || '100vh' } }
			>
				{ mediaUrl ? (
					mediaType === 'video' ? (
						<video src={ mediaUrl } autoPlay muted loop playsInline style={ { width: '100%', height: '100%', objectFit, position: 'absolute', inset: 0 } } />
					) : (
						<img src={ mediaUrl } alt="" style={ { width: '100%', height: '100%', objectFit, position: 'absolute', inset: 0 } } />
					)
				) : (
					<div style={ { position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#555', fontSize: '14px' } }>
						{ __( 'Upload an image or video in the sidebar to create a Reveal section.', 'scrollytelling' ) }
					</div>
				) }

				{ /* Reveal animation preview hint */ }
				<div style={ { position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1 } }>
					<span style={ { background: 'rgba(0,0,0,0.5)', color: '#fff', borderRadius: '4px', padding: '6px 12px', fontSize: '12px', letterSpacing: '0.05em' } }>
						{ __( 'REVEAL — fades in on scroll', 'scrollytelling' ) }
					</span>
				</div>

				{ caption && (
					<p style={ { position: 'absolute', bottom: 16, left: 0, right: 0, textAlign: 'center', color: 'rgba(255,255,255,0.7)', fontSize: '0.8rem', zIndex: 2 } }>{ caption }</p>
				) }
			</div>
		</>
	);
}
