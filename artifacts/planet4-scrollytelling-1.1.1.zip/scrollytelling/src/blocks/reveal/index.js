import metadata from './block.json';
import Edit from './edit';
import Save from './save';
import SaveV1 from './deprecated';
export default {
	...metadata,
	edit: Edit,
	save: Save,
	deprecated: [ { attributes: metadata.attributes, save: SaveV1 } ],
};
