import { useBlockProps } from '@wordpress/block-editor';

export default function Save( { attributes } ) {
	const { mediaUrl, mediaType, caption, height, objectFit, isRtl, fixedBackground } = attributes;
	const blockProps = useBlockProps.save( {
		className: `st-reveal st-reveal--${ height }`,
		dir: isRtl ? 'rtl' : undefined,
		style: { '--st-object-fit': objectFit },
	} );

	return (
		<div { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video className={ `st-reveal__media st-lazy-video${ fixedBackground ? ' st-video-fixed' : '' }` }
					data-src={ mediaUrl } muted loop playsInline preload="none"
					style={ { objectFit } } aria-hidden="true" />
			) : mediaUrl ? (
				fixedBackground ? (
					<div className="st-reveal__media st-bg-fixed"
						style={ { backgroundImage: `url(${ mediaUrl })` } }
						aria-hidden="true" />
				) : (
					<img className="st-reveal__media" src={ mediaUrl } alt=""
						style={ { objectFit } } aria-hidden="true" />
				)
			) : null }
			{ caption && <p className="st-reveal__caption">{ caption }</p> }
		</div>
	);
}
