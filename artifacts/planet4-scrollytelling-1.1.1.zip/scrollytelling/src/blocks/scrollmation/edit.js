import { __ } from '@wordpress/i18n';
import {
	InspectorControls,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
	RichText,
} from '@wordpress/block-editor';
import {
	Button,
	FocalPointPicker,
	PanelBody,
	TextControl,
	SelectControl,
	ToggleControl,
} from '@wordpress/components';
import { useState } from '@wordpress/element';

const ColorRow = ( { label, value, onChange } ) => (
	<div style={ { marginBottom: '14px' } }>
		<label style={ { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', fontWeight: 500, cursor: 'pointer' } }>
			<input
				type="color"
				value={ value }
				onChange={ ( e ) => onChange( e.target.value ) }
				style={ { width: 32, height: 24, borderRadius: '3px', border: '1px solid #ccc', cursor: 'pointer', padding: 0 } }
			/>
			{ label }
		</label>
	</div>
);

export default function Edit( { attributes, setAttributes } ) {
	const {
		frames, content, imageSide, textColor, bgColor,
		objectFit, imageBg, imageFullHeight, isRtl, textAlign,
	} = attributes;

	const [ previewFrame, setPreviewFrame ] = useState( 0 );

	const isImgRight  = imageSide === 'right';
	const safePreview = Math.min( previewFrame, Math.max( 0, frames.length - 1 ) );
	const current     = frames[ safePreview ];

	const blockProps = useBlockProps( { className: 'st-scrollmation-editor', style: { padding: 0 } } );

	/* ── Frame management ────────────────────────────────────────────── */

	const addFrames = ( mediaItems ) => {
		const next = ( Array.isArray( mediaItems ) ? mediaItems : [ mediaItems ] )
			.map( ( m ) => ( {
				id: m.id, url: m.url, alt: m.alt || '',
				caption: '', focalPoint: { x: 0.5, y: 0.5 },
			} ) );
		setAttributes( { frames: [ ...frames, ...next ] } );
	};

	const removeFrame = ( index ) => {
		setAttributes( { frames: frames.filter( ( _, i ) => i !== index ) } );
		setPreviewFrame( ( p ) => Math.max( 0, p >= index ? p - 1 : p ) );
	};

	const moveFrame = ( from, to ) => {
		const updated = [ ...frames ];
		const [ item ] = updated.splice( from, 1 );
		updated.splice( to, 0, item );
		setAttributes( { frames: updated } );
		setPreviewFrame( to );
	};

	const updateFrame = ( index, patch ) => {
		const updated = [ ...frames ];
		updated[ index ] = { ...updated[ index ], ...patch };
		setAttributes( { frames: updated } );
	};

	/* ── Helpers ─────────────────────────────────────────────────────── */

	const focalStyle = ( frame ) => ( {
		objectFit: objectFit,
		objectPosition: frame?.focalPoint
			? `${ Math.round( frame.focalPoint.x * 100 ) }% ${ Math.round( frame.focalPoint.y * 100 ) }%`
			: '50% 50%',
	} );

	/* column order for preview canvas */
	const colOrder = ( isMedia ) => ( {
		flex: '0 0 50%', maxWidth: '50%', boxSizing: 'border-box',
		order: isMedia ? ( isImgRight ? 2 : 1 ) : ( isImgRight ? 1 : 2 ),
	} );

	/* ── Image column preview ────────────────────────────────────────── */

	const mediaPreview = (
		frames.length === 0 ? (
			<div style={ { textAlign: 'center', color: '#888', padding: '40px 20px' } }>
				<div style={ { fontSize: '32px', marginBottom: '12px', opacity: 0.4 } }>🖼</div>
				<p style={ { fontSize: '13px', margin: 0, lineHeight: 1.5 } }>
					{ __( 'Add image frames in the sidebar →', 'scrollytelling' ) }
				</p>
			</div>
		) : (
			<>
				{ current && (
					<img
						src={ current.url }
						alt={ current.alt || '' }
						style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', ...focalStyle( current ) } }
					/>
				) }
				{ current?.caption && (
					<p style={ {
						position: 'absolute', bottom: 44, left: 0, right: 0, zIndex: 2,
						fontSize: '11px', color: 'rgba(255,255,255,0.8)',
						textAlign: 'center', margin: 0, padding: '0 12px',
					} }>
						{ current.caption }
					</p>
				) }
				{ /* Thumbnail strip */ }
				<div style={ {
					position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 2,
					display: 'flex', gap: '4px', padding: '8px', overflowX: 'auto',
					background: 'rgba(0,0,0,0.55)',
				} }>
					{ frames.map( ( frame, i ) => (
						<img
							key={ frame.id || i }
							src={ frame.url } alt=""
							onClick={ () => setPreviewFrame( i ) }
							style={ {
								width: 44, height: 33, objectFit: 'cover',
								objectPosition: frame.focalPoint
									? `${ Math.round( frame.focalPoint.x * 100 ) }% ${ Math.round( frame.focalPoint.y * 100 ) }%`
									: '50% 50%',
								borderRadius: '2px', cursor: 'pointer', flexShrink: 0,
								outline: i === safePreview ? '2px solid #0ea5e9' : 'none',
								outlineOffset: '1px',
							} }
						/>
					) ) }
				</div>
				{ /* Badge */ }
				<div style={ {
					position: 'absolute', top: 10, right: 10, zIndex: 2,
					background: 'rgba(0,0,0,0.6)', color: '#fff',
					fontSize: '11px', padding: '3px 8px', borderRadius: '20px',
				} }>
					{ safePreview + 1 } / { frames.length }
				</div>
			</>
		)
	);

	/* ── Editor canvas ───────────────────────────────────────────────── */

	const textCol = (
		<div
			dir={ isRtl ? 'rtl' : 'ltr' }
			style={ { ...colOrder( false ), padding: '40px 6%', color: textColor, minHeight: '300px', textAlign } }
		>
			<RichText
				tagName="div"
				className="st-scrollmation__text-content"
				value={ content }
				onChange={ ( v ) => setAttributes( { content: v } ) }
				placeholder={ __( 'Add your story text here — the images will advance as the reader scrolls through it.', 'scrollytelling' ) }
				multiline="p"
				allowedFormats={ [ 'core/bold', 'core/italic', 'core/link', 'core/superscript', 'core/subscript', 'core/underline' ] }
				style={ { minHeight: '150px', fontSize: '1.05rem', lineHeight: 1.8, color: textColor } }
			/>
		</div>
	);

	/* Image column background: imageBg in full-height mode, bgColor in natural-height */
	const imgColBg = imageFullHeight ? imageBg : bgColor;

	const imgCol = (
		<div style={ {
			...colOrder( true ),
			background: imgColBg, position: 'relative', overflow: 'hidden',
			minHeight: imageFullHeight ? '400px' : '250px',
			display: 'flex', flexDirection: 'column',
			justifyContent: 'center', alignItems: 'center',
		} }>
			{ mediaPreview }
		</div>
	);

	return (
		<>
			{ /* ── Sidebar ──────────────────────────────────────────────── */ }
			<InspectorControls>

				<PanelBody title={ __( 'Images', 'scrollytelling' ) } initialOpen>
					<p style={ { fontSize: '12px', color: '#555', marginBottom: '10px' } }>
						{ __( 'Frames advance proportionally as the reader scrolls through the text.', 'scrollytelling' ) }
					</p>

					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( media ) => addFrames( Array.isArray( media ) ? media : [ media ] ) }
							allowedTypes={ [ 'image' ] }
							multiple gallery={ false }
							value={ frames.map( ( f ) => f.id ) }
							render={ ( { open } ) => (
								<Button
									variant="primary" onClick={ open }
									style={ { width: '100%', marginBottom: '14px', justifyContent: 'center' } }
								>
									{ __( '+ Add / Replace Frames', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>

					{ frames.map( ( frame, i ) => (
						<div
							key={ frame.id || i }
							style={ {
								background: '#f5f5f5', borderRadius: '5px',
								padding: '8px', marginBottom: '10px',
								border: i === safePreview ? '2px solid #0ea5e9' : '2px solid transparent',
							} }
						>
							<div style={ { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' } }>
								<img
									src={ frame.url } alt=""
									onClick={ () => setPreviewFrame( i ) }
									style={ { width: 48, height: 36, objectFit: 'cover', borderRadius: '3px', cursor: 'pointer', flexShrink: 0 } }
								/>
								<span style={ { fontSize: '11px', flex: 1, color: '#555' } }>
									{ __( 'Frame', 'scrollytelling' ) } { i + 1 }
								</span>
								<Button variant="link" size="small" disabled={ i === 0 }
									onClick={ () => moveFrame( i, i - 1 ) }
									style={ { minWidth: 0, padding: '2px 4px' } }>↑</Button>
								<Button variant="link" size="small" disabled={ i === frames.length - 1 }
									onClick={ () => moveFrame( i, i + 1 ) }
									style={ { minWidth: 0, padding: '2px 4px' } }>↓</Button>
								<Button isDestructive variant="link" size="small"
									onClick={ () => removeFrame( i ) }
									style={ { minWidth: 0, padding: '2px 4px', fontSize: '11px' } }>✕</Button>
							</div>
							<TextControl
								label={ __( 'Caption (optional)', 'scrollytelling' ) }
								value={ frame.caption || '' }
								onChange={ ( v ) => updateFrame( i, { caption: v } ) }
								placeholder={ __( 'Caption for this frame…', 'scrollytelling' ) }
								style={ { marginBottom: 0 } }
							/>
						</div>
					) ) }

					{ /* Focal point for currently previewed frame */ }
					{ frames.length > 0 && current && (
						<div style={ { marginTop: '16px', borderTop: '1px solid #ddd', paddingTop: '14px' } }>
							<p style={ { fontSize: '11px', fontWeight: 600, margin: '0 0 8px', color: '#333' } }>
								{ __( 'Focal point — Frame', 'scrollytelling' ) } { safePreview + 1 }
								<span style={ { fontWeight: 400, color: '#777' } }>
									{ ' ' }({ __( 'click thumbnail above to switch', 'scrollytelling' ) })
								</span>
							</p>
							<FocalPointPicker
								url={ current.url }
								value={ current.focalPoint || { x: 0.5, y: 0.5 } }
								onChange={ ( focalPoint ) => updateFrame( safePreview, { focalPoint } ) }
							/>
						</div>
					) }
				</PanelBody>

				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<ToggleControl
						label={ __( 'Full-height image column', 'scrollytelling' ) }
						help={ imageFullHeight
							? __( 'Image fills the full viewport height and sticks while text scrolls.', 'scrollytelling' )
							: __( 'Image matches the text column height. Both columns scroll together.', 'scrollytelling' )
						}
						checked={ imageFullHeight }
						onChange={ ( v ) => setAttributes( { imageFullHeight: v } ) }
					/>
					<SelectControl
						label={ __( 'Image side', 'scrollytelling' ) }
						value={ imageSide }
						options={ [
							{ label: __( 'Right (text left)', 'scrollytelling' ),  value: 'right' },
							{ label: __( 'Left (text right)', 'scrollytelling' ), value: 'left' },
						] }
						onChange={ ( v ) => setAttributes( { imageSide: v } ) }
					/>
					<SelectControl
						label={ __( 'Image fit', 'scrollytelling' ) }
						value={ objectFit }
						options={ [
							{ label: __( 'Cover (crop to fill)', 'scrollytelling' ),   value: 'cover'   },
							{ label: __( 'Contain (letterbox)', 'scrollytelling' ), value: 'contain' },
						] }
						onChange={ ( v ) => setAttributes( { objectFit: v } ) }
						help={ __( 'Set focal point in the Images panel to control the crop centre.', 'scrollytelling' ) }
					/>
					<ToggleControl
						label={ __( 'Right-to-left text (RTL)', 'scrollytelling' ) }
						help={ isRtl
							? __( 'Text direction is right-to-left (Hebrew, Arabic…).', 'scrollytelling' )
							: __( 'Text direction is left-to-right.', 'scrollytelling' )
						}
						checked={ isRtl }
						onChange={ ( v ) => setAttributes( {
							isRtl: v,
							textAlign: v ? 'right' : 'left',
						} ) }
					/>
					<SelectControl
						label={ __( 'Text alignment', 'scrollytelling' ) }
						value={ textAlign }
						options={ [
							{ label: __( 'Start (follows direction)', 'scrollytelling' ), value: 'start' },
							{ label: __( 'Right', 'scrollytelling' ), value: 'right' },
							{ label: __( 'Center', 'scrollytelling' ), value: 'center' },
							{ label: __( 'Left', 'scrollytelling' ),  value: 'left'  },
						] }
						onChange={ ( v ) => setAttributes( { textAlign: v } ) }
					/>
				</PanelBody>

				<PanelBody title={ __( 'Colors', 'scrollytelling' ) } initialOpen={ false }>
					<ColorRow
						label={ __( 'Text color', 'scrollytelling' ) }
						value={ textColor }
						onChange={ ( v ) => setAttributes( { textColor: v } ) }
					/>
					<ColorRow
						label={ __( 'Section background', 'scrollytelling' ) }
						value={ bgColor }
						onChange={ ( v ) => setAttributes( { bgColor: v } ) }
					/>
					{ imageFullHeight && (
						<ColorRow
							label={ __( 'Image column background', 'scrollytelling' ) }
							value={ imageBg }
							onChange={ ( v ) => setAttributes( { imageBg: v } ) }
						/>
					) }
					{ ! imageFullHeight && (
						<p style={ { fontSize: '12px', color: '#888', margin: 0 } }>
							{ __( 'In natural-height mode the image column uses the section background colour.', 'scrollytelling' ) }
						</p>
					) }
				</PanelBody>
			</InspectorControls>

			{ /* ── Editor canvas ───────────────────────────────────────── */ }
			<div
				{ ...blockProps }
				style={ {
					display: 'flex', flexWrap: 'wrap', minHeight: '300px',
					background: bgColor, padding: 0,
				} }
			>
				{ textCol }
				{ imgCol }
			</div>
		</>
	);
}
