import { useBlockProps, RichText } from '@wordpress/block-editor';

const focalPos = ( frame ) =>
	frame.focalPoint
		? `${ Math.round( frame.focalPoint.x * 100 ) }% ${ Math.round( frame.focalPoint.y * 100 ) }%`
		: '50% 50%';

export default function Save( { attributes } ) {
	const {
		frames, content, imageSide, textColor,
		bgColor, objectFit, imageBg, imageFullHeight,
		isRtl, textAlign,
	} = attributes;

	const classes = [
		'st-scrollmation',
		`st-scrollmation--img-${ imageSide }`,
		! imageFullHeight ? 'st-scrollmation--natural' : '',
	].filter( Boolean ).join( ' ' );

	const blockProps = useBlockProps.save( {
		className: classes,
		style: { background: bgColor },
	} );

	/* In natural-height mode the image column uses the same background as the
	   text column so there is no visible contrast gap. */
	const mediaColBg = imageFullHeight ? imageBg : bgColor;

	return (
		<section { ...blockProps }>

			{ /* ── Text column ─────────────────────────────────────────── */ }
			<div
				className="st-scrollmation__text-col"
				dir={ isRtl ? 'rtl' : undefined }
			>
				<div className="st-scrollmation__text-inner">
					<RichText.Content
						tagName="div"
						className="st-scrollmation__text-content"
						value={ content }
						style={ {
							...( textColor ? { color: textColor } : {} ),
							...( textAlign && textAlign !== 'start' ? { textAlign } : {} ),
						} }
					/>
				</div>
			</div>

			{ /* ── Image column ─────────────────────────────────────────── */ }
			<div
				className="st-scrollmation__media-col"
				style={ { background: mediaColBg } }
				aria-hidden="true"
			>
				<div className="st-scrollmation__stage">
					{ frames.map( ( frame, i ) => (
						<img
							key={ frame.id || i }
							className="st-scrollmation__frame"
							src={ frame.url }
							alt={ frame.alt || '' }
							data-frame={ i }
							data-caption={ frame.caption || '' }
							data-fit={ objectFit }
							style={ { objectPosition: focalPos( frame ) } }
							aria-hidden={ i !== 0 ? 'true' : undefined }
						/>
					) ) }
				</div>
				<p className="st-scrollmation__caption"></p>
			</div>

		</section>
	);
}
