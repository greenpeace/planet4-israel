import { __ } from '@wordpress/i18n';
import {
	InspectorControls,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
	RichText,
} from '@wordpress/block-editor';
import {
	Button,
	FocalPointPicker,
	PanelBody,
	RangeControl,
	SelectControl,
	ToggleControl,
} from '@wordpress/components';
import { useState } from '@wordpress/element';

const hexToRgba = ( hex, opacity ) => {
	if ( ! hex || hex.length < 7 ) return `rgba(0,0,0,${ opacity })`;
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `rgba(${ r },${ g },${ b },${ opacity })`;
};

const ColorRow = ( { label, value, onChange } ) => (
	<div style={ { marginBottom: '14px' } }>
		<label style={ { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', fontWeight: 500, cursor: 'pointer' } }>
			<input
				type="color"
				value={ value }
				onChange={ ( e ) => onChange( e.target.value ) }
				style={ { width: 32, height: 24, borderRadius: '3px', border: '1px solid #ccc', cursor: 'pointer', padding: 0 } }
			/>
			{ label }
		</label>
	</div>
);

const createPoint = () => ( {
	id:         `sp-${ Date.now() }-${ Math.random().toString( 36 ).slice( 2, 6 ) }`,
	text:       '',
	focalPoint: { x: 0.5, y: 0.5 },
	zoom:       1.0,
} );

export default function Edit( { attributes, setAttributes } ) {
	const {
		imageUrl, imageId, imageAlt, points,
		textPosition, panelWidth,
		textColor, bgColor, bgOpacity,
		overlayColor, overlayOpacity,
		isRtl,
	} = attributes;

	const [ activeIdx, setActiveIdx ] = useState( 0 );

	const safeIdx    = Math.min( activeIdx, Math.max( 0, points.length - 1 ) );
	const activePoint = points[ safeIdx ];

	const blockProps = useBlockProps( { className: 'st-scrollpoints-editor', style: { padding: 0 } } );

	/* ── Point management ──────────────────────────────────────── */

	const addPoint = () => {
		const next = [ ...points, createPoint() ];
		setAttributes( { points: next } );
		setActiveIdx( next.length - 1 );
	};

	const removePoint = ( i ) => {
		setAttributes( { points: points.filter( ( _, idx ) => idx !== i ) } );
		setActiveIdx( ( p ) => Math.max( 0, p >= i ? p - 1 : p ) );
	};

	const movePoint = ( from, to ) => {
		const updated = [ ...points ];
		const [ item ] = updated.splice( from, 1 );
		updated.splice( to, 0, item );
		setAttributes( { points: updated } );
		setActiveIdx( to );
	};

	const updatePoint = ( i, patch ) => {
		const updated = [ ...points ];
		updated[ i ] = { ...updated[ i ], ...patch };
		setAttributes( { points: updated } );
	};

	/* ── Image preview transform for active point ───────────────── */

	const fpX = Math.round( ( activePoint?.focalPoint?.x ?? 0.5 ) * 100 );
	const fpY = Math.round( ( activePoint?.focalPoint?.y ?? 0.5 ) * 100 );
	const fpZoom = activePoint?.zoom ?? 1;

	const imgPreviewStyle = {
		position: 'absolute',
		inset: 0,
		width: '100%',
		height: '100%',
		objectFit: 'cover',
		objectPosition: `${ fpX }% ${ fpY }%`,
		transformOrigin: `${ fpX }% ${ fpY }%`,
		transform: fpZoom > 1 ? `scale( ${ fpZoom } )` : 'none',
		transition: 'object-position 0.6s ease, transform 0.6s ease',
	};

	/* ── Column layout helpers ───────────────────────────────────── */

	const isTextRight = textPosition === 'right';

	const imgColStyle = {
		flex: '0 0 50%',
		maxWidth: '50%',
		order: isTextRight ? 1 : 2,
		background: '#111',
		position: 'relative',
		overflow: 'hidden',
		minHeight: '400px',
	};

	const textColStyle = {
		flex: '0 0 50%',
		maxWidth: '50%',
		order: isTextRight ? 2 : 1,
		background: hexToRgba( bgColor, bgOpacity / 100 ),
		padding: '40px 6%',
		color: textColor,
		minHeight: '400px',
		boxSizing: 'border-box',
		display: 'flex',
		flexDirection: 'column',
	};

	return (
		<>
			{ /* ── Sidebar ─────────────────────────────────────────── */ }
			<InspectorControls>

				<PanelBody title={ __( 'Background Image', 'scrollytelling' ) } initialOpen>
					<p style={ { fontSize: '12px', color: '#555', marginBottom: '10px' } }>
						{ __( 'Use a large image (≥ 3000 px wide) for crisp pan + zoom quality.', 'scrollytelling' ) }
					</p>
					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( media ) => setAttributes( {
								imageUrl: media.url,
								imageId:  media.id,
								imageAlt: media.alt || '',
							} ) }
							allowedTypes={ [ 'image' ] }
							value={ imageId }
							render={ ( { open } ) => (
								<Button
									variant={ imageUrl ? 'secondary' : 'primary' }
									onClick={ open }
									style={ { width: '100%', marginBottom: '10px', justifyContent: 'center' } }
								>
									{ imageUrl
										? __( 'Replace Image', 'scrollytelling' )
										: __( 'Upload / Choose Image', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>
					{ imageUrl && (
						<img src={ imageUrl } alt="" style={ { width: '100%', borderRadius: '4px', display: 'block' } } />
					) }
				</PanelBody>

				<PanelBody title={ __( 'Scrollpoints', 'scrollytelling' ) } initialOpen>
					<p style={ { fontSize: '12px', color: '#555', marginBottom: '10px' } }>
						{ __( 'Each point defines a view (pan + zoom) into the image. Readers scroll through them in order.', 'scrollytelling' ) }
					</p>

					{ points.map( ( point, i ) => (
						<div
							key={ point.id || i }
							style={ {
								background: '#f5f5f5',
								borderRadius: '5px',
								padding: '8px',
								marginBottom: '8px',
								border: i === safeIdx ? '2px solid #0ea5e9' : '2px solid transparent',
								cursor: 'pointer',
							} }
							onClick={ () => setActiveIdx( i ) }
						>
							<div style={ { display: 'flex', alignItems: 'center', gap: '6px' } }>
								<span style={ { fontSize: '12px', fontWeight: 600, flex: 1, color: '#333' } }>
									{ __( 'Point', 'scrollytelling' ) } { i + 1 }
									{ i === safeIdx && (
										<span style={ { fontWeight: 400, color: '#0ea5e9', marginLeft: '6px' } }>
											{ `(${ __( 'editing', 'scrollytelling' ) })` }
										</span>
									) }
								</span>
								<Button variant="link" size="small" disabled={ i === 0 }
									onClick={ ( e ) => { e.stopPropagation(); movePoint( i, i - 1 ); } }
									style={ { minWidth: 0, padding: '2px 4px' } }>↑</Button>
								<Button variant="link" size="small" disabled={ i === points.length - 1 }
									onClick={ ( e ) => { e.stopPropagation(); movePoint( i, i + 1 ); } }
									style={ { minWidth: 0, padding: '2px 4px' } }>↓</Button>
								<Button isDestructive variant="link" size="small"
									onClick={ ( e ) => { e.stopPropagation(); removePoint( i ); } }
									style={ { minWidth: 0, padding: '2px 4px', fontSize: '11px' } }>✕</Button>
							</div>
							<div style={ { fontSize: '11px', color: '#777', marginTop: '3px' } }>
								{ `X: ${ Math.round( ( point.focalPoint?.x ?? 0.5 ) * 100 ) }%  Y: ${ Math.round( ( point.focalPoint?.y ?? 0.5 ) * 100 ) }%  Zoom: ${ ( point.zoom ?? 1 ).toFixed( 1 ) }×` }
							</div>
						</div>
					) ) }

					<Button
						variant="primary"
						onClick={ addPoint }
						style={ { width: '100%', justifyContent: 'center', marginBottom: '16px' } }
					>
						{ __( '+ Add Scrollpoint', 'scrollytelling' ) }
					</Button>

					{ imageUrl && activePoint && (
						<div style={ { borderTop: '1px solid #ddd', paddingTop: '14px' } }>
							<p style={ { fontSize: '11px', fontWeight: 600, margin: '0 0 8px', color: '#333' } }>
								{ __( 'Focal point — Point', 'scrollytelling' ) } { safeIdx + 1 }
								<span style={ { fontWeight: 400, color: '#777', marginLeft: '4px' } }>
									{ `(${ __( 'click a point above to switch', 'scrollytelling' ) })` }
								</span>
							</p>
							<FocalPointPicker
								url={ imageUrl }
								value={ activePoint.focalPoint || { x: 0.5, y: 0.5 } }
								onChange={ ( fp ) => updatePoint( safeIdx, { focalPoint: fp } ) }
							/>
							<RangeControl
								label={ __( 'Zoom', 'scrollytelling' ) }
								value={ activePoint.zoom ?? 1 }
								onChange={ ( v ) => updatePoint( safeIdx, { zoom: v } ) }
								min={ 1 }
								max={ 5 }
								step={ 0.1 }
								style={ { marginTop: '12px' } }
							/>
						</div>
					) }
				</PanelBody>

				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<SelectControl
						label={ __( 'Text panel position', 'scrollytelling' ) }
						value={ textPosition }
						options={ [
							{ label: __( 'Right', 'scrollytelling' ), value: 'right' },
							{ label: __( 'Left',  'scrollytelling' ), value: 'left'  },
						] }
						onChange={ ( v ) => setAttributes( { textPosition: v } ) }
					/>
					<RangeControl
						label={ __( 'Panel width (%)', 'scrollytelling' ) }
						value={ panelWidth }
						onChange={ ( v ) => setAttributes( { panelWidth: v } ) }
						min={ 20 }
						max={ 55 }
						step={ 1 }
					/>
					<ToggleControl
						label={ __( 'Right-to-left text (RTL)', 'scrollytelling' ) }
						help={ isRtl
							? __( 'Text direction is right-to-left (Hebrew, Arabic…).', 'scrollytelling' )
							: __( 'Text direction is left-to-right.', 'scrollytelling' )
						}
						checked={ isRtl }
						onChange={ ( v ) => setAttributes( { isRtl: v } ) }
					/>
				</PanelBody>

				<PanelBody title={ __( 'Colors', 'scrollytelling' ) } initialOpen={ false }>
					<ColorRow
						label={ __( 'Text color', 'scrollytelling' ) }
						value={ textColor }
						onChange={ ( v ) => setAttributes( { textColor: v } ) }
					/>
					<ColorRow
						label={ __( 'Panel background', 'scrollytelling' ) }
						value={ bgColor }
						onChange={ ( v ) => setAttributes( { bgColor: v } ) }
					/>
					<RangeControl
						label={ __( 'Panel opacity (%)', 'scrollytelling' ) }
						value={ bgOpacity }
						onChange={ ( v ) => setAttributes( { bgOpacity: v } ) }
						min={ 0 }
						max={ 100 }
						step={ 1 }
					/>
					<ColorRow
						label={ __( 'Image overlay color', 'scrollytelling' ) }
						value={ overlayColor }
						onChange={ ( v ) => setAttributes( { overlayColor: v } ) }
					/>
					<RangeControl
						label={ __( 'Overlay opacity (%)', 'scrollytelling' ) }
						value={ overlayOpacity }
						onChange={ ( v ) => setAttributes( { overlayOpacity: v } ) }
						min={ 0 }
						max={ 100 }
						step={ 1 }
					/>
				</PanelBody>

			</InspectorControls>

			{ /* ── Editor canvas ───────────────────────────────────── */ }
			<div
				{ ...blockProps }
				style={ { display: 'flex', flexWrap: 'wrap', minHeight: '400px', padding: 0 } }
			>
				{ /* Image column */ }
				<div style={ imgColStyle }>
					{ ! imageUrl ? (
						<div style={ {
							display: 'flex', alignItems: 'center', justifyContent: 'center',
							height: '100%', color: '#888', flexDirection: 'column', gap: '12px',
						} }>
							<div style={ { fontSize: '32px', opacity: 0.4 } }>🖼</div>
							<p style={ { fontSize: '13px', margin: 0 } }>
								{ __( 'Upload a background image in the sidebar →', 'scrollytelling' ) }
							</p>
						</div>
					) : (
						<img src={ imageUrl } alt={ imageAlt || '' } style={ imgPreviewStyle } />
					) }

					{ /* Point selector badges */ }
					{ points.length > 0 && (
						<div style={ {
							position: 'absolute', top: 10, left: 10, zIndex: 2,
							display: 'flex', gap: '6px', flexWrap: 'wrap',
						} }>
							{ points.map( ( _, i ) => (
								<button
									key={ i }
									onClick={ () => setActiveIdx( i ) }
									style={ {
										width: 28, height: 28, borderRadius: '50%',
										background:  i === safeIdx ? '#0ea5e9' : 'rgba(0,0,0,0.55)',
										border:      '2px solid ' + ( i === safeIdx ? '#fff' : 'rgba(255,255,255,0.45)' ),
										color: '#fff', fontSize: '11px', fontWeight: 700,
										cursor: 'pointer', display: 'flex',
										alignItems: 'center', justifyContent: 'center',
										transition: 'background 0.2s',
									} }
								>
									{ i + 1 }
								</button>
							) ) }
						</div>
					) }
				</div>

				{ /* Text column */ }
				<div dir={ isRtl ? 'rtl' : 'ltr' } style={ textColStyle }>
					{ points.length === 0 ? (
						<p style={ { color: '#999', margin: 'auto', fontSize: '13px', textAlign: 'center', lineHeight: 1.6 } }>
							{ __( 'Add a scrollpoint in the sidebar →\nthen write its story text here.', 'scrollytelling' ) }
						</p>
					) : (
						<>
							<p style={ {
								fontSize: '11px', fontWeight: 600, color: '#888',
								margin: '0 0 12px', letterSpacing: '0.05em', textTransform: 'uppercase',
							} }>
								{ __( 'Point', 'scrollytelling' ) } { safeIdx + 1 } / { points.length }
							</p>
							<RichText
								tagName="div"
								className="st-scrollpoints__text"
								value={ activePoint?.text || '' }
								onChange={ ( v ) => updatePoint( safeIdx, { text: v } ) }
								placeholder={ __( 'Write the story text for this scrollpoint…', 'scrollytelling' ) }
								multiline="p"
								allowedFormats={ [ 'core/bold', 'core/italic', 'core/link', 'core/superscript', 'core/subscript', 'core/underline' ] }
								style={ { fontSize: '1.05rem', lineHeight: 1.8, color: textColor, flex: 1 } }
							/>
						</>
					) }
				</div>
			</div>
		</>
	);
}
