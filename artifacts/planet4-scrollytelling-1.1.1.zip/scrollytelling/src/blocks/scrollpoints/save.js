import { useBlockProps, RichText } from '@wordpress/block-editor';

const focalPct = ( pt ) => ( {
	x: Math.round( ( pt.focalPoint?.x ?? 0.5 ) * 100 ),
	y: Math.round( ( pt.focalPoint?.y ?? 0.5 ) * 100 ),
} );

export default function Save( { attributes } ) {
	const {
		imageUrl, imageAlt, points,
		textPosition, panelWidth,
		textColor, bgColor, bgOpacity,
		overlayColor, overlayOpacity,
		isRtl,
	} = attributes;

	const blockProps = useBlockProps.save( {
		className: `st-scrollpoints st-panel-pos--${ textPosition }`,
		'data-text-color':      textColor,
		'data-bg-color':        bgColor,
		'data-bg-opacity':      bgOpacity,
		'data-overlay-color':   overlayColor,
		'data-overlay-opacity': overlayOpacity,
	} );

	return (
		<section { ...blockProps } dir={ isRtl ? 'rtl' : undefined }>

			{ /* ── Sticky background ─────────────────────────────────── */ }
			<div className="st-scrollpoints__sticky" aria-hidden="true">
				{ imageUrl && (
					<img
						className="st-scrollpoints__image"
						src={ imageUrl }
						alt={ imageAlt || '' }
					/>
				) }
				<div className="st-scrollpoints__overlay" />
			</div>

			{ /* ── Scrolling text panels ──────────────────────────────── */ }
			<div className="st-scrollpoints__panels">
				{ points.map( ( point, i ) => {
					const { x, y } = focalPct( point );
					return (
						<div
							key={ point.id || i }
							className="st-scrollpoints__panel"
							data-focus-x={ x }
							data-focus-y={ y }
							data-zoom={ point.zoom ?? 1 }
						>
							<div
								className="st-scrollpoints__panel-inner"
								style={ { width: `${ panelWidth }%` } }
							>
								{ point.text && (
									<RichText.Content
										tagName="div"
										className="st-scrollpoints__text"
										value={ point.text }
									/>
								) }
							</div>
						</div>
					);
				} ) }
			</div>

		</section>
	);
}
