import { RichText, useBlockProps } from '@wordpress/block-editor';

export default function Save( { attributes } ) {
	const { content, backgroundColor, textColor, maxWidth, paddingY } = attributes;
	const blockProps = useBlockProps.save( {
		className: 'st-section-text',
		style: { background: backgroundColor, padding: `${ paddingY }px 20px` },
	} );
	return (
		<section { ...blockProps }>
			<div style={ { maxWidth, margin: '0 auto' } }>
				<RichText.Content
					tagName="div"
					className="st-section-text__content"
					style={ { color: textColor } }
					value={ content }
				/>
			</div>
		</section>
	);
}
