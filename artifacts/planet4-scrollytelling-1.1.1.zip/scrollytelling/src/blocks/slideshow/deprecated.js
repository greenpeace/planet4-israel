import { useBlockProps } from '@wordpress/block-editor';

/* Pre-lazy-loading markup: video slides had src + autoplay directly, no
   data-src/preload/st-lazy-video. Kept so existing saved posts with a
   video slide still validate against this shape instead of the current
   save(). */
export default function SaveV1( { attributes } ) {
	const { slides, height, isRtl } = attributes;
	if ( ! slides.length ) return null;

	const blockProps = useBlockProps.save( {
		className: `st-slideshow st-slideshow--${ height }`,
		dir: isRtl ? 'rtl' : undefined,
	} );

	return (
		<div { ...blockProps }>
			<div className="st-slideshow__track">
				{ slides.map( ( slide, i ) => (
					<div key={ slide.id || i } className="st-slideshow__slide" aria-hidden={ i !== 0 ? 'true' : undefined }>
						{ slide.type === 'video' ? (
							<video src={ slide.url } autoPlay muted loop playsInline />
						) : (
							<img src={ slide.url } alt={ slide.alt || '' } />
						) }
						{ slide.caption && (
							<p className="st-slideshow__caption">{ slide.caption }</p>
						) }
					</div>
				) ) }
			</div>

			<button className="st-slideshow__prev" aria-label="Previous slide">&#8249;</button>
			<button className="st-slideshow__next" aria-label="Next slide">&#8250;</button>
			<p className="st-slideshow__counter" aria-live="polite"></p>
		</div>
	);
}
