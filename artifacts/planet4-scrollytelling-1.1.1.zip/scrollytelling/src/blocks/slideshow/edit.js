import { __ } from '@wordpress/i18n';
import { useState } from '@wordpress/element';
import { InspectorControls, MediaUpload, MediaUploadCheck, useBlockProps } from '@wordpress/block-editor';
import { Button, PanelBody, SelectControl, TextControl, ToggleControl } from '@wordpress/components';

const HEIGHT_MAP = { full: '100vh', half: '60vh' };

export default function Edit( { attributes, setAttributes } ) {
	const { slides, height, isRtl } = attributes;
	const [ current, setCurrent ] = useState( 0 );
	const blockProps = useBlockProps( { className: 'st-slideshow-editor' } );

	const addSlides = ( mediaItems ) => {
		const newSlides = mediaItems.map( ( m ) => ( {
			id: m.id, url: m.url, alt: m.alt || '',
			type: m.type === 'video' ? 'video' : 'image',
			caption: '',
		} ) );
		setAttributes( { slides: [ ...slides, ...newSlides ] } );
	};

	const updateCaption = ( index, value ) => {
		const updated = slides.map( ( s, i ) => i === index ? { ...s, caption: value } : s );
		setAttributes( { slides: updated } );
	};

	const removeSlide = ( index ) => {
		setAttributes( { slides: slides.filter( ( _, i ) => i !== index ) } );
		setCurrent( Math.max( 0, current - 1 ) );
	};

	const slide = slides[ current ];
	const minHeight = HEIGHT_MAP[ height ] || '100vh';

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Slides', 'scrollytelling' ) } initialOpen>
					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( media ) => addSlides( Array.isArray( media ) ? media : [ media ] ) }
							allowedTypes={ [ 'image', 'video' ] }
							multiple
							value={ slides.map( ( s ) => s.id ) }
							render={ ( { open } ) => (
								<Button variant="primary" onClick={ open } style={ { width: '100%', marginBottom: '12px' } }>
									{ __( '+ Add Slides', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>

					{ slides.map( ( s, i ) => (
						<div key={ s.id || i } style={ { border: `2px solid ${ i === current ? '#007cba' : '#e0e0e0' }`, borderRadius: '4px', padding: '6px', marginBottom: '6px', cursor: 'pointer' } }
							onClick={ () => setCurrent( i ) }>
							<div style={ { display: 'flex', alignItems: 'center', gap: '6px', marginBottom: i === current ? '8px' : '0' } }>
								<img src={ s.url } alt="" style={ { width: 48, height: 32, objectFit: 'cover', borderRadius: '2px', flexShrink: 0 } } />
								<span style={ { fontSize: '11px', flex: 1 } }>{ __( 'Slide', 'scrollytelling' ) } { i + 1 }</span>
								<Button isDestructive variant="link" style={ { fontSize: '11px' } }
									onClick={ ( e ) => { e.stopPropagation(); removeSlide( i ); } }>
									{ __( 'Remove', 'scrollytelling' ) }
								</Button>
							</div>
							{ i === current && (
								<TextControl
									label={ __( 'Caption', 'scrollytelling' ) }
									value={ s.caption }
									onChange={ ( v ) => updateCaption( i, v ) }
									placeholder={ __( 'Optional caption…', 'scrollytelling' ) }
								/>
							) }
						</div>
					) ) }
				</PanelBody>

				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<SelectControl
						label={ __( 'Height', 'scrollytelling' ) }
						value={ height }
						options={ [
							{ label: __( 'Full screen (100vh)', 'scrollytelling' ), value: 'full' },
							{ label: __( 'Tall (60vh)', 'scrollytelling' ),          value: 'half' },
						] }
						onChange={ ( v ) => setAttributes( { height: v } ) }
					/>
					<ToggleControl
						label={ __( 'Right-to-left (RTL)', 'scrollytelling' ) }
						checked={ isRtl }
						onChange={ ( v ) => setAttributes( { isRtl: v } ) }
					/>
				</PanelBody>
			</InspectorControls>

			<div { ...blockProps } style={ { position: 'relative', background: '#111', overflow: 'hidden', minHeight } }>
				{ slides.length === 0 ? (
					<div style={ { position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#555', fontSize: '14px' } }>
						{ __( 'Add slides in the sidebar →', 'scrollytelling' ) }
					</div>
				) : slide ? (
					slide.type === 'video' ? (
						<video src={ slide.url } autoPlay muted loop playsInline style={ { width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', inset: 0 } } />
					) : (
						<img src={ slide.url } alt={ slide.alt } style={ { width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', inset: 0 } } />
					)
				) : null }

				{ slides.length > 1 && (
					<>
						<button
							onClick={ () => setCurrent( Math.max( 0, current - 1 ) ) }
							disabled={ current === 0 }
							style={ { position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)', zIndex: 4, background: 'rgba(255,255,255,0.2)', border: '2px solid rgba(255,255,255,0.6)', color: '#fff', width: 44, height: 44, borderRadius: '50%', fontSize: 18, cursor: 'pointer' } }
						>‹</button>
						<button
							onClick={ () => setCurrent( Math.min( slides.length - 1, current + 1 ) ) }
							disabled={ current === slides.length - 1 }
							style={ { position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)', zIndex: 4, background: 'rgba(255,255,255,0.2)', border: '2px solid rgba(255,255,255,0.6)', color: '#fff', width: 44, height: 44, borderRadius: '50%', fontSize: 18, cursor: 'pointer' } }
						>›</button>
					</>
				) }

				{ slide?.caption && (
					<p style={ { position: 'absolute', bottom: 48, left: 0, right: 0, textAlign: 'center', color: 'rgba(255,255,255,0.8)', fontSize: '0.85rem', zIndex: 3, padding: '0 60px' } }>{ slide.caption }</p>
				) }
				{ slides.length > 0 && (
					<p style={ { position: 'absolute', bottom: 16, left: 0, right: 0, textAlign: 'center', color: 'rgba(255,255,255,0.5)', fontSize: '0.75rem', zIndex: 3 } }>
						{ current + 1 } / { slides.length }
					</p>
				) }
			</div>
		</>
	);
}
