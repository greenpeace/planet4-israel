import { useBlockProps } from '@wordpress/block-editor';

export default function Save( { attributes } ) {
	const { slides, height, isRtl } = attributes;
	if ( ! slides.length ) return null;

	const blockProps = useBlockProps.save( {
		className: `st-slideshow st-slideshow--${ height }`,
		dir: isRtl ? 'rtl' : undefined,
	} );

	return (
		<div { ...blockProps }>
			<div className="st-slideshow__track">
				{ slides.map( ( slide, i ) => (
					<div key={ slide.id || i } className="st-slideshow__slide" aria-hidden={ i !== 0 ? 'true' : undefined }>
						{ slide.type === 'video' ? (
							<video className="st-lazy-video" data-src={ slide.url } muted loop playsInline preload="none" />
						) : (
							<img src={ slide.url } alt={ slide.alt || '' } />
						) }
						{ slide.caption && (
							<p className="st-slideshow__caption">{ slide.caption }</p>
						) }
					</div>
				) ) }
			</div>

			<button className="st-slideshow__prev" aria-label="Previous slide">&#8249;</button>
			<button className="st-slideshow__next" aria-label="Next slide">&#8250;</button>
			<p className="st-slideshow__counter" aria-live="polite"></p>
		</div>
	);
}
