import { __ } from '@wordpress/i18n';
import { InspectorControls, MediaUpload, MediaUploadCheck, useBlockProps, useSettings } from '@wordpress/block-editor';
import { Button, ColorPalette, PanelBody, RangeControl, SelectControl, TextareaControl, TextControl, ColorPicker, ToggleControl } from '@wordpress/components';
import { PositionPicker, AlignPicker, POSITION_PREVIEW_STYLE } from '../../components/PositionPicker';

const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0,0,0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

export default function Edit( { attributes, setAttributes } ) {
	const { mediaUrl, mediaType, title, body, titleColor, bodyColor, textPosition, textAlign, overlayColor, overlayOpacity, minHeight, isRtl, fixedBackground } = attributes;

	const [ themeColors ] = useSettings( 'color.palette' );
	const colors = themeColors || [];

	const blockProps = useBlockProps( { className: 'st-tom-editor' } );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Media', 'scrollytelling' ) } initialOpen>
					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( m ) => setAttributes( { mediaUrl: m.url, mediaId: m.id, mediaType: m.type === 'video' ? 'video' : 'image' } ) }
							allowedTypes={ [ 'image', 'video' ] }
							value={ attributes.mediaId }
							render={ ( { open } ) => (
								<Button variant="secondary" onClick={ open } style={ { width: '100%', marginBottom: '8px' } }>
									{ mediaUrl ? __( 'Replace Media', 'scrollytelling' ) : __( 'Upload / Select Media', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>
					{ mediaUrl && <Button isDestructive variant="link" onClick={ () => setAttributes( { mediaUrl: '', mediaId: undefined } ) }>{ __( 'Remove', 'scrollytelling' ) }</Button> }
				</PanelBody>

				<PanelBody title={ __( 'Overlay', 'scrollytelling' ) } initialOpen={ false }>
					<p style={ { fontSize: '11px', color: '#757575', marginBottom: '8px' } }>{ __( 'Color', 'scrollytelling' ) }</p>
					<ColorPicker color={ overlayColor } onChange={ ( v ) => setAttributes( { overlayColor: v } ) } enableAlpha={ false } />
					<RangeControl label={ __( 'Opacity (%)', 'scrollytelling' ) } value={ overlayOpacity } onChange={ ( v ) => setAttributes( { overlayOpacity: v } ) } min={ 0 } max={ 90 } />
				</PanelBody>

				<PanelBody title={ __( 'Text', 'scrollytelling' ) } initialOpen={ false }>
					<TextControl label={ __( 'Title', 'scrollytelling' ) } value={ title } onChange={ ( v ) => setAttributes( { title: v } ) } />
					<p style={ { fontSize: '11px', color: '#757575', margin: '0 0 6px' } }>{ __( 'Title Color', 'scrollytelling' ) }</p>
					<ColorPalette colors={ colors } value={ titleColor } onChange={ ( v ) => setAttributes( { titleColor: v || titleColor } ) } clearable={ false } />

					<TextareaControl label={ __( 'Body', 'scrollytelling' ) } value={ body } onChange={ ( v ) => setAttributes( { body: v } ) } rows={ 3 } style={ { marginTop: '12px' } } />
					<p style={ { fontSize: '11px', color: '#757575', margin: '0 0 6px' } }>{ __( 'Body Color', 'scrollytelling' ) }</p>
					<ColorPalette colors={ colors } value={ bodyColor } onChange={ ( v ) => setAttributes( { bodyColor: v || bodyColor } ) } clearable={ false } />

					<PositionPicker value={ textPosition } onChange={ ( v ) => setAttributes( { textPosition: v } ) } />
					<AlignPicker value={ textAlign } onChange={ ( v ) => setAttributes( { textAlign: v } ) } />
					<SelectControl
						label={ __( 'Section Height', 'scrollytelling' ) }
						value={ minHeight }
						options={ [
							{ label: __( 'Full screen (100vh)', 'scrollytelling' ), value: '100vh' },
							{ label: __( 'Half screen (50vh)', 'scrollytelling' ),  value: '50vh'  },
							{ label: __( 'One third (34vh)', 'scrollytelling' ),    value: '34vh'  },
						] }
						onChange={ ( v ) => setAttributes( { minHeight: v } ) }
					/>
				</PanelBody>

				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<ToggleControl label={ __( 'Fixed background (parallax)', 'scrollytelling' ) } checked={ fixedBackground } onChange={ ( v ) => setAttributes( { fixedBackground: v } ) } />
					<ToggleControl label={ __( 'Right-to-left text (RTL / Hebrew)', 'scrollytelling' ) } checked={ isRtl } onChange={ ( v ) => setAttributes( { isRtl: v } ) } />
				</PanelBody>
			</InspectorControls>

			<div
				{ ...blockProps }
				style={ {
					position: 'relative',
					minHeight,
					display: 'flex',
					overflow: 'hidden',
					padding: '6%',
					textAlign,
					...( POSITION_PREVIEW_STYLE[ textPosition ] || POSITION_PREVIEW_STYLE[ 'middle-center' ] ),
				} }
			>
				{ mediaUrl ? (
					mediaType === 'video' ? (
						<video src={ mediaUrl } autoPlay muted loop playsInline style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 0 } } />
					) : (
						<img src={ mediaUrl } alt="" style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 0 } } />
					)
				) : (
					<div style={ { position: 'absolute', inset: 0, background: '#2d2d2d', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#555', fontSize: '14px' } }>
						{ __( 'Upload media in the sidebar →', 'scrollytelling' ) }
					</div>
				) }
				<div style={ { position: 'absolute', inset: 0, background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })`, zIndex: 1 } } />
				<div style={ { position: 'relative', zIndex: 2, maxWidth: '700px', padding: '40px' } }>
					{ title && <h2 style={ { fontSize: 'clamp(1.5rem, 4vw, 3rem)', fontWeight: 700, marginBottom: '12px', lineHeight: 1.2, color: titleColor } }>{ title }</h2> }
					{ body && <p style={ { fontSize: '1.1rem', lineHeight: 1.7, color: bodyColor } }>{ body }</p> }
					{ ! title && ! body && <p style={ { opacity: 0.4, color: '#fff' } }>{ __( 'Add text in the sidebar →', 'scrollytelling' ) }</p> }
				</div>
			</div>
		</>
	);
}
