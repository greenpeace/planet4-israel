import { useBlockProps } from '@wordpress/block-editor';
import { POSITION_CLASS } from '../../components/PositionPicker';

const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0,0,0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

export default function Save( { attributes } ) {
	const {
		mediaUrl, mediaType,
		title, body, titleColor, bodyColor,
		textTheme, textPosition, textAlign,
		overlayColor, overlayOpacity,
		minHeight, isRtl, fixedBackground,
	} = attributes;

	const posClass   = POSITION_CLASS[ textPosition ] || 'st-pos--center';
	const alignClass = textAlign ? `st-align--${ textAlign }` : '';
	// keep textTheme class for legacy CSS fallback if no explicit colors set
	const themeClass = textTheme ? `st-tom--${ textTheme }` : '';

	const blockProps = useBlockProps.save( {
		className: `st-tom ${ posClass } ${ alignClass } ${ themeClass }`.replace( /\s+/g, ' ' ).trim(),
		style: { '--st-min-height': minHeight },
		dir: isRtl ? 'rtl' : undefined,
	} );

	return (
		<section { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video className={ `st-tom__bg st-lazy-video${ fixedBackground ? ' st-video-fixed' : '' }` } data-src={ mediaUrl } muted loop playsInline preload="none" aria-hidden="true" />
			) : mediaUrl ? (
				fixedBackground ? (
					<div className="st-tom__bg st-bg-fixed" style={ { backgroundImage: `url(${ mediaUrl })` } } aria-hidden="true" />
				) : (
					<img className="st-tom__bg" src={ mediaUrl } alt="" aria-hidden="true" />
				)
			) : null }
			<div className="st-tom__overlay" style={ { background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })` } } aria-hidden="true" />
			<div className="st-tom__content">
				{ title && <h2 className="st-tom__title" style={ { color: titleColor } }>{ title }</h2> }
				{ body && <p className="st-tom__body" style={ { color: bodyColor } }>{ body }</p> }
			</div>
		</section>
	);
}
