import { useBlockProps, useInnerBlocksProps } from '@wordpress/block-editor';

/* Pre-direction-controls markup: block wrapper had no data-h-direction /
   data-v-direction attributes. Kept so any post saved before those were
   added still validates against this shape instead of the current save(). */
export default function SaveV1( { attributes } ) {
	const {
		mediaUrl, mode, scrubAxis,
		blockHeight, fixedPosition, focalPoint, hasInnerContent,
	} = attributes;

	const isBackground = mode === 'background';
	const focalPos = focalPoint
		? `${ Math.round( focalPoint.x * 100 ) }% ${ Math.round( focalPoint.y * 100 ) }%`
		: '50% 50%';

	const blockProps = useBlockProps.save( {
		className: `st-video-scrub st-video-scrub--${ mode }`,
		'data-scrub-axis': scrubAxis,
		style: ! isBackground ? { height: `${ blockHeight }vh` } : undefined,
	} );

	const innerBlocksProps = useInnerBlocksProps.save( {
		className: `st-video-scrub__content${ ( isBackground || hasInnerContent ) ? '' : ' st-video-scrub__content--off' }`,
	} );

	if ( isBackground ) {
		return (
			<div { ...blockProps }>
				<div className="st-video-scrub__placeholder" aria-hidden="true" />
				<div className="st-video-scrub__wrap">
					{ mediaUrl && (
						<video
							className="st-video-scrub__video st-scrub-video"
							data-src={ mediaUrl }
							muted playsInline preload="none"
						/>
					) }
					<div { ...innerBlocksProps } />
					<div className="st-video-scrub__progress" aria-hidden="true" />
				</div>
				<div className="st-video-scrub__cursor" aria-hidden="true" />
			</div>
		);
	}

	const videoClassName = [
		'st-video-scrub__video',
		'st-scrub-video',
		fixedPosition ? 'st-video-fixed' : '',
	].filter( Boolean ).join( ' ' );

	return (
		<div { ...blockProps }>
			{ mediaUrl && (
				<video
					className={ videoClassName }
					data-src={ mediaUrl }
					muted playsInline preload="none"
					style={ { objectPosition: focalPos } }
				/>
			) }
			<div { ...innerBlocksProps } />
		</div>
	);
}
