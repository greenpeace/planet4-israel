import { __ } from '@wordpress/i18n';
import {
	InspectorControls,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
	useInnerBlocksProps,
} from '@wordpress/block-editor';
import {
	Button,
	FocalPointPicker,
	PanelBody,
	RangeControl,
	SelectControl,
	ToggleControl,
} from '@wordpress/components';

const MODE_OPTIONS = [
	{ label: __( 'Background (full screen)', 'scrollytelling' ), value: 'background' },
	{ label: __( 'Block (horizontal strip)', 'scrollytelling' ), value: 'block' },
];

const AXIS_OPTIONS = [
	{ label: __( 'Horizontal movement', 'scrollytelling' ), value: 'horizontal' },
	{ label: __( 'Vertical movement', 'scrollytelling' ), value: 'vertical' },
	{ label: __( 'Any movement', 'scrollytelling' ), value: 'both' },
];

const H_DIRECTION_OPTIONS = [
	{ label: __( 'Left to right', 'scrollytelling' ), value: 'right' },
	{ label: __( 'Right to left', 'scrollytelling' ), value: 'left' },
];

const V_DIRECTION_OPTIONS = [
	{ label: __( 'Up to down', 'scrollytelling' ), value: 'down' },
	{ label: __( 'Down to up', 'scrollytelling' ), value: 'up' },
];

export default function Edit( { attributes, setAttributes } ) {
	const {
		mediaUrl, mediaId, mode, scrubAxis, horizontalDirection, verticalDirection,
		blockHeight, fixedPosition, focalPoint, hasInnerContent,
	} = attributes;

	const isBackground = mode === 'background';

	const blockProps = useBlockProps( { className: 'st-video-scrub-editor', style: { padding: 0 } } );

	const innerBlocksProps = useInnerBlocksProps(
		{ className: 'st-video-scrub__content-editor' },
		{ templateLock: false }
	);

	const focalPos = focalPoint
		? `${ Math.round( focalPoint.x * 100 ) }% ${ Math.round( focalPoint.y * 100 ) }%`
		: '50% 50%';

	const canvasHeight = isBackground ? '70vh' : `${ Math.min( blockHeight, 100 ) }vh`;
	const contentHidden = ! isBackground && ! hasInnerContent;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Video', 'scrollytelling' ) } initialOpen>
					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( media ) => setAttributes( { mediaUrl: media.url, mediaId: media.id } ) }
							allowedTypes={ [ 'video' ] }
							value={ mediaId }
							render={ ( { open } ) => (
								<Button variant={ mediaUrl ? 'secondary' : 'primary' } onClick={ open } style={ { width: '100%', marginBottom: '8px', justifyContent: 'center' } }>
									{ mediaUrl ? __( 'Replace Video', 'scrollytelling' ) : __( 'Choose Video', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>
					{ mediaUrl && (
						<Button isDestructive variant="link" onClick={ () => setAttributes( { mediaUrl: '', mediaId: undefined } ) }>
							{ __( 'Remove', 'scrollytelling' ) }
						</Button>
					) }
					<p style={ { fontSize: '12px', color: '#555', marginTop: '8px' } }>
						{ __( 'The video lazy-loads on the frontend — only the first frame shows until it finishes loading.', 'scrollytelling' ) }
					</p>
				</PanelBody>

				<PanelBody title={ __( 'Scrubbing', 'scrollytelling' ) } initialOpen>
					<SelectControl
						label={ __( 'Mode', 'scrollytelling' ) }
						value={ mode }
						options={ MODE_OPTIONS }
						onChange={ ( v ) => setAttributes( { mode: v } ) }
						help={ isBackground
							? __( 'Fixed, full-screen takeover. The reader scrolls about one screen before it disappears.', 'scrollytelling' )
							: __( 'A horizontal strip that sits in the normal flow of the page.', 'scrollytelling' )
						}
					/>
					<SelectControl
						label={ __( 'Mouse movement', 'scrollytelling' ) }
						value={ scrubAxis }
						options={ AXIS_OPTIONS }
						onChange={ ( v ) => setAttributes( { scrubAxis: v } ) }
						help={ __( 'Which direction of mouse movement scrubs through the video frames. On mobile this always behaves as Block mode and scrubs by scrolling instead.', 'scrollytelling' ) }
					/>
					{ ( scrubAxis === 'horizontal' || scrubAxis === 'both' ) && (
						<SelectControl
							label={ __( 'Horizontal direction', 'scrollytelling' ) }
							value={ horizontalDirection }
							options={ H_DIRECTION_OPTIONS }
							onChange={ ( v ) => setAttributes( { horizontalDirection: v } ) }
						/>
					) }
					{ ( scrubAxis === 'vertical' || scrubAxis === 'both' ) && (
						<SelectControl
							label={ __( 'Vertical direction', 'scrollytelling' ) }
							value={ verticalDirection }
							options={ V_DIRECTION_OPTIONS }
							onChange={ ( v ) => setAttributes( { verticalDirection: v } ) }
						/>
					) }
				</PanelBody>

				{ ! isBackground && (
					<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen>
						<RangeControl
							label={ __( 'Strip height (vh)', 'scrollytelling' ) }
							value={ blockHeight }
							onChange={ ( v ) => setAttributes( { blockHeight: v } ) }
							min={ 20 } max={ 100 }
						/>
						<ToggleControl
							label={ __( 'Fixed position (parallax)', 'scrollytelling' ) }
							help={ __( 'The video stays pinned in place while the strip scrolls past it.', 'scrollytelling' ) }
							checked={ fixedPosition }
							onChange={ ( v ) => setAttributes( { fixedPosition: v } ) }
						/>
						{ mediaUrl && (
							<div style={ { marginTop: '12px' } }>
								<p style={ { fontSize: '11px', fontWeight: 600, margin: '0 0 8px', color: '#333' } }>
									{ __( 'Focal point (crop centre)', 'scrollytelling' ) }
								</p>
								<FocalPointPicker
									url={ mediaUrl }
									value={ focalPoint || { x: 0.5, y: 0.5 } }
									onChange={ ( fp ) => setAttributes( { focalPoint: fp } ) }
								/>
							</div>
						) }
						<ToggleControl
							label={ __( 'Add content', 'scrollytelling' ) }
							help={ hasInnerContent
								? __( 'Content is shown over the video.', 'scrollytelling' )
								: __( 'No content shown — just the video strip.', 'scrollytelling' )
							}
							checked={ hasInnerContent }
							onChange={ ( v ) => setAttributes( { hasInnerContent: v } ) }
						/>
					</PanelBody>
				) }
			</InspectorControls>

			<div { ...blockProps }>
				<div
					style={ {
						position: 'relative',
						height: canvasHeight,
						minHeight: '200px',
						background: '#111',
						overflow: 'hidden',
						display: 'flex',
						alignItems: 'center',
						justifyContent: 'center',
					} }
				>
					{ mediaUrl ? (
						<video
							src={ mediaUrl }
							muted
							style={ {
								position: 'absolute', inset: 0, width: '100%', height: '100%',
								objectFit: 'cover', objectPosition: isBackground ? '50% 50%' : focalPos,
							} }
						/>
					) : (
						<p style={ { color: '#888', fontSize: '13px', margin: 0, zIndex: 1 } }>
							{ __( 'Choose a video in the sidebar →', 'scrollytelling' ) }
						</p>
					) }

					<div style={ {
						position: 'absolute', top: 10, left: 10, zIndex: 2,
						background: 'rgba(0,0,0,0.6)', color: '#fff', fontSize: '11px',
						padding: '4px 10px', borderRadius: '20px', letterSpacing: '0.04em',
					} }>
						{ isBackground
							? __( 'BACKGROUND MODE — scrub: ', 'scrollytelling' )
							: __( 'BLOCK MODE — scrub: ', 'scrollytelling' ) }
						{ AXIS_OPTIONS.find( ( o ) => o.value === scrubAxis )?.label }
					</div>

					{ ( isBackground || true ) && (
						<div
							{ ...innerBlocksProps }
							style={ {
								...innerBlocksProps.style,
								position: 'relative',
								zIndex: 1,
								width: '100%',
								height: '100%',
								opacity: contentHidden ? 0.35 : 1,
								outline: contentHidden ? '1px dashed rgba(255,255,255,0.4)' : 'none',
							} }
						/>
					) }
				</div>
				{ contentHidden && (
					<p style={ { fontSize: '12px', color: '#888', margin: '6px 2px 0' } }>
						{ __( '"Add content" is off — anything added here is hidden on the frontend until you switch it back on.', 'scrollytelling' ) }
					</p>
				) }
			</div>
		</>
	);
}
