import { useBlockProps, useInnerBlocksProps } from '@wordpress/block-editor';

/*
 * The video is never autoplayed and never has `src` directly — the real
 * URL sits in `data-src`, loaded lazily by frontend.js (same lazy-loading
 * principle as every other media block in this plugin, but the video stays
 * paused at all times — its frame is driven by mouse position, not
 * playback).
 *
 * Inner content: the wrapper for InnerBlocks is ALWAYS rendered, in both
 * modes, regardless of `hasInnerContent`. That attribute only toggles a CSS
 * class (`st-video-scrub__content--off`) to show/hide it — never whether
 * the markup is rendered. If it gated the JSX itself, toggling it off and
 * saving would permanently drop any nested blocks from the post the next
 * time the page saves, since WordPress only keeps a block's inner content
 * in the stored post_content if save() actually renders the InnerBlocks
 * placeholder somewhere.
 */
export default function Save( { attributes } ) {
	const {
		mediaUrl, mode, scrubAxis, horizontalDirection, verticalDirection,
		blockHeight, fixedPosition, focalPoint, hasInnerContent,
	} = attributes;

	const isBackground = mode === 'background';
	const focalPos = focalPoint
		? `${ Math.round( focalPoint.x * 100 ) }% ${ Math.round( focalPoint.y * 100 ) }%`
		: '50% 50%';

	const blockProps = useBlockProps.save( {
		className: `st-video-scrub st-video-scrub--${ mode }`,
		'data-scrub-axis': scrubAxis,
		'data-h-direction': horizontalDirection,
		'data-v-direction': verticalDirection,
		style: ! isBackground ? { height: `${ blockHeight }vh` } : undefined,
	} );

	const innerBlocksProps = useInnerBlocksProps.save( {
		className: `st-video-scrub__content${ ( isBackground || hasInnerContent ) ? '' : ' st-video-scrub__content--off' }`,
	} );

	if ( isBackground ) {
		return (
			<div { ...blockProps }>
				<div className="st-video-scrub__placeholder" aria-hidden="true" />
				<div className="st-video-scrub__wrap">
					{ mediaUrl && (
						<video
							className="st-video-scrub__video st-scrub-video"
							data-src={ mediaUrl }
							muted playsInline preload="none"
						/>
					) }
					<div { ...innerBlocksProps } />
					<div className="st-video-scrub__progress" aria-hidden="true" />
				</div>
				<div className="st-video-scrub__cursor" aria-hidden="true" />
			</div>
		);
	}

	const videoClassName = [
		'st-video-scrub__video',
		'st-scrub-video',
		fixedPosition ? 'st-video-fixed' : '',
	].filter( Boolean ).join( ' ' );

	return (
		<div { ...blockProps }>
			{ mediaUrl && (
				<video
					className={ videoClassName }
					data-src={ mediaUrl }
					muted playsInline preload="none"
					style={ { objectPosition: focalPos } }
				/>
			) }
			<div { ...innerBlocksProps } />
		</div>
	);
}
