/**
 * Shared position + alignment picker components used by Hero and Text-Over-Media blocks.
 */
import { __ } from '@wordpress/i18n';

/* Inline SVG align icons — no @wordpress/icons dependency needed */
const AlignLeftSVG = () => (
	<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
		<rect x="3" y="5"  width="12" height="2" rx="1" fill="currentColor"/>
		<rect x="3" y="9"  width="18" height="2" rx="1" fill="currentColor"/>
		<rect x="3" y="13" width="12" height="2" rx="1" fill="currentColor"/>
		<rect x="3" y="17" width="16" height="2" rx="1" fill="currentColor"/>
	</svg>
);
const AlignCenterSVG = () => (
	<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
		<rect x="6"  y="5"  width="12" height="2" rx="1" fill="currentColor"/>
		<rect x="3"  y="9"  width="18" height="2" rx="1" fill="currentColor"/>
		<rect x="6"  y="13" width="12" height="2" rx="1" fill="currentColor"/>
		<rect x="4"  y="17" width="16" height="2" rx="1" fill="currentColor"/>
	</svg>
);
const AlignRightSVG = () => (
	<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
		<rect x="9"  y="5"  width="12" height="2" rx="1" fill="currentColor"/>
		<rect x="3"  y="9"  width="18" height="2" rx="1" fill="currentColor"/>
		<rect x="9"  y="13" width="12" height="2" rx="1" fill="currentColor"/>
		<rect x="5"  y="17" width="16" height="2" rx="1" fill="currentColor"/>
	</svg>
);

// 3×3 grid — rows: top / middle / bottom  |  cols: left / center / right
export const GRID_POSITIONS = [
	[ 'top-left',    'top-center',    'top-right'    ],
	[ 'middle-left', 'middle-center', 'middle-right' ],
	[ 'bottom-left', 'bottom-center', 'bottom-right' ],
];

/** Normalize legacy 'center' → 'middle-center' for the picker. */
export const normalizePosition = ( v ) => ( v === 'center' ? 'middle-center' : v );

/**
 * 3×3 grid of dot-buttons for choosing where text sits in the block.
 */
export function PositionPicker( { value, onChange } ) {
	const active = normalizePosition( value );
	return (
		<div style={ { marginBottom: '16px' } }>
			<p style={ { fontSize: '11px', color: '#757575', margin: '0 0 8px', fontWeight: 500 } }>
				{ __( 'Text Position', 'scrollytelling' ) }
			</p>
			<div style={ {
				display: 'grid',
				gridTemplateColumns: 'repeat(3, 1fr)',
				gap: '3px',
				background: '#f0f0f0',
				padding: '4px',
				borderRadius: '6px',
			} }>
				{ GRID_POSITIONS.flat().map( ( pos ) => {
					const isActive = active === pos;
					return (
						<button
							key={ pos }
							type="button"
							onClick={ () => onChange( pos ) }
							title={ pos.replace( '-', ' ' ) }
							style={ {
								height: '36px',
								background: isActive ? '#007cba' : '#fff',
								border: `1px solid ${ isActive ? '#007cba' : '#ddd' }`,
								borderRadius: '3px',
								cursor: 'pointer',
								display: 'flex',
								alignItems: 'center',
								justifyContent: 'center',
								transition: 'background 0.15s, border-color 0.15s',
							} }
						>
							<span style={ {
								width: '8px',
								height: '8px',
								borderRadius: '50%',
								background: isActive ? '#fff' : '#bbb',
								display: 'block',
								flexShrink: 0,
							} } />
						</button>
					);
				} ) }
			</div>
		</div>
	);
}

/**
 * Left / Center / Right alignment buttons with WP icons.
 */
export function AlignPicker( { value, onChange } ) {
	const options = [
		{ value: 'left',   Icon: AlignLeftSVG,   label: __( 'Left',   'scrollytelling' ) },
		{ value: 'center', Icon: AlignCenterSVG, label: __( 'Center', 'scrollytelling' ) },
		{ value: 'right',  Icon: AlignRightSVG,  label: __( 'Right',  'scrollytelling' ) },
	];
	return (
		<div style={ { marginBottom: '16px' } }>
			<p style={ { fontSize: '11px', color: '#757575', margin: '0 0 8px', fontWeight: 500 } }>
				{ __( 'Text Alignment', 'scrollytelling' ) }
			</p>
			<div style={ { display: 'flex', gap: '2px' } }>
				{ options.map( ( { value: v, Icon: SvgIcon, label } ) => {
					const isActive = value === v;
					return (
						<button
							key={ v }
							type="button"
							onClick={ () => onChange( v ) }
							title={ label }
							style={ {
								flex: 1,
								height: '36px',
								background: isActive ? '#007cba' : '#f0f0f0',
								color: isActive ? '#fff' : '#555',
								border: `1px solid ${ isActive ? '#007cba' : '#ddd' }`,
								borderRadius: '3px',
								cursor: 'pointer',
								display: 'flex',
								alignItems: 'center',
								justifyContent: 'center',
								transition: 'background 0.15s, border-color 0.15s',
							} }
						>
							<SvgIcon />
						</button>
					);
				} ) }
			</div>
		</div>
	);
}

/** Map position key → inline flex styles for the editor preview. */
export const POSITION_PREVIEW_STYLE = {
	'top-left':     { alignItems: 'flex-start', justifyContent: 'flex-start' },
	'top-center':   { alignItems: 'flex-start', justifyContent: 'center' },
	'top-right':    { alignItems: 'flex-start', justifyContent: 'flex-end' },
	'middle-left':  { alignItems: 'center',     justifyContent: 'flex-start' },
	'middle-center':{ alignItems: 'center',     justifyContent: 'center' },
	'center':       { alignItems: 'center',     justifyContent: 'center' },
	'middle-right': { alignItems: 'center',     justifyContent: 'flex-end' },
	'bottom-left':  { alignItems: 'flex-end',   justifyContent: 'flex-start' },
	'bottom-center':{ alignItems: 'flex-end',   justifyContent: 'center' },
	'bottom-right': { alignItems: 'flex-end',   justifyContent: 'flex-end' },
};

/** Map position key → CSS class for saved frontend output. */
export const POSITION_CLASS = {
	'top-left':     'st-pos--top-left',
	'top-center':   'st-pos--top-center',
	'top-right':    'st-pos--top-right',
	'middle-left':  'st-pos--middle-left',
	'middle-center':'st-pos--middle-center',
	'center':       'st-pos--center',        // legacy alias
	'middle-right': 'st-pos--middle-right',
	'bottom-left':  'st-pos--bottom-left',
	'bottom-center':'st-pos--bottom-center',
	'bottom-right': 'st-pos--bottom-right',
};
