import { __ } from '@wordpress/i18n';
import { addFilter } from '@wordpress/hooks';
import { createHigherOrderComponent } from '@wordpress/compose';
import { Fragment } from '@wordpress/element';
import { InspectorControls } from '@wordpress/block-editor';
import { PanelBody, RangeControl, SelectControl } from '@wordpress/components';

/*
 * Ease In & Out Animator — lets the editor pick ANY block (core or
 * scrollytelling) and add a scroll-triggered entrance/exit animation,
 * without wrapping it in a new block. This works via WordPress's block
 * filters rather than a block.json/edit.js/save.js trio:
 *   - blocks.registerBlockType   adds the attributes to every block's schema
 *   - editor.BlockEdit           adds the sidebar panel to every block
 *   - blocks.getSaveContent.extraProps  adds the data-* attrs to the saved markup
 *
 * Critical safety property: addAnimateExtraProps() below returns the
 * UNCHANGED extraProps whenever neither animation is configured (the
 * default for every block that has never touched this feature). That
 * means save() output for every other block on the entire site — not just
 * this plugin's own blocks — is byte-for-byte identical to before this
 * feature existed, so nothing already published anywhere can be broken by
 * it. Only a block an editor has explicitly configured ever gets new
 * markup, and that's a fresh save, not a stored-vs-computed mismatch.
 */

const ANIMATE_ATTRIBUTES = {
	stAnimateIn:       { type: 'string', default: 'none' },
	stAnimateOut:      { type: 'string', default: 'none' },
	stAnimateDuration: { type: 'number', default: 700 },
	stAnimateDelay:    { type: 'number', default: 0 },
	stAnimateDistance: { type: 'number', default: 80 },
};

/* This block renders nothing visible — animating it would be a no-op,
   so it's left out of both the attribute injection and the sidebar panel. */
const EXCLUDED_BLOCKS = [ 'scrollytelling/css-handler' ];

const IN_OPTIONS = [
	{ label: __( 'None', 'scrollytelling' ), value: 'none' },
	{ label: __( 'Fade in', 'scrollytelling' ), value: 'fade' },
	{ label: __( 'Slide from left', 'scrollytelling' ), value: 'left' },
	{ label: __( 'Slide from right', 'scrollytelling' ), value: 'right' },
	{ label: __( 'Slide from bottom', 'scrollytelling' ), value: 'up' },
	{ label: __( 'Slide from top', 'scrollytelling' ), value: 'down' },
	{ label: __( 'Zoom in', 'scrollytelling' ), value: 'zoom' },
];

const OUT_OPTIONS = [
	{ label: __( 'None — stay visible', 'scrollytelling' ), value: 'none' },
	{ label: __( 'Fade out', 'scrollytelling' ), value: 'fade' },
	{ label: __( 'Slide to left', 'scrollytelling' ), value: 'left' },
	{ label: __( 'Slide to right', 'scrollytelling' ), value: 'right' },
	{ label: __( 'Slide to top', 'scrollytelling' ), value: 'up' },
	{ label: __( 'Slide to bottom', 'scrollytelling' ), value: 'down' },
	{ label: __( 'Zoom out', 'scrollytelling' ), value: 'zoom' },
];

function addAnimateAttributes( settings, name ) {
	if ( EXCLUDED_BLOCKS.includes( name ) || ! settings.attributes ) return settings;
	return {
		...settings,
		attributes: { ...settings.attributes, ...ANIMATE_ATTRIBUTES },
	};
}
addFilter( 'blocks.registerBlockType', 'scrollytelling/animate-attributes', addAnimateAttributes );

const withAnimateControls = createHigherOrderComponent( ( BlockEdit ) => ( props ) => {
	const { name, attributes, setAttributes, isSelected } = props;

	if ( EXCLUDED_BLOCKS.includes( name ) || ! isSelected ) {
		return <BlockEdit { ...props } />;
	}

	const {
		stAnimateIn = 'none', stAnimateOut = 'none',
		stAnimateDuration = 700, stAnimateDelay = 0, stAnimateDistance = 80,
	} = attributes;

	const hasAnimation = stAnimateIn !== 'none' || stAnimateOut !== 'none';

	return (
		<Fragment>
			<BlockEdit { ...props } />
			<InspectorControls>
				<PanelBody title={ __( 'Ease In & Out Animation', 'scrollytelling' ) } initialOpen={ false }>
					<SelectControl
						label={ __( 'Animate in', 'scrollytelling' ) }
						value={ stAnimateIn }
						options={ IN_OPTIONS }
						onChange={ ( v ) => setAttributes( { stAnimateIn: v } ) }
						help={ __( 'How this block enters as the reader scrolls to it.', 'scrollytelling' ) }
					/>
					<SelectControl
						label={ __( 'Animate out', 'scrollytelling' ) }
						value={ stAnimateOut }
						options={ OUT_OPTIONS }
						onChange={ ( v ) => setAttributes( { stAnimateOut: v } ) }
						help={ __( 'How this block leaves as the reader scrolls past it.', 'scrollytelling' ) }
					/>
					{ hasAnimation && (
						<>
							<RangeControl
								label={ __( 'Duration (ms)', 'scrollytelling' ) }
								value={ stAnimateDuration }
								onChange={ ( v ) => setAttributes( { stAnimateDuration: v } ) }
								min={ 200 } max={ 2000 } step={ 50 }
							/>
							<RangeControl
								label={ __( 'Delay (ms)', 'scrollytelling' ) }
								value={ stAnimateDelay }
								onChange={ ( v ) => setAttributes( { stAnimateDelay: v } ) }
								min={ 0 } max={ 1000 } step={ 50 }
								help={ __( 'Stagger several animated blocks by giving each a different delay.', 'scrollytelling' ) }
							/>
							<RangeControl
								label={ __( 'Travel distance (px)', 'scrollytelling' ) }
								value={ stAnimateDistance }
								onChange={ ( v ) => setAttributes( { stAnimateDistance: v } ) }
								min={ 20 } max={ 300 } step={ 10 }
								help={ __( 'How far the block travels for slide/zoom animations.', 'scrollytelling' ) }
							/>
						</>
					) }
				</PanelBody>
			</InspectorControls>
		</Fragment>
	);
}, 'withAnimateControls' );
addFilter( 'editor.BlockEdit', 'scrollytelling/with-animate-controls', withAnimateControls );

function addAnimateExtraProps( extraProps, blockType, attributes ) {
	const {
		stAnimateIn = 'none', stAnimateOut = 'none',
		stAnimateDuration = 700, stAnimateDelay = 0, stAnimateDistance = 80,
	} = attributes || {};

	if ( stAnimateIn === 'none' && stAnimateOut === 'none' ) {
		return extraProps;
	}

	return {
		...extraProps,
		className: [ extraProps.className, 'st-animate' ].filter( Boolean ).join( ' ' ),
		'data-st-animate-in': stAnimateIn,
		'data-st-animate-out': stAnimateOut,
		'data-st-animate-duration': stAnimateDuration,
		'data-st-animate-delay': stAnimateDelay,
		'data-st-animate-distance': stAnimateDistance,
	};
}
addFilter( 'blocks.getSaveContent.extraProps', 'scrollytelling/animate-extra-props', addAnimateExtraProps );
