import { __ } from '@wordpress/i18n';
import { addFilter } from '@wordpress/hooks';
import { createHigherOrderComponent } from '@wordpress/compose';
import { Fragment } from '@wordpress/element';
import { InspectorControls } from '@wordpress/block-editor';
import { PanelBody, RangeControl, SelectControl } from '@wordpress/components';

/*
 * Floating / parallax effect — lets the editor pick ANY block and make it
 * drift independently of the normal scroll rate, the same effect as:
 *   .parallax-icon { ... }  +  --parallax-speed: 0.2  +  a scroll listener
 * already used directly on greenpeace.org/israel pages, but generalised to
 * any block via the same block-filter mechanism as the Ease In & Out
 * Animator (see ease-animator.js — same trio of filters, same reasoning).
 *
 * Same critical safety property as that file: addFloatExtraProps() below
 * returns the UNCHANGED extraProps whenever speed is 0 (the default for
 * every block that's never touched this feature), so save() output for
 * every other block on the site is untouched and nothing already
 * published can be broken by this filter existing.
 */

const FLOAT_ATTRIBUTES = {
	stFloatAxis:  { type: 'string', default: 'vertical' },
	stFloatSpeed: { type: 'number', default: 0 },
};

const EXCLUDED_BLOCKS = [ 'scrollytelling/css-handler' ];

const AXIS_OPTIONS = [
	{ label: __( 'Vertical', 'scrollytelling' ), value: 'vertical' },
	{ label: __( 'Horizontal', 'scrollytelling' ), value: 'horizontal' },
	{ label: __( 'Both', 'scrollytelling' ), value: 'both' },
];

function addFloatAttributes( settings, name ) {
	if ( EXCLUDED_BLOCKS.includes( name ) || ! settings.attributes ) return settings;
	return {
		...settings,
		attributes: { ...settings.attributes, ...FLOAT_ATTRIBUTES },
	};
}
addFilter( 'blocks.registerBlockType', 'scrollytelling/float-attributes', addFloatAttributes );

const withFloatControls = createHigherOrderComponent( ( BlockEdit ) => ( props ) => {
	const { name, attributes, setAttributes, isSelected } = props;

	if ( EXCLUDED_BLOCKS.includes( name ) || ! isSelected ) {
		return <BlockEdit { ...props } />;
	}

	const { stFloatAxis = 'vertical', stFloatSpeed = 0 } = attributes;

	return (
		<Fragment>
			<BlockEdit { ...props } />
			<InspectorControls>
				<PanelBody title={ __( 'Floating Effect', 'scrollytelling' ) } initialOpen={ false }>
					<RangeControl
						label={ __( 'Floating speed', 'scrollytelling' ) }
						value={ stFloatSpeed }
						onChange={ ( v ) => setAttributes( { stFloatSpeed: v ?? 0 } ) }
						min={ -1 } max={ 1 } step={ 0.05 }
						help={ __( '0 disables it. Negative reverses the direction of the drift.', 'scrollytelling' ) }
					/>
					{ stFloatSpeed !== 0 && (
						<SelectControl
							label={ __( 'Direction', 'scrollytelling' ) }
							value={ stFloatAxis }
							options={ AXIS_OPTIONS }
							onChange={ ( v ) => setAttributes( { stFloatAxis: v } ) }
						/>
					) }
				</PanelBody>
			</InspectorControls>
		</Fragment>
	);
}, 'withFloatControls' );
addFilter( 'editor.BlockEdit', 'scrollytelling/with-float-controls', withFloatControls );

function addFloatExtraProps( extraProps, blockType, attributes ) {
	const { stFloatAxis = 'vertical', stFloatSpeed = 0 } = attributes || {};

	if ( ! stFloatSpeed ) {
		return extraProps;
	}

	return {
		...extraProps,
		className: [ extraProps.className, 'st-float' ].filter( Boolean ).join( ' ' ),
		'data-st-float-axis': stFloatAxis,
		'data-st-float-speed': stFloatSpeed,
	};
}
addFilter( 'blocks.getSaveContent.extraProps', 'scrollytelling/float-extra-props', addFloatExtraProps );
