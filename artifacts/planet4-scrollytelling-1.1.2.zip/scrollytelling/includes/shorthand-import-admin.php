<?php
/**
 * Admin page: "Import from Shorthand" — upload a Shorthand zip export and
 * convert it into a draft Page built from this plugin's blocks.
 *
 * The import runs as a background job (via a non-blocking wp_remote_post to
 * admin-ajax.php) so the user's browser never waits for media uploads and
 * thumbnail generation to finish — avoiding Cloudflare's ~100 s gateway
 * timeout on stories with many images/videos.
 *
 * Flow:
 *   1. Form submit → save zip to uploads/, store job in options table,
 *      fire non-blocking background request, redirect to status page.
 *   2. Background request → runs with set_time_limit(0) + ignore_user_abort,
 *      keeps going after Cloudflare cuts the connection, stores result.
 *   3. Status page → JS polls wp_ajax_st_import_status every 5 s until done.
 */

defined( 'ABSPATH' ) || exit;

/* ── Admin menu ─────────────────────────────────────────────────────────── */

add_action( 'admin_menu', 'st_register_shorthand_import_page' );
function st_register_shorthand_import_page() {
	add_menu_page(
		__( 'Import from Shorthand', 'scrollytelling' ),
		__( 'Scrollytelling', 'scrollytelling' ),
		'manage_options',
		'scrollytelling-import',
		'st_render_shorthand_import_page',
		'dashicons-controls-play'
	);
}

/* ── Main page renderer ─────────────────────────────────────────────────── */

function st_render_shorthand_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'scrollytelling' ) );
	}

	// If a job ID is in the URL, show the polling status page instead
	$job_id = isset( $_GET['st_job'] ) ? sanitize_key( $_GET['st_job'] ) : '';
	if ( $job_id ) {
		st_render_import_status_page( $job_id );
		return;
	}

	// Handle form submission
	$error_message = '';
	if ( isset( $_POST['st_import_nonce'] ) && wp_verify_nonce( $_POST['st_import_nonce'], 'st_import_shorthand' ) ) {
		$error_message = st_handle_import_submission();
		// st_handle_import_submission() redirects on success, so if we get here it's an error.
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Import from Shorthand', 'scrollytelling' ); ?></h1>
		<p>
			<?php esc_html_e( 'Upload a Shorthand.com zip export and this will convert it into a new draft Page built entirely from this plugin\'s own blocks (Hero, Text Over Media, Scrollmation, Scrollpoints, Reveal, Section Text) — matched by Shorthand\'s own section types where possible, with a best-effort fallback for anything else.', 'scrollytelling' ); ?>
		</p>
		<p><em><?php esc_html_e( 'This is a best-effort conversion, not pixel-perfect — review the result before publishing.', 'scrollytelling' ); ?></em></p>

		<?php if ( $error_message ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( $error_message ); ?></p></div>
		<?php endif; ?>

		<form method="post" enctype="multipart/form-data" style="max-width:600px;margin-top:20px;">
			<?php wp_nonce_field( 'st_import_shorthand', 'st_import_nonce' ); ?>
			<table class="form-table">
				<tr>
					<th scope="row"><label for="st_shorthand_zip"><?php esc_html_e( 'Shorthand export (.zip)', 'scrollytelling' ); ?></label></th>
					<td><input type="file" name="st_shorthand_zip" id="st_shorthand_zip" accept=".zip" required /></td>
				</tr>
				<tr>
					<th scope="row"><label for="st_page_title"><?php esc_html_e( 'Page title', 'scrollytelling' ); ?></label></th>
					<td>
						<input type="text" name="st_page_title" id="st_page_title" class="regular-text"
							placeholder="<?php esc_attr_e( 'Leave blank to use the story\'s own title', 'scrollytelling' ); ?>" />
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Convert to a Scrollytelling page', 'scrollytelling' ) ); ?>
		</form>
	</div>
	<?php
}

/* ── Form submission: persist zip + queue background job ─────────────────── */

function st_handle_import_submission() {
	if ( empty( $_FILES['st_shorthand_zip'] ) || UPLOAD_ERR_NO_FILE === $_FILES['st_shorthand_zip']['error'] ) {
		return __( 'Please choose a Shorthand .zip export to upload.', 'scrollytelling' );
	}
	if ( UPLOAD_ERR_OK !== $_FILES['st_shorthand_zip']['error'] ) {
		return __( 'The upload failed — please try again.', 'scrollytelling' );
	}

	$file = $_FILES['st_shorthand_zip'];
	if ( ! preg_match( '/\.zip$/i', $file['name'] ) ) {
		return __( 'Please upload a .zip file.', 'scrollytelling' );
	}

	// Move the uploaded zip out of /tmp (deleted at request end) to a
	// persistent uploads location that survives into the background request.
	$upload_dir = wp_upload_dir();
	$job_id     = wp_generate_password( 16, false );
	$zip_dest   = trailingslashit( $upload_dir['basedir'] ) . 'st-import-' . $job_id . '.zip';

	if ( ! move_uploaded_file( $file['tmp_name'], $zip_dest ) ) {
		return __( 'Could not save the uploaded file — check uploads folder permissions.', 'scrollytelling' );
	}

	// One-time secret token so the nopriv background handler can't be called
	// by anyone who doesn't know both the job ID and the token.
	$token = wp_generate_password( 32, false );

	update_option(
		'st_import_job_' . $job_id,
		[
			'status'  => 'queued',
			'zip'     => $zip_dest,
			'title'   => sanitize_text_field( wp_unslash( $_POST['st_page_title'] ?? '' ) ),
			'author'  => get_current_user_id(),
			'token'   => $token,
			'created' => time(),
		],
		false // don't autoload on every page
	);

	// Fire the background runner. blocking:false means we don't wait for the
	// response — the background process will finish on its own, storing its
	// result back in the options table for the status page to pick up.
	wp_remote_post(
		admin_url( 'admin-ajax.php' ),
		[
			'blocking'  => false,
			'timeout'   => 2,
			'sslverify' => false,
			'body'      => [
				'action' => 'st_run_import_job',
				'job_id' => $job_id,
				'token'  => $token,
			],
		]
	);

	wp_safe_redirect( admin_url( 'admin.php?page=scrollytelling-import&st_job=' . $job_id ) );
	exit;
}

/* ── Background job runner (nopriv AJAX, secured by one-time token) ──────── */

add_action( 'wp_ajax_st_run_import_job',        'st_ajax_run_import_job' );
add_action( 'wp_ajax_nopriv_st_run_import_job', 'st_ajax_run_import_job' );
function st_ajax_run_import_job() {
	$job_id = sanitize_key( $_POST['job_id'] ?? '' );
	$token  = sanitize_text_field( $_POST['token'] ?? '' );

	if ( ! $job_id || ! $token ) {
		wp_die( '', 400 );
	}

	$job = get_option( 'st_import_job_' . $job_id );

	if ( ! $job || 'queued' !== $job['status'] || ! hash_equals( $job['token'], $token ) ) {
		wp_die( '', 403 );
	}

	// No PHP timeout. Keep running even after Cloudflare closes the TCP
	// connection to the browser — the background process is server-to-server.
	set_time_limit( 0 );
	ignore_user_abort( true );

	// Impersonate the original submitter so post_author is set correctly.
	if ( ! empty( $job['author'] ) ) {
		wp_set_current_user( (int) $job['author'] );
	}

	$job['status'] = 'running';
	update_option( 'st_import_job_' . $job_id, $job, false );

	$importer = new ST_Shorthand_Importer();
	$result   = $importer->import( $job['zip'], $job['title'] );

	if ( is_wp_error( $result ) ) {
		$job['status'] = 'error';
		$job['error']  = $result->get_error_message();
	} else {
		$job['status']     = 'done';
		$job['post_id']    = $result;
		$job['post_url']   = get_edit_post_link( $result, 'raw' );
		$job['post_title'] = get_the_title( $result );
		$job['notes']      = $importer->notes;
	}

	$job['completed'] = time();
	unset( $job['token'] );         // single-use; discard after use
	@unlink( $job['zip'] );         // clean up the uploaded zip
	update_option( 'st_import_job_' . $job_id, $job, false );

	wp_die();
}

/* ── AJAX status poll (called by the status page's JS) ───────────────────── */

add_action( 'wp_ajax_st_import_status', 'st_ajax_import_status' );
function st_ajax_import_status() {
	$job_id = sanitize_key( $_GET['job_id'] ?? '' );
	check_ajax_referer( 'st_status_' . $job_id );

	$job = get_option( 'st_import_job_' . $job_id );
	if ( ! $job ) {
		wp_send_json_error( 'not_found' );
		return;
	}
	wp_send_json_success( [
		'status'     => $job['status'],
		'post_id'    => $job['post_id'] ?? null,
		'post_url'   => $job['post_url'] ?? null,
		'post_title' => $job['post_title'] ?? null,
		'error'      => $job['error'] ?? null,
		'notes'      => $job['notes'] ?? [],
	] );
}

/* ── Status / polling page ───────────────────────────────────────────────── */

function st_render_import_status_page( $job_id ) {
	$nonce = wp_create_nonce( 'st_status_' . $job_id );
	$ajax  = admin_url( 'admin-ajax.php' );
	?>
	<div class="wrap" id="st-status-wrap">
		<h1><?php esc_html_e( 'Importing from Shorthand…', 'scrollytelling' ); ?></h1>

		<div id="st-status-processing">
			<p>
				<span class="spinner is-active" style="float:none;margin:0 8px 0 0;vertical-align:middle;"></span>
				<?php esc_html_e( 'Converting your story — this may take a minute or two while media files are uploaded. This page will update automatically when it\'s done.', 'scrollytelling' ); ?>
			</p>
		</div>

		<div id="st-status-done" style="display:none;">
			<div class="notice notice-success" style="margin:20px 0 0;">
				<p id="st-done-message"></p>
			</div>
			<div id="st-notes-wrap" style="display:none;">
				<div class="notice notice-warning">
					<p><strong><?php esc_html_e( 'Notes from the conversion:', 'scrollytelling' ); ?></strong></p>
					<ul id="st-notes-list" style="margin-left:20px;list-style:disc;"></ul>
				</div>
			</div>
		</div>

		<div id="st-status-error" style="display:none;">
			<div class="notice notice-error" style="margin:20px 0 0;">
				<p id="st-error-message"></p>
			</div>
		</div>

		<p style="margin-top:24px;">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=scrollytelling-import' ) ); ?>">
				&larr; <?php esc_html_e( 'Import another story', 'scrollytelling' ); ?>
			</a>
		</p>
	</div>

	<script>
	(function () {
		var jobId  = <?php echo wp_json_encode( $job_id ); ?>;
		var nonce  = <?php echo wp_json_encode( $nonce ); ?>;
		var ajax   = <?php echo wp_json_encode( $ajax ); ?>;
		var checks = 0;
		var maxChecks = 120; // 10 minutes at 5 s intervals

		function poll() {
			var url = ajax
				+ '?action=st_import_status'
				+ '&job_id=' + encodeURIComponent(jobId)
				+ '&_wpnonce=' + encodeURIComponent(nonce);

			fetch(url, { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (data) {
					if (!data.success) {
						showError('<?php echo esc_js( __( 'Import job not found.', 'scrollytelling' ) ); ?>');
						return;
					}
					var job = data.data;
					if (job.status === 'done') {
						showDone(job);
					} else if (job.status === 'error') {
						showError(job.error || '<?php echo esc_js( __( 'An unknown error occurred.', 'scrollytelling' ) ); ?>');
					} else {
						checks++;
						if (checks >= maxChecks) {
							showError('<?php echo esc_js( __( 'The import is taking too long. Try again, or use the WP-CLI command: wp scrollytelling import_shorthand /path/to/story.zip', 'scrollytelling' ) ); ?>');
							return;
						}
						setTimeout(poll, 5000);
					}
				})
				.catch(function () {
					checks++;
					if (checks < maxChecks) { setTimeout(poll, 5000); }
				});
		}

		function showDone(job) {
			document.getElementById('st-status-processing').style.display = 'none';
			document.getElementById('st-status-done').style.display = '';
			document.getElementById('st-done-message').innerHTML =
				'<?php echo esc_js( __( 'Done! Created a draft page: ', 'scrollytelling' ) ); ?>'
				+ '<a href="' + job.post_url + '">' + escHtml(job.post_title) + '</a>';
			if (job.notes && job.notes.length) {
				document.getElementById('st-notes-wrap').style.display = '';
				var list = document.getElementById('st-notes-list');
				job.notes.forEach(function (n) {
					var li = document.createElement('li');
					li.textContent = n;
					list.appendChild(li);
				});
			}
		}

		function showError(msg) {
			document.getElementById('st-status-processing').style.display = 'none';
			document.getElementById('st-status-error').style.display = '';
			document.getElementById('st-error-message').textContent = msg;
		}

		function escHtml(s) {
			return String(s)
				.replace(/&/g, '&amp;').replace(/</g, '&lt;')
				.replace(/>/g, '&gt;').replace(/"/g, '&quot;');
		}

		poll();
	})();
	</script>
	<?php
}
