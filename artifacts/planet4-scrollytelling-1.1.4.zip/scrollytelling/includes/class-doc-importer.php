<?php
/**
 * Converts a Google Doc URL or a PDF file into a WordPress Page built
 * entirely from this plugin's own Scrollytelling blocks.
 *
 * Two import paths:
 *   Google Doc URL → wp_remote_get() on the export URL → parse HTML DOM
 *     → sections (heading + paragraphs + images) → download images into
 *     the WP media library → map sections to blocks.
 *
 *   PDF file → ImageMagick (PHP Imagick extension) converts each page to
 *     JPEG → optionally pdftotext extracts body text → map pages to blocks.
 *
 * Block-selection heuristic per section (after the mandatory Hero first):
 *   image + 3+ paragraphs OR >500 chars   → Background Scroll
 *   2+ images + any text                   → Scrollmation
 *   image + very short text + heading      → Text Over Media
 *   image + medium/long text               → Reveal + Section Text
 *   text only                              → Section Text (alternating bg)
 *
 * IMPORTANT: every render_*() method here must produce HTML that
 * byte-for-byte matches what the corresponding block's save.js would
 * produce for the same attributes, otherwise the block shows as "invalid"
 * the first time the user opens the page in the editor.
 */

defined( 'ABSPATH' ) || exit;

class ST_Doc_Importer {

	/** @var bool Whether the content appears to be right-to-left. */
	private bool $is_rtl = false;

	/** @var array<string> Human-readable notes about the import. */
	public array $notes = [];

	/* ═══════════════════════════ Entry points ══════════════════════════════ */

	/**
	 * @param string $gdoc_url   Google Docs share or publish URL.
	 * @param string $page_title Override; otherwise taken from the document's own title.
	 * @return int|WP_Error      New page ID, or WP_Error on failure.
	 */
	public function import_from_gdoc( string $gdoc_url, string $page_title = '' ): int|WP_Error {
		$html = $this->fetch_gdoc_html( $gdoc_url );
		if ( is_wp_error( $html ) ) {
			return $html;
		}

		$this->is_rtl = $this->detect_rtl_from_html( $html );
		$sections     = $this->parse_html_to_sections( $html );

		if ( ! $sections ) {
			return new WP_Error( 'st_doc_empty', __( 'No content could be extracted from this Google Doc. Make sure it is shared as "Anyone with the link can view".', 'scrollytelling' ) );
		}

		if ( ! $page_title ) {
			$page_title = $sections[0]['heading'] ?: $this->extract_title_from_html( $html );
		}

		$sections = $this->download_section_images( $sections );
		$content  = $this->sections_to_blocks( $sections );

		return wp_insert_post(
			wp_slash( [
				'post_title'   => $page_title ?: __( 'Imported Document', 'scrollytelling' ),
				'post_content' => $content,
				'post_type'    => 'page',
				'post_status'  => 'draft',
			] ),
			true
		);
	}

	/**
	 * @param string $pdf_path   Absolute server path to the uploaded PDF.
	 * @param string $page_title Override title; otherwise uses first extracted heading.
	 * @return int|WP_Error      New page ID, or WP_Error on failure.
	 */
	public function import_from_pdf( string $pdf_path, string $page_title = '' ): int|WP_Error {
		if ( ! file_exists( $pdf_path ) ) {
			return new WP_Error( 'st_doc_no_file', __( 'PDF file not found.', 'scrollytelling' ) );
		}

		$page_images = $this->extract_pdf_pages( $pdf_path );
		$raw_text    = $this->extract_pdf_text( $pdf_path );

		if ( ! $page_images && ! $raw_text ) {
			@unlink( $pdf_path );
			return new WP_Error( 'st_doc_pdf_empty', __( 'Could not extract content from this PDF. The PHP Imagick extension must be available on the server.', 'scrollytelling' ) );
		}

		$sections = $this->build_pdf_sections( $page_images, $raw_text, $page_title );

		if ( ! $page_title && $sections ) {
			$page_title = $sections[0]['heading'];
		}

		$content = $this->sections_to_blocks( $sections );

		@unlink( $pdf_path );

		return wp_insert_post(
			wp_slash( [
				'post_title'   => $page_title ?: __( 'Imported PDF', 'scrollytelling' ),
				'post_content' => $content,
				'post_type'    => 'page',
				'post_status'  => 'draft',
			] ),
			true
		);
	}

	/* ══════════════════════ Google Doc fetching / parsing ══════════════════ */

	private function fetch_gdoc_html( string $url ): string|WP_Error {
		$export_url = $this->normalize_gdoc_url( $url );
		if ( ! $export_url ) {
			return new WP_Error(
				'st_doc_bad_url',
				__( 'Please provide a valid Google Docs URL (e.g. https://docs.google.com/document/d/…).', 'scrollytelling' )
			);
		}

		$response = wp_remote_get(
			$export_url,
			[
				'timeout'     => 60,
				'sslverify'   => false,
				'redirection' => 5,
				'headers'     => [
					'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . get_bloginfo( 'url' ),
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'st_doc_fetch_error', __( 'Could not reach Google Docs: ', 'scrollytelling' ) . $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			if ( in_array( $code, [ 401, 403 ], true ) ) {
				return new WP_Error(
					'st_doc_access',
					__( 'Access denied. Make sure the document is shared as "Anyone with the link can view".', 'scrollytelling' )
				);
			}
			return new WP_Error( 'st_doc_fetch_error', sprintf( __( 'Google Docs returned HTTP %d.', 'scrollytelling' ), $code ) );
		}

		$body = wp_remote_retrieve_body( $response );
		if ( ! $body ) {
			return new WP_Error( 'st_doc_empty_response', __( 'Google Docs returned an empty response.', 'scrollytelling' ) );
		}

		return $body;
	}

	private function normalize_gdoc_url( string $url ): ?string {
		$url = trim( $url );
		if ( str_contains( $url, '/export?format=html' ) ) {
			return $url;
		}
		if ( preg_match( '#/document/d/([a-zA-Z0-9_-]+)#', $url, $m ) ) {
			return 'https://docs.google.com/document/d/' . $m[1] . '/export?format=html';
		}
		return null;
	}

	private function parse_html_to_sections( string $html ): array {
		$dom = new DOMDocument();
		libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING );
		libxml_clear_errors();

		$body = $dom->getElementsByTagName( 'body' )->item( 0 );
		if ( ! $body ) {
			return [];
		}

		$items = [];
		$this->flatten_dom( $body, $items );

		return $this->items_to_sections( $items );
	}

	private function flatten_dom( DOMNode $node, array &$items ): void {
		if ( ! ( $node instanceof DOMElement ) ) {
			return;
		}

		$tag = strtolower( $node->tagName );

		if ( in_array( $tag, [ 'script', 'style', 'head', 'nav', 'footer', 'noscript' ], true ) ) {
			return;
		}

		if ( preg_match( '/^h([1-4])$/', $tag, $m ) ) {
			$text = $this->clean_text( $node->textContent );
			if ( $text ) {
				$items[] = [ 'type' => 'heading', 'level' => (int) $m[1], 'text' => $text ];
			}
			return;
		}

		if ( 'p' === $tag || 'div' === $tag ) {
			$imgs = $node->getElementsByTagName( 'img' );
			if ( $imgs->length > 0 ) {
				foreach ( $imgs as $img ) {
					$src = $img->getAttribute( 'src' );
					if ( ! $src ) {
						continue;
					}
					// Skip tiny tracking pixels (data URIs shorter than ~2 KB are
					// 1×1 spacers or decorative icons, not content images)
					if ( str_starts_with( $src, 'data:' ) && strlen( $src ) < 2000 ) {
						continue;
					}
					$items[] = [ 'type' => 'image', 'src' => $src, 'alt' => $img->getAttribute( 'alt' ) ?: '' ];
				}
				// Also grab any text sibling to the image (caption-like content)
				$text = $this->clean_text( preg_replace( '/<img[^>]+>/', '', $node->textContent ) );
				if ( $text && mb_strlen( $text ) > 15 ) {
					$items[] = [ 'type' => 'paragraph', 'text' => $text ];
				}
				return;
			}

			// Paragraph with only text — recurse first to catch nested block elements
			$has_block_children = false;
			foreach ( $node->childNodes as $child ) {
				if ( $child instanceof DOMElement ) {
					$ct = strtolower( $child->tagName );
					if ( in_array( $ct, [ 'p', 'h1', 'h2', 'h3', 'h4', 'ul', 'ol', 'table', 'div' ], true ) ) {
						$has_block_children = true;
						break;
					}
				}
			}

			if ( 'p' === $tag || ! $has_block_children ) {
				$text = $this->clean_text( $node->textContent );
				if ( $text && mb_strlen( $text ) > 15 ) {
					$items[] = [ 'type' => 'paragraph', 'text' => $text ];
				}
				return;
			}
		}

		if ( 'li' === $tag ) {
			$text = $this->clean_text( $node->textContent );
			if ( $text ) {
				$items[] = [ 'type' => 'paragraph', 'text' => '• ' . $text ];
			}
			return;
		}

		if ( 'img' === $tag ) {
			$src = $node->getAttribute( 'src' );
			if ( $src && ! ( str_starts_with( $src, 'data:' ) && strlen( $src ) < 2000 ) ) {
				$items[] = [ 'type' => 'image', 'src' => $src, 'alt' => $node->getAttribute( 'alt' ) ?: '' ];
			}
			return;
		}

		foreach ( $node->childNodes as $child ) {
			$this->flatten_dom( $child, $items );
		}
	}

	private function items_to_sections( array $items ): array {
		$sections = [];
		$current  = [ 'heading' => '', 'paragraphs' => [], 'images' => [] ];

		foreach ( $items as $item ) {
			if ( 'heading' === $item['type'] ) {
				if ( $item['level'] <= 3 && ( $current['heading'] || $current['paragraphs'] || $current['images'] ) ) {
					$sections[] = $current;
					$current    = [ 'heading' => $item['text'], 'paragraphs' => [], 'images' => [] ];
				} elseif ( ! $current['heading'] ) {
					$current['heading'] = $item['text'];
				} else {
					$current['paragraphs'][] = $item['text'];
				}
			} elseif ( 'paragraph' === $item['type'] ) {
				$current['paragraphs'][] = $item['text'];
			} elseif ( 'image' === $item['type'] ) {
				$current['images'][] = [ 'src' => $item['src'], 'alt' => $item['alt'], 'wp_url' => '' ];
			}
		}

		if ( $current['heading'] || $current['paragraphs'] || $current['images'] ) {
			$sections[] = $current;
		}

		return $sections;
	}

	private function clean_text( string $text ): string {
		return trim( preg_replace( '/\s+/u', ' ', $text ) );
	}

	/* ════════════════════════════ Image downloading ═════════════════════════ */

	private function download_section_images( array $sections ): array {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';

		foreach ( $sections as &$section ) {
			foreach ( $section['images'] as &$img ) {
				if ( str_starts_with( $img['src'], 'data:' ) ) {
					$url = $this->store_data_uri( $img['src'] );
				} else {
					$url = $this->download_url_to_attachment( $img['src'] );
				}
				$img['wp_url'] = $url ?: '';
			}
			unset( $img );
		}
		unset( $section );

		return $sections;
	}

	private function download_url_to_attachment( string $url ): ?string {
		$tmp = download_url( $url, 60 );
		if ( is_wp_error( $tmp ) ) {
			$this->notes[] = sprintf( __( 'Could not download image: %s', 'scrollytelling' ), esc_url( $url ) );
			return null;
		}

		$path = parse_url( $url, PHP_URL_PATH );
		$name = $path ? sanitize_file_name( basename( $path ) ) : 'image.jpg';
		if ( ! preg_match( '/\.(jpe?g|png|gif|webp|svg)$/i', $name ) ) {
			$name .= '.jpg';
		}

		$file_array = [ 'name' => $name, 'tmp_name' => $tmp ];
		$attach_id  = media_handle_sideload( $file_array, 0 );
		@unlink( $tmp );

		if ( is_wp_error( $attach_id ) ) {
			$this->notes[] = sprintf( __( 'Could not store image: %s', 'scrollytelling' ), esc_url( $url ) );
			return null;
		}

		return wp_get_attachment_url( $attach_id ) ?: null;
	}

	private function store_data_uri( string $data_uri ): ?string {
		if ( ! preg_match( '#^data:(image/[a-z+]+);base64,(.+)$#i', $data_uri, $m ) ) {
			return null;
		}

		$mime = $m[1];
		$data = base64_decode( $m[2] );
		if ( ! $data ) {
			return null;
		}

		$ext_map  = [ 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp' ];
		$ext      = $ext_map[ $mime ] ?? 'jpg';
		$upload   = wp_upload_dir();
		$filename = wp_unique_filename( $upload['path'], 'doc-image.' . $ext );
		$filepath = trailingslashit( $upload['path'] ) . $filename;

		if ( ! file_put_contents( $filepath, $data ) ) {
			return null;
		}

		$attach_id = wp_insert_attachment(
			[ 'post_mime_type' => $mime, 'post_title' => 'doc-image', 'post_status' => 'inherit' ],
			$filepath
		);
		if ( ! $attach_id || is_wp_error( $attach_id ) ) {
			return null;
		}

		$meta = wp_generate_attachment_metadata( $attach_id, $filepath );
		wp_update_attachment_metadata( $attach_id, $meta );

		return wp_get_attachment_url( $attach_id ) ?: null;
	}

	/* ═════════════════════════════ PDF extraction ═══════════════════════════ */

	private function extract_pdf_pages( string $pdf_path ): array {
		if ( ! class_exists( 'Imagick' ) ) {
			$this->notes[] = __( 'PHP Imagick extension not found — PDF pages cannot be converted to images. Install Imagick on the server to enable PDF imports.', 'scrollytelling' );
			return [];
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';

		$upload = wp_upload_dir();
		$urls   = [];

		try {
			$imagick = new Imagick();
			$imagick->setResolution( 150, 150 );
			$imagick->readImage( $pdf_path );
			$count = $imagick->getNumberImages();

			for ( $i = 0; $i < $count; $i++ ) {
				$imagick->setIteratorIndex( $i );
				$frame = $imagick->getImage();
				$frame->setImageFormat( 'jpeg' );
				$frame->setImageCompressionQuality( 85 );
				$frame->setImageBackgroundColor( 'white' );
				$frame = $frame->flattenImages();

				$filename = wp_unique_filename( $upload['path'], 'pdf-page-' . ( $i + 1 ) . '.jpg' );
				$filepath = trailingslashit( $upload['path'] ) . $filename;
				$frame->writeImage( $filepath );
				$frame->destroy();

				$attach_id = wp_insert_attachment(
					[ 'post_mime_type' => 'image/jpeg', 'post_title' => 'PDF Page ' . ( $i + 1 ), 'post_status' => 'inherit' ],
					$filepath
				);
				if ( $attach_id && ! is_wp_error( $attach_id ) ) {
					$meta = wp_generate_attachment_metadata( $attach_id, $filepath );
					wp_update_attachment_metadata( $attach_id, $meta );
					$url = wp_get_attachment_url( $attach_id );
					if ( $url ) {
						$urls[] = $url;
					}
				}
			}
			$imagick->destroy();
		} catch ( Exception $e ) {
			$this->notes[] = __( 'PDF extraction failed: ', 'scrollytelling' ) . $e->getMessage();
		}

		return $urls;
	}

	private function extract_pdf_text( string $pdf_path ): string {
		if ( ! function_exists( 'exec' ) ) {
			return '';
		}
		$lines = [];
		exec( 'pdftotext -layout ' . escapeshellarg( $pdf_path ) . ' -', $lines, $code );
		return ( 0 === $code && $lines ) ? implode( "\n", $lines ) : '';
	}

	/**
	 * Builds sections array from PDF page images + optional raw text.
	 * pdftotext uses form-feed (\f) as page separator.
	 */
	private function build_pdf_sections( array $page_urls, string $raw_text, string $override_title ): array {
		$text_pages = $raw_text ? array_map( 'trim', explode( "\f", $raw_text ) ) : [];
		$sections   = [];

		// ── Section 0 (Hero): first page image ───────────────────────────────
		$first_img    = $page_urls[0] ?? '';
		$first_lines  = array_filter( explode( "\n", $text_pages[0] ?? '' ) );
		$first_lines  = array_values( array_map( 'trim', $first_lines ) );
		$hero_heading = $override_title ?: ( $first_lines[0] ?? __( 'Document', 'scrollytelling' ) );
		$hero_para    = '';
		if ( count( $first_lines ) > 1 ) {
			$hero_para = implode( ' ', array_slice( $first_lines, 1, 3 ) );
		}

		$sections[] = [
			'heading'    => $hero_heading,
			'paragraphs' => $hero_para ? [ $hero_para ] : [],
			'images'     => $first_img ? [ [ 'src' => '', 'alt' => '', 'wp_url' => $first_img ] ] : [],
		];

		$remaining_images = array_slice( $page_urls, 1 );

		// ── Gather body text from pages 2+ ────────────────────────────────────
		$body_text = '';
		for ( $i = 1; $i < count( $text_pages ); $i++ ) {
			$t = trim( $text_pages[ $i ] );
			if ( $t ) {
				$body_text .= ( $body_text ? "\n\n" : '' ) . $t;
			}
		}

		if ( count( $remaining_images ) >= 2 ) {
			// Multiple pages → Scrollmation (image sequence + body text)
			$paras = $body_text ? $this->split_text_to_paragraphs( $body_text, max( count( $remaining_images ), 3 ) ) : [];
			$sections[] = [
				'heading'    => '',
				'paragraphs' => $paras,
				'images'     => array_map( fn( $u ) => [ 'src' => '', 'alt' => '', 'wp_url' => $u ], $remaining_images ),
				'_force'     => 'scrollmation',
			];
		} elseif ( $remaining_images ) {
			// One extra page → Background Scroll (if we have text) or Reveal
			$paras = $body_text ? $this->split_text_to_paragraphs( $body_text, 4 ) : [];
			$sections[] = [
				'heading'    => '',
				'paragraphs' => $paras,
				'images'     => [ [ 'src' => '', 'alt' => '', 'wp_url' => $remaining_images[0] ] ],
			];
		} elseif ( $body_text ) {
			// No extra images → text section
			$paras = $this->split_text_to_paragraphs( $body_text, 5 );
			$sections[] = [
				'heading'    => '',
				'paragraphs' => $paras,
				'images'     => [],
			];
		}

		return $sections;
	}

	private function split_text_to_paragraphs( string $text, int $target_count ): array {
		// Try natural paragraph breaks first
		$paras = array_values( array_filter( array_map( 'trim', preg_split( '/\n{2,}/', $text ) ) ) );
		if ( count( $paras ) >= $target_count ) {
			return $paras;
		}

		// Fall back to sentence-level grouping
		$sents = preg_split( '/(?<=[.!?])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );
		if ( ! $sents || count( $sents ) <= $target_count ) {
			return $sents ?: [ trim( $text ) ];
		}

		$group_size = (int) ceil( count( $sents ) / $target_count );
		$groups     = [];
		for ( $i = 0; $i < count( $sents ); $i += $group_size ) {
			$groups[] = implode( ' ', array_slice( $sents, $i, $group_size ) );
		}
		return $groups;
	}

	/* ══════════════════════════ Sections → blocks ═══════════════════════════ */

	private function sections_to_blocks( array $sections ): string {
		if ( ! $sections ) {
			return '';
		}

		$blocks = [];

		// ── Section 0 → Hero (always) ────────────────────────────────────────
		$s0    = $sections[0];
		$img0  = $this->best_image_from( $s0 );

		// If hero has no image try stealing one from section 1
		if ( ! $img0 && isset( $sections[1] ) ) {
			$img0 = $this->best_image_from( $sections[1] );
		}

		$title    = $s0['heading'] ?: ( $s0['paragraphs'][0] ?? __( 'Untitled', 'scrollytelling' ) );
		$subtitle = '';
		if ( $s0['heading'] && $s0['paragraphs'] ) {
			$subtitle = mb_substr( $s0['paragraphs'][0], 0, 220 );
		} elseif ( count( $s0['paragraphs'] ) > 1 ) {
			$subtitle = mb_substr( $s0['paragraphs'][1], 0, 220 );
		}

		$blocks[] = $this->render_hero( [
			'mediaUrl'         => $img0,
			'mediaType'        => 'image',
			'title'            => $title,
			'subtitle'         => $subtitle,
			'byline'           => '',
			'titleColor'       => '#ffffff',
			'subtitleColor'    => '#f0f0f0',
			'bylineColor'      => '#ffffff',
			'textPosition'     => 'center',
			'textAlign'        => $this->is_rtl ? 'right' : 'start',
			'overlayColor'     => '#000000',
			'overlayOpacity'   => 45,
			'minHeight'        => '100vh',
			'isRtl'            => $this->is_rtl,
			'fixedBackground'  => false,
			'logoUrl'          => '',
			'logoPosition'     => 'before-title',
			'logoSize'         => 120,
			'zoomedBackground' => false,
			'backgroundBlur'   => 0,
		] );

		// ── Sections 1+ ───────────────────────────────────────────────────────
		$text_section_bg = [ '#ffffff', '#f6f7f8' ]; // alternate

		for ( $i = 1; $i < count( $sections ); $i++ ) {
			$s          = $sections[ $i ];
			$img        = $this->best_image_from( $s );
			$total_text = implode( ' ', $s['paragraphs'] );
			$text_len   = mb_strlen( $total_text );
			$num_imgs   = count( $s['images'] );
			$num_paras  = count( $s['paragraphs'] );

			// Forced type (set by build_pdf_sections)
			if ( ! empty( $s['_force'] ) ) {
				if ( 'scrollmation' === $s['_force'] ) {
					$b = $this->make_scrollmation( $s );
					if ( $b ) {
						$blocks[] = $b;
					}
				}
				continue;
			}

			// Lots of text + image → Background Scroll (sticky bg, text panels)
			if ( $img && ( $num_paras >= 3 || $text_len >= 500 ) ) {
				$b = $this->make_bg_scroll( $s );
				if ( $b ) {
					$blocks[] = $b;
					continue;
				}
			}

			// Multiple images + text → Scrollmation (image sequence)
			if ( $num_imgs >= 2 && $text_len >= 150 ) {
				$b = $this->make_scrollmation( $s );
				if ( $b ) {
					$blocks[] = $b;
					continue;
				}
			}

			// Image + short text → Text Over Media
			if ( $img && $text_len > 0 && $text_len <= 160 && $s['heading'] ) {
				$blocks[] = $this->render_tom( [
					'mediaUrl'        => $img,
					'mediaType'       => 'image',
					'title'           => $s['heading'],
					'body'            => $total_text,
					'titleColor'      => '#ffffff',
					'bodyColor'       => '#f0f0f0',
					'textPosition'    => ( $i % 2 === 0 ) ? 'middle-left' : 'middle-right',
					'textAlign'       => $this->is_rtl ? 'right' : 'start',
					'overlayColor'    => '#000000',
					'overlayOpacity'  => 40,
					'minHeight'       => '80vh',
					'textTheme'       => 'light',
					'isRtl'           => $this->is_rtl,
					'fixedBackground' => false,
				] );
				continue;
			}

			// Image + any text → Reveal + optional Section Text
			if ( $img ) {
				$blocks[] = $this->render_reveal( [
					'mediaUrl'        => $img,
					'mediaType'       => 'image',
					'caption'         => $s['heading'],
					'height'          => 'full',
					'objectFit'       => 'cover',
					'isRtl'           => $this->is_rtl,
					'fixedBackground' => false,
				] );
				if ( $s['paragraphs'] ) {
					$blocks[] = $this->render_section_text( [
						'content'         => $this->paragraphs_to_richtext( $s['paragraphs'], '' ),
						'backgroundColor' => $text_section_bg[ $i % 2 ],
						'textColor'       => '#1a1a1a',
						'maxWidth'        => '720px',
						'paddingY'        => 80,
					] );
				}
				continue;
			}

			// No image → Section Text
			if ( $s['paragraphs'] ) {
				$blocks[] = $this->render_section_text( [
					'content'         => $this->paragraphs_to_richtext( $s['paragraphs'], $s['heading'] ),
					'backgroundColor' => $text_section_bg[ $i % 2 ],
					'textColor'       => '#1a1a1a',
					'maxWidth'        => '720px',
					'paddingY'        => 80,
				] );
			}
		}

		return implode( "\n\n", array_filter( $blocks ) );
	}

	private function best_image_from( array $section ): string {
		foreach ( $section['images'] as $img ) {
			if ( ! empty( $img['wp_url'] ) ) {
				return $img['wp_url'];
			}
		}
		return '';
	}

	private function make_bg_scroll( array $s ): ?string {
		$img = $this->best_image_from( $s );
		if ( ! $s['paragraphs'] ) {
			return null;
		}

		$panels = [];
		foreach ( $s['paragraphs'] as $j => $para ) {
			$panels[] = [
				'id'       => 'panel-' . ( $j + 1 ),
				'title'    => ( 0 === $j && $s['heading'] ) ? $s['heading'] : '',
				'body'     => $para,
				'position' => '',
			];
		}

		return $this->render_background_scroll( [
			'mediaUrl'         => $img,
			'mediaId'          => 0,
			'mediaType'        => 'image',
			'mediaHeight'      => 'full',
			'focalPoint'       => [ 'x' => 0.5, 'y' => 0.5 ],
			'overlayColor'     => '#000000',
			'overlayOpacity'   => 35,
			'fixedBackground'  => false,
			'panelTitleColor'  => '#1a1a1a',
			'panelBodyColor'   => '#333333',
			'panelTextAlign'   => $this->is_rtl ? 'right' : 'left',
			'panelBgColor'     => '#ffffff',
			'panelBgOpacity'   => 95,
			'panelBorderColor' => '#cccccc',
			'panelBorderWidth' => 0,
			'gradientStyle'    => 'bottom',
			'gradientColor'    => '#000000',
			'gradientOpacity'  => 50,
			'panels'           => $panels,
			'panelPosition'    => 'right',
			'panelWidth'       => 40,
			'isRtl'            => $this->is_rtl,
		] );
	}

	private function make_scrollmation( array $s ): ?string {
		$frames = [];
		foreach ( $s['images'] as $k => $img ) {
			$url = $img['wp_url'] ?? '';
			if ( ! $url ) {
				continue;
			}
			$frames[] = [
				'id'         => 'frame-' . $k,
				'url'        => $url,
				'alt'        => $img['alt'] ?? '',
				'caption'    => '',
				'focalPoint' => [ 'x' => 0.5, 'y' => 0.5 ],
			];
		}
		if ( ! $frames ) {
			return null;
		}

		$content = $this->paragraphs_to_richtext( $s['paragraphs'], $s['heading'] );
		if ( ! $content ) {
			$content = '<p>' . esc_html( $s['heading'] ?: __( 'Image sequence', 'scrollytelling' ) ) . '</p>';
		}

		return $this->render_scrollmation( [
			'frames'          => $frames,
			'content'         => $content,
			'imageSide'       => 'left',
			'textColor'       => '#1a1a1a',
			'bgColor'         => '#ffffff',
			'objectFit'       => 'cover',
			'imageBg'         => '#000000',
			'imageFullHeight' => true,
			'isRtl'           => $this->is_rtl,
			'textAlign'       => $this->is_rtl ? 'right' : 'start',
		] );
	}

	/* ══════════════════════════ RTL / title helpers ═════════════════════════ */

	private function detect_rtl_from_html( string $html ): bool {
		if ( preg_match( '/<html[^>]*\bdir="rtl"/i', $html ) ) {
			return true;
		}
		if ( preg_match( '/<html[^>]*\blang="(he|ar|fa|ur)"/i', $html ) ) {
			return true;
		}
		$snippet = mb_substr( wp_strip_all_tags( $html ), 0, 2000 );
		return (bool) preg_match( '/[\x{0590}-\x{08FF}]/u', $snippet );
	}

	private function extract_title_from_html( string $html ): string {
		if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $m ) ) {
			$t = html_entity_decode( wp_strip_all_tags( $m[1] ), ENT_QUOTES, 'UTF-8' );
			$t = preg_replace( '/\s*[-–]\s*Google Docs\s*$/i', '', trim( $t ) );
			return $t;
		}
		return '';
	}

	/* ═══════════════════════ Shared HTML helpers ════════════════════════════ */

	private function block_props( string $block_slug, string $extra_class, array $attrs = [] ): string {
		$class = 'wp-block-scrollytelling-' . $block_slug;
		if ( $extra_class ) {
			$class .= ' ' . $extra_class;
		}
		$out = ' class="' . esc_attr( $class ) . '"';
		foreach ( $attrs as $name => $value ) {
			if ( null === $value || false === $value || '' === $value ) {
				continue;
			}
			$out .= ' ' . $name . '="' . esc_attr( (string) $value ) . '"';
		}
		return $out;
	}

	private function style_attr( array $pairs ): string {
		$parts = [];
		foreach ( $pairs as $prop => $value ) {
			if ( null === $value || '' === $value ) {
				continue;
			}
			$parts[] = $prop . ':' . $value;
		}
		return $parts ? ' style="' . esc_attr( implode( ';', $parts ) ) . '"' : '';
	}

	private function hex_to_rgb( string $hex ): string {
		if ( ! $hex || strlen( $hex ) < 7 ) {
			return '0, 0, 0';
		}
		return sprintf( '%d, %d, %d', hexdec( substr( $hex, 1, 2 ) ), hexdec( substr( $hex, 3, 2 ) ), hexdec( substr( $hex, 5, 2 ) ) );
	}

	private function open_comment( string $name, array $attributes ): string {
		return '<!-- wp:' . $name . ' ' . wp_json_encode( $attributes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ' -->';
	}

	private function close_comment( string $name ): string {
		return '<!-- /wp:' . $name . ' -->';
	}

	private function position_class( string $key ): string {
		$map = [
			'top-left'      => 'st-pos--top-left',    'top-center'    => 'st-pos--top-center',
			'top-right'     => 'st-pos--top-right',   'middle-left'   => 'st-pos--middle-left',
			'middle-center' => 'st-pos--middle-center','center'        => 'st-pos--center',
			'middle-right'  => 'st-pos--middle-right', 'bottom-left'   => 'st-pos--bottom-left',
			'bottom-center' => 'st-pos--bottom-center','bottom-right'  => 'st-pos--bottom-right',
		];
		return $map[ $key ] ?? 'st-pos--center';
	}

	private function paragraphs_to_richtext( array $paragraphs, string $heading = '' ): string {
		$html = '';
		if ( $heading ) {
			$html .= '<h2>' . esc_html( $heading ) . '</h2>';
		}
		foreach ( $paragraphs as $p ) {
			$html .= '<p>' . esc_html( $p ) . '</p>';
		}
		return $html;
	}

	/* ══════════════════════════ Block renderers ═════════════════════════════ */
	/* Must byte-match the corresponding block's save.js output.              */

	private function render_hero( array $a ): string {
		$pos_class   = $this->position_class( $a['textPosition'] );
		$align_class = $a['textAlign'] ? 'st-align--' . $a['textAlign'] : '';
		$class       = trim( "st-hero $pos_class $align_class" );

		$html  = '<section' . $this->block_props( 'hero', $class, [
			'data-blur' => $a['backgroundBlur'] > 0 ? $a['backgroundBlur'] : null,
			'dir'       => $a['isRtl'] ? 'rtl' : null,
		] );
		$html .= $this->style_attr( [ '--st-min-height' => $a['minHeight'] ] );
		$html .= '>';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-hero__bg st-lazy-video" data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none" aria-hidden="true"></video>';
		} elseif ( $a['mediaUrl'] ) {
			$html .= '<img class="st-hero__bg" src="' . esc_url( $a['mediaUrl'] ) . '" alt="" aria-hidden="true"/>';
		}

		$html .= '<div class="st-hero__overlay"' . $this->style_attr( [
			'--st-overlay-color' => $a['overlayColor'],
			'background'         => 'rgba(' . $this->hex_to_rgb( $a['overlayColor'] ) . ', ' . ( $a['overlayOpacity'] / 100 ) . ')',
		] ) . ' aria-hidden="true"></div>';

		$html .= '<div class="st-hero__content">';
		if ( $a['title'] ) {
			$html .= '<h1 class="st-hero__title"' . $this->style_attr( [ 'color' => $a['titleColor'] ] ) . '>' . esc_html( $a['title'] ) . '</h1>';
		}
		if ( $a['subtitle'] ) {
			$html .= '<p class="st-hero__subtitle"' . $this->style_attr( [ 'color' => $a['subtitleColor'] ] ) . '>' . esc_html( $a['subtitle'] ) . '</p>';
		}
		if ( $a['byline'] ) {
			$html .= '<p class="st-hero__byline"' . $this->style_attr( [ 'color' => $a['bylineColor'] ] ) . '>' . esc_html( $a['byline'] ) . '</p>';
		}
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/hero', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/hero' );
	}

	private function render_background_scroll( array $a ): string {
		$height_map = [ 'full' => 100, 'half' => 50, 'small' => 30 ];
		$height_vh  = $height_map[ $a['mediaHeight'] ] ?? 100;

		$class = 'st-bg-scroll st-panel-pos--' . $a['panelPosition'];
		$html  = '<section' . $this->block_props( 'background-scroll', $class, [
			'data-panel-position'    => $a['panelPosition'],
			'data-panel-bg-color'    => $a['panelBgColor'],
			'data-panel-bg-opacity'  => $a['panelBgOpacity'],
			'data-panel-border-color'=> $a['panelBorderColor'],
			'data-panel-border-width'=> $a['panelBorderWidth'],
			'data-media-height'      => $height_vh,
			'dir'                    => $a['isRtl'] ? 'rtl' : null,
		] ) . '>';

		$fpos      = $a['focalPoint'] ?? [ 'x' => 0.5, 'y' => 0.5 ];
		$focal_pos = round( $fpos['x'] * 100 ) . '% ' . round( $fpos['y'] * 100 ) . '%';

		$html .= '<div class="st-bg-scroll__sticky" aria-hidden="true">';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-bg-scroll__media st-lazy-video' . ( $a['fixedBackground'] ? ' st-video-fixed' : '' ) . '"'
				. ' data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none"'
				. $this->style_attr( [ 'object-position' => $focal_pos ] ) . '></video>';
		} elseif ( $a['mediaUrl'] ) {
			if ( $a['fixedBackground'] ) {
				$html .= '<div class="st-bg-scroll__media st-bg-fixed"'
					. $this->style_attr( [ 'background-image' => 'url(' . $a['mediaUrl'] . ')', 'background-position' => $focal_pos ] )
					. '></div>';
			} else {
				$html .= '<img class="st-bg-scroll__media" src="' . esc_url( $a['mediaUrl'] ) . '" alt=""'
					. $this->style_attr( [ 'object-position' => $focal_pos ] ) . '/>';
			}
		}

		$html .= '<div class="st-bg-scroll__overlay"'
			. $this->style_attr( [ 'background' => 'rgba(' . $this->hex_to_rgb( $a['overlayColor'] ) . ', ' . ( $a['overlayOpacity'] / 100 ) . ')' ] )
			. ' aria-hidden="true"></div>';

		if ( ! empty( $a['gradientStyle'] ) && 'none' !== $a['gradientStyle'] ) {
			$col = 'rgba(' . $this->hex_to_rgb( $a['gradientColor'] ) . ', ' . ( $a['gradientOpacity'] / 100 ) . ')';
			$grad_map = [
				'bottom' => "linear-gradient(to top, $col 0%, transparent 65%)",
				'top'    => "linear-gradient(to bottom, $col 0%, transparent 65%)",
				'left'   => "linear-gradient(to right, $col 0%, transparent 65%)",
				'right'  => "linear-gradient(to left, $col 0%, transparent 65%)",
			];
			$gradient = $grad_map[ $a['gradientStyle'] ] ?? null;
			if ( $gradient ) {
				$html .= '<div class="st-bg-scroll__gradient"'
					. $this->style_attr( [ 'background' => $gradient ] )
					. ' aria-hidden="true"></div>';
			}
		}

		$html .= '</div>'; // .st-bg-scroll__sticky

		$html .= '<div class="st-bg-scroll__panels">';
		foreach ( $a['panels'] as $j => $panel ) {
			$html .= '<div class="st-bg-scroll__panel"'
				. $this->style_attr( [ '--panel-width' => $a['panelWidth'] . '%' ] )
				. ' data-panel-index="' . (int) $j . '" data-panel-pos="' . esc_attr( $panel['position'] ?? '' ) . '">';
			$html .= '<div class="st-bg-scroll__panel-inner"'
				. ( $a['panelTextAlign'] ? $this->style_attr( [ 'text-align' => $a['panelTextAlign'] ] ) : '' ) . '>';
			if ( ! empty( $panel['title'] ) ) {
				$html .= '<h2 class="st-bg-scroll__panel-title"'
					. ( $a['panelTitleColor'] ? $this->style_attr( [ 'color' => $a['panelTitleColor'] ] ) : '' ) . '>'
					. esc_html( $panel['title'] ) . '</h2>';
			}
			if ( ! empty( $panel['body'] ) ) {
				$html .= '<p class="st-bg-scroll__panel-body"'
					. ( $a['panelBodyColor'] ? $this->style_attr( [ 'color' => $a['panelBodyColor'] ] ) : '' ) . '>'
					. esc_html( $panel['body'] ) . '</p>';
			}
			$html .= '</div></div>';
		}
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/background-scroll', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/background-scroll' );
	}

	private function render_scrollmation( array $a ): string {
		$classes = array_filter( [
			'st-scrollmation',
			'st-scrollmation--img-' . $a['imageSide'],
			! $a['imageFullHeight'] ? 'st-scrollmation--natural' : '',
		] );
		$class = implode( ' ', $classes );

		$html  = '<section' . $this->block_props( 'scrollmation', $class );
		$html .= $this->style_attr( [ 'background' => $a['bgColor'] ] );
		$html .= '>';

		$html .= '<div class="st-scrollmation__text-col"' . ( $a['isRtl'] ? ' dir="rtl"' : '' ) . '>';
		$html .= '<div class="st-scrollmation__text-inner">';
		$text_style = [];
		if ( $a['textColor'] ) {
			$text_style['color'] = $a['textColor'];
		}
		if ( $a['textAlign'] && 'start' !== $a['textAlign'] ) {
			$text_style['text-align'] = $a['textAlign'];
		}
		$html .= '<div class="st-scrollmation__text-content"' . $this->style_attr( $text_style ) . '>' . $a['content'] . '</div>';
		$html .= '</div></div>';

		$media_col_bg = $a['imageFullHeight'] ? $a['imageBg'] : $a['bgColor'];
		$html .= '<div class="st-scrollmation__media-col"' . $this->style_attr( [ 'background' => $media_col_bg ] ) . ' aria-hidden="true">';
		$html .= '<div class="st-scrollmation__stage">';
		foreach ( $a['frames'] as $idx => $frame ) {
			$focal    = $frame['focalPoint'] ?? [ 'x' => 0.5, 'y' => 0.5 ];
			$fpos_str = round( $focal['x'] * 100 ) . '% ' . round( $focal['y'] * 100 ) . '%';
			$html    .= '<img class="st-scrollmation__frame" src="' . esc_url( $frame['url'] ) . '" alt="' . esc_attr( $frame['alt'] ?? '' ) . '"'
				. ' data-frame="' . (int) $idx . '" data-caption="' . esc_attr( $frame['caption'] ?? '' ) . '" data-fit="' . esc_attr( $a['objectFit'] ) . '"'
				. $this->style_attr( [ 'object-position' => $fpos_str ] )
				. ( 0 !== $idx ? ' aria-hidden="true"' : '' )
				. '/>';
		}
		$html .= '</div><p class="st-scrollmation__caption"></p></div>';
		$html .= '</section>';

		return $this->open_comment( 'scrollytelling/scrollmation', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/scrollmation' );
	}

	private function render_tom( array $a ): string {
		$pos_class   = $this->position_class( $a['textPosition'] );
		$align_class = $a['textAlign'] ? 'st-align--' . $a['textAlign'] : '';
		$theme_class = $a['textTheme'] ? 'st-tom--' . $a['textTheme'] : '';
		$class       = trim( preg_replace( '/\s+/', ' ', "st-tom $pos_class $align_class $theme_class" ) );

		$html  = '<section' . $this->block_props( 'text-over-media', $class, [ 'dir' => $a['isRtl'] ? 'rtl' : null ] );
		$html .= $this->style_attr( [ '--st-min-height' => $a['minHeight'] ] );
		$html .= '>';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-tom__bg st-lazy-video' . ( $a['fixedBackground'] ? ' st-video-fixed' : '' ) . '" data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none" aria-hidden="true"></video>';
		} elseif ( $a['mediaUrl'] ) {
			if ( $a['fixedBackground'] ) {
				$html .= '<div class="st-tom__bg st-bg-fixed"' . $this->style_attr( [ 'background-image' => 'url(' . $a['mediaUrl'] . ')' ] ) . ' aria-hidden="true"></div>';
			} else {
				$html .= '<img class="st-tom__bg" src="' . esc_url( $a['mediaUrl'] ) . '" alt="" aria-hidden="true"/>';
			}
		}

		$html .= '<div class="st-tom__overlay"' . $this->style_attr( [
			'background' => 'rgba(' . $this->hex_to_rgb( $a['overlayColor'] ) . ', ' . ( $a['overlayOpacity'] / 100 ) . ')',
		] ) . ' aria-hidden="true"></div>';

		$html .= '<div class="st-tom__content">';
		if ( $a['title'] ) {
			$html .= '<h2 class="st-tom__title"' . $this->style_attr( [ 'color' => $a['titleColor'] ] ) . '>' . esc_html( $a['title'] ) . '</h2>';
		}
		if ( $a['body'] ) {
			$html .= '<p class="st-tom__body"' . $this->style_attr( [ 'color' => $a['bodyColor'] ] ) . '>' . esc_html( $a['body'] ) . '</p>';
		}
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/text-over-media', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/text-over-media' );
	}

	private function render_reveal( array $a ): string {
		$class = 'st-reveal st-reveal--' . $a['height'];
		$html  = '<div' . $this->block_props( 'reveal', $class, [ 'dir' => $a['isRtl'] ? 'rtl' : null ] );
		$html .= $this->style_attr( [ '--st-object-fit' => $a['objectFit'] ] );
		$html .= '>';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-reveal__media st-lazy-video' . ( $a['fixedBackground'] ? ' st-video-fixed' : '' ) . '"'
				. ' data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none"'
				. $this->style_attr( [ 'object-fit' => $a['objectFit'] ] ) . ' aria-hidden="true"></video>';
		} elseif ( $a['mediaUrl'] ) {
			if ( $a['fixedBackground'] ) {
				$html .= '<div class="st-reveal__media st-bg-fixed"' . $this->style_attr( [ 'background-image' => 'url(' . $a['mediaUrl'] . ')' ] ) . ' aria-hidden="true"></div>';
			} else {
				$html .= '<img class="st-reveal__media" src="' . esc_url( $a['mediaUrl'] ) . '" alt=""' . $this->style_attr( [ 'object-fit' => $a['objectFit'] ] ) . ' aria-hidden="true"/>';
			}
		}
		if ( $a['caption'] ) {
			$html .= '<p class="st-reveal__caption">' . esc_html( $a['caption'] ) . '</p>';
		}
		$html .= '</div>';

		return $this->open_comment( 'scrollytelling/reveal', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/reveal' );
	}

	private function render_section_text( array $a ): string {
		$html  = '<section' . $this->block_props( 'section-text', 'st-section-text' );
		$html .= $this->style_attr( [ 'background' => $a['backgroundColor'], 'padding' => $a['paddingY'] . 'px 20px' ] );
		$html .= '>';
		$html .= '<div' . $this->style_attr( [ 'max-width' => $a['maxWidth'], 'margin' => '0 auto' ] ) . '>';
		$html .= '<div class="st-section-text__content"' . $this->style_attr( [ 'color' => $a['textColor'] ] ) . '>' . $a['content'] . '</div>';
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/section-text', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/section-text' );
	}
}
