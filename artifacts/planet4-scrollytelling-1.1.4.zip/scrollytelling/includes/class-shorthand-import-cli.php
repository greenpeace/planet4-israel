<?php
/**
 * WP-CLI command wrapping the same importer the admin page uses, so the
 * conversion logic can be tested/run without going through the browser.
 */

defined( 'ABSPATH' ) || exit;

class ST_Shorthand_Import_CLI {

	/**
	 * Converts a Shorthand zip export into a draft Page built from
	 * scrollytelling blocks.
	 *
	 * ## OPTIONS
	 *
	 * <zip-path>
	 * : Absolute path to the Shorthand zip export.
	 *
	 * [--title=<title>]
	 * : Override the page title (defaults to the story's own <title> tag).
	 *
	 * ## EXAMPLES
	 *
	 *     wp scrollytelling import-shorthand /path/to/story.zip
	 *
	 * @when after_wp_load
	 */
	public function import_shorthand( $args, $assoc_args ) {
		list( $zip_path ) = $args;
		$title = $assoc_args['title'] ?? '';

		$importer = new ST_Shorthand_Importer();
		$result   = $importer->import( $zip_path, $title );

		foreach ( $importer->notes as $note ) {
			WP_CLI::log( 'Note: ' . $note );
		}

		if ( is_wp_error( $result ) ) {
			WP_CLI::error( $result->get_error_message() );
			return;
		}

		WP_CLI::success( sprintf( 'Created draft page #%d ("%s").', $result, get_the_title( $result ) ) );
		WP_CLI::log( 'Edit: ' . admin_url( 'post.php?post=' . $result . '&action=edit' ) );
	}
}

WP_CLI::add_command( 'scrollytelling', 'ST_Shorthand_Import_CLI' );
