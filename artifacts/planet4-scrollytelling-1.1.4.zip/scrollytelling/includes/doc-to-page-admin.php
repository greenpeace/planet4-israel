<?php
/**
 * Admin page: "PDF / Google Doc → Page"
 *
 * Two conversion modes on a single screen (tab UI):
 *   Google Doc — user pastes a share URL; the server fetches the HTML export
 *                and converts it without any file upload.
 *   PDF        — chunked file upload (same 512 KB / chunk pattern as the
 *                Shorthand importer) to avoid nginx 413 errors.
 *
 * Both modes queue a background job and redirect to a polling status page
 * identical in behaviour to the Shorthand importer's status page.
 */

defined( 'ABSPATH' ) || exit;

/* ── Admin submenu ──────────────────────────────────────────────────────── */

add_action( 'admin_menu', 'st_register_doc_import_page' );
function st_register_doc_import_page() {
	add_submenu_page(
		'scrollytelling-import',
		__( 'PDF / Google Doc → Page', 'scrollytelling' ),
		__( 'PDF / Doc → Page', 'scrollytelling' ),
		'manage_options',
		'scrollytelling-doc-import',
		'st_render_doc_import_page'
	);
}

/* ── Main page renderer ─────────────────────────────────────────────────── */

function st_render_doc_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'scrollytelling' ) );
	}

	$job_id = isset( $_GET['st_doc_job'] ) ? sanitize_key( $_GET['st_doc_job'] ) : '';
	if ( $job_id ) {
		st_render_doc_status_page( $job_id );
		return;
	}

	$ajax_url        = admin_url( 'admin-ajax.php' );
	$chunk_nonce     = wp_create_nonce( 'st_doc_upload_chunk' );
	$gdoc_nonce      = wp_create_nonce( 'st_doc_gdoc_submit' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'PDF / Google Doc → Scrollytelling Page', 'scrollytelling' ); ?></h1>
		<p><?php esc_html_e( 'Convert a document into a draft page built from Hero, Background Scroll, Scrollmation, Reveal and Section Text blocks — ready to review and publish.', 'scrollytelling' ); ?></p>

		<style>
		.st-doc-tabs{display:flex;gap:0;margin:24px 0 0;border-bottom:2px solid #c3c4c7;}
		.st-doc-tab{padding:10px 24px;cursor:pointer;border:2px solid transparent;border-bottom:none;background:#f6f7f7;font-weight:600;color:#50575e;border-radius:4px 4px 0 0;margin-bottom:-2px;user-select:none;}
		.st-doc-tab.active{background:#fff;border-color:#c3c4c7;color:#1d2327;}
		.st-doc-panel{display:none;padding:24px;background:#fff;border:2px solid #c3c4c7;border-top:none;max-width:640px;}
		.st-doc-panel.active{display:block;}
		.st-doc-drop{border:2px dashed #c3c4c7;border-radius:6px;padding:48px 24px;text-align:center;cursor:pointer;color:#50575e;transition:border-color .2s,background .2s;margin-bottom:16px;}
		.st-doc-drop:hover,.st-doc-drop.over{border-color:#0073aa;background:#f0f6fc;color:#0073aa;}
		.st-doc-drop input[type=file]{display:none;}
		.st-doc-drop .st-doc-drop__icon{font-size:36px;margin-bottom:8px;}
		.st-doc-drop .st-doc-drop__label{font-size:14px;}
		.st-doc-drop .st-doc-drop__name{font-weight:600;color:#1d2327;margin-top:6px;min-height:20px;}
		#st-doc-progress-wrap{margin:16px 0;}
		#st-doc-progress-bar-track{background:#e0e0e0;border-radius:4px;overflow:hidden;height:18px;}
		#st-doc-progress-bar{background:#0073aa;height:100%;width:0;transition:width .2s;}
		#st-doc-status-text{margin:6px 0 0;color:#555;font-size:13px;}
		#st-doc-error-banner{margin-top:12px;}
		</style>

		<div id="st-doc-error-banner" class="notice notice-error" style="display:none;max-width:640px;"><p id="st-doc-error-text"></p></div>

		<div class="st-doc-tabs">
			<div class="st-doc-tab active" data-panel="gdoc"><?php esc_html_e( '🔗 Google Doc URL', 'scrollytelling' ); ?></div>
			<div class="st-doc-tab" data-panel="pdf"><?php esc_html_e( '📄 PDF Upload', 'scrollytelling' ); ?></div>
		</div>

		<!-- ── Google Doc panel ──────────────────────────────────────────── -->
		<div class="st-doc-panel active" id="st-panel-gdoc">
			<p><?php esc_html_e( 'Share the document as "Anyone with the link can view", then paste the URL below.', 'scrollytelling' ); ?></p>
			<form id="st-gdoc-form">
				<table class="form-table" style="margin-top:0;">
					<tr>
						<th scope="row"><label for="st_gdoc_url"><?php esc_html_e( 'Google Docs URL', 'scrollytelling' ); ?></label></th>
						<td>
							<input type="url" id="st_gdoc_url" name="st_gdoc_url" class="large-text"
								placeholder="https://docs.google.com/document/d/…" required autocomplete="off" />
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="st_gdoc_title"><?php esc_html_e( 'Page title', 'scrollytelling' ); ?></label></th>
						<td>
							<input type="text" id="st_gdoc_title" name="st_gdoc_title" class="regular-text"
								placeholder="<?php esc_attr_e( 'Leave blank to use the document\'s own title', 'scrollytelling' ); ?>" />
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Convert to a Scrollytelling page', 'scrollytelling' ), 'primary', 'st-gdoc-submit-btn' ); ?>
			</form>
		</div>

		<!-- ── PDF panel ─────────────────────────────────────────────────── -->
		<div class="st-doc-panel" id="st-panel-pdf">
			<p><?php esc_html_e( 'Each PDF page is converted to a full-bleed image. Requires the PHP Imagick extension on the server.', 'scrollytelling' ); ?></p>
			<form id="st-pdf-form">
				<div class="st-doc-drop" id="st-pdf-drop">
					<input type="file" id="st_pdf_file" accept=".pdf" />
					<div class="st-doc-drop__icon">📄</div>
					<div class="st-doc-drop__label"><?php esc_html_e( 'Drop a PDF here, or click to browse', 'scrollytelling' ); ?></div>
					<div class="st-doc-drop__name" id="st-pdf-filename"></div>
				</div>
				<table class="form-table" style="margin-top:0;">
					<tr>
						<th scope="row"><label for="st_pdf_title"><?php esc_html_e( 'Page title', 'scrollytelling' ); ?></label></th>
						<td>
							<input type="text" id="st_pdf_title" name="st_pdf_title" class="regular-text"
								placeholder="<?php esc_attr_e( 'Leave blank to extract from PDF text', 'scrollytelling' ); ?>" />
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Convert to a Scrollytelling page', 'scrollytelling' ), 'primary', 'st-pdf-submit-btn' ); ?>
			</form>
		</div>

		<!-- ── Shared progress UI ────────────────────────────────────────── -->
		<div id="st-doc-progress-wrap" style="display:none;max-width:640px;">
			<div id="st-doc-progress-bar-track"><div id="st-doc-progress-bar"></div></div>
			<p id="st-doc-status-text"></p>
		</div>
	</div>

	<script>
	(function () {
		var CHUNK_SIZE = 512 * 1024;
		var ajaxUrl    = <?php echo wp_json_encode( $ajax_url ); ?>;
		var chunkNonce = <?php echo wp_json_encode( $chunk_nonce ); ?>;
		var gdocNonce  = <?php echo wp_json_encode( $gdoc_nonce ); ?>;

		// ── Tab switching ─────────────────────────────────────────────────
		document.querySelectorAll('.st-doc-tab').forEach(function (tab) {
			tab.addEventListener('click', function () {
				document.querySelectorAll('.st-doc-tab, .st-doc-panel').forEach(function (el) {
					el.classList.remove('active');
				});
				tab.classList.add('active');
				document.getElementById('st-panel-' + tab.dataset.panel).classList.add('active');
				hideError();
			});
		});

		// ── Drop zone ─────────────────────────────────────────────────────
		var dropZone  = document.getElementById('st-pdf-drop');
		var fileInput = document.getElementById('st_pdf_file');
		var fileName  = document.getElementById('st-pdf-filename');

		dropZone.addEventListener('click', function () { fileInput.click(); });
		fileInput.addEventListener('change', function () { setFile(fileInput.files[0]); });

		dropZone.addEventListener('dragover', function (e) { e.preventDefault(); dropZone.classList.add('over'); });
		dropZone.addEventListener('dragleave', function () { dropZone.classList.remove('over'); });
		dropZone.addEventListener('drop', function (e) {
			e.preventDefault();
			dropZone.classList.remove('over');
			var f = e.dataTransfer.files[0];
			if (f) setFile(f);
		});

		function setFile(f) {
			fileName.textContent = f ? f.name : '';
		}

		// ── Shared helpers ────────────────────────────────────────────────
		var progressWrap = document.getElementById('st-doc-progress-wrap');
		var progressBar  = document.getElementById('st-doc-progress-bar');
		var statusText   = document.getElementById('st-doc-status-text');
		var errorBanner  = document.getElementById('st-doc-error-banner');
		var errorText    = document.getElementById('st-doc-error-text');

		function setProgress(pct, msg) {
			progressWrap.style.display = '';
			progressBar.style.width    = pct + '%';
			statusText.textContent     = msg;
		}

		function showError(msg) {
			errorBanner.style.display   = '';
			errorText.textContent        = msg;
			progressWrap.style.display  = 'none';
		}

		function hideError() {
			errorBanner.style.display = 'none';
		}

		function disableButtons() {
			document.getElementById('st-gdoc-submit-btn').disabled = true;
			document.getElementById('st-pdf-submit-btn').disabled  = true;
		}

		function enableButtons() {
			document.getElementById('st-gdoc-submit-btn').disabled = false;
			document.getElementById('st-pdf-submit-btn').disabled  = false;
		}

		// ── Google Doc form ───────────────────────────────────────────────
		document.getElementById('st-gdoc-form').addEventListener('submit', function (e) {
			e.preventDefault();
			var url   = document.getElementById('st_gdoc_url').value.trim();
			var title = document.getElementById('st_gdoc_title').value.trim();
			if (!url) return;

			hideError();
			disableButtons();
			setProgress(30, '<?php echo esc_js( __( 'Sending to server…', 'scrollytelling' ) ); ?>');

			var fd = new FormData();
			fd.append('action',   'st_doc_gdoc_submit');
			fd.append('_wpnonce', gdocNonce);
			fd.append('url',      url);
			fd.append('title',    title);

			fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
				.then(function (r) { return r.json(); })
				.then(function (data) {
					if (!data.success) {
						showError(data.data || '<?php echo esc_js( __( 'Submission failed.', 'scrollytelling' ) ); ?>');
						enableButtons();
						return;
					}
					setProgress(100, '<?php echo esc_js( __( 'Starting conversion…', 'scrollytelling' ) ); ?>');
					window.location.href = data.data.redirect;
				})
				.catch(function (err) {
					showError('<?php echo esc_js( __( 'Network error: ', 'scrollytelling' ) ); ?>' + err.message);
					enableButtons();
				});
		});

		// ── PDF chunked upload ────────────────────────────────────────────
		document.getElementById('st-pdf-form').addEventListener('submit', function (e) {
			e.preventDefault();
			var file = fileInput.files[0];
			if (!file) {
				showError('<?php echo esc_js( __( 'Please select a PDF file.', 'scrollytelling' ) ); ?>');
				return;
			}
			if (!file.name.match(/\.pdf$/i)) {
				showError('<?php echo esc_js( __( 'Please select a .pdf file.', 'scrollytelling' ) ); ?>');
				return;
			}

			hideError();
			disableButtons();

			var uploadId    = Math.random().toString(36).substr(2, 16);
			var totalChunks = Math.ceil(file.size / CHUNK_SIZE);
			var title       = document.getElementById('st_pdf_title').value.trim();

			setProgress(0, '<?php echo esc_js( __( 'Uploading…', 'scrollytelling' ) ); ?>');
			uploadChunks(file, uploadId, totalChunks, title, 0);
		});

		function uploadChunks(file, uploadId, totalChunks, title, startAt) {
			var i = startAt;

			function next() {
				if (i >= totalChunks) return;

				var start = i * CHUNK_SIZE;
				var end   = Math.min(start + CHUNK_SIZE, file.size);
				var chunk = file.slice(start, end);

				var fd = new FormData();
				fd.append('action',    'st_doc_upload_chunk');
				fd.append('_wpnonce', chunkNonce);
				fd.append('upload_id', uploadId);
				fd.append('chunk',     i);
				fd.append('chunks',    totalChunks);
				fd.append('title',     title);
				fd.append('file',      chunk, file.name);

				fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
					.then(function (r) { return r.json(); })
					.then(function (data) {
						if (!data.success) {
							showError(data.data || '<?php echo esc_js( __( 'Upload failed.', 'scrollytelling' ) ); ?>');
							enableButtons();
							return;
						}
						i++;
						setProgress(
							Math.round(i / totalChunks * 100),
							'<?php echo esc_js( __( 'Uploading…', 'scrollytelling' ) ); ?> ' + Math.round(i / totalChunks * 100) + '%'
						);
						if (data.data.assembled) {
							setProgress(100, '<?php echo esc_js( __( 'Upload complete! Starting conversion…', 'scrollytelling' ) ); ?>');
							window.location.href = data.data.redirect;
						} else {
							next();
						}
					})
					.catch(function (err) {
						showError('<?php echo esc_js( __( 'Network error: ', 'scrollytelling' ) ); ?>' + err.message);
						enableButtons();
					});
			}

			next();
		}
	})();
	</script>
	<?php
}

/* ── Google Doc AJAX submit ─────────────────────────────────────────────── */

add_action( 'wp_ajax_st_doc_gdoc_submit', 'st_ajax_doc_gdoc_submit' );
function st_ajax_doc_gdoc_submit() {
	check_ajax_referer( 'st_doc_gdoc_submit' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Permission denied', 403 );
		return;
	}

	$url   = esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) );
	$title = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );

	if ( ! $url ) {
		wp_send_json_error( __( 'No URL provided.', 'scrollytelling' ), 400 );
		return;
	}

	if ( ! preg_match( '#docs\.google\.com/document/d/#', $url ) ) {
		wp_send_json_error( __( 'Please provide a Google Docs URL.', 'scrollytelling' ), 400 );
		return;
	}

	$token  = wp_generate_password( 32, false );
	$job_id = wp_generate_password( 16, false );

	update_option(
		'st_doc_job_' . $job_id,
		[
			'status'  => 'queued',
			'type'    => 'gdoc',
			'url'     => $url,
			'title'   => $title,
			'author'  => get_current_user_id(),
			'token'   => $token,
			'created' => time(),
		],
		false
	);

	wp_remote_post(
		admin_url( 'admin-ajax.php' ),
		[
			'blocking'  => false,
			'timeout'   => 2,
			'sslverify' => false,
			'body'      => [
				'action' => 'st_doc_run_job',
				'job_id' => $job_id,
				'token'  => $token,
			],
		]
	);

	wp_send_json_success( [
		'job_id'   => $job_id,
		'redirect' => admin_url( 'admin.php?page=scrollytelling-doc-import&st_doc_job=' . $job_id ),
	] );
}

/* ── PDF chunk upload AJAX handler ─────────────────────────────────────── */

add_action( 'wp_ajax_st_doc_upload_chunk', 'st_ajax_doc_upload_chunk' );
function st_ajax_doc_upload_chunk() {
	check_ajax_referer( 'st_doc_upload_chunk' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Permission denied', 403 );
		return;
	}

	$upload_id    = sanitize_key( $_POST['upload_id'] ?? '' );
	$chunk_idx    = (int) ( $_POST['chunk'] ?? 0 );
	$total_chunks = (int) ( $_POST['chunks'] ?? 1 );
	$title        = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );

	if ( ! $upload_id || $total_chunks < 1 || $chunk_idx < 0 || $chunk_idx >= $total_chunks ) {
		wp_send_json_error( 'Invalid parameters', 400 );
		return;
	}

	if ( empty( $_FILES['file'] ) || UPLOAD_ERR_OK !== $_FILES['file']['error'] ) {
		wp_send_json_error( 'File upload error: ' . ( $_FILES['file']['error'] ?? 'missing' ), 400 );
		return;
	}

	$upload_dir = wp_upload_dir();
	$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'st-chunks/';
	wp_mkdir_p( $tmp_dir );

	$chunk_file = $tmp_dir . $upload_id . '.part.' . $chunk_idx;
	if ( ! move_uploaded_file( $_FILES['file']['tmp_name'], $chunk_file ) ) {
		wp_send_json_error( 'Could not save chunk', 500 );
		return;
	}

	for ( $i = 0; $i < $total_chunks; $i++ ) {
		if ( ! file_exists( $tmp_dir . $upload_id . '.part.' . $i ) ) {
			wp_send_json_success( [ 'assembled' => false ] );
			return;
		}
	}

	// All chunks present — assemble PDF
	$final_pdf = trailingslashit( $upload_dir['basedir'] ) . 'st-doc-' . $upload_id . '.pdf';
	$out       = fopen( $final_pdf, 'wb' );
	if ( ! $out ) {
		wp_send_json_error( 'Could not create output file', 500 );
		return;
	}
	for ( $i = 0; $i < $total_chunks; $i++ ) {
		$part = $tmp_dir . $upload_id . '.part.' . $i;
		fwrite( $out, file_get_contents( $part ) );
		@unlink( $part );
	}
	fclose( $out );

	// Quick PDF magic-byte check (%PDF-)
	$fh = fopen( $final_pdf, 'rb' );
	$magic = fread( $fh, 5 );
	fclose( $fh );
	if ( '%PDF-' !== $magic ) {
		@unlink( $final_pdf );
		wp_send_json_error( __( 'The uploaded file is not a valid PDF.', 'scrollytelling' ), 400 );
		return;
	}

	$token  = wp_generate_password( 32, false );
	$job_id = $upload_id;

	update_option(
		'st_doc_job_' . $job_id,
		[
			'status'  => 'queued',
			'type'    => 'pdf',
			'pdf'     => $final_pdf,
			'title'   => $title,
			'author'  => get_current_user_id(),
			'token'   => $token,
			'created' => time(),
		],
		false
	);

	wp_remote_post(
		admin_url( 'admin-ajax.php' ),
		[
			'blocking'  => false,
			'timeout'   => 2,
			'sslverify' => false,
			'body'      => [
				'action' => 'st_doc_run_job',
				'job_id' => $job_id,
				'token'  => $token,
			],
		]
	);

	wp_send_json_success( [
		'assembled' => true,
		'job_id'    => $job_id,
		'redirect'  => admin_url( 'admin.php?page=scrollytelling-doc-import&st_doc_job=' . $job_id ),
	] );
}

/* ── Background job runner (nopriv, secured by one-time token) ──────────── */

add_action( 'wp_ajax_st_doc_run_job',        'st_ajax_doc_run_job' );
add_action( 'wp_ajax_nopriv_st_doc_run_job', 'st_ajax_doc_run_job' );
function st_ajax_doc_run_job() {
	$job_id = sanitize_key( $_POST['job_id'] ?? '' );
	$token  = sanitize_text_field( $_POST['token'] ?? '' );

	if ( ! $job_id || ! $token ) {
		wp_die( '', 400 );
	}

	$job = get_option( 'st_doc_job_' . $job_id );

	if ( ! $job || 'queued' !== $job['status'] || ! hash_equals( $job['token'], $token ) ) {
		wp_die( '', 403 );
	}

	set_time_limit( 0 );
	ignore_user_abort( true );

	if ( ! empty( $job['author'] ) ) {
		wp_set_current_user( (int) $job['author'] );
	}

	$job['status'] = 'running';
	update_option( 'st_doc_job_' . $job_id, $job, false );

	$importer = new ST_Doc_Importer();

	if ( 'gdoc' === $job['type'] ) {
		$result = $importer->import_from_gdoc( $job['url'], $job['title'] );
	} else {
		$result = $importer->import_from_pdf( $job['pdf'], $job['title'] );
	}

	if ( is_wp_error( $result ) ) {
		$job['status'] = 'error';
		$job['error']  = $result->get_error_message();
	} else {
		$job['status']     = 'done';
		$job['post_id']    = $result;
		$job['post_url']   = get_edit_post_link( $result, 'raw' );
		$job['post_title'] = get_the_title( $result );
		$job['notes']      = $importer->notes;
	}

	$job['completed'] = time();
	unset( $job['token'] );

	if ( ! empty( $job['pdf'] ) ) {
		@unlink( $job['pdf'] );
	}

	update_option( 'st_doc_job_' . $job_id, $job, false );
	wp_die();
}

/* ── Status poll AJAX ───────────────────────────────────────────────────── */

add_action( 'wp_ajax_st_doc_status', 'st_ajax_doc_status' );
function st_ajax_doc_status() {
	$job_id = sanitize_key( $_GET['job_id'] ?? '' );
	check_ajax_referer( 'st_doc_status_' . $job_id );

	$job = get_option( 'st_doc_job_' . $job_id );
	if ( ! $job ) {
		wp_send_json_error( 'not_found' );
		return;
	}
	wp_send_json_success( [
		'status'     => $job['status'],
		'type'       => $job['type'],
		'post_id'    => $job['post_id'] ?? null,
		'post_url'   => $job['post_url'] ?? null,
		'post_title' => $job['post_title'] ?? null,
		'error'      => $job['error'] ?? null,
		'notes'      => $job['notes'] ?? [],
	] );
}

/* ── Status / polling page ──────────────────────────────────────────────── */

function st_render_doc_status_page( string $job_id ) {
	$nonce = wp_create_nonce( 'st_doc_status_' . $job_id );
	$ajax  = admin_url( 'admin-ajax.php' );
	?>
	<div class="wrap" id="st-doc-status-wrap">
		<h1><?php esc_html_e( 'Converting document…', 'scrollytelling' ); ?></h1>

		<div id="st-doc-status-processing">
			<p>
				<span class="spinner is-active" style="float:none;margin:0 8px 0 0;vertical-align:middle;"></span>
				<?php esc_html_e( 'Converting your document — images are being downloaded and stored in the media library. This page refreshes automatically when conversion is complete.', 'scrollytelling' ); ?>
			</p>
		</div>

		<div id="st-doc-status-done" style="display:none;">
			<div class="notice notice-success" style="margin:20px 0 0;">
				<p id="st-doc-done-message"></p>
			</div>
			<div id="st-doc-notes-wrap" style="display:none;">
				<div class="notice notice-warning">
					<p><strong><?php esc_html_e( 'Notes from the conversion:', 'scrollytelling' ); ?></strong></p>
					<ul id="st-doc-notes-list" style="margin-left:20px;list-style:disc;"></ul>
				</div>
			</div>
		</div>

		<div id="st-doc-status-error" style="display:none;">
			<div class="notice notice-error" style="margin:20px 0 0;">
				<p id="st-doc-error-message"></p>
			</div>
		</div>

		<p style="margin-top:24px;">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=scrollytelling-doc-import' ) ); ?>">
				&larr; <?php esc_html_e( 'Convert another document', 'scrollytelling' ); ?>
			</a>
		</p>
	</div>

	<script>
	(function () {
		var jobId     = <?php echo wp_json_encode( $job_id ); ?>;
		var nonce     = <?php echo wp_json_encode( $nonce ); ?>;
		var ajax      = <?php echo wp_json_encode( $ajax ); ?>;
		var checks    = 0;
		var maxChecks = 144; // ~12 minutes at 5 s intervals

		function poll() {
			var url = ajax
				+ '?action=st_doc_status'
				+ '&job_id=' + encodeURIComponent(jobId)
				+ '&_wpnonce=' + encodeURIComponent(nonce);

			fetch(url, { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (data) {
					if (!data.success) { showError('<?php echo esc_js( __( 'Job not found.', 'scrollytelling' ) ); ?>'); return; }
					var job = data.data;
					if      ('done'  === job.status) showDone(job);
					else if ('error' === job.status) showError(job.error || '<?php echo esc_js( __( 'An unknown error occurred.', 'scrollytelling' ) ); ?>');
					else {
						checks++;
						if (checks >= maxChecks) {
							showError('<?php echo esc_js( __( 'The conversion is taking too long — please try again with a smaller document.', 'scrollytelling' ) ); ?>');
							return;
						}
						setTimeout(poll, 5000);
					}
				})
				.catch(function () { if (++checks < maxChecks) setTimeout(poll, 5000); });
		}

		function showDone(job) {
			document.getElementById('st-doc-status-processing').style.display = 'none';
			document.getElementById('st-doc-status-done').style.display = '';
			document.getElementById('st-doc-done-message').innerHTML =
				'<?php echo esc_js( __( 'Done! Draft page created: ', 'scrollytelling' ) ); ?>'
				+ '<strong><a href="' + escHtml(job.post_url) + '">' + escHtml(job.post_title) + '</a></strong>';
			if (job.notes && job.notes.length) {
				document.getElementById('st-doc-notes-wrap').style.display = '';
				var list = document.getElementById('st-doc-notes-list');
				job.notes.forEach(function (n) {
					var li = document.createElement('li');
					li.textContent = n;
					list.appendChild(li);
				});
			}
		}

		function showError(msg) {
			document.getElementById('st-doc-status-processing').style.display = 'none';
			document.getElementById('st-doc-status-error').style.display = '';
			document.getElementById('st-doc-error-message').textContent = msg;
		}

		function escHtml(s) {
			return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
		}

		poll();
	})();
	</script>
	<?php
}
