<?php
/**
 * Admin page: "Import from Shorthand" — upload a Shorthand zip export and
 * convert it into a draft Page built from this plugin's blocks.
 *
 * Upload flow (avoids both Cloudflare 504 and nginx 413 limits):
 *   1. Browser slices the zip into 512 KB chunks and POSTs each one
 *      individually via Fetch — each request is tiny, never hitting the
 *      nginx client_max_body_size limit.
 *   2. The chunk handler (wp_ajax_st_upload_chunk) accumulates parts on
 *      disk; when the last chunk arrives it assembles the zip, creates a
 *      job record, fires a non-blocking background request, and returns
 *      the status-page URL to JavaScript.
 *   3. JavaScript redirects to the status page, which polls
 *      wp_ajax_st_import_status every 5 s until the background import
 *      finishes and stores its result.
 */

defined( 'ABSPATH' ) || exit;

/* ── Admin menu ─────────────────────────────────────────────────────────── */

add_action( 'admin_menu', 'st_register_shorthand_import_page' );
function st_register_shorthand_import_page() {
	add_menu_page(
		__( 'Import from Shorthand', 'scrollytelling' ),
		__( 'Scrollytelling', 'scrollytelling' ),
		'manage_options',
		'scrollytelling-import',
		'st_render_shorthand_import_page',
		'dashicons-controls-play'
	);
}

/* ── Main page renderer ─────────────────────────────────────────────────── */

function st_render_shorthand_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'scrollytelling' ) );
	}

	// Status page: show polling UI if a job ID is present
	$job_id = isset( $_GET['st_job'] ) ? sanitize_key( $_GET['st_job'] ) : '';
	if ( $job_id ) {
		st_render_import_status_page( $job_id );
		return;
	}

	$upload_nonce = wp_create_nonce( 'st_upload_chunk' );
	$ajax_url     = admin_url( 'admin-ajax.php' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Import from Shorthand', 'scrollytelling' ); ?></h1>
		<p>
			<?php esc_html_e( 'Upload a Shorthand.com zip export and this will convert it into a new draft Page built entirely from this plugin\'s own blocks (Hero, Text Over Media, Scrollmation, Scrollpoints, Reveal, Section Text) — matched by Shorthand\'s own section types where possible, with a best-effort fallback for anything else.', 'scrollytelling' ); ?>
		</p>
		<p><em><?php esc_html_e( 'This is a best-effort conversion, not pixel-perfect — review the result before publishing.', 'scrollytelling' ); ?></em></p>

		<div id="st-error-banner" class="notice notice-error" style="display:none;"><p id="st-error-text"></p></div>

		<form id="st-upload-form" style="max-width:600px;margin-top:20px;">
			<table class="form-table">
				<tr>
					<th scope="row"><label for="st_shorthand_zip"><?php esc_html_e( 'Shorthand export (.zip)', 'scrollytelling' ); ?></label></th>
					<td>
						<input type="file" name="st_shorthand_zip" id="st_shorthand_zip" accept=".zip" required />
						<p class="description" id="st-filename"></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="st_page_title"><?php esc_html_e( 'Page title', 'scrollytelling' ); ?></label></th>
					<td>
						<input type="text" name="st_page_title" id="st_page_title" class="regular-text"
							placeholder="<?php esc_attr_e( 'Leave blank to use the story\'s own title', 'scrollytelling' ); ?>" />
					</td>
				</tr>
			</table>

			<div id="st-progress-wrap" style="display:none;margin:16px 0;">
				<div style="background:#e0e0e0;border-radius:4px;overflow:hidden;height:20px;width:100%;">
					<div id="st-progress-bar" style="background:#0073aa;height:100%;width:0;transition:width .2s;"></div>
				</div>
				<p id="st-status-text" style="margin:6px 0 0;color:#555;"></p>
			</div>

			<?php submit_button( __( 'Convert to a Scrollytelling page', 'scrollytelling' ), 'primary', 'st-submit-btn' ); ?>
		</form>
	</div>

	<script>
	(function () {
		var CHUNK_SIZE  = 512 * 1024; // 512 KB — well below any sane nginx limit
		var ajaxUrl     = <?php echo wp_json_encode( $ajax_url ); ?>;
		var uploadNonce = <?php echo wp_json_encode( $upload_nonce ); ?>;

		var form        = document.getElementById('st-upload-form');
		var fileInput   = document.getElementById('st_shorthand_zip');
		var submitBtn   = document.getElementById('st-submit-btn');
		var progressWrap= document.getElementById('st-progress-wrap');
		var progressBar = document.getElementById('st-progress-bar');
		var statusText  = document.getElementById('st-status-text');
		var errorBanner = document.getElementById('st-error-banner');
		var errorText   = document.getElementById('st-error-text');

		fileInput.addEventListener('change', function () {
			if (fileInput.files.length) {
				document.getElementById('st-filename').textContent = fileInput.files[0].name;
			}
		});

		form.addEventListener('submit', function (e) {
			e.preventDefault();

			var file = fileInput.files[0];
			if (!file) return;
			if (!file.name.match(/\.zip$/i)) {
				showError('<?php echo esc_js( __( 'Please select a .zip file.', 'scrollytelling' ) ); ?>');
				return;
			}

			var title      = document.getElementById('st_page_title').value;
			var uploadId   = Math.random().toString(36).substr(2, 16);
			var totalChunks= Math.ceil(file.size / CHUNK_SIZE);

			submitBtn.disabled = true;
			progressWrap.style.display = '';
			errorBanner.style.display  = 'none';
			setProgress(0, '<?php echo esc_js( __( 'Uploading…', 'scrollytelling' ) ); ?>');

			uploadChunks(file, uploadId, totalChunks, title, 0);
		});

		function uploadChunks(file, uploadId, totalChunks, title, startAt) {
			var i = startAt;

			function next() {
				if (i >= totalChunks) return; // shouldn't happen — server sends redirect

				var start = i * CHUNK_SIZE;
				var end   = Math.min(start + CHUNK_SIZE, file.size);
				var chunk = file.slice(start, end);

				var fd = new FormData();
				fd.append('action',    'st_upload_chunk');
				fd.append('_wpnonce', uploadNonce);
				fd.append('upload_id', uploadId);
				fd.append('chunk',     i);
				fd.append('chunks',    totalChunks);
				fd.append('title',     title);
				fd.append('file',      chunk, file.name);

				fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
					.then(function (r) { return r.json(); })
					.then(function (data) {
						if (!data.success) {
							showError(data.data || '<?php echo esc_js( __( 'Upload failed.', 'scrollytelling' ) ); ?>');
							submitBtn.disabled = false;
							return;
						}

						i++;
						var pct = Math.round(i / totalChunks * 100);
						setProgress(pct, '<?php echo esc_js( __( 'Uploading…', 'scrollytelling' ) ); ?> ' + pct + '%');

						if (data.data.assembled) {
							setProgress(100, '<?php echo esc_js( __( 'Upload complete! Starting conversion…', 'scrollytelling' ) ); ?>');
							window.location.href = data.data.redirect;
						} else {
							next();
						}
					})
					.catch(function (err) {
						showError('<?php echo esc_js( __( 'Network error — please try again.', 'scrollytelling' ) ); ?>' + ' (' + err.message + ')');
						submitBtn.disabled = false;
					});
			}

			next();
		}

		function setProgress(pct, msg) {
			progressBar.style.width = pct + '%';
			statusText.textContent  = msg;
		}

		function showError(msg) {
			errorBanner.style.display = '';
			errorText.textContent     = msg;
			progressWrap.style.display= 'none';
		}
	})();
	</script>
	<?php
}

/* ── Chunk upload AJAX handler ───────────────────────────────────────────── */

add_action( 'wp_ajax_st_upload_chunk', 'st_ajax_upload_chunk' );
function st_ajax_upload_chunk() {
	check_ajax_referer( 'st_upload_chunk' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Permission denied', 403 );
		return;
	}

	$upload_id    = sanitize_key( $_POST['upload_id'] ?? '' );
	$chunk_idx    = (int) ( $_POST['chunk'] ?? 0 );
	$total_chunks = (int) ( $_POST['chunks'] ?? 1 );
	$title        = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );

	if ( ! $upload_id || $total_chunks < 1 || $chunk_idx < 0 || $chunk_idx >= $total_chunks ) {
		wp_send_json_error( 'Invalid parameters', 400 );
		return;
	}

	if ( empty( $_FILES['file'] ) || UPLOAD_ERR_OK !== $_FILES['file']['error'] ) {
		wp_send_json_error( 'File upload error: ' . ( $_FILES['file']['error'] ?? 'missing' ), 400 );
		return;
	}

	$upload_dir = wp_upload_dir();
	$tmp_dir    = trailingslashit( $upload_dir['basedir'] ) . 'st-chunks/';
	wp_mkdir_p( $tmp_dir );

	$chunk_file = $tmp_dir . $upload_id . '.part.' . $chunk_idx;
	if ( ! move_uploaded_file( $_FILES['file']['tmp_name'], $chunk_file ) ) {
		wp_send_json_error( 'Could not save chunk to disk', 500 );
		return;
	}

	// Check whether every chunk has arrived
	for ( $i = 0; $i < $total_chunks; $i++ ) {
		if ( ! file_exists( $tmp_dir . $upload_id . '.part.' . $i ) ) {
			// Still waiting for more chunks
			wp_send_json_success( [ 'assembled' => false ] );
			return;
		}
	}

	// All chunks present — assemble
	$final_zip = trailingslashit( $upload_dir['basedir'] ) . 'st-import-' . $upload_id . '.zip';
	$out       = fopen( $final_zip, 'wb' );
	if ( ! $out ) {
		wp_send_json_error( 'Could not create output file', 500 );
		return;
	}
	for ( $i = 0; $i < $total_chunks; $i++ ) {
		$part = $tmp_dir . $upload_id . '.part.' . $i;
		fwrite( $out, file_get_contents( $part ) );
		@unlink( $part );
	}
	fclose( $out );

	// Quick sanity-check: is it a valid zip?
	$zip = new ZipArchive();
	if ( true !== $zip->open( $final_zip ) ) {
		@unlink( $final_zip );
		wp_send_json_error( 'The assembled file is not a valid zip — please try again', 400 );
		return;
	}
	$zip->close();

	// Queue the background import job
	$token  = wp_generate_password( 32, false );
	$job_id = $upload_id;

	update_option(
		'st_import_job_' . $job_id,
		[
			'status'  => 'queued',
			'zip'     => $final_zip,
			'title'   => $title,
			'author'  => get_current_user_id(),
			'token'   => $token,
			'created' => time(),
		],
		false
	);

	wp_remote_post(
		admin_url( 'admin-ajax.php' ),
		[
			'blocking'  => false,
			'timeout'   => 2,
			'sslverify' => false,
			'body'      => [
				'action' => 'st_run_import_job',
				'job_id' => $job_id,
				'token'  => $token,
			],
		]
	);

	wp_send_json_success( [
		'assembled' => true,
		'job_id'    => $job_id,
		'redirect'  => admin_url( 'admin.php?page=scrollytelling-import&st_job=' . $job_id ),
	] );
}

/* ── Background job runner (nopriv AJAX, secured by one-time token) ──────── */

add_action( 'wp_ajax_st_run_import_job',        'st_ajax_run_import_job' );
add_action( 'wp_ajax_nopriv_st_run_import_job', 'st_ajax_run_import_job' );
function st_ajax_run_import_job() {
	$job_id = sanitize_key( $_POST['job_id'] ?? '' );
	$token  = sanitize_text_field( $_POST['token'] ?? '' );

	if ( ! $job_id || ! $token ) {
		wp_die( '', 400 );
	}

	$job = get_option( 'st_import_job_' . $job_id );

	if ( ! $job || 'queued' !== $job['status'] || ! hash_equals( $job['token'], $token ) ) {
		wp_die( '', 403 );
	}

	set_time_limit( 0 );
	ignore_user_abort( true );

	if ( ! empty( $job['author'] ) ) {
		wp_set_current_user( (int) $job['author'] );
	}

	$job['status'] = 'running';
	update_option( 'st_import_job_' . $job_id, $job, false );

	$importer = new ST_Shorthand_Importer();
	$result   = $importer->import( $job['zip'], $job['title'] );

	if ( is_wp_error( $result ) ) {
		$job['status'] = 'error';
		$job['error']  = $result->get_error_message();
	} else {
		$job['status']     = 'done';
		$job['post_id']    = $result;
		$job['post_url']   = get_edit_post_link( $result, 'raw' );
		$job['post_title'] = get_the_title( $result );
		$job['notes']      = $importer->notes;
	}

	$job['completed'] = time();
	unset( $job['token'] );
	@unlink( $job['zip'] );
	update_option( 'st_import_job_' . $job_id, $job, false );

	wp_die();
}

/* ── AJAX status poll ─────────────────────────────────────────────────────── */

add_action( 'wp_ajax_st_import_status', 'st_ajax_import_status' );
function st_ajax_import_status() {
	$job_id = sanitize_key( $_GET['job_id'] ?? '' );
	check_ajax_referer( 'st_status_' . $job_id );

	$job = get_option( 'st_import_job_' . $job_id );
	if ( ! $job ) {
		wp_send_json_error( 'not_found' );
		return;
	}
	wp_send_json_success( [
		'status'     => $job['status'],
		'post_id'    => $job['post_id'] ?? null,
		'post_url'   => $job['post_url'] ?? null,
		'post_title' => $job['post_title'] ?? null,
		'error'      => $job['error'] ?? null,
		'notes'      => $job['notes'] ?? [],
	] );
}

/* ── Status / polling page ───────────────────────────────────────────────── */

function st_render_import_status_page( $job_id ) {
	$nonce = wp_create_nonce( 'st_status_' . $job_id );
	$ajax  = admin_url( 'admin-ajax.php' );
	?>
	<div class="wrap" id="st-status-wrap">
		<h1><?php esc_html_e( 'Importing from Shorthand…', 'scrollytelling' ); ?></h1>

		<div id="st-status-processing">
			<p>
				<span class="spinner is-active" style="float:none;margin:0 8px 0 0;vertical-align:middle;"></span>
				<?php esc_html_e( 'Converting your story — this may take a minute or two while media files are uploaded. This page will update automatically when it\'s done.', 'scrollytelling' ); ?>
			</p>
		</div>

		<div id="st-status-done" style="display:none;">
			<div class="notice notice-success" style="margin:20px 0 0;">
				<p id="st-done-message"></p>
			</div>
			<div id="st-notes-wrap" style="display:none;">
				<div class="notice notice-warning">
					<p><strong><?php esc_html_e( 'Notes from the conversion:', 'scrollytelling' ); ?></strong></p>
					<ul id="st-notes-list" style="margin-left:20px;list-style:disc;"></ul>
				</div>
			</div>
		</div>

		<div id="st-status-error" style="display:none;">
			<div class="notice notice-error" style="margin:20px 0 0;">
				<p id="st-error-message"></p>
			</div>
		</div>

		<p style="margin-top:24px;">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=scrollytelling-import' ) ); ?>">
				&larr; <?php esc_html_e( 'Import another story', 'scrollytelling' ); ?>
			</a>
		</p>
	</div>

	<script>
	(function () {
		var jobId     = <?php echo wp_json_encode( $job_id ); ?>;
		var nonce     = <?php echo wp_json_encode( $nonce ); ?>;
		var ajax      = <?php echo wp_json_encode( $ajax ); ?>;
		var checks    = 0;
		var maxChecks = 120; // 10 minutes at 5 s intervals

		function poll() {
			var url = ajax
				+ '?action=st_import_status'
				+ '&job_id=' + encodeURIComponent(jobId)
				+ '&_wpnonce=' + encodeURIComponent(nonce);

			fetch(url, { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (data) {
					if (!data.success) { showError('<?php echo esc_js( __( 'Import job not found.', 'scrollytelling' ) ); ?>'); return; }
					var job = data.data;
					if (job.status === 'done')       showDone(job);
					else if (job.status === 'error') showError(job.error || '<?php echo esc_js( __( 'An unknown error occurred.', 'scrollytelling' ) ); ?>');
					else {
						checks++;
						if (checks >= maxChecks) { showError('<?php echo esc_js( __( 'The import is taking too long. Try again, or use: wp scrollytelling import_shorthand /path/to/story.zip', 'scrollytelling' ) ); ?>'); return; }
						setTimeout(poll, 5000);
					}
				})
				.catch(function () { if (++checks < maxChecks) setTimeout(poll, 5000); });
		}

		function showDone(job) {
			document.getElementById('st-status-processing').style.display = 'none';
			document.getElementById('st-status-done').style.display = '';
			document.getElementById('st-done-message').innerHTML =
				'<?php echo esc_js( __( 'Done! Created a draft page: ', 'scrollytelling' ) ); ?>'
				+ '<a href="' + job.post_url + '">' + escHtml(job.post_title) + '</a>';
			if (job.notes && job.notes.length) {
				document.getElementById('st-notes-wrap').style.display = '';
				var list = document.getElementById('st-notes-list');
				job.notes.forEach(function (n) { var li = document.createElement('li'); li.textContent = n; list.appendChild(li); });
			}
		}

		function showError(msg) {
			document.getElementById('st-status-processing').style.display = 'none';
			document.getElementById('st-status-error').style.display = '';
			document.getElementById('st-error-message').textContent = msg;
		}

		function escHtml(s) {
			return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
		}

		poll();
	})();
	</script>
	<?php
}
