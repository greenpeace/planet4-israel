<?php
/**
 * AI-assisted layout planner for the PDF / GDoc importer.
 *
 * Sends per-page text (and optionally page images) to a Gemini or Claude
 * model and returns a structured block plan that sections_to_blocks() uses
 * instead of pure heuristics.
 */

defined( 'ABSPATH' ) || exit;

class ST_AI_Planner {

	const BLOCK_TYPES = [
		'hero'         => 'Full-screen cover. Use ONCE for page 0.',
		'reveal'       => 'Full-bleed image, no text or ≤3 word caption. Chapter dividers, visual pauses.',
		'tom'          => 'Image + short text overlay (≤50 words). When image context strengthens a concise message.',
		'bg-scroll'    => 'Sticky background image, scrolling text panels. Use for 4+ paragraph analysis/narrative pages.',
		'scrollmation' => 'Image sequence that animates on scroll. Only when 3+ consecutive pages are near-image-only.',
		'wp-table'     => 'Native WP table. REQUIRED for glossaries, product lists, comparisons, structured data.',
		'wp-text'      => 'Native WP paragraphs. Text-only sections: references, footnotes, long explanatory text.',
		'section-text' => 'Styled text section. Short-to-medium text without a strong image.',
	];

	/** Default models per provider. */
	const DEFAULTS = [
		'gemini' => 'gemini-2.5-flash-lite',
		'claude' => 'claude-haiku-4-5-20251001',
	];

	private string $provider;
	private string $api_key;
	private string $model;
	private string $last_error = '';

	public function __construct( string $provider, string $api_key, string $model = '' ) {
		$this->provider = strtolower( $provider );
		$this->api_key  = $api_key;
		$this->model    = $model ?: ( self::DEFAULTS[ $this->provider ] ?? '' );
	}

	public function get_last_error(): string {
		return $this->last_error;
	}

	// ── Public API ────────────────────────────────────────────────────────────

	/**
	 * Plans the block layout for all pages.
	 *
	 * @param string[] $page_texts Extracted text per page.
	 * @param string[] $page_urls  WP image URL per page (empty = no image).
	 * @return array[]  Plan items with: page, block, heading, paragraphs, caption, use_image.
	 *                  Returns [] on any failure; call get_last_error() for the reason.
	 */
	public function plan( array $page_texts, array $page_urls ): array {
		$this->last_error = '';

		$prompt = $this->build_prompt( $page_texts, $page_urls );

		$raw = match ( $this->provider ) {
			'gemini' => $this->call_gemini( $prompt ),
			'claude' => $this->call_claude( $prompt ),
			default  => '',
		};

		if ( ! $raw ) {
			return [];
		}

		$parsed = $this->parse_response( $raw );
		if ( ! $parsed ) {
			$this->last_error = 'AI returned a response but no valid JSON block plan could be extracted. Raw: '
				. mb_substr( $raw, 0, 300 );
		}
		return $parsed;
	}

	/**
	 * Sends a minimal "ping" to verify the API key and model are valid.
	 *
	 * @return string  '' on success, human-readable error message on failure.
	 */
	public function test_connection(): string {
		$raw = match ( $this->provider ) {
			'gemini' => $this->call_gemini( 'Reply with exactly the word: OK' ),
			'claude' => $this->call_claude( 'Reply with exactly the word: OK' ),
			default  => '',
		};

		if ( $this->last_error ) {
			return $this->last_error;
		}
		if ( ! $raw ) {
			return 'Empty response from API.';
		}
		return ''; // success
	}

	// ── Prompt ───────────────────────────────────────────────────────────────

	private function build_prompt( array $page_texts, array $page_urls ): string {
		$block_list = '';
		foreach ( self::BLOCK_TYPES as $type => $desc ) {
			$block_list .= "  - **{$type}**: {$desc}\n";
		}

		$pages_section = '';
		$count = max( count( $page_texts ), count( $page_urls ) );
		for ( $i = 0; $i < $count; $i++ ) {
			$text      = trim( $page_texts[ $i ] ?? '' );
			$words     = $text ? count( preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY ) ) : 0;
			$has_img   = ! empty( $page_urls[ $i ] ) ? 'yes' : 'no';
			$excerpt   = mb_substr( $text, 0, 400 );
			if ( mb_strlen( $text ) > 400 ) {
				$excerpt .= '…';
			}
			$pages_section .= "[Page {$i}] word_count={$words} has_image={$has_img}\n";
			$pages_section .= $excerpt ?: '(image-only page, no extractable text)';
			$pages_section .= "\n\n";
		}

		return <<<PROMPT
You are a senior UX/UI designer converting a multi-page PDF into a WordPress scrollytelling web page.
The document is written in Hebrew (right-to-left). Text extraction may be imperfect — use word_count and visual context to guide decisions when text is unclear.

## Block types
{$block_list}

## Layout rules
1. **Rhythm**: never place the same block type more than 2 times in a row. Break runs with reveal or section-text.
2. **Visual pauses**: insert a `reveal` after every 2-3 heavy content blocks (bg-scroll, tom).
3. **Hero**: appears ONCE, always for page 0 — no exceptions.
4. **Tables**: use `wp-table` for ANY page that contains a glossary, product list, comparison table, or structured data grid.
5. **bg-scroll** requires ≥4 paragraphs of text; don't use it for pages with fewer than ~60 words.
6. **scrollmation**: only when 3 or more consecutive pages have word_count < 8. Group them into one entry with "pages":[n,n+1,...].
7. **Image signal**: when has_image=yes and word_count < 8, prefer `reveal`. When word_count 8-50, prefer `tom`. When word_count ≥ 50, prefer `bg-scroll`.
8. **Preserve text**: copy Hebrew text exactly into "heading" and "paragraphs" — do NOT translate or summarise.

## Pages
{$pages_section}

## Output format
Return ONLY a valid JSON array, starting with [ and ending with ]. No markdown, no explanation.

Schema for each element:
{
  "page": <integer, omit only for scrollmation groups>,
  "pages": <array of integers, ONLY for scrollmation groups>,
  "block": <one of the block type names above>,
  "heading": <string>,
  "paragraphs": <array of strings>,
  "caption": <1-3 word string, only for reveal>,
  "use_image": <true|false>
}
PROMPT;
	}

	// ── API calls ─────────────────────────────────────────────────────────────

	private function call_gemini( string $prompt ): string {
		$url = 'https://generativelanguage.googleapis.com/v1beta/models/'
			. rawurlencode( $this->model )
			. ':generateContent?key='
			. rawurlencode( $this->api_key );

		$response = wp_remote_post( $url, [
			'timeout' => 120,
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( [
				'contents'         => [ [ 'parts' => [ [ 'text' => $prompt ] ] ] ],
				'generationConfig' => [
					'temperature'     => 0.1,
					'maxOutputTokens' => 8192,
					'responseMimeType' => 'application/json',
				],
			] ),
		] );

		return $this->unwrap_response( $response, 'gemini' );
	}

	private function call_claude( string $prompt ): string {
		$response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
			'timeout' => 120,
			'headers' => [
				'Content-Type'      => 'application/json',
				'x-api-key'         => $this->api_key,
				'anthropic-version' => '2023-06-01',
			],
			'body'    => wp_json_encode( [
				'model'      => $this->model,
				'max_tokens' => 8192,
				'messages'   => [ [ 'role' => 'user', 'content' => $prompt ] ],
			] ),
		] );

		return $this->unwrap_response( $response, 'claude' );
	}

	/**
	 * Extracts the text payload from a wp_remote_post() response.
	 * Sets $this->last_error on any failure.
	 */
	private function unwrap_response( $response, string $provider ): string {
		if ( is_wp_error( $response ) ) {
			$this->last_error = 'Network error: ' . $response->get_error_message();
			return '';
		}

		$http_code = (int) wp_remote_retrieve_response_code( $response );
		$body      = wp_remote_retrieve_body( $response );
		$data      = json_decode( $body, true );

		if ( $http_code < 200 || $http_code >= 300 ) {
			// Extract error message from API error response
			$api_msg = '';
			if ( 'gemini' === $provider ) {
				$api_msg = $data['error']['message'] ?? $body;
			} else {
				$api_msg = $data['error']['message'] ?? ( $data['error']['type'] ?? $body );
			}
			$this->last_error = "API error HTTP {$http_code}: " . mb_substr( (string) $api_msg, 0, 200 );
			return '';
		}

		if ( 'gemini' === $provider ) {
			$text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
			if ( ! $text && isset( $data['candidates'][0]['finishReason'] ) ) {
				$this->last_error = 'Gemini stopped: ' . $data['candidates'][0]['finishReason'];
			}
			return (string) $text;
		}

		// Claude
		$text = $data['content'][0]['text'] ?? '';
		if ( ! $text && isset( $data['stop_reason'] ) ) {
			$this->last_error = 'Claude stop_reason: ' . $data['stop_reason'];
		}
		return (string) $text;
	}

	// ── Response parsing ──────────────────────────────────────────────────────

	private function parse_response( string $raw ): array {
		// Strip markdown code fences
		$raw = preg_replace( '/^```(?:json)?\s*/m', '', $raw );
		$raw = preg_replace( '/^```\s*$/m', '', $raw );
		$raw = trim( $raw );

		// Find the outermost [...] block
		$start = strpos( $raw, '[' );
		$end   = strrpos( $raw, ']' );
		if ( false === $start || false === $end || $end <= $start ) {
			return [];
		}

		$plan = json_decode( substr( $raw, $start, $end - $start + 1 ), true );
		if ( ! is_array( $plan ) ) {
			return [];
		}

		$valid = array_keys( self::BLOCK_TYPES );
		$out   = [];

		foreach ( $plan as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$block = $item['block'] ?? '';
			if ( ! in_array( $block, $valid, true ) ) {
				continue;
			}

			$is_group = ! empty( $item['pages'] ) && is_array( $item['pages'] );

			$out[] = [
				'block'      => $block,
				'heading'    => sanitize_text_field( $item['heading'] ?? '' ),
				'paragraphs' => array_values( array_filter(
					array_map( 'sanitize_textarea_field', (array) ( $item['paragraphs'] ?? [] ) )
				) ),
				'caption'    => sanitize_text_field( $item['caption'] ?? '' ),
				'use_image'  => ! empty( $item['use_image'] ),
				'page'       => $is_group ? -1 : (int) ( $item['page'] ?? 0 ),
				'pages'      => $is_group ? array_map( 'intval', $item['pages'] ) : [],
			];
		}

		return $out;
	}

	// ── WP options helpers ────────────────────────────────────────────────────

	public static function saved_provider(): string {
		return (string) get_option( 'st_ai_provider', '' );
	}

	public static function saved_api_key(): string {
		return (string) get_option( 'st_ai_api_key', '' );
	}

	public static function saved_model(): string {
		return (string) get_option( 'st_ai_model', '' );
	}

	public static function save_settings( string $provider, string $api_key, string $model ): void {
		update_option( 'st_ai_provider', sanitize_key( $provider ) );
		if ( $api_key && '[hidden]' !== $api_key ) {
			update_option( 'st_ai_api_key', sanitize_text_field( $api_key ) );
		}
		update_option( 'st_ai_model', sanitize_text_field( $model ) );
	}
}
