<?php
/**
 * Converts a Google Doc URL or a PDF file into a WordPress Page built
 * entirely from this plugin's own Scrollytelling blocks.
 *
 * Two import paths:
 *   Google Doc URL → wp_remote_get() on the export URL → parse HTML DOM
 *     → sections (heading + paragraphs + images) → download images into
 *     the WP media library → map sections to blocks.
 *
 *   PDF file → ImageMagick (PHP Imagick extension) converts each page to
 *     JPEG → optionally pdftotext extracts body text → map pages to blocks.
 *
 * Block-selection heuristic per section (after the mandatory Hero first):
 *   image + 3+ paragraphs OR >500 chars   → Background Scroll
 *   2+ images + any text                   → Scrollmation
 *   image + very short text + heading      → Text Over Media
 *   image + medium/long text               → Reveal + Section Text
 *   text only                              → Section Text (alternating bg)
 *
 * IMPORTANT: every render_*() method here must produce HTML that
 * byte-for-byte matches what the corresponding block's save.js would
 * produce for the same attributes, otherwise the block shows as "invalid"
 * the first time the user opens the page in the editor.
 */

defined( 'ABSPATH' ) || exit;

class ST_Doc_Importer {

	/** @var bool Whether the content appears to be right-to-left. */
	private bool $is_rtl = false;

	/** @var array<string> Human-readable notes about the import. */
	public array $notes = [];

	/** AI planning configuration — set via set_ai_config() before importing. */
	private string $ai_provider = '';
	private string $ai_api_key  = '';
	private string $ai_model    = '';

	/** Configure the AI layout planner. Call before import_from_pdf(). */
	public function set_ai_config( string $provider, string $api_key, string $model = '' ): void {
		$this->ai_provider = $provider;
		$this->ai_api_key  = $api_key;
		$this->ai_model    = $model;
	}

	/* ═══════════════════════════ Entry points ══════════════════════════════ */

	/**
	 * @param string $gdoc_url   Google Docs share or publish URL.
	 * @param string $page_title Override; otherwise taken from the document's own title.
	 * @return int|WP_Error      New page ID, or WP_Error on failure.
	 */
	public function import_from_gdoc( string $gdoc_url, string $page_title = '' ): int|WP_Error {
		$html = $this->fetch_gdoc_html( $gdoc_url );
		if ( is_wp_error( $html ) ) {
			return $html;
		}

		$this->is_rtl = $this->detect_rtl_from_html( $html );
		$sections     = $this->parse_html_to_sections( $html );

		if ( ! $sections ) {
			return new WP_Error( 'st_doc_empty', __( 'No content could be extracted from this Google Doc. Make sure it is shared as "Anyone with the link can view".', 'scrollytelling' ) );
		}

		if ( ! $page_title ) {
			$page_title = $sections[0]['heading'] ?: $this->extract_title_from_html( $html );
		}

		$sections = $this->download_section_images( $sections );
		$content  = $this->sections_to_blocks( $sections );

		return wp_insert_post(
			wp_slash( [
				'post_title'   => $page_title ?: __( 'Imported Document', 'scrollytelling' ),
				'post_content' => $content,
				'post_type'    => 'page',
				'post_status'  => 'draft',
			] ),
			true
		);
	}

	/**
	 * @param string $pdf_path   Absolute server path to the uploaded PDF.
	 * @param string $page_title Override title; otherwise uses first extracted heading.
	 * @return int|WP_Error      New page ID, or WP_Error on failure.
	 */
	public function import_from_pdf( string $pdf_path, string $page_title = '' ): int|WP_Error {
		if ( ! file_exists( $pdf_path ) ) {
			return new WP_Error( 'st_doc_no_file', __( 'PDF file not found.', 'scrollytelling' ) );
		}

		$page_images = $this->extract_pdf_pages( $pdf_path );
		$page_count  = count( $page_images ) ?: 1;
		$page_texts  = $this->extract_pdf_text_per_page( $pdf_path, $page_count );

		if ( ! $page_images && ! array_filter( $page_texts ) ) {
			@unlink( $pdf_path );
			return new WP_Error(
				'st_doc_pdf_empty',
				__( 'Could not extract any content from this PDF. Install pdftoppm (poppler-utils), GhostScript, or the PHP Imagick extension on the server. Scanned/image-only PDFs also require one of these tools.', 'scrollytelling' )
			);
		}

		// ── Detect RTL from extracted text (Hebrew/Arabic Unicode ranges) ─────
		$combined_text = implode( ' ', array_slice( $page_texts, 0, 5 ) );
		$this->is_rtl  = (bool) preg_match( '/[\x{0590}-\x{05FF}\x{0600}-\x{06FF}]/u', $combined_text );

		// ── Try AI layout planning ────────────────────────────────────────────
		$sections = null;
		if ( $this->ai_provider && $this->ai_api_key ) {
			$planner = new ST_AI_Planner( $this->ai_provider, $this->ai_api_key, $this->ai_model );
			$ai_plan = $planner->plan( $page_texts, $page_images );

			if ( $ai_plan ) {
				$sections        = $this->build_sections_from_ai_plan( $ai_plan, $page_images, $page_texts );
				$this->notes[]   = sprintf(
					// translators: %1$s = AI provider name, %2$s = model name
					__( 'Layout planned by %1$s (%2$s). %3$d pages → %4$d blocks.', 'scrollytelling' ),
					ucfirst( $this->ai_provider ),
					$planner->get_last_error() ? 'error' : ( $this->ai_model ?: ST_AI_Planner::DEFAULTS[ $this->ai_provider ] ?? '' ),
					$page_count,
					count( $sections )
				);
			} else {
				$err           = $planner->get_last_error();
				$this->notes[] = __( 'AI planning failed — fell back to heuristic layout.', 'scrollytelling' )
					. ( $err ? ' Error: ' . $err : '' );
			}
		}

		// ── Fallback: heuristic layout ────────────────────────────────────────
		if ( null === $sections ) {
			$sections = $this->build_pdf_sections( $page_images, $page_texts, $page_title );
		}

		if ( ! $page_title && $sections ) {
			$page_title = $sections[0]['heading'];
		}

		$content = $this->sections_to_blocks( $sections );

		@unlink( $pdf_path );

		return wp_insert_post(
			wp_slash( [
				'post_title'   => $page_title ?: __( 'Imported PDF', 'scrollytelling' ),
				'post_content' => $content,
				'post_type'    => 'page',
				'post_status'  => 'draft',
			] ),
			true
		);
	}

	/* ══════════════════════ Google Doc fetching / parsing ══════════════════ */

	private function fetch_gdoc_html( string $url ): string|WP_Error {
		$export_url = $this->normalize_gdoc_url( $url );
		if ( ! $export_url ) {
			return new WP_Error(
				'st_doc_bad_url',
				__( 'Please provide a valid Google Docs URL (e.g. https://docs.google.com/document/d/…).', 'scrollytelling' )
			);
		}

		$response = wp_remote_get(
			$export_url,
			[
				'timeout'     => 60,
				'sslverify'   => false,
				'redirection' => 5,
				'headers'     => [
					'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . get_bloginfo( 'url' ),
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'st_doc_fetch_error', __( 'Could not reach Google Docs: ', 'scrollytelling' ) . $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			if ( in_array( $code, [ 401, 403 ], true ) ) {
				return new WP_Error(
					'st_doc_access',
					__( 'Access denied. Make sure the document is shared as "Anyone with the link can view".', 'scrollytelling' )
				);
			}
			return new WP_Error( 'st_doc_fetch_error', sprintf( __( 'Google Docs returned HTTP %d.', 'scrollytelling' ), $code ) );
		}

		$body = wp_remote_retrieve_body( $response );
		if ( ! $body ) {
			return new WP_Error( 'st_doc_empty_response', __( 'Google Docs returned an empty response.', 'scrollytelling' ) );
		}

		return $body;
	}

	private function normalize_gdoc_url( string $url ): ?string {
		$url = trim( $url );
		if ( str_contains( $url, '/export?format=html' ) ) {
			return $url;
		}
		if ( preg_match( '#/document/d/([a-zA-Z0-9_-]+)#', $url, $m ) ) {
			return 'https://docs.google.com/document/d/' . $m[1] . '/export?format=html';
		}
		return null;
	}

	private function parse_html_to_sections( string $html ): array {
		$dom = new DOMDocument();
		libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING );
		libxml_clear_errors();

		$body = $dom->getElementsByTagName( 'body' )->item( 0 );
		if ( ! $body ) {
			return [];
		}

		$items = [];
		$this->flatten_dom( $body, $items );

		return $this->items_to_sections( $items );
	}

	private function flatten_dom( DOMNode $node, array &$items ): void {
		if ( ! ( $node instanceof DOMElement ) ) {
			return;
		}

		$tag = strtolower( $node->tagName );

		if ( in_array( $tag, [ 'script', 'style', 'head', 'nav', 'footer', 'noscript' ], true ) ) {
			return;
		}

		if ( preg_match( '/^h([1-4])$/', $tag, $m ) ) {
			$text = $this->clean_text( $node->textContent );
			if ( $text ) {
				$items[] = [ 'type' => 'heading', 'level' => (int) $m[1], 'text' => $text ];
			}
			return;
		}

		if ( 'p' === $tag || 'div' === $tag ) {
			$imgs = $node->getElementsByTagName( 'img' );
			if ( $imgs->length > 0 ) {
				foreach ( $imgs as $img ) {
					$src = $img->getAttribute( 'src' );
					if ( ! $src ) {
						continue;
					}
					// Skip tiny tracking pixels (data URIs shorter than ~2 KB are
					// 1×1 spacers or decorative icons, not content images)
					if ( str_starts_with( $src, 'data:' ) && strlen( $src ) < 2000 ) {
						continue;
					}
					$items[] = [ 'type' => 'image', 'src' => $src, 'alt' => $img->getAttribute( 'alt' ) ?: '' ];
				}
				// Also grab any text sibling to the image (caption-like content)
				$text = $this->clean_text( preg_replace( '/<img[^>]+>/', '', $node->textContent ) );
				if ( $text && mb_strlen( $text ) > 15 ) {
					$items[] = [ 'type' => 'paragraph', 'text' => $text ];
				}
				return;
			}

			// Paragraph with only text — recurse first to catch nested block elements
			$has_block_children = false;
			foreach ( $node->childNodes as $child ) {
				if ( $child instanceof DOMElement ) {
					$ct = strtolower( $child->tagName );
					if ( in_array( $ct, [ 'p', 'h1', 'h2', 'h3', 'h4', 'ul', 'ol', 'table', 'div' ], true ) ) {
						$has_block_children = true;
						break;
					}
				}
			}

			if ( 'p' === $tag || ! $has_block_children ) {
				$text = $this->clean_text( $node->textContent );
				if ( $text && mb_strlen( $text ) > 15 ) {
					$items[] = [ 'type' => 'paragraph', 'text' => $text ];
				}
				return;
			}
		}

		if ( 'li' === $tag ) {
			$text = $this->clean_text( $node->textContent );
			if ( $text ) {
				$items[] = [ 'type' => 'paragraph', 'text' => '• ' . $text ];
			}
			return;
		}

		if ( 'img' === $tag ) {
			$src = $node->getAttribute( 'src' );
			if ( $src && ! ( str_starts_with( $src, 'data:' ) && strlen( $src ) < 2000 ) ) {
				$items[] = [ 'type' => 'image', 'src' => $src, 'alt' => $node->getAttribute( 'alt' ) ?: '' ];
			}
			return;
		}

		foreach ( $node->childNodes as $child ) {
			$this->flatten_dom( $child, $items );
		}
	}

	private function items_to_sections( array $items ): array {
		$sections = [];
		$current  = [ 'heading' => '', 'paragraphs' => [], 'images' => [] ];

		foreach ( $items as $item ) {
			if ( 'heading' === $item['type'] ) {
				if ( $item['level'] <= 3 && ( $current['heading'] || $current['paragraphs'] || $current['images'] ) ) {
					$sections[] = $current;
					$current    = [ 'heading' => $item['text'], 'paragraphs' => [], 'images' => [] ];
				} elseif ( ! $current['heading'] ) {
					$current['heading'] = $item['text'];
				} else {
					$current['paragraphs'][] = $item['text'];
				}
			} elseif ( 'paragraph' === $item['type'] ) {
				$current['paragraphs'][] = $item['text'];
			} elseif ( 'image' === $item['type'] ) {
				$current['images'][] = [ 'src' => $item['src'], 'alt' => $item['alt'], 'wp_url' => '' ];
			}
		}

		if ( $current['heading'] || $current['paragraphs'] || $current['images'] ) {
			$sections[] = $current;
		}

		return $sections;
	}

	private function clean_text( string $text ): string {
		return trim( preg_replace( '/\s+/u', ' ', $text ) );
	}

	/* ════════════════════════════ Image downloading ═════════════════════════ */

	private function download_section_images( array $sections ): array {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';

		foreach ( $sections as &$section ) {
			foreach ( $section['images'] as &$img ) {
				if ( str_starts_with( $img['src'], 'data:' ) ) {
					$url = $this->store_data_uri( $img['src'] );
				} else {
					$url = $this->download_url_to_attachment( $img['src'] );
				}
				$img['wp_url'] = $url ?: '';
			}
			unset( $img );
		}
		unset( $section );

		return $sections;
	}

	private function download_url_to_attachment( string $url ): ?string {
		$tmp = download_url( $url, 60 );
		if ( is_wp_error( $tmp ) ) {
			$this->notes[] = sprintf( __( 'Could not download image: %s', 'scrollytelling' ), esc_url( $url ) );
			return null;
		}

		$path = parse_url( $url, PHP_URL_PATH );
		$name = $path ? sanitize_file_name( basename( $path ) ) : 'image.jpg';
		if ( ! preg_match( '/\.(jpe?g|png|gif|webp|svg)$/i', $name ) ) {
			$name .= '.jpg';
		}

		$file_array = [ 'name' => $name, 'tmp_name' => $tmp ];
		$attach_id  = media_handle_sideload( $file_array, 0 );
		@unlink( $tmp );

		if ( is_wp_error( $attach_id ) ) {
			$this->notes[] = sprintf( __( 'Could not store image: %s', 'scrollytelling' ), esc_url( $url ) );
			return null;
		}

		return wp_get_attachment_url( $attach_id ) ?: null;
	}

	private function store_data_uri( string $data_uri ): ?string {
		if ( ! preg_match( '#^data:(image/[a-z+]+);base64,(.+)$#i', $data_uri, $m ) ) {
			return null;
		}

		$mime = $m[1];
		$data = base64_decode( $m[2] );
		if ( ! $data ) {
			return null;
		}

		$ext_map  = [ 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp' ];
		$ext      = $ext_map[ $mime ] ?? 'jpg';
		$upload   = wp_upload_dir();
		$filename = wp_unique_filename( $upload['path'], 'doc-image.' . $ext );
		$filepath = trailingslashit( $upload['path'] ) . $filename;

		if ( ! file_put_contents( $filepath, $data ) ) {
			return null;
		}

		$attach_id = wp_insert_attachment(
			[ 'post_mime_type' => $mime, 'post_title' => 'doc-image', 'post_status' => 'inherit' ],
			$filepath
		);
		if ( ! $attach_id || is_wp_error( $attach_id ) ) {
			return null;
		}

		$meta = wp_generate_attachment_metadata( $attach_id, $filepath );
		wp_update_attachment_metadata( $attach_id, $meta );

		return wp_get_attachment_url( $attach_id ) ?: null;
	}

	/* ═════════════════════════════ PDF extraction ═══════════════════════════ */

	private function extract_pdf_pages( string $pdf_path ): array {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';

		if ( class_exists( 'Imagick' ) ) {
			return $this->extract_pdf_pages_imagick( $pdf_path );
		}
		if ( $this->command_exists( 'pdftoppm' ) ) {
			return $this->extract_pdf_pages_pdftoppm( $pdf_path );
		}
		if ( $this->command_exists( 'gs' ) ) {
			return $this->extract_pdf_pages_gs( $pdf_path );
		}
		if ( $this->command_exists( 'convert' ) ) {
			return $this->extract_pdf_pages_convert( $pdf_path );
		}

		$this->notes[] = __( 'No PDF-to-image tool found (tried: PHP Imagick, pdftoppm, gs, convert). Text-only import will be used if text is available.', 'scrollytelling' );
		return [];
	}

	private function command_exists( string $cmd ): bool {
		if ( ! function_exists( 'exec' ) ) {
			return false;
		}
		return ! empty( $this->resolve_command( $cmd ) );
	}

	private function resolve_command( string $cmd ): string {
		$search_paths = [
			'/opt/homebrew/bin', // Apple Silicon Homebrew
			'/usr/local/bin',    // Intel Homebrew / standard
			'/usr/bin',
			'/bin',
		];
		foreach ( $search_paths as $dir ) {
			$full = $dir . '/' . $cmd;
			if ( is_executable( $full ) ) {
				return $full;
			}
		}
		// Fallback: try `which` (works if the system PATH is set)
		$out  = [];
		$code = 0;
		exec( 'which ' . escapeshellarg( $cmd ) . ' 2>/dev/null', $out, $code );
		return ( 0 === $code && ! empty( $out[0] ) ) ? trim( $out[0] ) : '';
	}

	private function extract_pdf_pages_imagick( string $pdf_path ): array {
		$upload = wp_upload_dir();
		$urls   = [];
		try {
			$imagick = new Imagick();
			$imagick->setResolution( 150, 150 );
			$imagick->readImage( $pdf_path );
			$count = $imagick->getNumberImages();
			for ( $i = 0; $i < $count; $i++ ) {
				$imagick->setIteratorIndex( $i );
				$frame = $imagick->getImage();
				$frame->setImageFormat( 'jpeg' );
				$frame->setImageCompressionQuality( 85 );
				$frame->setImageBackgroundColor( 'white' );
				$frame    = $frame->flattenImages();
				$filename = wp_unique_filename( $upload['path'], 'pdf-page-' . ( $i + 1 ) . '.jpg' );
				$filepath = trailingslashit( $upload['path'] ) . $filename;
				$frame->writeImage( $filepath );
				$frame->destroy();
				$url = $this->attach_image_file( $filepath, 'PDF Page ' . ( $i + 1 ) );
				if ( $url ) {
					$urls[] = $url;
				}
			}
			$imagick->destroy();
		} catch ( Exception $e ) {
			$this->notes[] = __( 'Imagick PDF extraction failed: ', 'scrollytelling' ) . $e->getMessage();
		}
		return $urls;
	}

	private function extract_pdf_pages_pdftoppm( string $pdf_path ): array {
		$upload = wp_upload_dir();
		$prefix = trailingslashit( $upload['path'] ) . 'pdf-page-' . uniqid();
		$bin    = $this->resolve_command( 'pdftoppm' );
		$cmd    = escapeshellarg( $bin ) . ' -jpeg -r 150 -jpegopt quality=85 '
			. escapeshellarg( $pdf_path ) . ' ' . escapeshellarg( $prefix ) . ' 2>/dev/null';
		exec( $cmd, $out, $code );
		if ( 0 !== $code ) {
			$this->notes[] = __( 'pdftoppm failed to convert PDF pages.', 'scrollytelling' );
			return [];
		}
		$files = glob( $prefix . '-*.jpg' );
		if ( ! $files ) {
			$files = glob( $prefix . '-*.ppm' );
		}
		sort( $files );
		$urls = [];
		foreach ( $files as $idx => $file ) {
			$dest = trailingslashit( $upload['path'] ) . wp_unique_filename( $upload['path'], 'pdf-page-' . ( $idx + 1 ) . '.jpg' );
			rename( $file, $dest );
			$url = $this->attach_image_file( $dest, 'PDF Page ' . ( $idx + 1 ) );
			if ( $url ) {
				$urls[] = $url;
			}
		}
		return $urls;
	}

	private function extract_pdf_pages_gs( string $pdf_path ): array {
		$upload  = wp_upload_dir();
		$pattern = trailingslashit( $upload['path'] ) . 'pdf-page-' . uniqid() . '_%03d.jpg';
		$bin     = $this->resolve_command( 'gs' );
		$cmd     = escapeshellarg( $bin ) . ' -dBATCH -dNOPAUSE -dSAFER -sDEVICE=jpeg -r150 -dJPEGQ=85'
			. ' -sOutputFile=' . escapeshellarg( $pattern )
			. ' ' . escapeshellarg( $pdf_path ) . ' 2>/dev/null';
		exec( $cmd, $out, $code );
		if ( 0 !== $code ) {
			$this->notes[] = __( 'GhostScript failed to convert PDF pages.', 'scrollytelling' );
			return [];
		}
		// Glob the produced files (pattern uses %03d so they are numbered)
		$dir   = trailingslashit( $upload['path'] );
		$base  = basename( str_replace( '%03d.jpg', '', $pattern ) );
		$files = glob( $dir . $base . '*.jpg' );
		sort( $files );
		$urls  = [];
		foreach ( $files as $idx => $file ) {
			$dest = $dir . wp_unique_filename( $upload['path'], 'pdf-page-' . ( $idx + 1 ) . '.jpg' );
			rename( $file, $dest );
			$url  = $this->attach_image_file( $dest, 'PDF Page ' . ( $idx + 1 ) );
			if ( $url ) {
				$urls[] = $url;
			}
		}
		return $urls;
	}

	private function extract_pdf_pages_convert( string $pdf_path ): array {
		$upload  = wp_upload_dir();
		$pattern = trailingslashit( $upload['path'] ) . 'pdf-page-' . uniqid() . '-%d.jpg';
		$bin     = $this->resolve_command( 'convert' );
		$cmd     = escapeshellarg( $bin ) . ' -density 150 -quality 85 -background white -flatten '
			. escapeshellarg( $pdf_path ) . ' ' . escapeshellarg( $pattern ) . ' 2>/dev/null';
		exec( $cmd, $out, $code );
		if ( 0 !== $code ) {
			$this->notes[] = __( 'ImageMagick convert failed to convert PDF pages.', 'scrollytelling' );
			return [];
		}
		$base  = str_replace( '-%d.jpg', '', $pattern );
		$files = glob( $base . '-*.jpg' );
		// Also check for single-page output (no suffix)
		if ( ! $files && file_exists( $base . '.jpg' ) ) {
			$files = [ $base . '.jpg' ];
		}
		sort( $files );
		$urls  = [];
		$dir   = trailingslashit( $upload['path'] );
		foreach ( $files as $idx => $file ) {
			$dest = $dir . wp_unique_filename( $upload['path'], 'pdf-page-' . ( $idx + 1 ) . '.jpg' );
			rename( $file, $dest );
			$url  = $this->attach_image_file( $dest, 'PDF Page ' . ( $idx + 1 ) );
			if ( $url ) {
				$urls[] = $url;
			}
		}
		return $urls;
	}

	private function attach_image_file( string $filepath, string $title ): ?string {
		if ( ! file_exists( $filepath ) ) {
			return null;
		}
		$attach_id = wp_insert_attachment(
			[ 'post_mime_type' => 'image/jpeg', 'post_title' => $title, 'post_status' => 'inherit' ],
			$filepath
		);
		if ( ! $attach_id || is_wp_error( $attach_id ) ) {
			return null;
		}
		$meta = wp_generate_attachment_metadata( $attach_id, $filepath );
		wp_update_attachment_metadata( $attach_id, $meta );
		return wp_get_attachment_url( $attach_id ) ?: null;
	}

	/**
	 * Extracts text per-page using pdftotext -f/-l flags.
	 * Falls back to form-feed split of full extraction.
	 * Returns array indexed 0..N-1.
	 */
	private function extract_pdf_text_per_page( string $pdf_path, int $page_count ): array {
		if ( ! function_exists( 'exec' ) ) {
			return array_fill( 0, $page_count, '' );
		}

		// Best: pdftotext (poppler) — per-page via -f/-l flags
		$bin = $this->resolve_command( 'pdftotext' );
		if ( $bin ) {
			$texts = [];
			for ( $i = 1; $i <= $page_count; $i++ ) {
				$out  = [];
				$code = 0;
				exec(
					escapeshellarg( $bin ) . ' -f ' . $i . ' -l ' . $i . ' -layout -nopgbrk '
					. escapeshellarg( $pdf_path ) . ' - 2>/dev/null',
					$out,
					$code
				);
				$texts[] = ( 0 === $code && $out ) ? implode( "\n", $out ) : '';
			}
			return $texts;
		}

		// Fallback: GhostScript per-page with -dFirstPage/-dLastPage
		// -q suppresses the "GPL Ghostscript X.X" banner
		$gs_bin = $this->resolve_command( 'gs' );
		if ( $gs_bin ) {
			$texts = [];
			for ( $i = 1; $i <= $page_count; $i++ ) {
				$out  = [];
				$code = 0;
				exec(
					escapeshellarg( $gs_bin )
					. ' -q -dBATCH -dNOPAUSE -dSAFER -sDEVICE=txtwrite'
					. ' -dFirstPage=' . $i . ' -dLastPage=' . $i
					. ' -sOutputFile=- '
					. escapeshellarg( $pdf_path ) . ' 2>/dev/null',
					$out,
					$code
				);
				$texts[] = ( 0 === $code && $out ) ? $this->strip_gs_artifacts( implode( "\n", $out ) ) : '';
			}
			return $texts;
		}

		return array_fill( 0, $page_count, '' );
	}

	private function strip_gs_artifacts( string $text ): string {
		// Remove GhostScript banner lines ("GPL Ghostscript X.X ...", "Processing pages N through N.")
		$lines = explode( "\n", $text );
		$lines = array_filter( $lines, function ( $line ) {
			$l = trim( $line );
			if ( preg_match( '/^GPL Ghostscript/i', $l ) ) return false;
			if ( preg_match( '/^Processing pages/i', $l ) ) return false;
			if ( preg_match( '/^Copyright \(C\)/i', $l ) ) return false;
			if ( preg_match( '/^This software comes with/i', $l ) ) return false;
			return true;
		} );
		return implode( "\n", $lines );
	}

	/**
	 * One section per PDF page. Sets _type so sections_to_blocks() can pick
	 * the right block without re-guessing.
	 *
	 *  hero      – page 0 (always)
	 *  reveal    – near-pure image (<8 words)
	 *  tom       – image + short text  (8–49 words)
	 *  bg-scroll – image + lots of text (≥50 words)
	 *  wp-text   – text only, no image (≥50 words) → WP core heading+paragraphs
	 *  table     – looks like a data table → WP core table block
	 */
	/**
	 * Converts an AI plan array into the sections format that sections_to_blocks() consumes.
	 *
	 * @param array[]  $plan        Output of ST_AI_Planner::plan()
	 * @param string[] $page_urls   Image URL per PDF page.
	 * @param string[] $page_texts  Extracted text per PDF page.
	 * @return array[]              Sections array.
	 */
	private function build_sections_from_ai_plan( array $plan, array $page_urls, array $page_texts ): array {
		// Map AI block names → internal _type values
		$type_map = [
			'hero'         => 'hero',
			'reveal'       => 'reveal',
			'tom'          => 'tom',
			'bg-scroll'    => 'bg-scroll',
			'scrollmation' => 'scrollmation',
			'wp-table'     => 'table',
			'wp-text'      => 'wp-text',
			'section-text' => 'section-text',
		];

		$sections  = [];
		$hero_done = false;

		foreach ( $plan as $item ) {
			$block = $item['block'];
			$type  = $type_map[ $block ] ?? $block;

			// ── Scrollmation group (multi-page) ──────────────────────────────
			if ( 'scrollmation' === $type && ! empty( $item['pages'] ) ) {
				$imgs = [];
				foreach ( $item['pages'] as $pg ) {
					if ( ! empty( $page_urls[ $pg ] ) ) {
						$imgs[] = [ 'src' => '', 'alt' => '', 'wp_url' => $page_urls[ $pg ] ];
					}
				}
				if ( $imgs ) {
					$sections[] = [
						'heading'    => $item['heading'],
						'paragraphs' => array_values( $item['paragraphs'] ),
						'images'     => $imgs,
						'_force'     => 'scrollmation',
					];
				}
				continue;
			}

			// ── Single-page items ─────────────────────────────────────────────
			$page_idx = max( 0, $item['page'] );
			$img      = ( $item['use_image'] && ! empty( $page_urls[ $page_idx ] ) )
				? $page_urls[ $page_idx ] : '';

			// First hero item initialises RTL detection from page text
			if ( 'hero' === $type && ! $hero_done ) {
				$hero_done    = true;
				$first_text   = implode( ' ', array_slice( $page_texts, 0, 3 ) );
				$this->is_rtl = (bool) preg_match( '/[\x{0590}-\x{05FF}\x{0600}-\x{06FF}]/u', $first_text );
			}

			$section = [
				'heading'    => $item['heading'],
				'paragraphs' => array_values( $item['paragraphs'] ),
				'images'     => $img ? [ [ 'src' => '', 'alt' => '', 'wp_url' => $img ] ] : [],
				'_type'      => $type,
			];

			// Reveal: use caption as heading
			if ( 'reveal' === $type ) {
				$section['heading'] = $item['caption'] ?: $item['heading'];
			}

			// Table: store raw page text for table parser
			if ( 'table' === $type ) {
				$section['_raw_text'] = trim( $page_texts[ $page_idx ] ?? '' );
			}

			// Single-page scrollmation → downgrade to reveal
			if ( 'scrollmation' === $type ) {
				$section['_type'] = 'reveal';
			}

			$sections[] = $section;
		}

		// Safety: ensure at least a hero at position 0 if AI omitted it
		if ( $sections && 'hero' !== ( $sections[0]['_type'] ?? '' ) ) {
			$title      = $plan[0]['heading'] ?? ( $page_texts[0] ? explode( "\n", trim( $page_texts[0] ) )[0] : '' );
			$img        = $page_urls[0] ?? '';
			array_unshift( $sections, [
				'heading'    => $title,
				'paragraphs' => [],
				'images'     => $img ? [ [ 'src' => '', 'alt' => '', 'wp_url' => $img ] ] : [],
				'_type'      => 'hero',
			] );
		}

		return $sections;
	}

	private function build_pdf_sections( array $page_urls, array $page_texts, string $override_title ): array {
		$sections = [];
		$count    = max( count( $page_urls ), count( $page_texts ) );

		for ( $i = 0; $i < $count; $i++ ) {
			$img   = $page_urls[ $i ] ?? '';
			$raw   = $this->clean_pdf_page_text( $page_texts[ $i ] ?? '' );
			$words = $this->count_words_unicode( $raw );
			$lines = array_values( array_filter( array_map( 'trim', explode( "\n", $raw ) ) ) );

			// ── Hero (page 0) ────────────────────────────────────────────────
			if ( 0 === $i ) {
				$heading  = $override_title ?: ( $lines[0] ?? __( 'Document', 'scrollytelling' ) );
				$subtitle = count( $lines ) > 1 ? implode( ' ', array_slice( $lines, 1, 3 ) ) : '';
				$sections[] = [
					'heading'    => $heading,
					'paragraphs' => $subtitle ? [ $subtitle ] : [],
					'images'     => $img ? [ [ 'src' => '', 'alt' => '', 'wp_url' => $img ] ] : [],
					'_type'      => 'hero',
				];
				continue;
			}

			// ── Table-like page ──────────────────────────────────────────────
			if ( $words >= 8 && $this->is_table_like( $raw ) ) {
				$sections[] = [
					'heading'    => $lines[0] ?? '',
					'paragraphs' => array_slice( $lines, 1 ),
					'images'     => $img ? [ [ 'src' => '', 'alt' => '', 'wp_url' => $img ] ] : [],
					'_type'      => 'table',
					'_raw_text'  => $raw,
				];
				continue;
			}

			// ── Text-heavy ≥50 words ─────────────────────────────────────────
			if ( $words >= 50 ) {
				$heading = '';
				$rest    = $raw;
				if ( $lines && mb_strlen( $lines[0] ) <= 60 ) {
					$heading = array_shift( $lines );
					$rest    = implode( "\n", $lines );
				}
				$sections[] = [
					'heading'    => $heading,
					'paragraphs' => $this->split_text_to_paragraphs( $rest, 5 ),
					'images'     => $img ? [ [ 'src' => '', 'alt' => '', 'wp_url' => $img ] ] : [],
					'_type'      => $img ? 'bg-scroll' : 'wp-text',
				];
				continue;
			}

			// ── Near-pure image <8 words → Reveal ───────────────────────────
			if ( $words < 8 ) {
				$sections[] = [
					'heading'    => $lines[0] ?? '',
					'paragraphs' => [],
					'images'     => $img ? [ [ 'src' => '', 'alt' => '', 'wp_url' => $img ] ] : [],
					'_type'      => 'reveal',
				];
				continue;
			}

			// ── Medium text 8–49 words → Text Over Media ────────────────────
			$heading = $lines[0] ?? '';
			$body    = implode( ' ', array_slice( $lines, 1 ) );
			$sections[] = [
				'heading'    => $heading,
				'paragraphs' => $body ? [ $body ] : [],
				'images'     => $img ? [ [ 'src' => '', 'alt' => '', 'wp_url' => $img ] ] : [],
				'_type'      => 'tom',
			];
		}

		return $sections;
	}

	/**
	 * Returns true when text looks like tabular data:
	 * many short lines, or lines with tab/multi-space column separators.
	 */
	private function is_table_like( string $text ): bool {
		$lines = array_values( array_filter(
			array_map( 'trim', explode( "\n", $text ) ),
			fn( $l ) => mb_strlen( $l ) > 2
		) );
		if ( count( $lines ) < 4 ) {
			return false;
		}
		$short  = array_filter( $lines, fn( $l ) => mb_strlen( $l ) < 40 );
		$tabbed = array_filter( $lines, fn( $l ) => str_contains( $l, "\t" ) || (bool) preg_match( '/\s{3,}/', $l ) );
		return ( count( $short ) / count( $lines ) > 0.55 )
			|| ( count( $tabbed ) / count( $lines ) > 0.4 );
	}

	private function clean_pdf_page_text( string $text ): string {
		$text = $this->strip_gs_artifacts( $text );
		$text = str_replace( "\f", "\n", $text );    // form-feed → newline
		$text = preg_replace( '/[ \t]+/u', ' ', $text );
		$text = preg_replace( '/\n{3,}/u', "\n\n", $text );
		// Remove lone page-number lines (e.g. "  1  " or "12")
		$text = preg_replace( '/^\s*\d{1,3}\s*$/mu', '', $text );
		return trim( $text );
	}

	private function count_words_unicode( string $text ): int {
		$text = trim( $text );
		if ( ! $text ) {
			return 0;
		}
		return count( preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY ) );
	}

	private function split_text_to_paragraphs( string $text, int $target_count ): array {
		// Try natural paragraph breaks first
		$paras = array_values( array_filter( array_map( 'trim', preg_split( '/\n{2,}/', $text ) ) ) );
		if ( count( $paras ) >= $target_count ) {
			return $paras;
		}

		// Fall back to sentence-level grouping
		$sents = preg_split( '/(?<=[.!?])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );
		if ( ! $sents || count( $sents ) <= $target_count ) {
			return $sents ?: [ trim( $text ) ];
		}

		$group_size = (int) ceil( count( $sents ) / $target_count );
		$groups     = [];
		for ( $i = 0; $i < count( $sents ); $i += $group_size ) {
			$groups[] = implode( ' ', array_slice( $sents, $i, $group_size ) );
		}
		return $groups;
	}

	/* ══════════════════════════ Sections → blocks ═══════════════════════════ */

	private function sections_to_blocks( array $sections ): string {
		if ( ! $sections ) {
			return '';
		}

		$blocks = [];

		// ── Section 0 → Hero (always) ────────────────────────────────────────
		$s0    = $sections[0];
		$img0  = $this->best_image_from( $s0 );

		// If hero has no image try stealing one from section 1
		if ( ! $img0 && isset( $sections[1] ) ) {
			$img0 = $this->best_image_from( $sections[1] );
		}

		$title    = $s0['heading'] ?: ( $s0['paragraphs'][0] ?? __( 'Untitled', 'scrollytelling' ) );
		$subtitle = '';
		if ( $s0['heading'] && $s0['paragraphs'] ) {
			$subtitle = mb_substr( $s0['paragraphs'][0], 0, 220 );
		} elseif ( count( $s0['paragraphs'] ) > 1 ) {
			$subtitle = mb_substr( $s0['paragraphs'][1], 0, 220 );
		}

		$blocks[] = $this->render_hero( [
			'mediaUrl'         => $img0,
			'mediaType'        => 'image',
			'title'            => $title,
			'subtitle'         => $subtitle,
			'byline'           => '',
			'titleColor'       => '#ffffff',
			'subtitleColor'    => '#f0f0f0',
			'bylineColor'      => '#ffffff',
			'textPosition'     => 'center',
			'textAlign'        => $this->is_rtl ? 'right' : 'start',
			'overlayColor'     => '#000000',
			'overlayOpacity'   => 45,
			'minHeight'        => '100vh',
			'isRtl'            => $this->is_rtl,
			'fixedBackground'  => false,
			'logoUrl'          => '',
			'logoPosition'     => 'before-title',
			'logoSize'         => 120,
			'zoomedBackground' => false,
			'backgroundBlur'   => 0,
		] );

		// ── Sections 1+ ───────────────────────────────────────────────────────
		$text_section_bg = [ '#ffffff', '#f6f7f8' ]; // alternate

		for ( $i = 1; $i < count( $sections ); $i++ ) {
			$s          = $sections[ $i ];
			$img        = $this->best_image_from( $s );
			$total_text = implode( ' ', $s['paragraphs'] );
			$text_len   = mb_strlen( $total_text );
			$num_imgs   = count( $s['images'] );
			$num_paras  = count( $s['paragraphs'] );
			$type       = $s['_type'] ?? '';

			// ── PDF-typed sections ────────────────────────────────────────────
			if ( 'reveal' === $type ) {
				if ( $img ) {
					$blocks[] = $this->render_reveal( [
						'mediaUrl'        => $img,
						'mediaType'       => 'image',
						'caption'         => $s['heading'],
						'height'          => 'full',
						'objectFit'       => 'cover',
						'isRtl'           => $this->is_rtl,
						'fixedBackground' => false,
					] );
				}
				continue;
			}

			if ( 'table' === $type ) {
				// Show the page as a full-height image so the table layout is visible
				if ( $img ) {
					$blocks[] = $this->render_reveal( [
						'mediaUrl'        => $img,
						'mediaType'       => 'image',
						'caption'         => '',
						'height'          => 'full',
						'objectFit'       => 'contain',
						'isRtl'           => $this->is_rtl,
						'fixedBackground' => false,
					] );
				}
				// Then render accessible table/text below
				$raw = $s['_raw_text'] ?? $total_text;
				$b   = $this->render_wp_table_text( $raw, $s['heading'] );
				if ( $b ) {
					$blocks[] = $b;
				}
				continue;
			}

			if ( 'bg-scroll' === $type ) {
				$b = $this->make_bg_scroll( $s );
				if ( $b ) {
					$blocks[] = $b;
				}
				continue;
			}

			if ( 'tom' === $type ) {
				if ( $img ) {
					$blocks[] = $this->render_tom( [
						'mediaUrl'        => $img,
						'mediaType'       => 'image',
						'title'           => $s['heading'],
						'body'            => $total_text,
						'titleColor'      => '#ffffff',
						'bodyColor'       => '#f0f0f0',
						'textPosition'    => ( $i % 2 === 0 ) ? 'middle-left' : 'middle-right',
						'textAlign'       => $this->is_rtl ? 'right' : 'start',
						'overlayColor'    => '#000000',
						'overlayOpacity'  => 45,
						'minHeight'       => '80vh',
						'textTheme'       => 'light',
						'isRtl'           => $this->is_rtl,
						'fixedBackground' => false,
					] );
				} else {
					$blocks[] = $this->render_section_text( [
						'content'         => $this->paragraphs_to_richtext( $s['paragraphs'], $s['heading'] ),
						'backgroundColor' => $text_section_bg[ $i % 2 ],
						'textColor'       => '#1a1a1a',
						'maxWidth'        => '720px',
						'paddingY'        => 60,
					] );
				}
				continue;
			}

			if ( 'wp-text' === $type ) {
				$b = $this->render_wp_text_block( $s['paragraphs'], $s['heading'] );
				if ( $b ) {
					$blocks[] = $b;
				}
				continue;
			}

			if ( 'section-text' === $type ) {
				$blocks[] = $this->render_section_text( [
					'content'         => $this->paragraphs_to_richtext( $s['paragraphs'], $s['heading'] ),
					'backgroundColor' => $text_section_bg[ $i % 2 ],
					'textColor'       => '#1a1a1a',
					'maxWidth'        => '720px',
					'paddingY'        => 80,
				] );
				continue;
			}

			// ── Legacy heuristics (Google Doc imports without _type) ──────────

			// Forced type (set by Google Doc importer)
			if ( ! empty( $s['_force'] ) ) {
				if ( 'scrollmation' === $s['_force'] ) {
					$b = $this->make_scrollmation( $s );
					if ( $b ) {
						$blocks[] = $b;
					}
				}
				continue;
			}

			// Lots of text + image → Background Scroll (sticky bg, text panels)
			if ( $img && ( $num_paras >= 3 || $text_len >= 500 ) ) {
				$b = $this->make_bg_scroll( $s );
				if ( $b ) {
					$blocks[] = $b;
					continue;
				}
			}

			// Multiple images + text → Scrollmation (image sequence)
			if ( $num_imgs >= 2 && $text_len >= 150 ) {
				$b = $this->make_scrollmation( $s );
				if ( $b ) {
					$blocks[] = $b;
					continue;
				}
			}

			// Image + short text → Text Over Media
			if ( $img && $text_len > 0 && $text_len <= 160 && $s['heading'] ) {
				$blocks[] = $this->render_tom( [
					'mediaUrl'        => $img,
					'mediaType'       => 'image',
					'title'           => $s['heading'],
					'body'            => $total_text,
					'titleColor'      => '#ffffff',
					'bodyColor'       => '#f0f0f0',
					'textPosition'    => ( $i % 2 === 0 ) ? 'middle-left' : 'middle-right',
					'textAlign'       => $this->is_rtl ? 'right' : 'start',
					'overlayColor'    => '#000000',
					'overlayOpacity'  => 40,
					'minHeight'       => '80vh',
					'textTheme'       => 'light',
					'isRtl'           => $this->is_rtl,
					'fixedBackground' => false,
				] );
				continue;
			}

			// Image + any text → Reveal + optional Section Text
			if ( $img ) {
				$blocks[] = $this->render_reveal( [
					'mediaUrl'        => $img,
					'mediaType'       => 'image',
					'caption'         => $s['heading'],
					'height'          => 'full',
					'objectFit'       => 'cover',
					'isRtl'           => $this->is_rtl,
					'fixedBackground' => false,
				] );
				if ( $s['paragraphs'] ) {
					$blocks[] = $this->render_section_text( [
						'content'         => $this->paragraphs_to_richtext( $s['paragraphs'], '' ),
						'backgroundColor' => $text_section_bg[ $i % 2 ],
						'textColor'       => '#1a1a1a',
						'maxWidth'        => '720px',
						'paddingY'        => 80,
					] );
				}
				continue;
			}

			// No image → Section Text
			if ( $s['paragraphs'] ) {
				$blocks[] = $this->render_section_text( [
					'content'         => $this->paragraphs_to_richtext( $s['paragraphs'], $s['heading'] ),
					'backgroundColor' => $text_section_bg[ $i % 2 ],
					'textColor'       => '#1a1a1a',
					'maxWidth'        => '720px',
					'paddingY'        => 80,
				] );
			}
		}

		return implode( "\n\n", array_filter( $blocks ) );
	}

	private function best_image_from( array $section ): string {
		foreach ( $section['images'] as $img ) {
			if ( ! empty( $img['wp_url'] ) ) {
				return $img['wp_url'];
			}
		}
		return '';
	}

	private function make_bg_scroll( array $s ): ?string {
		$img = $this->best_image_from( $s );
		if ( ! $s['paragraphs'] ) {
			return null;
		}

		$panels = [];
		foreach ( $s['paragraphs'] as $j => $para ) {
			$panels[] = [
				'id'       => 'panel-' . ( $j + 1 ),
				'title'    => ( 0 === $j && $s['heading'] ) ? $s['heading'] : '',
				'body'     => $para,
				'position' => '',
			];
		}

		return $this->render_background_scroll( [
			'mediaUrl'         => $img,
			'mediaId'          => 0,
			'mediaType'        => 'image',
			'mediaHeight'      => 'full',
			'focalPoint'       => [ 'x' => 0.5, 'y' => 0.5 ],
			'overlayColor'     => '#000000',
			'overlayOpacity'   => 35,
			'fixedBackground'  => false,
			'panelTitleColor'  => '#1a1a1a',
			'panelBodyColor'   => '#333333',
			'panelTextAlign'   => $this->is_rtl ? 'right' : 'left',
			'panelBgColor'     => '#ffffff',
			'panelBgOpacity'   => 95,
			'panelBorderColor' => '#cccccc',
			'panelBorderWidth' => 0,
			'gradientStyle'    => 'bottom',
			'gradientColor'    => '#000000',
			'gradientOpacity'  => 50,
			'panels'           => $panels,
			'panelPosition'    => 'right',
			'panelWidth'       => 40,
			'isRtl'            => $this->is_rtl,
		] );
	}

	private function make_scrollmation( array $s ): ?string {
		$frames = [];
		foreach ( $s['images'] as $k => $img ) {
			$url = $img['wp_url'] ?? '';
			if ( ! $url ) {
				continue;
			}
			$frames[] = [
				'id'         => 'frame-' . $k,
				'url'        => $url,
				'alt'        => $img['alt'] ?? '',
				'caption'    => '',
				'focalPoint' => [ 'x' => 0.5, 'y' => 0.5 ],
			];
		}
		if ( ! $frames ) {
			return null;
		}

		$content = $this->paragraphs_to_richtext( $s['paragraphs'], $s['heading'] );
		if ( ! $content ) {
			$content = '<p>' . esc_html( $s['heading'] ?: __( 'Image sequence', 'scrollytelling' ) ) . '</p>';
		}

		return $this->render_scrollmation( [
			'frames'          => $frames,
			'content'         => $content,
			'imageSide'       => 'left',
			'textColor'       => '#1a1a1a',
			'bgColor'         => '#ffffff',
			'objectFit'       => 'cover',
			'imageBg'         => '#000000',
			'imageFullHeight' => true,
			'isRtl'           => $this->is_rtl,
			'textAlign'       => $this->is_rtl ? 'right' : 'start',
		] );
	}

	/* ══════════════════════════ RTL / title helpers ═════════════════════════ */

	private function detect_rtl_from_html( string $html ): bool {
		if ( preg_match( '/<html[^>]*\bdir="rtl"/i', $html ) ) {
			return true;
		}
		if ( preg_match( '/<html[^>]*\blang="(he|ar|fa|ur)"/i', $html ) ) {
			return true;
		}
		$snippet = mb_substr( wp_strip_all_tags( $html ), 0, 2000 );
		return (bool) preg_match( '/[\x{0590}-\x{08FF}]/u', $snippet );
	}

	private function extract_title_from_html( string $html ): string {
		if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $m ) ) {
			$t = html_entity_decode( wp_strip_all_tags( $m[1] ), ENT_QUOTES, 'UTF-8' );
			$t = preg_replace( '/\s*[-–]\s*Google Docs\s*$/i', '', trim( $t ) );
			return $t;
		}
		return '';
	}

	/* ═══════════════════════ Shared HTML helpers ════════════════════════════ */

	private function block_props( string $block_slug, string $extra_class, array $attrs = [] ): string {
		$class = 'wp-block-scrollytelling-' . $block_slug;
		if ( $extra_class ) {
			$class .= ' ' . $extra_class;
		}
		$out = ' class="' . esc_attr( $class ) . '"';
		foreach ( $attrs as $name => $value ) {
			if ( null === $value || false === $value || '' === $value ) {
				continue;
			}
			$out .= ' ' . $name . '="' . esc_attr( (string) $value ) . '"';
		}
		return $out;
	}

	private function style_attr( array $pairs ): string {
		$parts = [];
		foreach ( $pairs as $prop => $value ) {
			if ( null === $value || '' === $value ) {
				continue;
			}
			$parts[] = $prop . ':' . $value;
		}
		return $parts ? ' style="' . esc_attr( implode( ';', $parts ) ) . '"' : '';
	}

	private function hex_to_rgb( string $hex ): string {
		if ( ! $hex || strlen( $hex ) < 7 ) {
			return '0, 0, 0';
		}
		return sprintf( '%d, %d, %d', hexdec( substr( $hex, 1, 2 ) ), hexdec( substr( $hex, 3, 2 ) ), hexdec( substr( $hex, 5, 2 ) ) );
	}

	private function open_comment( string $name, array $attributes ): string {
		return '<!-- wp:' . $name . ' ' . wp_json_encode( $attributes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ' -->';
	}

	private function close_comment( string $name ): string {
		return '<!-- /wp:' . $name . ' -->';
	}

	private function position_class( string $key ): string {
		$map = [
			'top-left'      => 'st-pos--top-left',    'top-center'    => 'st-pos--top-center',
			'top-right'     => 'st-pos--top-right',   'middle-left'   => 'st-pos--middle-left',
			'middle-center' => 'st-pos--middle-center','center'        => 'st-pos--center',
			'middle-right'  => 'st-pos--middle-right', 'bottom-left'   => 'st-pos--bottom-left',
			'bottom-center' => 'st-pos--bottom-center','bottom-right'  => 'st-pos--bottom-right',
		];
		return $map[ $key ] ?? 'st-pos--center';
	}

	private function paragraphs_to_richtext( array $paragraphs, string $heading = '' ): string {
		$html = '';
		if ( $heading ) {
			$html .= '<h2>' . esc_html( $heading ) . '</h2>';
		}
		foreach ( $paragraphs as $p ) {
			$html .= '<p>' . esc_html( $p ) . '</p>';
		}
		return $html;
	}

	/* ══════════════════════════ Block renderers ═════════════════════════════ */
	/* Must byte-match the corresponding block's save.js output.              */

	private function render_hero( array $a ): string {
		$pos_class   = $this->position_class( $a['textPosition'] );
		$align_class = $a['textAlign'] ? 'st-align--' . $a['textAlign'] : '';
		$class       = trim( "st-hero $pos_class $align_class" );

		$html  = '<section' . $this->block_props( 'hero', $class, [
			'data-blur' => $a['backgroundBlur'] > 0 ? $a['backgroundBlur'] : null,
			'dir'       => $a['isRtl'] ? 'rtl' : null,
		] );
		$html .= $this->style_attr( [ '--st-min-height' => $a['minHeight'] ] );
		$html .= '>';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-hero__bg st-lazy-video" data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none" aria-hidden="true"></video>';
		} elseif ( $a['mediaUrl'] ) {
			$html .= '<img class="st-hero__bg" src="' . esc_url( $a['mediaUrl'] ) . '" alt="" aria-hidden="true"/>';
		}

		$html .= '<div class="st-hero__overlay"' . $this->style_attr( [
			'--st-overlay-color' => $a['overlayColor'],
			'background'         => 'rgba(' . $this->hex_to_rgb( $a['overlayColor'] ) . ', ' . ( $a['overlayOpacity'] / 100 ) . ')',
		] ) . ' aria-hidden="true"></div>';

		$html .= '<div class="st-hero__content">';
		if ( $a['title'] ) {
			$html .= '<h1 class="st-hero__title"' . $this->style_attr( [ 'color' => $a['titleColor'] ] ) . '>' . esc_html( $a['title'] ) . '</h1>';
		}
		if ( $a['subtitle'] ) {
			$html .= '<p class="st-hero__subtitle"' . $this->style_attr( [ 'color' => $a['subtitleColor'] ] ) . '>' . esc_html( $a['subtitle'] ) . '</p>';
		}
		if ( $a['byline'] ) {
			$html .= '<p class="st-hero__byline"' . $this->style_attr( [ 'color' => $a['bylineColor'] ] ) . '>' . esc_html( $a['byline'] ) . '</p>';
		}
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/hero', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/hero' );
	}

	private function render_background_scroll( array $a ): string {
		$height_map = [ 'full' => 100, 'half' => 50, 'small' => 30 ];
		$height_vh  = $height_map[ $a['mediaHeight'] ] ?? 100;

		$class = 'st-bg-scroll st-panel-pos--' . $a['panelPosition'];
		$html  = '<section' . $this->block_props( 'background-scroll', $class, [
			'data-panel-position'    => $a['panelPosition'],
			'data-panel-bg-color'    => $a['panelBgColor'],
			'data-panel-bg-opacity'  => $a['panelBgOpacity'],
			'data-panel-border-color'=> $a['panelBorderColor'],
			'data-panel-border-width'=> $a['panelBorderWidth'],
			'data-media-height'      => $height_vh,
			'dir'                    => $a['isRtl'] ? 'rtl' : null,
		] ) . '>';

		$fpos      = $a['focalPoint'] ?? [ 'x' => 0.5, 'y' => 0.5 ];
		$focal_pos = round( $fpos['x'] * 100 ) . '% ' . round( $fpos['y'] * 100 ) . '%';

		$html .= '<div class="st-bg-scroll__sticky" aria-hidden="true">';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-bg-scroll__media st-lazy-video' . ( $a['fixedBackground'] ? ' st-video-fixed' : '' ) . '"'
				. ' data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none"'
				. $this->style_attr( [ 'object-position' => $focal_pos ] ) . '></video>';
		} elseif ( $a['mediaUrl'] ) {
			if ( $a['fixedBackground'] ) {
				$html .= '<div class="st-bg-scroll__media st-bg-fixed"'
					. $this->style_attr( [ 'background-image' => 'url(' . $a['mediaUrl'] . ')', 'background-position' => $focal_pos ] )
					. '></div>';
			} else {
				$html .= '<img class="st-bg-scroll__media" src="' . esc_url( $a['mediaUrl'] ) . '" alt=""'
					. $this->style_attr( [ 'object-position' => $focal_pos ] ) . '/>';
			}
		}

		$html .= '<div class="st-bg-scroll__overlay"'
			. $this->style_attr( [ 'background' => 'rgba(' . $this->hex_to_rgb( $a['overlayColor'] ) . ', ' . ( $a['overlayOpacity'] / 100 ) . ')' ] )
			. ' aria-hidden="true"></div>';

		if ( ! empty( $a['gradientStyle'] ) && 'none' !== $a['gradientStyle'] ) {
			$col = 'rgba(' . $this->hex_to_rgb( $a['gradientColor'] ) . ', ' . ( $a['gradientOpacity'] / 100 ) . ')';
			$grad_map = [
				'bottom' => "linear-gradient(to top, $col 0%, transparent 65%)",
				'top'    => "linear-gradient(to bottom, $col 0%, transparent 65%)",
				'left'   => "linear-gradient(to right, $col 0%, transparent 65%)",
				'right'  => "linear-gradient(to left, $col 0%, transparent 65%)",
			];
			$gradient = $grad_map[ $a['gradientStyle'] ] ?? null;
			if ( $gradient ) {
				$html .= '<div class="st-bg-scroll__gradient"'
					. $this->style_attr( [ 'background' => $gradient ] )
					. ' aria-hidden="true"></div>';
			}
		}

		$html .= '</div>'; // .st-bg-scroll__sticky

		$html .= '<div class="st-bg-scroll__panels">';
		foreach ( $a['panels'] as $j => $panel ) {
			$html .= '<div class="st-bg-scroll__panel"'
				. $this->style_attr( [ '--panel-width' => $a['panelWidth'] . '%' ] )
				. ' data-panel-index="' . (int) $j . '" data-panel-pos="' . esc_attr( $panel['position'] ?? '' ) . '">';
			$html .= '<div class="st-bg-scroll__panel-inner"'
				. ( $a['panelTextAlign'] ? $this->style_attr( [ 'text-align' => $a['panelTextAlign'] ] ) : '' ) . '>';
			if ( ! empty( $panel['title'] ) ) {
				$html .= '<h2 class="st-bg-scroll__panel-title"'
					. ( $a['panelTitleColor'] ? $this->style_attr( [ 'color' => $a['panelTitleColor'] ] ) : '' ) . '>'
					. esc_html( $panel['title'] ) . '</h2>';
			}
			if ( ! empty( $panel['body'] ) ) {
				$html .= '<p class="st-bg-scroll__panel-body"'
					. ( $a['panelBodyColor'] ? $this->style_attr( [ 'color' => $a['panelBodyColor'] ] ) : '' ) . '>'
					. esc_html( $panel['body'] ) . '</p>';
			}
			$html .= '</div></div>';
		}
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/background-scroll', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/background-scroll' );
	}

	private function render_scrollmation( array $a ): string {
		$classes = array_filter( [
			'st-scrollmation',
			'st-scrollmation--img-' . $a['imageSide'],
			! $a['imageFullHeight'] ? 'st-scrollmation--natural' : '',
		] );
		$class = implode( ' ', $classes );

		$html  = '<section' . $this->block_props( 'scrollmation', $class );
		$html .= $this->style_attr( [ 'background' => $a['bgColor'] ] );
		$html .= '>';

		$html .= '<div class="st-scrollmation__text-col"' . ( $a['isRtl'] ? ' dir="rtl"' : '' ) . '>';
		$html .= '<div class="st-scrollmation__text-inner">';
		$text_style = [];
		if ( $a['textColor'] ) {
			$text_style['color'] = $a['textColor'];
		}
		if ( $a['textAlign'] && 'start' !== $a['textAlign'] ) {
			$text_style['text-align'] = $a['textAlign'];
		}
		$html .= '<div class="st-scrollmation__text-content"' . $this->style_attr( $text_style ) . '>' . $a['content'] . '</div>';
		$html .= '</div></div>';

		$media_col_bg = $a['imageFullHeight'] ? $a['imageBg'] : $a['bgColor'];
		$html .= '<div class="st-scrollmation__media-col"' . $this->style_attr( [ 'background' => $media_col_bg ] ) . ' aria-hidden="true">';
		$html .= '<div class="st-scrollmation__stage">';
		foreach ( $a['frames'] as $idx => $frame ) {
			$focal    = $frame['focalPoint'] ?? [ 'x' => 0.5, 'y' => 0.5 ];
			$fpos_str = round( $focal['x'] * 100 ) . '% ' . round( $focal['y'] * 100 ) . '%';
			$html    .= '<img class="st-scrollmation__frame" src="' . esc_url( $frame['url'] ) . '" alt="' . esc_attr( $frame['alt'] ?? '' ) . '"'
				. ' data-frame="' . (int) $idx . '" data-caption="' . esc_attr( $frame['caption'] ?? '' ) . '" data-fit="' . esc_attr( $a['objectFit'] ) . '"'
				. $this->style_attr( [ 'object-position' => $fpos_str ] )
				. ( 0 !== $idx ? ' aria-hidden="true"' : '' )
				. '/>';
		}
		$html .= '</div><p class="st-scrollmation__caption"></p></div>';
		$html .= '</section>';

		return $this->open_comment( 'scrollytelling/scrollmation', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/scrollmation' );
	}

	private function render_tom( array $a ): string {
		$pos_class   = $this->position_class( $a['textPosition'] );
		$align_class = $a['textAlign'] ? 'st-align--' . $a['textAlign'] : '';
		$theme_class = $a['textTheme'] ? 'st-tom--' . $a['textTheme'] : '';
		$class       = trim( preg_replace( '/\s+/', ' ', "st-tom $pos_class $align_class $theme_class" ) );

		$html  = '<section' . $this->block_props( 'text-over-media', $class, [ 'dir' => $a['isRtl'] ? 'rtl' : null ] );
		$html .= $this->style_attr( [ '--st-min-height' => $a['minHeight'] ] );
		$html .= '>';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-tom__bg st-lazy-video' . ( $a['fixedBackground'] ? ' st-video-fixed' : '' ) . '" data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none" aria-hidden="true"></video>';
		} elseif ( $a['mediaUrl'] ) {
			if ( $a['fixedBackground'] ) {
				$html .= '<div class="st-tom__bg st-bg-fixed"' . $this->style_attr( [ 'background-image' => 'url(' . $a['mediaUrl'] . ')' ] ) . ' aria-hidden="true"></div>';
			} else {
				$html .= '<img class="st-tom__bg" src="' . esc_url( $a['mediaUrl'] ) . '" alt="" aria-hidden="true"/>';
			}
		}

		$html .= '<div class="st-tom__overlay"' . $this->style_attr( [
			'background' => 'rgba(' . $this->hex_to_rgb( $a['overlayColor'] ) . ', ' . ( $a['overlayOpacity'] / 100 ) . ')',
		] ) . ' aria-hidden="true"></div>';

		$html .= '<div class="st-tom__content">';
		if ( $a['title'] ) {
			$html .= '<h2 class="st-tom__title"' . $this->style_attr( [ 'color' => $a['titleColor'] ] ) . '>' . esc_html( $a['title'] ) . '</h2>';
		}
		if ( $a['body'] ) {
			$html .= '<p class="st-tom__body"' . $this->style_attr( [ 'color' => $a['bodyColor'] ] ) . '>' . esc_html( $a['body'] ) . '</p>';
		}
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/text-over-media', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/text-over-media' );
	}

	private function render_reveal( array $a ): string {
		$class = 'st-reveal st-reveal--' . $a['height'];
		$html  = '<div' . $this->block_props( 'reveal', $class, [ 'dir' => $a['isRtl'] ? 'rtl' : null ] );
		$html .= $this->style_attr( [ '--st-object-fit' => $a['objectFit'] ] );
		$html .= '>';

		if ( $a['mediaUrl'] && 'video' === $a['mediaType'] ) {
			$html .= '<video class="st-reveal__media st-lazy-video' . ( $a['fixedBackground'] ? ' st-video-fixed' : '' ) . '"'
				. ' data-src="' . esc_url( $a['mediaUrl'] ) . '" muted loop playsinline preload="none"'
				. $this->style_attr( [ 'object-fit' => $a['objectFit'] ] ) . ' aria-hidden="true"></video>';
		} elseif ( $a['mediaUrl'] ) {
			if ( $a['fixedBackground'] ) {
				$html .= '<div class="st-reveal__media st-bg-fixed"' . $this->style_attr( [ 'background-image' => 'url(' . $a['mediaUrl'] . ')' ] ) . ' aria-hidden="true"></div>';
			} else {
				$html .= '<img class="st-reveal__media" src="' . esc_url( $a['mediaUrl'] ) . '" alt=""' . $this->style_attr( [ 'object-fit' => $a['objectFit'] ] ) . ' aria-hidden="true"/>';
			}
		}
		if ( $a['caption'] ) {
			$html .= '<p class="st-reveal__caption">' . esc_html( $a['caption'] ) . '</p>';
		}
		$html .= '</div>';

		return $this->open_comment( 'scrollytelling/reveal', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/reveal' );
	}

	/**
	 * Renders native WP heading + paragraph blocks for text-only sections.
	 */
	private function render_wp_text_block( array $paragraphs, string $heading = '' ): string {
		$out = [];
		if ( $heading ) {
			$out[] = '<!-- wp:heading {"level":2} -->'
				. '<h2 class="wp-block-heading">' . esc_html( $heading ) . '</h2>'
				. '<!-- /wp:heading -->';
		}
		foreach ( $paragraphs as $para ) {
			$para = trim( $para );
			if ( $para ) {
				$out[] = '<!-- wp:paragraph -->'
					. '<p>' . esc_html( $para ) . '</p>'
					. '<!-- /wp:paragraph -->';
			}
		}
		return implode( "\n", $out );
	}

	/**
	 * Attempts to render raw text as a WP table block.
	 * Falls back to heading + paragraphs when fewer than 2 columns are detected.
	 */
	private function render_wp_table_text( string $raw_text, string $heading = '' ): string {
		$lines = array_values( array_filter(
			array_map( 'trim', explode( "\n", $raw_text ) ),
			fn( $l ) => mb_strlen( $l ) > 1
		) );

		if ( ! $lines ) {
			return '';
		}

		// Split each line into cells by tabs or 3+ consecutive spaces.
		$rows = [];
		foreach ( $lines as $line ) {
			$cells = preg_split( '/\t+|\s{3,}/', $line );
			$cells = array_values( array_filter( array_map( 'trim', $cells ) ) );
			if ( $cells ) {
				$rows[] = $cells;
			}
		}

		$max_cols = $rows ? max( array_map( 'count', $rows ) ) : 0;
		if ( $max_cols < 2 ) {
			return $this->render_wp_text_block( $lines, $heading );
		}

		// Pad rows to uniform column count.
		foreach ( $rows as &$row ) {
			while ( count( $row ) < $max_cols ) {
				$row[] = '';
			}
		}
		unset( $row );

		$header_row = array_shift( $rows );

		$thead = '<thead><tr>'
			. implode( '', array_map( fn( $c ) => '<th>' . esc_html( $c ) . '</th>', $header_row ) )
			. '</tr></thead>';

		$tbody_rows = array_map(
			fn( $r ) => '<tr>' . implode( '', array_map( fn( $c ) => '<td>' . esc_html( $c ) . '</td>', $r ) ) . '</tr>',
			$rows
		);
		$tbody = '<tbody>' . implode( '', $tbody_rows ) . '</tbody>';

		$out = '';
		if ( $heading ) {
			$out .= '<!-- wp:heading {"level":2} -->'
				. '<h2 class="wp-block-heading">' . esc_html( $heading ) . '</h2>'
				. '<!-- /wp:heading -->' . "\n";
		}
		$out .= '<!-- wp:table {"className":"is-style-stripes"} -->'
			. '<figure class="wp-block-table is-style-stripes">'
			. '<table dir="rtl">' . $thead . $tbody . '</table>'
			. '</figure>'
			. '<!-- /wp:table -->';

		return $out;
	}

	private function render_section_text( array $a ): string {
		$html  = '<section' . $this->block_props( 'section-text', 'st-section-text' );
		$html .= $this->style_attr( [ 'background' => $a['backgroundColor'], 'padding' => $a['paddingY'] . 'px 20px' ] );
		$html .= '>';
		$html .= '<div' . $this->style_attr( [ 'max-width' => $a['maxWidth'], 'margin' => '0 auto' ] ) . '>';
		$html .= '<div class="st-section-text__content"' . $this->style_attr( [ 'color' => $a['textColor'] ] ) . '>' . $a['content'] . '</div>';
		$html .= '</div></section>';

		return $this->open_comment( 'scrollytelling/section-text', $a ) . "\n" . $html . "\n" . $this->close_comment( 'scrollytelling/section-text' );
	}
}
