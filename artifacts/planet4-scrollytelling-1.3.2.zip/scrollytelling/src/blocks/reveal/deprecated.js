import { useBlockProps } from '@wordpress/block-editor';

/* Shared attribute schema for old single-image format (V1 and V2). */
export const oldAttributes = {
	mediaUrl:        { type: 'string',  default: '' },
	mediaId:         { type: 'number' },
	mediaType:       { type: 'string',  default: 'image' },
	caption:         { type: 'string',  default: '' },
	height:          { type: 'string',  default: 'full' },
	objectFit:       { type: 'string',  default: 'cover' },
	isRtl:           { type: 'boolean', default: false },
	fixedBackground: { type: 'boolean', default: false },
};

/* Migrate V1/V2 single-image block to the new multi-frame format. */
export function migrateToV3( { mediaUrl, mediaId, mediaType, caption, objectFit, isRtl } ) {
	return {
		frames: mediaUrl ? [ {
			id: 'frame-0',
			url:       mediaUrl,
			mediaId:   mediaId,
			mediaType: mediaType || 'image',
			alt:       '',
			text:      caption || '',
		} ] : [],
		transition:      'fade',
		transitionSpeed: 'medium',
		objectFit:       objectFit || 'cover',
		isRtl:           !! isRtl,
		textCardBg:      '#000000',
		textCardOpacity: 70,
		textCardColor:   '#ffffff',
	};
}

/* V2 — lazy-loaded video (data-src / st-lazy-video). Current save before this refactor. */
export function SaveV2( { attributes } ) {
	const { mediaUrl, mediaType, caption, height, objectFit, isRtl, fixedBackground } = attributes;
	const blockProps = useBlockProps.save( {
		className: `st-reveal st-reveal--${ height }`,
		dir: isRtl ? 'rtl' : undefined,
		style: { '--st-object-fit': objectFit },
	} );
	return (
		<div { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video
					className={ `st-reveal__media st-lazy-video${ fixedBackground ? ' st-video-fixed' : '' }` }
					data-src={ mediaUrl } muted loop playsInline preload="none"
					style={ { objectFit } } aria-hidden="true"
				/>
			) : mediaUrl ? (
				fixedBackground ? (
					<div className="st-reveal__media st-bg-fixed"
						style={ { backgroundImage: `url(${ mediaUrl })` } }
						aria-hidden="true" />
				) : (
					<img className="st-reveal__media" src={ mediaUrl } alt=""
						style={ { objectFit } } aria-hidden="true" />
				)
			) : null }
			{ caption && <p className="st-reveal__caption">{ caption }</p> }
		</div>
	);
}

/* V1 — original autoplay video (src + autoplay, no lazy-loading). */
export function SaveV1( { attributes } ) {
	const { mediaUrl, mediaType, caption, height, objectFit, isRtl, fixedBackground } = attributes;
	const blockProps = useBlockProps.save( {
		className: `st-reveal st-reveal--${ height }`,
		dir: isRtl ? 'rtl' : undefined,
		style: { '--st-object-fit': objectFit },
	} );
	return (
		<div { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video
					className={ `st-reveal__media${ fixedBackground ? ' st-video-fixed' : '' }` }
					src={ mediaUrl } autoPlay muted loop playsInline
					style={ { objectFit } } aria-hidden="true"
				/>
			) : mediaUrl ? (
				fixedBackground ? (
					<div className="st-reveal__media st-bg-fixed"
						style={ { backgroundImage: `url(${ mediaUrl })` } }
						aria-hidden="true" />
				) : (
					<img className="st-reveal__media" src={ mediaUrl } alt=""
						style={ { objectFit } } aria-hidden="true" />
				)
			) : null }
			{ caption && <p className="st-reveal__caption">{ caption }</p> }
		</div>
	);
}
