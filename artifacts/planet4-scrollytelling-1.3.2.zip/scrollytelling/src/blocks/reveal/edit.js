import { __, sprintf } from '@wordpress/i18n';
import { InspectorControls, MediaUpload, MediaUploadCheck, useBlockProps } from '@wordpress/block-editor';
import {
	Button, PanelBody, SelectControl, RangeControl,
	ToggleControl, TextareaControl, TextControl,
} from '@wordpress/components';
import { useState } from '@wordpress/element';

const TRANSITION_OPTIONS = [
	{ label: __( 'Fade', 'scrollytelling' ),         value: 'fade' },
	{ label: __( 'Wipe up', 'scrollytelling' ),      value: 'wipe-up' },
	{ label: __( 'Wipe down', 'scrollytelling' ),    value: 'wipe-down' },
	{ label: __( 'Wipe left', 'scrollytelling' ),    value: 'wipe-left' },
	{ label: __( 'Wipe right', 'scrollytelling' ),   value: 'wipe-right' },
	{ label: __( 'None (instant)', 'scrollytelling' ), value: 'none' },
];

const SPEED_OPTIONS = [
	{ label: __( 'Slow', 'scrollytelling' ),   value: 'slow' },
	{ label: __( 'Medium', 'scrollytelling' ), value: 'medium' },
	{ label: __( 'Fast', 'scrollytelling' ),   value: 'fast' },
];

let _uid = 0;
const genId = () => 'frame-' + ( ++_uid ) + '-' + Math.random().toString( 36 ).slice( 2, 6 );

export default function Edit( { attributes, setAttributes } ) {
	const {
		frames, transition, transitionSpeed,
		objectFit, isRtl,
		textCardBg, textCardOpacity, textCardColor,
	} = attributes;

	const [ activeIdx, setActiveIdx ] = useState( 0 );
	const blockProps = useBlockProps( { className: 'st-reveal-editor' } );

	const frame = frames[ activeIdx ] ?? null;

	const updateFrame = ( idx, updates ) =>
		setAttributes( { frames: frames.map( ( f, i ) => ( i === idx ? { ...f, ...updates } : f ) ) } );

	const addFrame = () => {
		const next = [ ...frames, { id: genId(), url: '', mediaId: undefined, mediaType: 'image', alt: '', text: '' } ];
		setAttributes( { frames: next } );
		setActiveIdx( next.length - 1 );
	};

	const removeFrame = ( idx ) => {
		setAttributes( { frames: frames.filter( ( _, i ) => i !== idx ) } );
		setActiveIdx( Math.max( 0, idx - 1 ) );
	};

	/* hex + opacity → CSS rgba preview (editor only, not saved) */
	const cardBgPreview = ( () => {
		if ( ! textCardBg || textCardBg.length < 7 ) return `rgba(0,0,0,${ textCardOpacity / 100 })`;
		const r = parseInt( textCardBg.slice( 1, 3 ), 16 );
		const g = parseInt( textCardBg.slice( 3, 5 ), 16 );
		const b = parseInt( textCardBg.slice( 5, 7 ), 16 );
		return `rgba(${ r },${ g },${ b },${ textCardOpacity / 100 })`;
	} )();

	return (
		<>
			<InspectorControls>

				{ /* ── Transition ── */ }
				<PanelBody title={ __( 'Transition', 'scrollytelling' ) } initialOpen>
					<SelectControl
						label={ __( 'Effect', 'scrollytelling' ) }
						value={ transition }
						options={ TRANSITION_OPTIONS }
						onChange={ ( v ) => setAttributes( { transition: v } ) }
					/>
					<SelectControl
						label={ __( 'Speed', 'scrollytelling' ) }
						value={ transitionSpeed }
						options={ SPEED_OPTIONS }
						onChange={ ( v ) => setAttributes( { transitionSpeed: v } ) }
					/>
				</PanelBody>

				{ /* ── Per-frame settings ── */ }
				{ frame && (
					<PanelBody
						title={ sprintf(
							/* translators: 1: current frame, 2: total frames */
							__( 'Frame %1$d of %2$d', 'scrollytelling' ),
							activeIdx + 1,
							frames.length
						) }
						initialOpen
					>
						<MediaUploadCheck>
							<MediaUpload
								onSelect={ ( m ) => updateFrame( activeIdx, {
									url: m.url,
									mediaId: m.id,
									mediaType: m.type === 'video' ? 'video' : 'image',
								} ) }
								allowedTypes={ [ 'image', 'video' ] }
								value={ frame.mediaId }
								render={ ( { open } ) => (
									<Button
										variant="secondary"
										onClick={ open }
										style={ { width: '100%', marginBottom: '8px' } }
									>
										{ frame.url
											? __( 'Replace media', 'scrollytelling' )
											: __( 'Upload / Select media', 'scrollytelling' ) }
									</Button>
								) }
							/>
						</MediaUploadCheck>
						{ frame.url && (
							<Button
								isDestructive variant="link"
								onClick={ () => updateFrame( activeIdx, { url: '', mediaId: undefined } ) }
								style={ { marginBottom: '12px' } }
							>
								{ __( 'Remove media', 'scrollytelling' ) }
							</Button>
						) }
						<TextControl
							label={ __( 'Alt text', 'scrollytelling' ) }
							value={ frame.alt || '' }
							onChange={ ( v ) => updateFrame( activeIdx, { alt: v } ) }
						/>
						<TextareaControl
							label={ __( 'Text card (optional)', 'scrollytelling' ) }
							value={ frame.text || '' }
							onChange={ ( v ) => updateFrame( activeIdx, { text: v } ) }
							rows={ 4 }
							help={ __( 'Overlaid on the image while this frame is visible. Basic HTML supported.', 'scrollytelling' ) }
						/>
					</PanelBody>
				) }

				{ /* ── Text card style ── */ }
				<PanelBody title={ __( 'Text Card Style', 'scrollytelling' ) } initialOpen={ false }>
					<div style={ { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' } }>
						<span style={ { flex: 1, fontWeight: 500, fontSize: '12px' } }>
							{ __( 'Card background', 'scrollytelling' ) }
						</span>
						<input
							type="color"
							value={ textCardBg }
							onChange={ ( e ) => setAttributes( { textCardBg: e.target.value } ) }
						/>
					</div>
					<RangeControl
						label={ __( 'Card opacity (%)', 'scrollytelling' ) }
						value={ textCardOpacity }
						onChange={ ( v ) => setAttributes( { textCardOpacity: v } ) }
						min={ 0 } max={ 100 }
					/>
					<div style={ { display: 'flex', alignItems: 'center', gap: '8px', marginTop: '10px' } }>
						<span style={ { flex: 1, fontWeight: 500, fontSize: '12px' } }>
							{ __( 'Text color', 'scrollytelling' ) }
						</span>
						<input
							type="color"
							value={ textCardColor }
							onChange={ ( e ) => setAttributes( { textCardColor: e.target.value } ) }
						/>
					</div>
				</PanelBody>

				{ /* ── Layout ── */ }
				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<SelectControl
						label={ __( 'Image fit', 'scrollytelling' ) }
						value={ objectFit }
						options={ [
							{ label: __( 'Cover (fill & crop)', 'scrollytelling' ), value: 'cover' },
							{ label: __( 'Contain (show all)', 'scrollytelling' ),  value: 'contain' },
						] }
						onChange={ ( v ) => setAttributes( { objectFit: v } ) }
					/>
					<ToggleControl
						label={ __( 'Right-to-left (RTL)', 'scrollytelling' ) }
						checked={ isRtl }
						onChange={ ( v ) => setAttributes( { isRtl: v } ) }
					/>
				</PanelBody>

			</InspectorControls>

			<div { ...blockProps }>
				{ /* ── Main preview ── */ }
				<div style={ {
					position: 'relative',
					background: '#111',
					minHeight: '50vh',
					overflow: 'hidden',
				} }>
					{ frame && frame.url ? (
						frame.mediaType === 'video' ? (
							<video
								src={ frame.url } autoPlay muted loop playsInline
								style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit } }
							/>
						) : (
							<img
								src={ frame.url } alt={ frame.alt || '' }
								style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit } }
							/>
						)
					) : (
						<div style={ {
							position: 'absolute', inset: 0,
							display: 'flex', alignItems: 'center', justifyContent: 'center',
							color: '#555', fontSize: '14px', padding: '20px', textAlign: 'center',
						} }>
							{ frames.length === 0
								? __( 'Add frames using the sidebar to build a Reveal section.', 'scrollytelling' )
								: __( 'Select media for this frame in the sidebar.', 'scrollytelling' ) }
						</div>
					) }

					{ /* Status badge */ }
					<div style={ {
						position: 'absolute', top: 12, left: 12,
						background: 'rgba(0,0,0,0.6)', color: '#fff',
						borderRadius: '4px', padding: '4px 10px', fontSize: '11px',
						letterSpacing: '0.05em', zIndex: 5,
					} }>
						{ sprintf(
							/* translators: 1: current frame, 2: total, 3: transition */
							__( 'REVEAL — Frame %1$d / %2$d · %3$s', 'scrollytelling' ),
							activeIdx + 1,
							Math.max( frames.length, 1 ),
							transition
						) }
					</div>

					{ /* Text card preview */ }
					{ frame && frame.text && (
						<div style={ {
							position: 'absolute', bottom: '12%',
							left: '50%', transform: 'translateX(-50%)',
							maxWidth: '680px', width: '90%',
							padding: '1.5em 2em',
							backgroundColor: cardBgPreview,
							color: textCardColor,
							zIndex: 4,
							/* eslint-disable-next-line react/no-danger */
						} } dangerouslySetInnerHTML={ { __html: frame.text } } />
					) }
				</div>

				{ /* ── Frame strip ── */ }
				<div style={ {
					display: 'flex', gap: '6px', padding: '10px',
					background: '#1e1e1e', flexWrap: 'wrap', alignItems: 'center',
				} }>
					{ frames.map( ( f, i ) => (
						<div key={ f.id || i } style={ { position: 'relative' } }>
							<button
								onClick={ () => setActiveIdx( i ) }
								style={ {
									width: '60px', height: '40px', cursor: 'pointer', padding: 0,
									border: i === activeIdx ? '2px solid #00a0d2' : '2px solid transparent',
									background: '#333', overflow: 'hidden', borderRadius: '2px',
									display: 'flex', alignItems: 'center', justifyContent: 'center',
								} }
								title={ sprintf( __( 'Frame %d', 'scrollytelling' ), i + 1 ) }
							>
								{ f.url ? (
									<img
										src={ f.url } alt=""
										style={ { width: '100%', height: '100%', objectFit: 'cover', display: 'block' } }
									/>
								) : (
									<span style={ { color: '#555', fontSize: '10px' } }>
										{ __( 'Empty', 'scrollytelling' ) }
									</span>
								) }
							</button>
							{ /* Remove button */ }
							<button
								onClick={ () => removeFrame( i ) }
								style={ {
									position: 'absolute', top: '-6px', right: '-6px',
									background: '#cc1818', color: '#fff', border: 'none',
									borderRadius: '50%', width: '16px', height: '16px',
									fontSize: '11px', cursor: 'pointer', padding: 0,
									lineHeight: '16px', textAlign: 'center',
								} }
								title={ __( 'Remove frame', 'scrollytelling' ) }
							>×</button>
						</div>
					) ) }
					{ /* Add frame button */ }
					<button
						onClick={ addFrame }
						style={ {
							width: '60px', height: '40px', cursor: 'pointer',
							background: '#333', border: '2px dashed #555',
							color: '#888', borderRadius: '2px', fontSize: '22px',
							display: 'flex', alignItems: 'center', justifyContent: 'center',
						} }
						title={ __( 'Add frame', 'scrollytelling' ) }
					>+</button>
				</div>
			</div>
		</>
	);
}
