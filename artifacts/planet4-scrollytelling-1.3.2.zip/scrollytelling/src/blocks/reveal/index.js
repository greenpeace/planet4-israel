import metadata from './block.json';
import Edit from './edit';
import Save from './save';
import { SaveV1, SaveV2, oldAttributes, migrateToV3 } from './deprecated';

export default {
	...metadata,
	edit: Edit,
	save: Save,
	deprecated: [
		/* V2 → V3: lazy-loaded video, single-image format → multi-frame */
		{ attributes: oldAttributes, save: SaveV2, migrate: migrateToV3 },
		/* V1 → V3: original autoplay video */
		{ attributes: oldAttributes, save: SaveV1, migrate: migrateToV3 },
	],
};
