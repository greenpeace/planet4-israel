import { useBlockProps } from '@wordpress/block-editor';
import { RawHTML } from '@wordpress/element';

const hexToRgba = ( hex, opacity ) => {
	if ( ! hex || hex.length < 7 ) return `rgba(0,0,0,${ opacity / 100 })`;
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `rgba(${ r },${ g },${ b },${ opacity / 100 })`;
};

export default function Save( { attributes } ) {
	const {
		frames, transition, transitionSpeed,
		objectFit, isRtl,
		textCardBg, textCardOpacity, textCardColor,
	} = attributes;

	const cardBg = hexToRgba( textCardBg, textCardOpacity );

	const blockProps = useBlockProps.save( {
		className: 'st-reveal',
		'data-transition': transition,
		'data-speed': transitionSpeed,
		dir: isRtl ? 'rtl' : undefined,
		style: { '--st-reveal-frames': frames.length },
	} );

	return (
		<div { ...blockProps }>
			<div className="st-reveal__sticky">
				{ frames.map( ( frame, i ) => (
					<div key={ frame.id || i } className="st-reveal__frame" data-frame={ i }>
						{ frame.mediaType === 'video' && frame.url ? (
							<video
								className="st-reveal__media st-lazy-video"
								data-src={ frame.url }
								muted loop playsInline preload="none"
								style={ { objectFit } }
								aria-hidden="true"
							/>
						) : frame.url ? (
							<img
								className="st-reveal__media"
								src={ frame.url }
								alt={ frame.alt || '' }
								style={ { objectFit } }
							/>
						) : null }
						{ frame.text && (
							<div
								className="st-reveal__card"
								style={ { backgroundColor: cardBg, color: textCardColor } }
							>
								<RawHTML>{ frame.text }</RawHTML>
							</div>
						) }
					</div>
				) ) }
			</div>
		</div>
	);
}
