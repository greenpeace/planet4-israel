/**
 * Scrollytelling frontend — v1.3
 * Features: progress bar, section nav dots, background-scroll sticky panels,
 *           scrollmation frame sequencing, reveal block, slideshow,
 *           hero zoom/blur/text-entrance, content fade-in on scroll.
 * Zero dependencies — native IntersectionObserver + scroll events only.
 */

/* ─── Utility ────────────────────────────────────────────────────── */
const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0, 0, 0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

/* Throttle a scroll handler to at most once per animation frame. Most of
   this file's scroll listeners ran unthrottled (one call per native scroll
   event), which is fine on desktop but causes visible jank and extra
   battery drain on mobile CPUs/GPUs — wrapping them all here keeps every
   scroll-driven effect to a single layout/paint per frame. */
function onScrollRAF( fn ) {
	let pending = false;
	window.addEventListener( 'scroll', () => {
		if ( pending ) return;
		pending = true;
		requestAnimationFrame( () => { fn(); pending = false; } );
	}, { passive: true } );
}

/* Most reduced-motion handling lives in style.css (transition:none on every
   fade/crossfade, !important so it wins over the inline transitions this
   file sets). This covers the two effects that have no transition to
   suppress in the first place — they're continuously recalculated, scroll-
   coupled values (hero's scroll-driven blur, fixed-video parallax) — so
   they're skipped entirely here instead. */
const prefersReducedMotion = () =>
	window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

/* ─── Lazy-loaded video ──────────────────────────────────────────── */
/**
 * Every <video> across the plugin (Hero, Background Scroll, Text Over
 * Media, Reveal, Slideshow) is saved with no `src` — the real URL sits in
 * `data-src` — and no `autoplay`, so the browser never starts downloading
 * or playing it up front.
 *
 * An IntersectionObserver defers loading until the video is near the
 * viewport (rootMargin gives it a head start before it's actually visible).
 * Once loading starts, the element naturally shows its first decoded frame
 * — paused, since there's no autoplay — until `canplaythrough` confirms
 * enough has buffered to play smoothly, at which point JS calls .play().
 * That's the "first frame until loaded" behaviour, achieved with the
 * browser's native rendering rather than a separately uploaded poster image.
 *
 * Users with prefers-reduced-motion never get the .play() call — the still
 * first frame becomes the permanent state for them.
 */
function initLazyVideos() {
	const videos = document.querySelectorAll( 'video.st-lazy-video' );
	if ( ! videos.length ) return;

	const loadVideo = ( video ) => {
		const src = video.dataset.src;
		if ( ! src || video.src ) return; // no source, or already loading/loaded

		video.addEventListener( 'canplaythrough', () => {
			if ( ! prefersReducedMotion() ) {
				video.play().catch( () => {} ); // ignore autoplay-blocked rejections
			}
		}, { once: true } );

		video.src = src;
		video.load();
	};

	const io = new IntersectionObserver(
		( entries ) => {
			entries.forEach( ( entry ) => {
				if ( ! entry.isIntersecting ) return;
				loadVideo( entry.target );
				io.unobserve( entry.target );
			} );
		},
		{ rootMargin: '200px 0px' }
	);

	videos.forEach( ( v ) => io.observe( v ) );
}

/* ─── Video Scrubbing ────────────────────────────────────────────── */
/**
 * The video's frame is driven entirely by mouse position — it is never
 * played. Lazy-loading mirrors initLazyVideos() above (defer fetching
 * until near the viewport, preload="none" until then) but never calls
 * .play(): "ready" here just means duration is known and currentTime
 * writes will work, so the video stays paused on whatever frame the
 * mouse last pointed at (or its first frame, before any movement).
 *
 * Background mode: mouse position over the full-screen fixed wrap maps to
 * a point in the video's duration. A placeholder reserves one viewport's
 * worth of scroll distance in the page flow; the wrap fades out once the
 * reader scrolls past it.
 *
 * Block mode: mouse position over the strip itself maps to the video's
 * duration — only active while hovering the element, since it's a normal,
 * bounded part of the page rather than a full-screen takeover. "Fixed
 * position" parallax is handled entirely by initFixedVideos() above via
 * the shared .st-video-fixed class — not duplicated here.
 *
 * Touch is intentionally not wired up: there's no touch equivalent of
 * "hover position" (only discrete touch-start/move events), and treating
 * touchmove as a scrub gesture would trap touch users by blocking the
 * normal page-scroll swipe over the block.
 */
function initVideoScrub() {
	const isMobile = () => window.innerWidth <= 768;

	document.querySelectorAll( '.st-video-scrub' ).forEach( ( block ) => {
		const video = block.querySelector( '.st-scrub-video' );
		if ( ! video ) return;

		const isBackground = block.classList.contains( 'st-video-scrub--background' );
		const axis    = block.dataset.scrubAxis  || 'horizontal';
		const hDir    = block.dataset.hDirection || 'right'; // which edge = end of video
		const vDir    = block.dataset.vDirection || 'down';
		const progressEl  = block.querySelector( '.st-video-scrub__progress' );
		const cursorEl    = isBackground ? block.querySelector( '.st-video-scrub__cursor' ) : null;

		/* On mobile, background mode's CSS collapses to a normal in-flow
		   strip (see style.css) — scrub against that strip the same way
		   block mode does, not the (now visually inert) fixed wrap. */
		const scrubTarget = isBackground
			? ( block.querySelector( '.st-video-scrub__wrap' ) || block )
			: block;

		let duration = 0;
		let pending  = -1;
		let rafId    = null;

		const applyProgress = ( ratio ) => {
			if ( progressEl ) progressEl.style.width = ( ratio * 100 ) + '%';
		};

		const flush = () => {
			rafId = null;
			if ( pending < 0 || ! duration ) return;
			video.currentTime = pending;
			applyProgress( pending / duration );
			pending = -1;
		};

		const seek = ( t ) => {
			pending = Math.max( 0, Math.min( duration, t ) );
			if ( ! rafId ) rafId = requestAnimationFrame( flush );
		};

		video.addEventListener( 'loadedmetadata', () => { duration = video.duration || 0; } );

		/* ── Lazy-load: defer fetching until near the viewport ───────── */
		const loadVideo = () => {
			const src = video.dataset.src;
			if ( ! src || video.src ) return;
			video.preload = 'auto';
			video.src = src;
			video.load();
		};

		const io = new IntersectionObserver(
			( entries ) => {
				entries.forEach( ( entry ) => {
					if ( ! entry.isIntersecting ) return;
					loadVideo();
					io.unobserve( entry.target );
				} );
			},
			{ rootMargin: '200px 0px' }
		);
		io.observe( scrubTarget );

		/* ── Desktop: mouse-driven scrubbing ──────────────────────────── */
		/*
		 * hDir/vDir name which screen edge holds the END of the video
		 * (time = duration): 'right'/'down' is the default — the right or
		 * bottom edge is the end, so moving left-to-right / top-to-bottom
		 * plays forward. Flipping to 'left'/'up' inverts that edge, which
		 * is the same as inverting the computed ratio.
		 */
		const computeRatio = ( rect, x, y ) => {
			let xr = Math.max( 0, Math.min( 1, ( x - rect.left ) / rect.width ) );
			let yr = Math.max( 0, Math.min( 1, ( y - rect.top )  / rect.height ) );
			if ( hDir === 'left' ) xr = 1 - xr;
			if ( vDir === 'up' )   yr = 1 - yr;
			if ( axis === 'vertical' )   return yr;
			if ( axis === 'horizontal' ) return xr;
			return ( xr + yr ) / 2; // both/any movement
		};

		scrubTarget.addEventListener( 'mousemove', ( e ) => {
			if ( isMobile() ) return; // mobile scrubs by scrolling instead — see below
			if ( cursorEl ) {
				cursorEl.style.left = e.clientX + 'px';
				cursorEl.style.top  = e.clientY + 'px';
				cursorEl.classList.add( 'is-visible' );
			}
			if ( ! duration ) return;
			const rect = scrubTarget.getBoundingClientRect();
			seek( computeRatio( rect, e.clientX, e.clientY ) * duration );
		}, { passive: true } );

		if ( cursorEl ) {
			scrubTarget.addEventListener( 'mouseleave', () => cursorEl.classList.remove( 'is-visible' ) );
		}

		/* ── Mobile: scroll-driven scrubbing ──────────────────────────── */
		/*
		 * No mouse on touch devices, so the frame is instead driven by how
		 * far the block has scrolled through the viewport — 0 as it just
		 * enters at the bottom, 1 as it fully exits at the top. Always
		 * "scrolling down plays forward", independent of the desktop
		 * mouse-direction settings (a different input, kept simple).
		 */
		const updateScrollScrub = () => {
			if ( ! isMobile() || ! duration ) return;
			const rect  = scrubTarget.getBoundingClientRect();
			const vh    = window.innerHeight;
			const total = rect.height + vh;
			const ratio = total > 0 ? Math.max( 0, Math.min( 1, ( vh - rect.top ) / total ) ) : 0;
			seek( ratio * duration );
		};
		onScrollRAF( updateScrollScrub );
		updateScrollScrub();

		/* ── Background mode (desktop only): fixed wrap hides once
		   scrolled past. On mobile the wrap is a normal in-flow strip
		   (see style.css) so it should never be opacity-hidden — without
		   this guard, the now-display:none placeholder's rect always
		   reports bottom:0, which would otherwise hide the wrap permanently. */
		if ( isBackground ) {
			const placeholder = block.querySelector( '.st-video-scrub__placeholder' );
			const wrap         = block.querySelector( '.st-video-scrub__wrap' );
			if ( placeholder && wrap ) {
				const updateVisibility = () => {
					if ( isMobile() ) { wrap.classList.remove( 'is-hidden' ); return; }
					wrap.classList.toggle( 'is-hidden', placeholder.getBoundingClientRect().bottom <= 0 );
				};
				onScrollRAF( updateVisibility );
				updateVisibility();
			}
		}
	} );
}

/* ─── Custom CSS handler ─────────────────────────────────────────── */
/**
 * Reads the raw CSS each block instance stored in its data-css attribute
 * and injects it into <head> as a real <style> element.
 *
 * Security: `styleEl.textContent = css` is a DOM text-node write, not
 * HTML/CSS parsed from a string — there is no way for the CSS text to be
 * interpreted as markup, regardless of what characters it contains. This
 * is also why the markup never embeds the CSS inside a literal
 * <style>...</style> tag in save.js — only inside an HTML attribute, which
 * uses ordinary, unambiguous entity-escaping.
 */
function initCssHandler() {
	document.querySelectorAll( '.st-css-handler' ).forEach( ( el ) => {
		const css = el.dataset.css;
		if ( ! css ) return;
		const styleEl = document.createElement( 'style' );
		styleEl.textContent = css;
		document.head.appendChild( styleEl );
	} );
}

document.addEventListener( 'DOMContentLoaded', () => {
	initCssHandler();        // first — custom CSS should be in place before
	                          // other blocks measure layout off it
	const sections = collectSections();
	injectStoryChrome( sections );
	initBackgroundScroll();
	initScrollmation();
	initScrollpoints();
	initReveal();
	initSlideshow();
	initFixedVideos();
	initLazyVideos();
	initVideoScrub();
	initHeroEntrance();      // hero text fades up with delay (Ken Burns companion)
	initContentFadeIn();     // section-text + TOM content fade in on scroll
	initEaseAnimator();      // ease in/out animations on any block (see extensions/ease-animator.js)
	initFloatParallax();     // floating/parallax drift on any block (see extensions/float-parallax.js)
} );

/* ─── Collect all scrollytelling sections for nav ───────────────── */

function collectSections() {
	return Array.from(
		document.querySelectorAll(
			'.st-hero, .st-bg-scroll, .st-scrollmation, .st-scrollpoints, .st-tom, .st-section-text, .st-reveal, .st-slideshow, .st-video-scrub'
		)
	);
}

/* ─── Story Chrome: progress bar + section nav dots ─────────────── */

function injectStoryChrome( sections ) {
	if ( ! sections.length ) return;

	/* Progress bar */
	const bar = document.createElement( 'div' );
	bar.className = 'st-progress-bar';
	bar.setAttribute( 'role', 'progressbar' );
	bar.setAttribute( 'aria-label', 'Reading progress' );
	bar.setAttribute( 'aria-valuemin', '0' );
	bar.setAttribute( 'aria-valuemax', '100' );
	const fill = document.createElement( 'div' );
	fill.className = 'st-progress-bar__fill';
	bar.appendChild( fill );
	document.body.appendChild( bar );

	/* Nav dots */
	const nav = document.createElement( 'nav' );
	nav.className = 'st-nav-dots';
	nav.setAttribute( 'aria-label', 'Story sections' );

	const dots = sections.map( ( section, i ) => {
		const dot = document.createElement( 'button' );
		dot.className = 'st-nav-dots__dot';
		dot.setAttribute( 'aria-label', `Section ${ i + 1 }` );
		dot.title = section.dataset.sectionLabel || `Section ${ i + 1 }`;
		dot.addEventListener( 'click', () => {
			section.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		} );
		nav.appendChild( dot );
		return dot;
	} );

	document.body.appendChild( nav );

	const docHeight = () => document.documentElement.scrollHeight - window.innerHeight;

	const onScroll = () => {
		const progress = Math.min( 100, ( window.scrollY / ( docHeight() || 1 ) ) * 100 );
		fill.style.width = progress + '%';
		bar.setAttribute( 'aria-valuenow', Math.round( progress ) );

		let activeIndex = 0;
		sections.forEach( ( section, i ) => {
			const rect = section.getBoundingClientRect();
			if ( rect.top <= window.innerHeight * 0.5 ) activeIndex = i;
		} );
		dots.forEach( ( d, i ) => d.classList.toggle( 'is-active', i === activeIndex ) );
	};

	onScrollRAF( onScroll );
	onScroll();
}

/* ─── Background Scroll ──────────────────────────────────────────── */
/**
 * Fake-sticky background — identical on every screen size (CSS sticky
 * breaks with overflow:hidden ancestors, hence the JS approach). The sticky
 * container starts as position:absolute (out of flow, so panels overlay it
 * naturally), switches to position:fixed while the section fills the
 * viewport, then back to absolute:bottom:0 as it exits. Its height is the
 * block's chosen percentage of the viewport (100/50/30) on mobile and
 * desktop alike.
 *
 * Panel styling (bg colour/opacity, border) is read from data-* attributes
 * placed on the section element by save.js.
 *
 * Per-panel position: each panel may carry data-panel-pos overriding the
 * block-level default.
 */
function initBackgroundScroll() {
	document.querySelectorAll( '.st-bg-scroll' ).forEach( ( section ) => {
		const sticky    = section.querySelector( '.st-bg-scroll__sticky' );
		const panelsWrap = section.querySelector( '.st-bg-scroll__panels' );
		const panels    = section.querySelectorAll( '.st-bg-scroll__panel' );
		if ( ! sticky || ! panels.length ) return;

		const defaultPos = section.dataset.panelPosition || 'right';

		/* ── Read panel styling from block data attributes ─────────── */
		const panelBgColor   = section.dataset.panelBgColor || '#ffffff';
		const panelBgOpacity = section.dataset.panelBgOpacity !== undefined
			? parseFloat( section.dataset.panelBgOpacity ) / 100 : 0.95;
		const panelBorderColor = section.dataset.panelBorderColor || '#cccccc';
		const panelBorderWidth = parseInt( section.dataset.panelBorderWidth || '0', 10 );
		const bgRgb     = hexToRgb( panelBgColor );
		const borderRgb = hexToRgb( panelBorderColor );

		section.style.position = 'relative';

		/* Panels wrapper floats above the background */
		if ( panelsWrap ) {
			Object.assign( panelsWrap.style, {
				position: 'relative',
				zIndex: '2',
				pointerEvents: 'none',
			} );
		}

		/* ── Style each panel ─────────────────────────────────────── */
		panels.forEach( ( panel ) => {
			/* Per-panel position overrides the block default */
			const pos = panel.dataset.panelPos || defaultPos;

			Object.assign( panel.style, {
				minHeight: '100vh',
				display: 'flex',
				alignItems: 'center',
				pointerEvents: 'none',
			} );

			const inner = panel.querySelector( '.st-bg-scroll__panel-inner' );
			if ( inner ) {
				const panelWidth = panel.style.getPropertyValue( '--panel-width' ) || '40%';
				Object.assign( inner.style, {
					width: panelWidth,
					maxWidth: '560px',
					marginLeft:  pos === 'right' ? 'auto' : pos === 'center' ? 'auto' : '5%',
					marginRight: pos === 'left'  ? 'auto' : pos === 'center' ? 'auto' : '5%',
					background: `rgba(${ bgRgb }, ${ panelBgOpacity })`,
					backdropFilter: 'blur(6px)',
					WebkitBackdropFilter: 'blur(6px)',
					borderRadius: '8px',
					padding: '32px 36px',
					boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
					border: panelBorderWidth > 0
						? `${ panelBorderWidth }px solid rgba(${ borderRgb }, 0.7)`
						: 'none',
					pointerEvents: 'auto',
					opacity: '0',
					transform: 'translateY(24px)',
					transition: 'opacity 0.55s ease, transform 0.55s ease',
				} );
			}
		} );

		/* ── Fake-sticky — identical on every screen size ─────────────── */
		/*
		 * heightVh controls how much of the screen the sticky image fills
		 * (100/50/30, from the block's "Section height" setting) — applied
		 * the same way on mobile as desktop, since "full screen" should mean
		 * the same thing everywhere. Text panels stay min-height:100vh
		 * regardless, so reading space doesn't shrink with a smaller image.
		 */
		const heightVh = parseFloat( section.dataset.mediaHeight ) || 100;
		const stickyH  = heightVh + 'vh';

		const updateSticky = () => {
			const rect = section.getBoundingClientRect();
			const vh   = window.innerHeight;

			if ( rect.top <= 0 && rect.bottom >= vh ) {
				Object.assign( sticky.style, {
					position: 'fixed',
					top: '0', bottom: 'auto', left: '0',
					width: '100vw', height: stickyH,
				} );
			} else if ( rect.bottom < vh ) {
				Object.assign( sticky.style, {
					position: 'absolute',
					top: 'auto', bottom: '0', left: '0',
					width: '100%', height: stickyH,
				} );
			} else {
				Object.assign( sticky.style, {
					position: 'absolute',
					top: '0', bottom: 'auto', left: '0',
					width: '100%', height: stickyH,
				} );
			}
		};

		onScrollRAF( updateSticky );
		window.addEventListener( 'resize', updateSticky, { passive: true } );
		updateSticky();

		/* ── Panel fade-in via IntersectionObserver ──────────────────── */
		const io = new IntersectionObserver(
			( entries ) => {
				entries.forEach( ( e ) => {
					const inner = e.target.querySelector( '.st-bg-scroll__panel-inner' );
					if ( ! inner ) return;
					inner.style.opacity   = e.isIntersecting ? '1' : '0';
					inner.style.transform = e.isIntersecting ? 'translateY(0)' : 'translateY(24px)';
				} );
			},
			{ threshold: 0.25 }
		);

		panels.forEach( ( p ) => io.observe( p ) );
	} );
}

/* ─── Scrollmation ───────────────────────────────────────────────── */
/**
 * Two-column layout: text column scrolls normally and determines the block
 * height; image column uses fake-sticky (position:absolute → fixed → absolute)
 * so it remains visible even when ancestor elements have overflow:hidden —
 * native CSS position:sticky does not work here for the same reason.
 *
 * The fixed image column is offset below any fixed headers (admin bar, site
 * header) detected at runtime so it never hides behind them.
 *
 * Desktop natural-height mode (.st-scrollmation--natural): both columns are
 * flex items; no fake-sticky. Frames still advance proportionally as the
 * block scrolls.
 *
 * Mobile (≤768 px, either mode): uses the same JS fake-sticky mechanism as
 * desktop's full-height mode, but the image is a fixed 16:9 crop of the
 * block's own width (not the full viewport) — always a horizontal crop,
 * never tall/vertical — and the text column gets a dynamic top margin
 * reserving that height, instead of desktop's left/right margin.
 */

/* Returns the bottom edge (px from viewport top) of all fixed/sticky elements
   at the top of the screen — admin bar, site header, nav bars, etc. */
function getScrollmationTopOffset() {
	let bottom = 0;
	[
		'#wpadminbar',
		'#masthead',
		'.site-header',
		'header.navbar',
		'nav.navbar-default',
		'.c-navigation-bar',
		'.navigation-bar',
		'#site-navigation',
	].forEach( ( sel ) => {
		const el = document.querySelector( sel );
		if ( ! el ) return;
		const pos = window.getComputedStyle( el ).position;
		if ( pos === 'fixed' || pos === 'sticky' ) {
			const r = el.getBoundingClientRect();
			if ( r.bottom > bottom ) bottom = r.bottom;
		}
	} );
	return bottom;
}

function initScrollmation() {
	document.querySelectorAll( '.st-scrollmation' ).forEach( ( block ) => {
		const frames    = block.querySelectorAll( '.st-scrollmation__frame' );
		const mediaCol  = block.querySelector( '.st-scrollmation__media-col' );
		const textCol   = block.querySelector( '.st-scrollmation__text-col' );
		const captionEl = block.querySelector( '.st-scrollmation__caption' );
		if ( ! frames.length || ! mediaCol ) return;

		const total      = frames.length;
		const isNatural  = block.classList.contains( 'st-scrollmation--natural' );
		const isImgRight = block.classList.contains( 'st-scrollmation--img-right' );
		const isMobile   = () => window.innerWidth <= 768;

		block.style.position = 'relative';
		let currentIndex = 0;

		/* Cache block size; refresh on resize. Header offset (hh) is NOT
		   cached here — a header that auto-hides/shows on scroll changes
		   height purely from scrolling, not resizing, so it's recomputed
		   fresh on every scroll tick below instead. */
		let blockH = block.offsetHeight;
		let blockW = block.offsetWidth;
		let hh     = getScrollmationTopOffset();

		/* Mobile: media-col becomes position:absolute/fixed (out of flow,
		   exactly like desktop's full-height mode), so text-col needs a
		   top margin reserving the 16:9 image's height above it — the
		   vertical equivalent of desktop's margin-left/right:50%. */
		const updateMobileTextOffset = () => {
			if ( ! textCol ) return;
			textCol.style.marginTop = isMobile() ? ( blockW * 9 / 16 ) + 'px' : '';
		};

		window.addEventListener( 'resize', () => {
			blockH = block.offsetHeight;
			blockW = block.offsetWidth;
			hh     = getScrollmationTopOffset();
			updateMobileTextOffset();
		}, { passive: true } );
		updateMobileTextOffset();

		const onScroll = () => {
			/*
			 * getBoundingClientRect() is always viewport-relative — correct
			 * regardless of positioned ancestors or CSS transforms on parents.
			 */
			const rect   = block.getBoundingClientRect();
			const vh     = window.innerHeight;
			const mobile = isMobile();
			hh = getScrollmationTopOffset();

			/* ── Fake-sticky ──────────────────────────────────────────── */
			/*
			 * Desktop natural mode: no fake-sticky — the image just stretches
			 * to the text column's height via flex (CSS handles it alone).
			 * Every other case (desktop full-height mode, OR mobile in
			 * either mode) pins the image with JS: native CSS
			 * position:sticky does not work here — an ancestor in the
			 * Planet4 theme clips overflow, which silently breaks it.
			 *
			 * stickyH is the image's own height in this state: on desktop
			 * that's the full usable viewport (vh - header); on mobile it's
			 * a fixed 16:9 crop of the block's own width, so the image is
			 * always a horizontal crop — never a tall/vertical one.
			 */
			if ( mobile || ! isNatural ) {
				const stickyH       = mobile ? ( blockW * 9 / 16 ) : ( vh - hh );
				const leftCss       = mobile ? '0' : ( isImgRight ? '50%'  : '0' );
				const widthCss      = mobile ? '100%' : '50%';
				const fixedLeftCss  = mobile ? '0' : ( isImgRight ? '50vw' : '0' );
				const fixedWidthCss = mobile ? '100vw' : '50vw';

				if ( blockH <= stickyH ) {
					/* Block shorter than the sticky area — pin to block top */
					Object.assign( mediaCol.style, {
						position: 'absolute', top: '0', bottom: 'auto',
						left: leftCss, width: widthCss, height: stickyH + 'px',
					} );
				} else if ( rect.top <= hh && rect.bottom >= hh + stickyH ) {
					/* Block fills the sticky area — fix image below header */
					Object.assign( mediaCol.style, {
						position: 'fixed', top: hh + 'px', bottom: 'auto',
						left: fixedLeftCss, width: fixedWidthCss, height: stickyH + 'px',
					} );
				} else if ( rect.bottom < hh + stickyH ) {
					/* Block exiting at bottom — anchor image to block bottom */
					Object.assign( mediaCol.style, {
						position: 'absolute', top: 'auto', bottom: '0',
						left: leftCss, width: widthCss, height: stickyH + 'px',
					} );
				} else {
					/* Block below viewport (entering) — anchor image to block top */
					Object.assign( mediaCol.style, {
						position: 'absolute', top: '0', bottom: 'auto',
						left: leftCss, width: widthCss, height: stickyH + 'px',
					} );
				}
			}

			/* ── Frame advancement ────────────────────────────────────── */
			/*
			 * Full-height mode (desktop or mobile): progress starts when the
			 * block top reaches the header (rect.top = hh → scrolledIn = 0)
			 * and ends when the block bottom exits the viewport. This is
			 * independent of stickyH above — it's about how much of the
			 * whole block (text included) has scrolled past, not the
			 * sticky image's own size.
			 *
			 * Natural-height mode: both columns scroll with the page; progress
			 * is the classic -rect.top / (blockH - vh) formula.
			 */
			const effectiveVh = isNatural ? vh : ( vh - hh );
			const scrollableH = blockH - effectiveVh;
			if ( scrollableH <= 0 ) return;

			const scrolledIn = isNatural
				? Math.max( 0, -rect.top )
				: Math.max( 0, hh - rect.top );
			const progress   = Math.min( 1, scrolledIn / scrollableH );
			const target     = Math.min( total - 1, Math.floor( progress * total ) );

			if ( target !== currentIndex ) {
				frames[ currentIndex ].style.opacity = '0';
				frames[ target ].style.opacity       = '1';
				currentIndex = target;

				if ( captionEl ) {
					const cap = frames[ target ].dataset.caption || '';
					captionEl.textContent   = cap;
					captionEl.style.display = cap ? 'block' : 'none';
				}
			}
		};

		onScrollRAF( onScroll );
		onScroll();

		/* Initialise first-frame caption */
		if ( captionEl ) {
			const firstCap = frames[ 0 ]?.dataset.caption || '';
			captionEl.textContent   = firstCap;
			captionEl.style.display = firstCap ? 'block' : 'none';
		}
	} );
}

/* ─── Scrollpoints ───────────────────────────────────────────────── */
/**
 * Full-viewport background image that pans + zooms as the reader scrolls
 * between focal points — identical behaviour on every screen size, since a
 * full-bleed image IS the feature (no separate, smaller mobile variant).
 *
 * Fake-sticky background (same pattern as background-scroll): fixed while
 * the section fills the viewport, absolute-pinned to top/bottom while
 * entering/exiting. On every scroll tick we compute the interpolation
 * factor between the two panels currently bracketing the viewport centre,
 * then lerp focal-X, focal-Y and zoom directly onto the image (no CSS
 * transition) so it travels continuously rather than jumping between
 * states. Smoothstep easing on the interpolation factor eases motion
 * in/out near each point.
 */

const lerp       = ( a, b, t ) => a + ( b - a ) * t;
const smoothstep = ( t ) => t * t * ( 3 - 2 * t );

function initScrollpoints() {
	document.querySelectorAll( '.st-scrollpoints' ).forEach( ( section ) => {
		const sticky      = section.querySelector( '.st-scrollpoints__sticky' );
		const img         = section.querySelector( '.st-scrollpoints__image' );
		const overlay     = section.querySelector( '.st-scrollpoints__overlay' );
		const panels      = Array.from( section.querySelectorAll( '.st-scrollpoints__panel' ) );
		const panelInners = Array.from( section.querySelectorAll( '.st-scrollpoints__panel-inner' ) );
		if ( ! img || ! panels.length ) return;

		/* ── Apply colours from data attributes ─────────────────────── */
		const textColor      = section.dataset.textColor      || '#1a1a1a';
		const bgColor        = section.dataset.bgColor        || '#ffffff';
		const bgOpacity      = parseFloat( section.dataset.bgOpacity      ?? 92 ) / 100;
		const overlayColor   = section.dataset.overlayColor   || '#000000';
		const overlayOpacity = parseFloat( section.dataset.overlayOpacity  ?? 0  ) / 100;

		const bgRgb      = hexToRgb( bgColor );
		const overlayRgb = hexToRgb( overlayColor );

		if ( overlay && overlayOpacity > 0 ) {
			overlay.style.background = `rgba( ${ overlayRgb }, ${ overlayOpacity } )`;
		}
		panelInners.forEach( ( inner ) => {
			inner.style.background = `rgba( ${ bgRgb }, ${ bgOpacity } )`;
			inner.style.color = textColor;
		} );

		/* ── Cache focal-point data (static after render) ────────────── */
		const pointData = panels.map( ( p ) => ( {
			fx:   parseFloat( p.dataset.focusX ?? 50 ),
			fy:   parseFloat( p.dataset.focusY ?? 50 ),
			zoom: parseFloat( p.dataset.zoom   ?? 1  ),
		} ) );

		/* ── Disable CSS transition — JS drives all animation ─────────── */
		img.style.transition = 'none';

		/* Apply a focal-point immediately (no animation on load) */
		const applyValues = ( fx, fy, zoom ) => {
			img.style.objectPosition  = `${ fx.toFixed( 2 ) }% ${ fy.toFixed( 2 ) }%`;
			img.style.transformOrigin = `${ fx.toFixed( 2 ) }% ${ fy.toFixed( 2 ) }%`;
			img.style.transform = zoom > 1.001 ? `scale( ${ zoom.toFixed( 4 ) } )` : '';
		};
		applyValues( pointData[ 0 ].fx, pointData[ 0 ].fy, pointData[ 0 ].zoom );

		/* ── Fake-sticky — identical on every screen size ─────────────── */
		/*
		 * The image fills the full viewport (fixed while the section is in
		 * view, absolute pinned to top/bottom while entering/exiting) on
		 * mobile exactly as on desktop — this block's whole point is a
		 * full-bleed pan/zoom image, so there's no smaller "mobile" variant.
		 */
		section.style.position = 'relative';

		const updateSticky = () => {
			const rect = section.getBoundingClientRect();
			const vh   = window.innerHeight;
			if ( rect.top <= 0 && rect.bottom >= vh ) {
				Object.assign( sticky.style, { position: 'fixed',    top: '0',    bottom: 'auto', left: '0', width: '100vw', height: '100vh' } );
			} else if ( rect.bottom < vh ) {
				Object.assign( sticky.style, { position: 'absolute', top: 'auto', bottom: '0',    left: '0', width: '100%',  height: '100vh' } );
			} else {
				Object.assign( sticky.style, { position: 'absolute', top: '0',    bottom: 'auto', left: '0', width: '100%',  height: '100vh' } );
			}
		};

		onScrollRAF( updateSticky );
		window.addEventListener( 'resize', updateSticky, { passive: true } );
		updateSticky();

		/* ── Continuous pan + zoom interpolation ─────────────────────── */
		/*
		 * On each scroll tick:
		 * 1. Measure the viewport-relative midpoint of every panel.
		 * 2. Find prevIdx = the last panel whose midpoint has scrolled above
		 *    the viewport centre (that panel is the "from" point).
		 *    nextIdx = prevIdx + 1 (the "to" point).
		 * 3. t = how far the viewport centre has travelled from prevIdx's
		 *    midpoint toward nextIdx's midpoint (0 → 1).
		 * 4. Lerp focal-X, focal-Y, zoom and write directly to the image.
		 *
		 * Result: the image travels continuously from one focal point to the
		 * next — speed matches scroll speed.
		 */
		const updateImage = () => {
			const vc   = window.innerHeight / 2;
			const mids = panels.map( ( p ) => {
				const r = p.getBoundingClientRect();
				return r.top + r.height / 2;
			} );

			/* Find the "from" panel — last one whose centre is above vc */
			let prevIdx = 0;
			for ( let i = 0; i < mids.length - 1; i++ ) {
				if ( mids[ i ] <= vc ) prevIdx = i;
			}
			const nextIdx = Math.min( prevIdx + 1, panels.length - 1 );

			/* Interpolation factor 0→1 between prevIdx and nextIdx */
			let t = 0;
			if ( prevIdx !== nextIdx ) {
				t = ( vc - mids[ prevIdx ] ) / ( mids[ nextIdx ] - mids[ prevIdx ] );
				t = Math.max( 0, Math.min( 1, t ) );
				t = smoothstep( t );
			}

			const prev = pointData[ prevIdx ];
			const next = pointData[ nextIdx ];
			applyValues(
				lerp( prev.fx,   next.fx,   t ),
				lerp( prev.fy,   next.fy,   t ),
				lerp( prev.zoom, next.zoom,  t )
			);
		};

		onScrollRAF( updateImage );
		updateImage();

		/* ── Panel fade-in via IntersectionObserver ────────────────── */
		panelInners.forEach( ( inner ) => {
			Object.assign( inner.style, {
				opacity: '0',
				transform: 'translateY(24px)',
				transition: 'opacity 0.55s ease, transform 0.55s ease',
			} );
		} );

		const io = new IntersectionObserver(
			( entries ) => {
				entries.forEach( ( e ) => {
					const inner = e.target.querySelector( '.st-scrollpoints__panel-inner' );
					if ( ! inner ) return;
					inner.style.opacity   = e.isIntersecting ? '1' : '0';
					inner.style.transform = e.isIntersecting ? 'translateY(0)' : 'translateY(24px)';
				} );
			},
			{ threshold: 0.25 }
		);

		panels.forEach( ( p ) => io.observe( p ) );
	} );
}

/* ─── Reveal section ─────────────────────────────────────────────── */

function initReveal() {
	/* ── Old single-image reveals (no data-transition): fade+scale on scroll ── */
	const oldReveals = document.querySelectorAll( '.st-reveal:not([data-transition])' );

	oldReveals.forEach( ( el ) => {
		const media   = el.querySelector( '.st-reveal__media' );
		const caption = el.querySelector( '.st-reveal__caption' );
		if ( media ) {
			const isFixed = media.classList.contains( 'st-bg-fixed' ) || media.classList.contains( 'st-video-fixed' );
			if ( isFixed ) {
				Object.assign( media.style, { opacity: '0', transition: 'opacity 0.9s ease' } );
			} else {
				Object.assign( media.style, { opacity: '0', transform: 'scale(1.04)', transition: 'opacity 0.9s ease, transform 1.2s ease' } );
			}
		}
		if ( caption ) {
			Object.assign( caption.style, { opacity: '0', transform: 'translateY(12px)', transition: 'opacity 0.7s ease 0.5s, transform 0.7s ease 0.5s' } );
		}
	} );

	const oldIo = new IntersectionObserver(
		( entries ) => {
			entries.forEach( ( e ) => {
				if ( ! e.isIntersecting ) return;
				const media   = e.target.querySelector( '.st-reveal__media' );
				const caption = e.target.querySelector( '.st-reveal__caption' );
				if ( media ) {
					media.style.opacity = '1';
					if ( ! media.classList.contains( 'st-bg-fixed' ) && ! media.classList.contains( 'st-video-fixed' ) ) {
						media.style.transform = 'scale(1)';
					}
				}
				if ( caption ) { caption.style.opacity = '1'; caption.style.transform = 'translateY(0)'; }
				oldIo.unobserve( e.target );
			} );
		},
		{ threshold: 0.08 }
	);
	oldReveals.forEach( ( el ) => oldIo.observe( el ) );

	/* ── New multi-frame reveals (has data-transition): scroll-driven transitions ── */
	const newReveals = document.querySelectorAll( '.st-reveal[data-transition]' );
	if ( ! newReveals.length ) return;

	const SPEED_MULT = { slow: 1.5, medium: 1.0, fast: 0.6 };

	const applyProgress = ( frame, effect, progress ) => {
		const p  = Math.max( 0, Math.min( 1, progress ) );
		const pct = ( 1 - p ) * 100;
		switch ( effect ) {
			case 'wipe-up':
				frame.style.opacity  = '1';
				frame.style.clipPath = `inset(${ pct }% 0 0 0)`;
				break;
			case 'wipe-down':
				frame.style.opacity  = '1';
				frame.style.clipPath = `inset(0 0 ${ pct }% 0)`;
				break;
			case 'wipe-left':
				frame.style.opacity  = '1';
				frame.style.clipPath = `inset(0 ${ pct }% 0 0)`;
				break;
			case 'wipe-right':
				frame.style.opacity  = '1';
				frame.style.clipPath = `inset(0 0 0 ${ pct }%)`;
				break;
			case 'none':
				frame.style.opacity  = p >= 1 ? '1' : '0';
				frame.style.clipPath = '';
				break;
			default: /* fade */
				frame.style.opacity  = p;
				frame.style.clipPath = '';
		}
		frame.style.zIndex        = p > 0 ? '1' : '0';
		frame.style.pointerEvents = p > 0 ? '' : 'none';
	};

	newReveals.forEach( ( el ) => {
		const frameEls = Array.from( el.querySelectorAll( '.st-reveal__frame' ) );
		if ( ! frameEls.length ) return;

		const transition = el.dataset.transition || 'fade';
		const rm         = prefersReducedMotion();
		const effect     = rm ? 'none' : transition;

		let sp = window.innerHeight * ( SPEED_MULT[ el.dataset.speed ] ?? 1.0 );

		const setHeight = () => {
			sp = window.innerHeight * ( SPEED_MULT[ el.dataset.speed ] ?? 1.0 );
			el.style.height = ( frameEls.length * sp + window.innerHeight ) + 'px';
		};
		setHeight();
		window.addEventListener( 'resize', setHeight, { passive: true } );

		/* Frame i becomes fully visible when scrolled ≥ i × sp.
		   Frame 0 starts visible; each subsequent frame transitions in
		   during scrolled ∈ [(i-1)×sp, i×sp]. */
		frameEls.forEach( ( frame, i ) => {
			Object.assign( frame.style, { position: 'absolute', inset: '0' } );
			applyProgress( frame, effect, i === 0 ? 1 : 0 );
			const card = frame.querySelector( '.st-reveal__card' );
			if ( card ) {
				card.style.opacity    = i === 0 ? '1' : '0';
				card.style.transition = 'opacity 0.35s ease';
			}
		} );

		const sticky = el.querySelector( '.st-reveal__sticky' );

		const update = () => {
			const rect = el.getBoundingClientRect();
			const vh   = window.innerHeight;

			/* Fake-sticky: CSS position:sticky breaks with overflow:hidden ancestors
			   in the Planet4 theme — same fix used by bg-scroll and scrollmation. */
			if ( sticky ) {
				if ( rect.top <= 0 && rect.bottom >= vh ) {
					Object.assign( sticky.style, { position: 'fixed', top: '0', bottom: 'auto', left: '0', width: '100vw', height: '100vh' } );
				} else if ( rect.bottom < vh ) {
					Object.assign( sticky.style, { position: 'absolute', top: 'auto', bottom: '0', left: '0', width: '100%', height: '100vh' } );
				} else {
					Object.assign( sticky.style, { position: 'absolute', top: '0', bottom: 'auto', left: '0', width: '100%', height: '100vh' } );
				}
			}

			const scrolled = -rect.top;
			if ( scrolled < 0 || scrolled >= el.offsetHeight - vh + 1 ) return;

			frameEls.forEach( ( frame, i ) => {
				/* Transition progress 0→1 over scrolled ∈ [(i-1)×sp, i×sp] */
				const transProgress = i === 0
					? 1
					: ( scrolled - ( i - 1 ) * sp ) / sp;

				applyProgress( frame, effect, transProgress );

				const card = frame.querySelector( '.st-reveal__card' );
				if ( card ) {
					/* Card is visible while this frame is active and not yet
					   transitioning out to the next one. */
					const isIn     = transProgress >= 1 || i === 0;
					const transOut = ( scrolled - i * sp ) / sp; // 0→1 as frame exits
					const opacity  = isIn ? Math.max( 0, 1 - Math.max( 0, transOut ) ) : 0;
					card.style.opacity = opacity;
				}
			} );
		};

		onScrollRAF( update );
		window.addEventListener( 'resize', update, { passive: true } );
		update();
	} );
}

/* ─── Slideshow / Gallery ────────────────────────────────────────── */

function initSlideshow() {
	document.querySelectorAll( '.st-slideshow' ).forEach( ( block ) => {
		const slides = block.querySelectorAll( '.st-slideshow__slide' );
		const prevBtn = block.querySelector( '.st-slideshow__prev' );
		const nextBtn = block.querySelector( '.st-slideshow__next' );
		const counter = block.querySelector( '.st-slideshow__counter' );
		if ( ! slides.length ) return;

		let current = 0;

		const show = ( index ) => {
			slides.forEach( ( s, i ) => {
				s.style.opacity = i === index ? '1' : '0';
				s.style.zIndex = i === index ? '1' : '0';
				s.setAttribute( 'aria-hidden', i !== index ? 'true' : 'false' );
			} );
			if ( counter ) counter.textContent = `${ index + 1 } / ${ slides.length }`;
			if ( prevBtn ) prevBtn.disabled = index === 0;
			if ( nextBtn ) nextBtn.disabled = index === slides.length - 1;
			current = index;
		};

		if ( prevBtn ) prevBtn.addEventListener( 'click', () => show( Math.max( 0, current - 1 ) ) );
		if ( nextBtn ) nextBtn.addEventListener( 'click', () => show( Math.min( slides.length - 1, current + 1 ) ) );

		block.addEventListener( 'keydown', ( e ) => {
			if ( e.key === 'ArrowLeft' ) show( Math.max( 0, current - 1 ) );
			if ( e.key === 'ArrowRight' ) show( Math.min( slides.length - 1, current + 1 ) );
		} );

		/* ── Touch swipe (mobile) ─────────────────────────────────────── */
		const track = block.querySelector( '.st-slideshow__track' );
		if ( track ) {
			let touchStartX = 0;
			let touchDeltaX  = 0;

			track.addEventListener( 'touchstart', ( e ) => {
				touchStartX = e.touches[ 0 ].clientX;
				touchDeltaX = 0;
			}, { passive: true } );

			track.addEventListener( 'touchmove', ( e ) => {
				touchDeltaX = e.touches[ 0 ].clientX - touchStartX;
			}, { passive: true } );

			track.addEventListener( 'touchend', () => {
				const SWIPE_THRESHOLD = 40; // px — short flicks shouldn't accidentally page
				if ( touchDeltaX > SWIPE_THRESHOLD ) {
					show( Math.max( 0, current - 1 ) );
				} else if ( touchDeltaX < -SWIPE_THRESHOLD ) {
					show( Math.min( slides.length - 1, current + 1 ) );
				}
			}, { passive: true } );
		}

		show( 0 );
	} );
}

/* ─── Fixed-position video parallax ─────────────────────────────── */

function initFixedVideos() {
	const videos = document.querySelectorAll( '.st-video-fixed' );
	if ( ! videos.length ) return;

	/* Parallax translate is disabled on mobile — janky on touch-device
	   compositors and the effect barely registers on a small screen anyway.
	   The video just plays inline at its normal scroll position instead. */
	const isMobile = () => window.innerWidth <= 768;

	const getContainer = ( el ) =>
		el.closest( '.st-bg-scroll__sticky' ) ||
		el.closest( '.st-hero' ) ||
		el.closest( '.st-tom' ) ||
		el.closest( '.st-reveal' ) ||
		el.closest( '.st-video-scrub--block' );

	const onScroll = () => {
		if ( isMobile() || prefersReducedMotion() ) return;
		videos.forEach( ( video ) => {
			const container = getContainer( video );
			if ( ! container ) return;
			const rect = container.getBoundingClientRect();
			video.style.transform = `translateY(${ -rect.top }px)`;
		} );
	};

	onScrollRAF( onScroll );
	onScroll();
}

/* ─── Hero entrance + Ken Burns reset + scroll-driven blur ──────── */
/**
 * Three things happen here per hero block:
 *
 * 1. TEXT ENTRANCE — content fades up 0.45 s after load.
 *
 * 2. KEN BURNS RESET — CSS animations start at stylesheet-parse time, so by
 *    the time the user sees the page the 10-second zoom may already be seconds
 *    in.  We immediately set `animation:none`, force a reflow, then re-enable
 *    after a double-rAF so the animation always plays from frame 0.
 *
 * 3. SCROLL-DRIVEN BLUR — instead of a static filter, blur is applied
 *    progressively via a scroll listener: 0 px at ≤40% of hero scrolled,
 *    ramping to the configured max at 90%.  A slight scale-up (.st-blur-only)
 *    is added when zoom is inactive to prevent filter edge-bleed artifacts.
 */
function initHeroEntrance() {
	document.querySelectorAll( '.st-hero' ).forEach( ( hero ) => {
		const content = hero.querySelector( '.st-hero__content' );
		const bg      = hero.querySelector( '.st-hero__bg' );
		const maxBlur  = parseFloat( hero.dataset.blur ) || 0;
		const isZoomed = bg && bg.classList.contains( 'st-zoom' );

		/* ── 1. Text: snap hidden before first paint ─────────────── */
		if ( content ) {
			content.style.opacity   = '0';
			content.style.transform = 'translateY(28px)';
			content.style.transition = 'none';
		}

		/* ── 2. Ken Burns: proper reset so animation always plays from frame 0.
		 *
		 * Setting bg.style.animation = 'none' and then clearing it does NOT
		 * restart the CSS class animation — the browser resumes from wherever
		 * the animation was in its timeline.
		 *
		 * The correct technique:
		 *  a) Remove the CSS class (stops the running animation entirely).
		 *  b) Hold the bg at scale(1.08) so there's no visible snap.
		 *  c) void bg.offsetWidth — synchronous reflow clears animation state.
		 *  d) Re-add the class in the next rendered frame → fresh animation. */
		if ( isZoomed && bg ) {
			bg.classList.remove( 'st-zoom' );
			bg.style.transform       = 'scale(1.08)';
			bg.style.transformOrigin = 'center center';
			void bg.offsetWidth; // ← synchronous reflow, must be in same call stack
		}

		/* ── Blur-only scale: prevents transparent edge bleed ──────── */
		/* No-op without the blur itself, which is skipped under reduced motion. */
		if ( maxBlur > 0 && bg && ! isZoomed && ! prefersReducedMotion() ) {
			bg.classList.add( 'st-blur-only' );
		}

		/* ── Commit after browser has painted the above ────────────── */
		requestAnimationFrame( () => requestAnimationFrame( () => {
			if ( content ) {
				content.style.transition = 'opacity 1s ease 0.45s, transform 1s ease 0.45s';
				content.style.opacity    = '1';
				content.style.transform  = 'translateY(0)';
			}
			if ( isZoomed && bg ) {
				/* Re-add class: animation starts fresh from @keyframes 'from'.
				 * The CSS animation overrides the inline transform we set above. */
				bg.classList.add( 'st-zoom' );
			}
		} ) );

		/* ── 3. Scroll-driven blur ───────────────────────────────────── */
		if ( maxBlur > 0 && bg && ! prefersReducedMotion() ) {
			const updateBlur = () => {
				const rect       = hero.getBoundingClientRect();
				const heroHeight = hero.offsetHeight;
				const scrolled   = Math.max( 0, -rect.top ); // px past the hero's top edge

				// Ramp: 0 blur until 40 % scrolled, full blur at 90 %
				const blurStart = heroHeight * 0.4;
				const blurEnd   = heroHeight * 0.9;

				let blurPx = 0;
				if ( scrolled >= blurEnd ) {
					blurPx = maxBlur;
				} else if ( scrolled > blurStart ) {
					blurPx = ( ( scrolled - blurStart ) / ( blurEnd - blurStart ) ) * maxBlur;
				}

				bg.style.filter = blurPx > 0.05 ? `blur(${ blurPx.toFixed( 2 ) }px)` : '';
			};

			onScrollRAF( updateBlur );
			updateBlur();
		}
	} );
}

/* ─── Content fade-in on scroll (section-text + TOM) ────────────── */
/**
 * Elements that are NOT immediately visible on load get a fade-up
 * animation as they scroll into the viewport.
 */
function initContentFadeIn() {
	const selectors = [
		'.st-tom__content',
		'.st-section-text__content',
	];

	const targets = document.querySelectorAll( selectors.join( ',' ) );
	if ( ! targets.length ) return;

	targets.forEach( ( el ) => {
		el.style.opacity = '0';
		el.style.transform = 'translateY(20px)';
		el.style.transition = 'opacity 0.75s ease, transform 0.75s ease';
	} );

	const io = new IntersectionObserver(
		( entries ) => {
			entries.forEach( ( e ) => {
				if ( e.isIntersecting ) {
					e.target.style.opacity = '1';
					e.target.style.transform = 'translateY(0)';
					io.unobserve( e.target );
				}
			} );
		},
		{ threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
	);

	targets.forEach( ( el ) => io.observe( el ) );
}

/* ─── Ease In & Out Animator ─────────────────────────────────────── */
/**
 * Applies to ANY block — see src/extensions/ease-animator.js, which adds
 * the data-st-animate-* attributes to a block's saved markup ONLY when an
 * editor has actually configured an animation on it.
 *
 * Duration/delay/distance are per-instance numbers, so they're set here as
 * inline styles / a CSS custom property at runtime rather than baked into
 * the saved HTML — avoids ever needing to merge into whatever inline style
 * a given block already has of its own.
 *
 * One IntersectionObserver drives a 3-state machine per element:
 *   default (not yet revealed)         → CSS's data-st-animate-in hidden state
 *   .st-animate--visible (revealed)    → natural position
 *   .st-animate--exited (scrolled back past, with animate-out configured)
 * Scrolling back down into view after exiting re-triggers the "in"
 * transition, since removing/re-adding .st-animate--visible animates from
 * wherever the element currently is.
 */
function initEaseAnimator() {
	const elements = document.querySelectorAll( '.st-animate' );
	if ( ! elements.length ) return;

	elements.forEach( ( el ) => {
		const duration = parseInt( el.dataset.stAnimateDuration, 10 ) || 700;
		const delay    = parseInt( el.dataset.stAnimateDelay, 10 )    || 0;
		const distance = parseInt( el.dataset.stAnimateDistance, 10 ) || 80;

		el.style.setProperty( '--st-anim-distance', distance + 'px' );
		el.style.transitionDuration = duration + 'ms';
		el.style.transitionDelay    = delay + 'ms';
	} );

	const hasOutAnimation = ( el ) => {
		const out = el.dataset.stAnimateOut;
		return Boolean( out ) && out !== 'none';
	};

	const io = new IntersectionObserver(
		( entries ) => {
			entries.forEach( ( entry ) => {
				const el = entry.target;
				if ( entry.isIntersecting ) {
					el.classList.add( 'st-animate--visible' );
					el.classList.remove( 'st-animate--exited' );
					return;
				}
				/* Only treat this as an "exit" if it scrolled past going up
				   (top < 0 — above the viewport) and it was actually revealed
				   already; otherwise it just hasn't been reached yet. */
				const scrolledPastAbove = entry.boundingClientRect.top < 0;
				if ( hasOutAnimation( el ) && scrolledPastAbove && el.classList.contains( 'st-animate--visible' ) ) {
					el.classList.remove( 'st-animate--visible' );
					el.classList.add( 'st-animate--exited' );
				}
			} );
		},
		{ threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
	);

	elements.forEach( ( el ) => io.observe( el ) );
}

/* ─── Floating / Parallax Effect ─────────────────────────────────── */
/**
 * Applies to ANY block — see src/extensions/float-parallax.js, which adds
 * data-st-float-axis/speed ONLY when an editor has actually set a non-zero
 * speed. Generalises the .parallax-icon + --parallax-speed snippet already
 * used directly on greenpeace.org/israel pages: same core formula (offset
 * scales with distance from viewport centre × speed), with two changes:
 *
 *  - rAF-throttled via onScrollRAF() instead of recomputing on every raw
 *    scroll event, consistent with every other scroll handler in this file.
 *  - Skipped entirely under prefers-reduced-motion: continuous scroll-linked
 *    motion is exactly what that preference exists to avoid, more so than
 *    the one-shot reveal transitions in initEaseAnimator() above.
 *
 * Distance is measured from each element's own centre (not its top edge)
 * to the viewport's centre, since this generalises to blocks of any size,
 * not just small icons.
 */
function initFloatParallax() {
	if ( prefersReducedMotion() ) return;

	const elements = document.querySelectorAll( '.st-float' );
	if ( ! elements.length ) return;

	const update = () => {
		const vh = window.innerHeight;
		const vw = window.innerWidth;

		elements.forEach( ( el ) => {
			const speed = parseFloat( el.dataset.stFloatSpeed ) || 0;
			if ( ! speed ) return;

			const axis = el.dataset.stFloatAxis || 'vertical';
			const rect = el.getBoundingClientRect();
			let tx = 0;
			let ty = 0;

			if ( axis === 'vertical' || axis === 'both' ) {
				ty = ( rect.top + rect.height / 2 - vh / 2 ) * speed;
			}
			if ( axis === 'horizontal' || axis === 'both' ) {
				tx = ( rect.left + rect.width / 2 - vw / 2 ) * speed;
			}

			el.style.transform = `translate3d(${ tx.toFixed( 1 ) }px, ${ ty.toFixed( 1 ) }px, 0)`;
		} );
	};

	onScrollRAF( update );
	update();
}
