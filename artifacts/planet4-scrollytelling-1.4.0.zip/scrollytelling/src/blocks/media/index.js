import metadata from './block.json';
import Edit from './edit';
import Save from './save';

export default {
	...metadata,
	edit: Edit,
	save: Save,
};
