import { useBlockProps } from '@wordpress/block-editor';

function extractYouTubeId( url ) {
	if ( ! url ) return '';
	let m = url.match( /youtu\.be\/([a-zA-Z0-9_-]{11})/ );
	if ( m ) return m[ 1 ];
	m = url.match( /[?&]v=([a-zA-Z0-9_-]{11})/ );
	if ( m ) return m[ 1 ];
	m = url.match( /embed\/([a-zA-Z0-9_-]{11})/ );
	if ( m ) return m[ 1 ];
	if ( /^[a-zA-Z0-9_-]{11}$/.test( url ) ) return url;
	return '';
}

export default function Save( { attributes } ) {
	const { mediaType, url, altText, objectFit, showControls, autoplay } = attributes;

	const blockProps = useBlockProps.save( {
		className: `st-media st-media--${ objectFit }`,
	} );

	if ( mediaType === 'youtube' ) {
		const ytId = extractYouTubeId( url );
		const params = new URLSearchParams( {
			playsinline: '1',
			rel:         '0',
			autoplay:    autoplay ? '1' : '0',
			mute:        autoplay ? '1' : '0',
			controls:    showControls ? '1' : '0',
		} );
		const embedUrl = ytId ? `https://www.youtube.com/embed/${ ytId }?${ params }` : '';

		return (
			<div { ...blockProps }>
				{ embedUrl && (
					<div className="st-media__yt-wrap">
						<iframe
							src={ embedUrl }
							title="YouTube video"
							allow="autoplay; encrypted-media"
							allowFullScreen
						/>
					</div>
				) }
			</div>
		);
	}

	if ( mediaType === 'video' ) {
		return (
			<div { ...blockProps }>
				{ url && (
					<video
						className="st-media__el"
						src={ url }
						muted={ autoplay ? true : undefined }
						autoPlay={ autoplay ? true : undefined }
						loop={ autoplay ? true : undefined }
						controls={ showControls ? true : undefined }
						playsInline
						preload={ autoplay ? 'auto' : 'metadata' }
					/>
				) }
			</div>
		);
	}

	/* image */
	return (
		<div { ...blockProps }>
			{ url && (
				<img
					className="st-media__el"
					src={ url }
					alt={ altText || '' }
				/>
			) }
		</div>
	);
}
