import './style.css';
import { registerBlockType } from '@wordpress/blocks';
import './extensions/ease-animator';
import './extensions/float-parallax';

import heroBlock from './blocks/hero';
import sectionTextBlock from './blocks/section-text';
import backgroundScrollBlock from './blocks/background-scroll';
import scrollmationBlock from './blocks/scrollmation';
import textOverMediaBlock from './blocks/text-over-media';
import revealBlock from './blocks/reveal';
import slideshowBlock from './blocks/slideshow';
import scrollpointsBlock from './blocks/scrollpoints';
import cssHandlerBlock from './blocks/css-handler';
import videoScrubBlock from './blocks/video-scrub';
import mediaBlock from './blocks/media';

// Category registered via PHP filter in scrollytelling.php
registerBlockType( 'scrollytelling/hero', heroBlock );
registerBlockType( 'scrollytelling/section-text', sectionTextBlock );
registerBlockType( 'scrollytelling/background-scroll', backgroundScrollBlock );
registerBlockType( 'scrollytelling/scrollmation', scrollmationBlock );
registerBlockType( 'scrollytelling/text-over-media', textOverMediaBlock );
registerBlockType( 'scrollytelling/reveal', revealBlock );
registerBlockType( 'scrollytelling/slideshow', slideshowBlock );
registerBlockType( 'scrollytelling/scrollpoints', scrollpointsBlock );
registerBlockType( 'scrollytelling/css-handler', cssHandlerBlock );
registerBlockType( 'scrollytelling/video-scrub', videoScrubBlock );
registerBlockType( 'scrollytelling/media', mediaBlock );
