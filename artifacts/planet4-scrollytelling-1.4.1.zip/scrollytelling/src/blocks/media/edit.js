import { __ } from '@wordpress/i18n';
import {
	InspectorControls,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
} from '@wordpress/block-editor';
import {
	Button,
	PanelBody,
	SelectControl,
	TextControl,
	ToggleControl,
} from '@wordpress/components';

function extractYouTubeId( url ) {
	if ( ! url ) return '';
	let m = url.match( /youtu\.be\/([a-zA-Z0-9_-]{11})/ );
	if ( m ) return m[ 1 ];
	m = url.match( /[?&]v=([a-zA-Z0-9_-]{11})/ );
	if ( m ) return m[ 1 ];
	m = url.match( /embed\/([a-zA-Z0-9_-]{11})/ );
	if ( m ) return m[ 1 ];
	if ( /^[a-zA-Z0-9_-]{11}$/.test( url ) ) return url;
	return '';
}

const MEDIA_TYPES = [
	{ label: __( 'Image', 'scrollytelling' ),   value: 'image' },
	{ label: __( 'Video', 'scrollytelling' ),   value: 'video' },
	{ label: __( 'YouTube', 'scrollytelling' ), value: 'youtube' },
];

const FIT_OPTIONS = [
	{ label: __( 'Fill (cover)', 'scrollytelling' ),    value: 'cover' },
	{ label: __( 'Contain (letterbox)', 'scrollytelling' ), value: 'contain' },
];

export default function Edit( { attributes, setAttributes } ) {
	const { mediaType, url, mediaId, altText, objectFit, showControls, autoplay, showCaptions } = attributes;

	const blockProps = useBlockProps( { className: 'st-media-editor' } );

	/* ── Editor preview helpers ── */
	const ytId      = mediaType === 'youtube' ? extractYouTubeId( url ) : '';
	const ytThumb   = ytId ? `https://img.youtube.com/vi/${ ytId }/maxresdefault.jpg` : '';
	const fitStyle  = objectFit === 'contain' ? 'contain' : 'cover';
	const hasSrc    = !! url;

	const previewBg = {
		position: 'relative',
		width: '100%',
		height: '360px',
		background: '#111',
		overflow: 'hidden',
		display: 'flex',
		alignItems: 'center',
		justifyContent: 'center',
	};

	const mediaStyle = {
		position: 'absolute',
		inset: 0,
		width: '100%',
		height: '100%',
		objectFit: fitStyle,
	};

	return (
		<>
			<InspectorControls>

				{ /* ── Media ── */ }
				<PanelBody title={ __( 'Media', 'scrollytelling' ) } initialOpen>
					<SelectControl
						label={ __( 'Media Type', 'scrollytelling' ) }
						value={ mediaType }
						options={ MEDIA_TYPES }
						onChange={ ( v ) => setAttributes( { mediaType: v, url: '', mediaId: undefined } ) }
					/>

					{ mediaType !== 'youtube' && (
						<MediaUploadCheck>
							<MediaUpload
								onSelect={ ( media ) => setAttributes( {
									url:     media.url,
									mediaId: media.id,
									altText: media.alt || '',
								} ) }
								allowedTypes={ mediaType === 'video' ? [ 'video' ] : [ 'image' ] }
								value={ mediaId }
								render={ ( { open } ) => (
									<Button
										variant="secondary"
										onClick={ open }
										style={ { width: '100%', marginBottom: '8px' } }
									>
										{ url
											? __( 'Replace Media', 'scrollytelling' )
											: __( 'Upload / Select Media', 'scrollytelling' ) }
									</Button>
								) }
							/>
						</MediaUploadCheck>
					) }

					{ mediaType === 'youtube' && (
						<TextControl
							label={ __( 'YouTube URL or Video ID', 'scrollytelling' ) }
							value={ url }
							onChange={ ( v ) => setAttributes( { url: v } ) }
							placeholder="https://www.youtube.com/watch?v=…"
						/>
					) }

					{ mediaType === 'image' && url && (
						<TextControl
							label={ __( 'Alt text', 'scrollytelling' ) }
							value={ altText }
							onChange={ ( v ) => setAttributes( { altText: v } ) }
						/>
					) }

					{ url && (
						<Button
							isDestructive
							variant="link"
							onClick={ () => setAttributes( { url: '', mediaId: undefined, altText: '' } ) }
						>
							{ __( 'Remove', 'scrollytelling' ) }
						</Button>
					) }
				</PanelBody>

				{ /* ── Display ── */ }
				<PanelBody title={ __( 'Display', 'scrollytelling' ) } initialOpen={ false }>
					<SelectControl
						label={ __( 'Fit', 'scrollytelling' ) }
						value={ objectFit }
						options={ FIT_OPTIONS }
						onChange={ ( v ) => setAttributes( { objectFit: v } ) }
					/>
				</PanelBody>

				{ /* ── Playback (video + youtube only) ── */ }
				{ mediaType !== 'image' && (
					<PanelBody title={ __( 'Playback', 'scrollytelling' ) } initialOpen={ false }>
						<ToggleControl
							label={ __( 'Autoplay', 'scrollytelling' ) }
							help={ autoplay
								? __( 'Video starts automatically (muted, looped).', 'scrollytelling' )
								: __( 'Video waits for the user to press play.', 'scrollytelling' ) }
							checked={ autoplay }
							onChange={ ( v ) => setAttributes( { autoplay: v } ) }
						/>
						<ToggleControl
							label={ __( 'Show Controls', 'scrollytelling' ) }
							checked={ showControls }
							onChange={ ( v ) => setAttributes( { showControls: v } ) }
						/>
						{ mediaType === 'youtube' && (
							<ToggleControl
								label={ __( 'Show Captions', 'scrollytelling' ) }
								help={ showCaptions
									? __( 'Captions forced on (cc_load_policy=1).', 'scrollytelling' )
									: __( 'Captions disabled (cc_load_policy=0).', 'scrollytelling' ) }
								checked={ showCaptions }
								onChange={ ( v ) => setAttributes( { showCaptions: v } ) }
							/>
						) }
					</PanelBody>
				) }

			</InspectorControls>

			{ /* ── Editor Preview ── */ }
			<div { ...blockProps }>
				<div style={ previewBg }>
					{ hasSrc && mediaType === 'image' && (
						<img src={ url } alt={ altText } style={ mediaStyle } />
					) }

					{ hasSrc && mediaType === 'video' && (
						<video src={ url } muted autoPlay loop playsInline style={ mediaStyle } />
					) }

					{ mediaType === 'youtube' && ytThumb && (
						<img src={ ytThumb } alt="" style={ mediaStyle } />
					) }

					{ mediaType === 'youtube' && ytId && ! ytThumb && (
						<div style={ { color: '#888', fontSize: '13px' } }>
							{ __( 'YouTube ID not recognised', 'scrollytelling' ) }
						</div>
					) }

					{ ! hasSrc && mediaType !== 'youtube' && (
						<p style={ { color: '#666', fontSize: '13px', textAlign: 'center', padding: '0 24px' } }>
							{ __( 'Select media in the sidebar →', 'scrollytelling' ) }
						</p>
					) }

					{ mediaType === 'youtube' && ! url && (
						<p style={ { color: '#666', fontSize: '13px', textAlign: 'center', padding: '0 24px' } }>
							{ __( 'Paste a YouTube URL in the sidebar →', 'scrollytelling' ) }
						</p>
					) }
				</div>
			</div>
		</>
	);
}
