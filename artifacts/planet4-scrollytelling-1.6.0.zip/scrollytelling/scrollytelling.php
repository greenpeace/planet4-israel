<?php
/**
 * Plugin Name: Scrollytelling
 * Description: Scrollytelling blocks for posts and pages — hero, sticky-background scroll, scrollmation, text-over-media, and text sections. This plugin was created by Elad Aybes / Greenpeace MED.
 * Version: 1.6.0
 * Requires at least: 6.3
 * Requires PHP: 8.0
 * Text Domain: scrollytelling
 */

defined( 'ABSPATH' ) || exit;

define( 'SCROLLYTELLING_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCROLLYTELLING_URL', plugin_dir_url( __FILE__ ) );
define( 'SCROLLYTELLING_VERSION', '1.6.0' );

require_once SCROLLYTELLING_DIR . 'includes/class-shorthand-importer.php';
require_once SCROLLYTELLING_DIR . 'includes/shorthand-import-admin.php';
require_once SCROLLYTELLING_DIR . 'includes/class-ai-planner.php';
require_once SCROLLYTELLING_DIR . 'includes/class-doc-importer.php';
require_once SCROLLYTELLING_DIR . 'includes/doc-to-page-admin.php';
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once SCROLLYTELLING_DIR . 'includes/class-shorthand-import-cli.php';
}

// Run after the Planet4 theme's allowed_block_types_all filter (priority 10) so we can append our blocks.
add_filter( 'allowed_block_types_all', 'scrollytelling_allow_blocks', 20 );
function scrollytelling_allow_blocks( $allowed ) {
	if ( ! is_array( $allowed ) ) {
		return $allowed; // true = all blocks already allowed
	}
	return array_merge( $allowed, [
		'scrollytelling/hero',
		'scrollytelling/section-text',
		'scrollytelling/background-scroll',
		'scrollytelling/scrollmation',
		'scrollytelling/text-over-media',
		'scrollytelling/reveal',
		'scrollytelling/slideshow',
		'scrollytelling/scrollpoints',
		'scrollytelling/css-handler',
		'scrollytelling/video-scrub',
		'scrollytelling/media',
		'scrollytelling/story-in-numbers',
	] );
}

add_filter( 'block_categories_all', 'scrollytelling_register_category' );
function scrollytelling_register_category( $categories ) {
	return array_merge(
		[ [ 'slug' => 'scrollytelling', 'title' => 'Scrollytelling', 'icon' => null ] ],
		$categories
	);
}

add_action( 'init', 'scrollytelling_register_assets' );
function scrollytelling_register_assets() {
	$asset_file = SCROLLYTELLING_DIR . 'build/index.asset.php';
	$asset      = file_exists( $asset_file ) ? require $asset_file : [ 'dependencies' => [], 'version' => SCROLLYTELLING_VERSION ];

	wp_register_script(
		'scrollytelling-editor',
		SCROLLYTELLING_URL . 'build/index.js',
		$asset['dependencies'],
		$asset['version']
	);

	wp_register_style(
		'scrollytelling-style',
		SCROLLYTELLING_URL . 'build/style-index.css',
		[],
		$asset['version']
	);
}

add_action( 'init', 'scrollytelling_register_blocks', 20 );
function scrollytelling_register_blocks() {
	$blocks = [
		[
			'name'        => 'scrollytelling/hero',
			'title'       => 'Hero Section',
			'description' => 'Full-screen hero with background image, title, subtitle, and byline.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'hero', 'cover', 'scrollytelling', 'fullscreen' ],
			'attributes'  => [
				'mediaUrl'       => [ 'type' => 'string',  'default' => '' ],
				'mediaId'        => [ 'type' => 'number' ],
				'mediaType'      => [ 'type' => 'string',  'default' => 'image' ],
				'title'          => [ 'type' => 'string',  'default' => '' ],
				'subtitle'       => [ 'type' => 'string',  'default' => '' ],
				'byline'         => [ 'type' => 'string',  'default' => '' ],
				'titleColor'     => [ 'type' => 'string',  'default' => '#ffffff' ],
				'subtitleColor'  => [ 'type' => 'string',  'default' => '#ffffff' ],
				'bylineColor'    => [ 'type' => 'string',  'default' => '#ffffff' ],
				'textPosition'   => [ 'type' => 'string',  'default' => 'center' ],
				'textAlign'      => [ 'type' => 'string',  'default' => 'center' ],
				'overlayColor'   => [ 'type' => 'string',  'default' => '#000000' ],
				'overlayOpacity' => [ 'type' => 'number',  'default' => 40 ],
				'minHeight'      => [ 'type' => 'string',  'default' => '100vh' ],
				'isRtl'          => [ 'type' => 'boolean', 'default' => false ],
				'fixedBackground'=> [ 'type' => 'boolean', 'default' => false ],
				'logoUrl'          => [ 'type' => 'string',  'default' => '' ],
				'logoId'           => [ 'type' => 'number' ],
				'logoPosition'     => [ 'type' => 'string',  'default' => 'before-title' ],
				'logoSize'         => [ 'type' => 'number',  'default' => 120 ],
				'zoomedBackground' => [ 'type' => 'boolean', 'default' => false ],
				'backgroundBlur'   => [ 'type' => 'number',  'default' => 0 ],
			],
			'supports' => [ 'align' => [ 'full', 'wide' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/section-text',
			'title'       => 'Text Section',
			'description' => 'A clean, readable text section for long-form storytelling.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'text', 'prose', 'reading', 'scrollytelling' ],
			'attributes'  => [
				'content'         => [ 'type' => 'string', 'default' => '' ],
				'backgroundColor' => [ 'type' => 'string', 'default' => '#ffffff' ],
				'textColor'       => [ 'type' => 'string', 'default' => '#1a1a1a' ],
				'maxWidth'        => [ 'type' => 'string', 'default' => '680px' ],
				'paddingY'        => [ 'type' => 'number', 'default' => 80 ],
			],
			'supports' => [ 'align' => [ 'wide', 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/background-scroll',
			'title'       => 'Background Scroll',
			'description' => 'Sticky background image or video with scrolling text panels on top.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'sticky', 'parallax', 'scroll', 'scrollytelling', 'background' ],
			'attributes'  => [
				'mediaUrl'      => [ 'type' => 'string', 'default' => '' ],
				'mediaId'       => [ 'type' => 'number' ],
				'mediaType'     => [ 'type' => 'string', 'default' => 'image' ],
				'mediaHeight'   => [ 'type' => 'string', 'default' => 'full' ],
				'focalPoint'    => [ 'type' => 'object', 'default' => [ 'x' => 0.5, 'y' => 0.5 ] ],
				'overlayColor'    => [ 'type' => 'string', 'default' => '#000000' ],
				'overlayOpacity'  => [ 'type' => 'number', 'default' => 30 ],
				'fixedBackground' => [ 'type' => 'boolean', 'default' => false ],
				'panelTitleColor'    => [ 'type' => 'string', 'default' => '#1a1a1a' ],
				'panelBodyColor'     => [ 'type' => 'string', 'default' => '#333333' ],
				'panelTextAlign'     => [ 'type' => 'string', 'default' => 'left' ],
				'panelBgColor'       => [ 'type' => 'string', 'default' => '#ffffff' ],
				'panelBgOpacity'     => [ 'type' => 'number', 'default' => 95 ],
				'panelBorderColor'   => [ 'type' => 'string', 'default' => '#cccccc' ],
				'panelBorderWidth'   => [ 'type' => 'number', 'default' => 0 ],
				'gradientStyle'      => [ 'type' => 'string', 'default' => 'none' ],
				'gradientColor'      => [ 'type' => 'string', 'default' => '#000000' ],
				'gradientOpacity'    => [ 'type' => 'number', 'default' => 60 ],
				'panels'             => [
					'type'    => 'array',
					'default' => [ [ 'id' => 'panel-1', 'title' => '', 'body' => '' ] ],
					'items'   => [ 'type' => 'object' ],
				],
				'panelPosition' => [ 'type' => 'string',  'default' => 'right' ],
				'panelWidth'    => [ 'type' => 'number',  'default' => 40 ],
				'isRtl'         => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/scrollmation',
			'title'       => 'Scrollmation',
			'description' => 'Sticky image sequence alongside scrolling text — images advance as the reader scrolls.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'scrollmation', 'animation', 'frames', 'sequence', 'scrollytelling', 'two-column' ],
			'attributes'  => [
				'frames'    => [ 'type' => 'array',   'default' => [], 'items' => [ 'type' => 'object' ] ],
				'content'   => [ 'type' => 'string',  'default' => '' ],
				'imageSide' => [ 'type' => 'string',  'default' => 'right' ],
				'textColor' => [ 'type' => 'string',  'default' => '#1a1a1a' ],
				'bgColor'   => [ 'type' => 'string',  'default' => '#ffffff' ],
				'objectFit' => [ 'type' => 'string',  'default' => 'cover' ],
				'imageBg'         => [ 'type' => 'string',  'default' => '#000000' ],
				'imageFullHeight' => [ 'type' => 'boolean', 'default' => true ],
				'isRtl'           => [ 'type' => 'boolean', 'default' => false ],
				'textAlign'       => [ 'type' => 'string',  'default' => 'start' ],
			],
			'supports' => [ 'align' => [ 'wide', 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/text-over-media',
			'title'       => 'Text Over Media',
			'description' => 'Full-width image or video with positioned text overlay.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'text over media', 'overlay', 'image text', 'scrollytelling' ],
			'attributes'  => [
				'mediaUrl'       => [ 'type' => 'string', 'default' => '' ],
				'mediaId'        => [ 'type' => 'number' ],
				'mediaType'      => [ 'type' => 'string', 'default' => 'image' ],
				'title'          => [ 'type' => 'string', 'default' => '' ],
				'body'           => [ 'type' => 'string', 'default' => '' ],
				'titleColor'     => [ 'type' => 'string', 'default' => '#ffffff' ],
				'bodyColor'      => [ 'type' => 'string', 'default' => '#ffffff' ],
				'textPosition'   => [ 'type' => 'string', 'default' => 'center' ],
				'textAlign'      => [ 'type' => 'string', 'default' => 'center' ],
				'overlayColor'   => [ 'type' => 'string', 'default' => '#000000' ],
				'overlayOpacity' => [ 'type' => 'number', 'default' => 30 ],
				'minHeight'      => [ 'type' => 'string',  'default' => '80vh' ],
				'textTheme'      => [ 'type' => 'string',  'default' => 'light' ],
				'isRtl'          => [ 'type' => 'boolean', 'default' => false ],
				'fixedBackground'=> [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'wide', 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/reveal',
			'title'       => 'Reveal',
			'description' => 'Full-screen image or video that fades and scales into view as the reader scrolls to it.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'reveal', 'fullscreen', 'fade', 'image', 'scrollytelling' ],
			'attributes'  => [
				'mediaUrl'  => [ 'type' => 'string',  'default' => '' ],
				'mediaId'   => [ 'type' => 'number' ],
				'mediaType' => [ 'type' => 'string',  'default' => 'image' ],
				'caption'        => [ 'type' => 'string',  'default' => '' ],
				'height'         => [ 'type' => 'string',  'default' => 'full' ],
				'objectFit'      => [ 'type' => 'string',  'default' => 'cover' ],
				'isRtl'          => [ 'type' => 'boolean', 'default' => false ],
				'fixedBackground'=> [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full', 'wide' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/slideshow',
			'title'       => 'Slideshow',
			'description' => 'Image or video carousel with prev/next navigation and optional per-slide captions.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'slideshow', 'gallery', 'carousel', 'images', 'scrollytelling' ],
			'attributes'  => [
				'slides' => [ 'type' => 'array', 'default' => [], 'items' => [ 'type' => 'object' ] ],
				'height' => [ 'type' => 'string',  'default' => 'full' ],
				'isRtl'  => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full', 'wide' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/scrollpoints',
			'title'       => 'Scrollpoints',
			'description' => 'Pan and zoom a large image to multiple focal points as the reader scrolls.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'scrollpoints', 'pan', 'zoom', 'image', 'scrollytelling' ],
			'attributes'  => [
				'imageUrl'       => [ 'type' => 'string',  'default' => '' ],
				'imageId'        => [ 'type' => 'number' ],
				'imageAlt'       => [ 'type' => 'string',  'default' => '' ],
				'points'         => [ 'type' => 'array',   'default' => [], 'items' => [ 'type' => 'object' ] ],
				'textPosition'   => [ 'type' => 'string',  'default' => 'right' ],
				'panelWidth'     => [ 'type' => 'number',  'default' => 38 ],
				'textColor'      => [ 'type' => 'string',  'default' => '#1a1a1a' ],
				'bgColor'        => [ 'type' => 'string',  'default' => '#ffffff' ],
				'bgOpacity'      => [ 'type' => 'number',  'default' => 92 ],
				'overlayColor'   => [ 'type' => 'string',  'default' => '#000000' ],
				'overlayOpacity' => [ 'type' => 'number',  'default' => 0 ],
				'isRtl'          => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/css-handler',
			'title'       => 'Custom CSS',
			'description' => 'Add custom CSS styling to the page. Applies site-wide on the page, regardless of where this block is placed.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'css', 'style', 'custom css', 'css handler', 'scrollytelling' ],
			'attributes'  => [
				'css' => [ 'type' => 'string', 'default' => '' ],
			],
			'supports' => [ 'html' => false, 'customClassName' => false, 'align' => false ],
		],
		[
			'name'        => 'scrollytelling/video-scrub',
			'title'       => 'Video Scrubbing',
			'description' => 'A video whose frame is driven by mouse movement instead of playing normally. Background mode takes over the full screen; Block mode is a horizontal strip within the page.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'video', 'scrub', 'scrubbing', 'mouse', 'interactive', 'scrollytelling' ],
			'attributes'  => [
				'mediaUrl'        => [ 'type' => 'string',  'default' => '' ],
				'mediaId'         => [ 'type' => 'number' ],
				'mode'                => [ 'type' => 'string',  'default' => 'background' ],
				'scrubAxis'           => [ 'type' => 'string',  'default' => 'horizontal' ],
				'horizontalDirection' => [ 'type' => 'string',  'default' => 'right' ],
				'verticalDirection'   => [ 'type' => 'string',  'default' => 'down' ],
				'blockHeight'     => [ 'type' => 'number',  'default' => 60 ],
				'fixedPosition'   => [ 'type' => 'boolean', 'default' => false ],
				'focalPoint'      => [ 'type' => 'object',  'default' => [ 'x' => 0.5, 'y' => 0.5 ] ],
				'hasInnerContent' => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/story-in-numbers',
			'title'       => 'Story in Numbers',
			'description' => 'Animated statistics strips — numbers count up on scroll, grid or detail layout, RTL/LTR ready.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'numbers', 'statistics', 'counter', 'data', 'facts', 'scrollytelling' ],
			'attributes'  => [
				'items'                => [ 'type' => 'array',   'default' => [], 'items' => [ 'type' => 'object' ] ],
				'backgroundColor'      => [ 'type' => 'string',  'default' => '#f5f5f5' ],
				'backgroundTransparent'=> [ 'type' => 'boolean', 'default' => false ],
				'stripPaddingY'        => [ 'type' => 'number',  'default' => 64 ],
				'textColor'            => [ 'type' => 'string',  'default' => '#1a1a1a' ],
				'numberColor'          => [ 'type' => 'string',  'default' => '#1a6632' ],
				'numberSize'           => [ 'type' => 'number',  'default' => 64 ],
				'titleAnimation'       => [ 'type' => 'string',  'default' => 'fade-up' ],
				'counterDuration'      => [ 'type' => 'number',  'default' => 2000 ],
				'isRtl'                => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'wide', 'full' ], 'html' => false ],
		],
	];

	foreach ( $blocks as $block ) {
		register_block_type( $block['name'], [
			'title'           => $block['title'],
			'description'     => $block['description'],
			'category'        => $block['category'],
			'keywords'        => $block['keywords'],
			'attributes'      => $block['attributes'],
			'supports'        => $block['supports'],
			'editor_script'   => 'scrollytelling-editor',
			'style'           => 'scrollytelling-style',
		] );
	}
}

add_action( 'wp_enqueue_scripts', 'scrollytelling_frontend_assets' );
function scrollytelling_frontend_assets() {
	$scrollytelling_blocks = [
		'scrollytelling/hero',
		'scrollytelling/section-text',
		'scrollytelling/background-scroll',
		'scrollytelling/scrollmation',
		'scrollytelling/text-over-media',
		'scrollytelling/reveal',
		'scrollytelling/slideshow',
		'scrollytelling/scrollpoints',
		'scrollytelling/css-handler',
		'scrollytelling/video-scrub',
		'scrollytelling/story-in-numbers',
	];

	$has_block = false;
	foreach ( $scrollytelling_blocks as $block_name ) {
		if ( has_block( $block_name ) ) {
			$has_block = true;
			break;
		}
	}

	// The Ease In & Out animator and the Floating/Parallax effect can both
	// be applied to ANY block, including plain core blocks (paragraph,
	// image, group, ...) — has_block() above only matches block NAMES, so
	// it can't detect that. Fall back to a direct scan of the post content
	// for the marker classes those filters add only when actually
	// configured (see extensions/ease-animator.js and float-parallax.js).
	if ( ! $has_block ) {
		$post = get_post();
		if ( $post && ( str_contains( $post->post_content, 'st-animate' ) || str_contains( $post->post_content, 'st-float' ) ) ) {
			$has_block = true;
		}
	}

	if ( ! $has_block ) return;

	// Use webpack's content-hash version (same pattern as the editor script
	// above) so browsers reliably bust their cache for frontend.js whenever
	// it changes — the static SCROLLYTELLING_VERSION constant never changes
	// between builds, so visitors could otherwise keep an old cached copy
	// indefinitely after an update.
	$frontend_asset_file = SCROLLYTELLING_DIR . 'build/frontend.asset.php';
	$frontend_asset       = file_exists( $frontend_asset_file ) ? require $frontend_asset_file : [ 'dependencies' => [], 'version' => SCROLLYTELLING_VERSION ];

	wp_enqueue_script(
		'scrollytelling-frontend',
		SCROLLYTELLING_URL . 'build/frontend.js',
		[],
		$frontend_asset['version'],
		true
	);
}
