// Dynamic block — rendered server-side via st_render_scrollpoints_block().
export default function Save() {
	return null;
}
