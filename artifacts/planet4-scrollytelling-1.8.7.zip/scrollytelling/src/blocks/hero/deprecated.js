import { useBlockProps } from '@wordpress/block-editor';
import { POSITION_CLASS } from '../../components/PositionPicker';

const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0,0,0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

function bgClass( fixedBackground, zoomedBackground, mediaType ) {
	const classes = [ 'st-hero__bg' ];
	if ( fixedBackground && mediaType === 'video' ) classes.push( 'st-video-fixed' );
	if ( fixedBackground && mediaType !== 'video' ) classes.push( 'st-bg-fixed' );
	if ( zoomedBackground ) classes.push( 'st-zoom' );
	return classes.join( ' ' );
}

/* v2: lazy-loading video, static title/subtitle/byline attributes (pre-InnerBlocks) */
function SaveV2( { attributes } ) {
	const {
		mediaUrl, mediaType,
		title, subtitle, byline,
		titleColor, subtitleColor, bylineColor,
		textPosition, textAlign,
		overlayColor, overlayOpacity,
		minHeight, isRtl,
		fixedBackground, zoomedBackground, backgroundBlur,
		logoUrl, logoPosition, logoSize,
	} = attributes;

	const posClass   = POSITION_CLASS[ textPosition ] || 'st-pos--center';
	const alignClass = textAlign ? `st-align--${ textAlign }` : '';
	const sectionStyle = { '--st-min-height': minHeight };

	const blockProps = useBlockProps.save( {
		className: `st-hero ${ posClass } ${ alignClass }`.trim(),
		style: sectionStyle,
		'data-blur': backgroundBlur > 0 ? backgroundBlur : undefined,
		dir: isRtl ? 'rtl' : undefined,
	} );

	const bgClassName = bgClass( fixedBackground, zoomedBackground, mediaType );

	const logoImg = logoUrl ? (
		<img
			className={ `st-hero__logo st-hero__logo--${ logoPosition }` }
			src={ logoUrl }
			alt=""
			style={ { width: logoSize + 'px' } }
		/>
	) : null;

	return (
		<section { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video
					className={ `${ bgClassName } st-lazy-video` }
					data-src={ mediaUrl }
					muted loop playsInline preload="none"
					aria-hidden="true"
				/>
			) : mediaUrl ? (
				fixedBackground ? (
					<div className={ bgClassName } style={ { backgroundImage: `url(${ mediaUrl })` } } aria-hidden="true" />
				) : (
					<img className={ bgClassName } src={ mediaUrl } alt="" aria-hidden="true" />
				)
			) : null }

			<div
				className="st-hero__overlay"
				style={ {
					'--st-overlay-color': overlayColor,
					background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })`,
				} }
				aria-hidden="true"
			/>

			{ logoUrl && logoPosition === 'bottom-right' && logoImg }

			<div className="st-hero__content">
				{ logoUrl && logoPosition === 'before-title' && logoImg }
				{ title && <h1 className="st-hero__title" style={ { color: titleColor } }>{ title }</h1> }
				{ subtitle && <p className="st-hero__subtitle" style={ { color: subtitleColor } }>{ subtitle }</p> }
				{ logoUrl && logoPosition === 'after-subtitle' && logoImg }
				{ byline && <p className="st-hero__byline" style={ { color: bylineColor } }>{ byline }</p> }
			</div>
		</section>
	);
}

/* v1: pre-lazy-loading — <video> had src + autoplay directly, no data-src/preload */
function SaveV1( { attributes } ) {
	const {
		mediaUrl, mediaType,
		title, subtitle, byline,
		titleColor, subtitleColor, bylineColor,
		textPosition, textAlign,
		overlayColor, overlayOpacity,
		minHeight, isRtl,
		fixedBackground, zoomedBackground, backgroundBlur,
		logoUrl, logoPosition, logoSize,
	} = attributes;

	const posClass   = POSITION_CLASS[ textPosition ] || 'st-pos--center';
	const alignClass = textAlign ? `st-align--${ textAlign }` : '';
	const sectionStyle = { '--st-min-height': minHeight };

	const blockProps = useBlockProps.save( {
		className: `st-hero ${ posClass } ${ alignClass }`.trim(),
		style: sectionStyle,
		'data-blur': backgroundBlur > 0 ? backgroundBlur : undefined,
		dir: isRtl ? 'rtl' : undefined,
	} );

	const bgClassName = bgClass( fixedBackground, zoomedBackground, mediaType );

	const logoImg = logoUrl ? (
		<img
			className={ `st-hero__logo st-hero__logo--${ logoPosition }` }
			src={ logoUrl }
			alt=""
			style={ { width: logoSize + 'px' } }
		/>
	) : null;

	return (
		<section { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video
					className={ bgClassName }
					src={ mediaUrl }
					autoPlay muted loop playsInline
					aria-hidden="true"
				/>
			) : mediaUrl ? (
				fixedBackground ? (
					<div className={ bgClassName } style={ { backgroundImage: `url(${ mediaUrl })` } } aria-hidden="true" />
				) : (
					<img className={ bgClassName } src={ mediaUrl } alt="" aria-hidden="true" />
				)
			) : null }

			<div
				className="st-hero__overlay"
				style={ {
					'--st-overlay-color': overlayColor,
					background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })`,
				} }
				aria-hidden="true"
			/>

			{ logoUrl && logoPosition === 'bottom-right' && logoImg }

			<div className="st-hero__content">
				{ logoUrl && logoPosition === 'before-title' && logoImg }
				{ title && <h1 className="st-hero__title" style={ { color: titleColor } }>{ title }</h1> }
				{ subtitle && <p className="st-hero__subtitle" style={ { color: subtitleColor } }>{ subtitle }</p> }
				{ logoUrl && logoPosition === 'after-subtitle' && logoImg }
				{ byline && <p className="st-hero__byline" style={ { color: bylineColor } }>{ byline }</p> }
			</div>
		</section>
	);
}

const ATTRS_WITH_TEXT = {
	mediaUrl:        { type: 'string',  default: '' },
	mediaId:         { type: 'number' },
	mediaType:       { type: 'string',  default: 'image' },
	title:           { type: 'string',  default: '' },
	subtitle:        { type: 'string',  default: '' },
	byline:          { type: 'string',  default: '' },
	titleColor:      { type: 'string',  default: '#ffffff' },
	subtitleColor:   { type: 'string',  default: '#ffffff' },
	bylineColor:     { type: 'string',  default: '#ffffff' },
	textPosition:    { type: 'string',  default: 'center' },
	textAlign:       { type: 'string',  default: 'center' },
	overlayColor:    { type: 'string',  default: '#000000' },
	overlayOpacity:  { type: 'number',  default: 40 },
	minHeight:       { type: 'string',  default: '100vh' },
	isRtl:           { type: 'boolean', default: false },
	fixedBackground: { type: 'boolean', default: false },
	logoUrl:         { type: 'string',  default: '' },
	logoId:          { type: 'number' },
	logoPosition:    { type: 'string',  default: 'before-title' },
	logoSize:        { type: 'number',  default: 120 },
	zoomedBackground:{ type: 'boolean', default: false },
	backgroundBlur:  { type: 'number',  default: 0 },
};

export default [
	{ attributes: ATTRS_WITH_TEXT, save: SaveV2 },
	{ attributes: ATTRS_WITH_TEXT, save: SaveV1 },
];
