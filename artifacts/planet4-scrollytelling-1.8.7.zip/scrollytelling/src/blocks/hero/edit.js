import { __ } from '@wordpress/i18n';
import {
	InspectorControls,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
	useInnerBlocksProps,
} from '@wordpress/block-editor';
import {
	Button,
	ColorPicker,
	PanelBody,
	RangeControl,
	SelectControl,
	ToggleControl,
} from '@wordpress/components';
import { PositionPicker, AlignPicker, POSITION_PREVIEW_STYLE } from '../../components/PositionPicker';

const LOGO_POSITIONS = [
	{ label: __( 'Before title (center)', 'scrollytelling' ), value: 'before-title' },
	{ label: __( 'After subtitle (center)', 'scrollytelling' ), value: 'after-subtitle' },
	{ label: __( 'Fixed bottom-right', 'scrollytelling' ), value: 'bottom-right' },
];

const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0,0,0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

const TEMPLATE = [
	[ 'core/heading', { level: 1, placeholder: __( 'Title…', 'scrollytelling' ) } ],
	[ 'core/paragraph', { placeholder: __( 'Subtitle…', 'scrollytelling' ) } ],
];

export default function Edit( { attributes, setAttributes } ) {
	const {
		mediaUrl, mediaType,
		textPosition, textAlign,
		overlayColor, overlayOpacity,
		minHeight, isRtl, fixedBackground,
		logoUrl, logoId, logoPosition, logoSize,
		zoomedBackground, backgroundBlur,
	} = attributes;

	const blockProps = useBlockProps( { className: 'st-hero-editor' } );

	const innerBlocksProps = useInnerBlocksProps(
		{
			className: 'st-hero__content-editor',
			style: {
				position: 'relative',
				zIndex: 2,
				padding: '40px',
				maxWidth: '800px',
				color: '#fff',
			},
			dir: isRtl ? 'rtl' : 'ltr',
		},
		{ template: TEMPLATE, templateLock: false }
	);

	const positionPreviewStyle = POSITION_PREVIEW_STYLE[ textPosition ] || POSITION_PREVIEW_STYLE[ 'middle-center' ];

	return (
		<>
			<InspectorControls>

				{ /* ── Background Media ── */ }
				<PanelBody title={ __( 'Background Media', 'scrollytelling' ) } initialOpen>
					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( media ) => setAttributes( {
								mediaUrl: media.url,
								mediaId: media.id,
								mediaType: media.type === 'video' ? 'video' : 'image',
							} ) }
							allowedTypes={ [ 'image', 'video' ] }
							value={ attributes.mediaId }
							render={ ( { open } ) => (
								<Button variant="secondary" onClick={ open } style={ { width: '100%', marginBottom: '8px' } }>
									{ mediaUrl ? __( 'Replace Media', 'scrollytelling' ) : __( 'Upload / Select Media', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>
					{ mediaUrl && (
						<Button isDestructive variant="link" onClick={ () => setAttributes( { mediaUrl: '', mediaId: undefined } ) }>
							{ __( 'Remove', 'scrollytelling' ) }
						</Button>
					) }
				</PanelBody>

				{ /* ── Campaign Logo ── */ }
				<PanelBody title={ __( 'Campaign Logo', 'scrollytelling' ) } initialOpen={ false }>
					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( media ) => setAttributes( { logoUrl: media.url, logoId: media.id } ) }
							allowedTypes={ [ 'image' ] }
							value={ logoId }
							render={ ( { open } ) => (
								<Button variant="secondary" onClick={ open } style={ { width: '100%', marginBottom: '8px' } }>
									{ logoUrl ? __( 'Replace Logo', 'scrollytelling' ) : __( 'Upload / Select Logo', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>
					{ logoUrl && (
						<>
							<Button isDestructive variant="link" onClick={ () => setAttributes( { logoUrl: '', logoId: undefined } ) } style={ { marginBottom: '12px' } }>
								{ __( 'Remove Logo', 'scrollytelling' ) }
							</Button>
							<SelectControl
								label={ __( 'Logo Position', 'scrollytelling' ) }
								value={ logoPosition }
								options={ LOGO_POSITIONS }
								onChange={ ( v ) => setAttributes( { logoPosition: v } ) }
							/>
							<RangeControl
								label={ __( 'Logo Width (px)', 'scrollytelling' ) }
								value={ logoSize }
								onChange={ ( v ) => setAttributes( { logoSize: v } ) }
								min={ 40 }
								max={ 400 }
							/>
						</>
					) }
				</PanelBody>

				{ /* ── Overlay ── */ }
				<PanelBody title={ __( 'Overlay', 'scrollytelling' ) } initialOpen={ false }>
					<p style={ { fontSize: '11px', color: '#757575', marginBottom: '8px' } }>
						{ __( 'Overlay Color', 'scrollytelling' ) }
					</p>
					<ColorPicker
						color={ overlayColor }
						onChange={ ( val ) => setAttributes( { overlayColor: val } ) }
						enableAlpha={ false }
					/>
					<RangeControl
						label={ __( 'Overlay Opacity (%)', 'scrollytelling' ) }
						value={ overlayOpacity }
						onChange={ ( val ) => setAttributes( { overlayOpacity: val } ) }
						min={ 0 } max={ 100 }
					/>
				</PanelBody>

				{ /* ── Text ── */ }
				<PanelBody title={ __( 'Text', 'scrollytelling' ) } initialOpen={ false }>
					<PositionPicker value={ textPosition } onChange={ ( val ) => setAttributes( { textPosition: val } ) } />
					<AlignPicker value={ textAlign } onChange={ ( val ) => setAttributes( { textAlign: val } ) } />
					<p style={ { fontSize: '12px', color: '#888', margin: '8px 0 0', fontStyle: 'italic' } }>
						{ __( 'Add heading and paragraph blocks directly on the canvas below. Use block settings to customise colours and typography.', 'scrollytelling' ) }
					</p>
				</PanelBody>

				{ /* ── Layout ── */ }
				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<SelectControl
						label={ __( 'Section Height', 'scrollytelling' ) }
						value={ minHeight }
						options={ [
							{ label: __( 'Full Screen (100vh)', 'scrollytelling' ), value: '100vh' },
							{ label: __( 'Tall (80vh)', 'scrollytelling' ),          value: '80vh' },
							{ label: __( 'Half (50vh)', 'scrollytelling' ),           value: '50vh' },
						] }
						onChange={ ( val ) => setAttributes( { minHeight: val } ) }
					/>
					<ToggleControl
						label={ __( 'Right-to-left text (RTL / Hebrew)', 'scrollytelling' ) }
						help={ __( 'Enable for Hebrew, Arabic, and other RTL languages.', 'scrollytelling' ) }
						checked={ isRtl }
						onChange={ ( val ) => setAttributes( { isRtl: val } ) }
					/>
					<ToggleControl
						label={ __( 'Fixed background (parallax)', 'scrollytelling' ) }
						checked={ fixedBackground }
						onChange={ ( val ) => setAttributes( { fixedBackground: val } ) }
					/>
					<ToggleControl
						label={ __( 'Zoomed background (Ken Burns)', 'scrollytelling' ) }
						help={ __( 'Background slowly zooms out on page load for a cinematic entrance.', 'scrollytelling' ) }
						checked={ zoomedBackground }
						onChange={ ( val ) => setAttributes( { zoomedBackground: val } ) }
					/>
					<RangeControl
						label={ __( 'Background Blur (px)', 'scrollytelling' ) }
						value={ backgroundBlur }
						onChange={ ( val ) => setAttributes( { backgroundBlur: val } ) }
						min={ 0 }
						max={ 20 }
					/>
				</PanelBody>

			</InspectorControls>

			{ /* ── Editor Preview ── */ }
			<div
				{ ...blockProps }
				style={ {
					position: 'relative',
					minHeight,
					display: 'flex',
					overflow: 'hidden',
					padding: 0,
					textAlign,
					...positionPreviewStyle,
				} }
			>
				{ mediaUrl ? (
					mediaType === 'video' ? (
						<video src={ mediaUrl } autoPlay muted loop playsInline
							style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 0 } } />
					) : (
						<img src={ mediaUrl } alt=""
							style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 0 } } />
					)
				) : (
					<div style={ { position: 'absolute', inset: 0, background: '#1a1a2e', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#555', fontSize: '14px' } }>
						{ __( 'Upload a background image or video in the sidebar →', 'scrollytelling' ) }
					</div>
				) }

				<div style={ { position: 'absolute', inset: 0, background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })`, zIndex: 1 } } />

				{ logoUrl && logoPosition === 'bottom-right' && (
					<img src={ logoUrl } alt="" style={ { position: 'absolute', bottom: '24px', right: '24px', width: logoSize + 'px', maxWidth: '100%', height: 'auto', zIndex: 3, objectFit: 'contain' } } />
				) }

				<div { ...innerBlocksProps } />
			</div>
		</>
	);
}
