import metadata from './block.json';
import Edit from './edit';
import Save from './save';
import deprecated from './deprecated';
export default { ...metadata, edit: Edit, save: Save, deprecated };
