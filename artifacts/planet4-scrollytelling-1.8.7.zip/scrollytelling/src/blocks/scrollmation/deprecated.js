import { RichText, useBlockProps } from '@wordpress/block-editor';

const focalPos = ( frame ) =>
	frame.focalPoint
		? `${ Math.round( frame.focalPoint.x * 100 ) }% ${ Math.round( frame.focalPoint.y * 100 ) }%`
		: '50% 50%';

export default [
	{
		attributes: {
			frames:          { type: 'array',   default: [] },
			content:         { type: 'string',  default: '' },
			imageSide:       { type: 'string',  default: 'right' },
			textColor:       { type: 'string',  default: '#1a1a1a' },
			bgColor:         { type: 'string',  default: '#ffffff' },
			objectFit:       { type: 'string',  default: 'cover' },
			imageBg:         { type: 'string',  default: '#000000' },
			imageFullHeight: { type: 'boolean', default: true },
			isRtl:           { type: 'boolean', default: false },
			textAlign:       { type: 'string',  default: 'start' },
		},
		save( { attributes } ) {
			const {
				frames, content, imageSide, textColor,
				bgColor, objectFit, imageBg, imageFullHeight,
				isRtl, textAlign,
			} = attributes;

			const classes = [
				'st-scrollmation',
				`st-scrollmation--img-${ imageSide }`,
				! imageFullHeight ? 'st-scrollmation--natural' : '',
			].filter( Boolean ).join( ' ' );

			const blockProps = useBlockProps.save( {
				className: classes,
				style: { background: bgColor },
			} );

			const mediaColBg = imageFullHeight ? imageBg : bgColor;

			return (
				<section { ...blockProps }>
					<div
						className="st-scrollmation__text-col"
						dir={ isRtl ? 'rtl' : undefined }
					>
						<div className="st-scrollmation__text-inner">
							<RichText.Content
								tagName="div"
								className="st-scrollmation__text-content"
								value={ content }
								style={ {
									...( textColor ? { color: textColor } : {} ),
									...( textAlign && textAlign !== 'start' ? { textAlign } : {} ),
								} }
							/>
						</div>
					</div>

					<div
						className="st-scrollmation__media-col"
						style={ { background: mediaColBg } }
						aria-hidden="true"
					>
						<div className="st-scrollmation__stage">
							{ frames.map( ( frame, i ) => (
								<img
									key={ frame.id || i }
									className="st-scrollmation__frame"
									src={ frame.url }
									alt={ frame.alt || '' }
									data-frame={ i }
									data-caption={ frame.caption || '' }
									data-fit={ objectFit }
									style={ { objectPosition: focalPos( frame ) } }
									aria-hidden={ i !== 0 ? 'true' : undefined }
								/>
							) ) }
						</div>
						<p className="st-scrollmation__caption"></p>
					</div>
				</section>
			);
		},
	},
];
