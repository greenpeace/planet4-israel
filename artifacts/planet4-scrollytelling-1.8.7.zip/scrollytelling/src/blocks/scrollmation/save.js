import { useBlockProps, useInnerBlocksProps } from '@wordpress/block-editor';

const focalPos = ( frame ) =>
	frame.focalPoint
		? `${ Math.round( frame.focalPoint.x * 100 ) }% ${ Math.round( frame.focalPoint.y * 100 ) }%`
		: '50% 50%';

export default function Save( { attributes } ) {
	const {
		frames, imageSide, textColor,
		bgColor, objectFit, imageBg, imageFullHeight,
		isRtl, textAlign, captionColor,
	} = attributes;

	const classes = [
		'st-scrollmation',
		`st-scrollmation--img-${ imageSide }`,
		! imageFullHeight ? 'st-scrollmation--natural' : '',
	].filter( Boolean ).join( ' ' );

	const blockProps = useBlockProps.save( {
		className: classes,
		style: { background: bgColor },
	} );

	const mediaColBg = imageFullHeight ? imageBg : bgColor;

	const innerBlocksProps = useInnerBlocksProps.save( {
		className: 'st-scrollmation__text-content',
		style: {
			...( textColor ? { color: textColor } : {} ),
			...( textAlign && textAlign !== 'start' ? { textAlign } : {} ),
		},
		dir: isRtl ? 'rtl' : undefined,
	} );

	return (
		<section { ...blockProps }>
			<div className="st-scrollmation__text-col">
				<div className="st-scrollmation__text-inner">
					<div { ...innerBlocksProps } />
				</div>
			</div>

			<div
				className="st-scrollmation__media-col"
				style={ { background: mediaColBg } }
				aria-hidden="true"
			>
				<div className="st-scrollmation__stage">
					{ frames.map( ( frame, i ) => (
						<img
							key={ frame.id || i }
							className="st-scrollmation__frame"
							src={ frame.url }
							alt={ frame.alt || '' }
							data-frame={ i }
							data-caption={ frame.caption || '' }
							data-fit={ objectFit }
							style={ { objectPosition: focalPos( frame ) } }
							aria-hidden={ i !== 0 ? 'true' : undefined }
						/>
					) ) }
				</div>
				<p
					className="st-scrollmation__caption"
					style={ captionColor ? { color: captionColor } : undefined }
				></p>
			</div>
		</section>
	);
}
