import { RichText, useBlockProps } from '@wordpress/block-editor';

export default [
	{
		attributes: {
			content:         { type: 'string', default: '' },
			backgroundColor: { type: 'string', default: '#ffffff' },
			textColor:       { type: 'string', default: '#1a1a1a' },
			maxWidth:        { type: 'string', default: '680px' },
			paddingY:        { type: 'number', default: 80 },
		},
		save( { attributes } ) {
			const { content, backgroundColor, textColor, maxWidth, paddingY } = attributes;
			const blockProps = useBlockProps.save( {
				className: 'st-section-text',
				style: { background: backgroundColor, padding: `${ paddingY }px 20px` },
			} );
			return (
				<section { ...blockProps }>
					<div style={ { maxWidth, margin: '0 auto' } }>
						<RichText.Content
							tagName="div"
							className="st-section-text__content"
							style={ { color: textColor } }
							value={ content }
						/>
					</div>
				</section>
			);
		},
	},
];
