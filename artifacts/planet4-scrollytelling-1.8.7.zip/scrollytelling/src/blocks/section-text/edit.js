import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps, useInnerBlocksProps, useSettings } from '@wordpress/block-editor';
import { ColorPalette, PanelBody, RangeControl, ColorPicker, ToggleControl } from '@wordpress/components';

const TEMPLATE = [
	[ 'core/paragraph', { placeholder: __( 'Start writing your story…', 'scrollytelling' ) } ],
];

export default function Edit( { attributes, setAttributes } ) {
	const { backgroundColor, textColor, maxWidth, paddingY, isRtl } = attributes;

	const [ themeColors ] = useSettings( 'color.palette' );
	const colors = themeColors || [];

	const blockProps = useBlockProps( {
		className: 'st-section-text-editor',
		style: { background: backgroundColor, padding: `${ paddingY }px 20px` },
	} );

	const innerBlocksProps = useInnerBlocksProps(
		{
			className: 'st-section-text__content',
			style: { color: textColor, maxWidth, margin: '0 auto' },
			dir: isRtl ? 'rtl' : 'ltr',
		},
		{ template: TEMPLATE, templateLock: false }
	);

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Colours', 'scrollytelling' ) } initialOpen>
					<p style={ { fontSize: '11px', color: '#757575', margin: '0 0 6px' } }>{ __( 'Background', 'scrollytelling' ) }</p>
					<ColorPalette
						colors={ colors }
						value={ backgroundColor }
						onChange={ ( v ) => setAttributes( { backgroundColor: v || backgroundColor } ) }
						clearable={ false }
					/>
					<p style={ { fontSize: '11px', color: '#757575', margin: '12px 0 6px' } }>{ __( 'Text', 'scrollytelling' ) }</p>
					<ColorPalette
						colors={ colors }
						value={ textColor }
						onChange={ ( v ) => setAttributes( { textColor: v || textColor } ) }
						clearable={ false }
					/>
					<p style={ { fontSize: '11px', color: '#9a9a9a', margin: '8px 0 0', fontStyle: 'italic' } }>
						{ __( 'Use "Custom color" below the swatches for any hex value.', 'scrollytelling' ) }
					</p>
				</PanelBody>
				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<RangeControl
						label={ __( 'Vertical Padding (px)', 'scrollytelling' ) }
						value={ paddingY }
						onChange={ ( v ) => setAttributes( { paddingY: v } ) }
						min={ 20 } max={ 200 }
					/>
					<ToggleControl
						label={ __( 'Right-to-left text (RTL)', 'scrollytelling' ) }
						help={ __( 'Enable for Hebrew, Arabic, and other RTL languages.', 'scrollytelling' ) }
						checked={ isRtl }
						onChange={ ( v ) => setAttributes( { isRtl: v } ) }
					/>
				</PanelBody>
			</InspectorControls>

			<section { ...blockProps }>
				<div { ...innerBlocksProps } />
			</section>
		</>
	);
}
