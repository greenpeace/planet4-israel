import { useBlockProps, useInnerBlocksProps } from '@wordpress/block-editor';

export default function Save( { attributes } ) {
	const { backgroundColor, textColor, maxWidth, paddingY, isRtl } = attributes;

	const blockProps = useBlockProps.save( {
		className: 'st-section-text',
		style: { background: backgroundColor, padding: `${ paddingY }px 20px` },
	} );

	const innerBlocksProps = useInnerBlocksProps.save( {
		className: 'st-section-text__content',
		style: { color: textColor, maxWidth, margin: '0 auto' },
		dir: isRtl ? 'rtl' : undefined,
	} );

	return (
		<section { ...blockProps }>
			<div { ...innerBlocksProps } />
		</section>
	);
}
