import { useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import {
	InspectorControls,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
} from '@wordpress/block-editor';
import {
	Button,
	ColorPicker,
	PanelBody,
	RangeControl,
	SelectControl,
	Spinner,
	TextareaControl,
	TextControl,
	ToggleControl,
} from '@wordpress/components';

const ANIMATION_OPTIONS = [
	{ label: __( 'Fade up (classic)', 'scrollytelling' ),  value: 'fade-up' },
	{ label: __( 'Fade in',           'scrollytelling' ),  value: 'fade-in' },
	{ label: __( 'Slide in',          'scrollytelling' ),  value: 'slide-in' },
	{ label: __( 'None',              'scrollytelling' ),  value: 'none' },
];

const genId = () =>
	`sin-${ Date.now().toString( 36 ) }-${ Math.random().toString( 36 ).slice( 2, 6 ) }`;

const defaultItem = () => ( {
	id:        genId(),
	endValue:  100,
	startValue: 0,
	prefix:    '',
	suffix:    '',
	decimals:  0,
	useLocale: true,
	iconUrl:   '',
	iconId:    null,
	title:     '',
	body:      '',
} );

/* ── helpers ──────────────────────────────────────────────────────── */

const fmtNum = ( item ) => {
	const n = Number( item.endValue ) || 0;
	const dec = Number( item.decimals ) || 0;
	const s = item.useLocale !== false
		? n.toLocaleString( 'en', { minimumFractionDigits: dec, maximumFractionDigits: dec } )
		: n.toFixed( dec );
	return `${ item.prefix || '' }${ s }${ item.suffix || '' }`;
};

/* Groups consecutive no-body items into grids */
const groupItems = ( items ) => {
	const groups = [];
	let grid = null;
	items.forEach( ( item ) => {
		if ( item.body ) {
			if ( grid ) { groups.push( { type: 'grid', items: grid } ); grid = null; }
			groups.push( { type: 'detail', item } );
		} else {
			if ( ! grid ) grid = [];
			grid.push( item );
		}
	} );
	if ( grid ) groups.push( { type: 'grid', items: grid } );
	return groups;
};

/* ── stat preview card ──────────────────────────────────────────────── */

function StatCard( { item, numberColor, numberSize, isDetailMode } ) {
	return (
		<div className={ `st-sin__stat${ isDetailMode ? ' st-sin__stat--detail' : '' }` }>
			{ ( item.iconEmoji || item.iconUrl ) && (
				<div className="st-sin__icon-wrap">
					{ item.iconEmoji
						? <span className="st-sin__icon-emoji" role="img" aria-hidden="true">{ item.iconEmoji }</span>
						: <img src={ item.iconUrl } alt="" className="st-sin__icon" />
					}
				</div>
			) }
			<div className="st-sin__number" style={ { color: numberColor, fontSize: numberSize + 'px' } }>
				{ fmtNum( item ) }
			</div>
			{ item.title && (
				<div className="st-sin__title">{ item.title }</div>
			) }
		</div>
	);
}

/* ── AI suggest panel ───────────────────────────────────────────────── */

function AiSuggestPanel( { item, blockColors, onApplyEmoji, onApplyColor } ) {
	const [ loading,    setLoading    ] = useState( false );
	const [ suggestion, setSuggestion ] = useState( null );
	const [ error,      setError      ] = useState( null );
	const [ picked,     setPicked     ] = useState( 0 );

	const suggest = async () => {
		setLoading( true );
		setError( null );
		setSuggestion( null );
		try {
			const result = await apiFetch( {
				path:   '/scrollytelling/v1/ai-suggest',
				method: 'POST',
				data:   {
					title:           item.title   || '',
					body:            item.body    || '',
					endValue:        item.endValue || 0,
					prefix:          item.prefix  || '',
					suffix:          item.suffix  || '',
					backgroundColor: blockColors.backgroundColor,
					textColor:       blockColors.textColor,
					numberColor:     blockColors.numberColor,
				},
			} );
			setSuggestion( result );
			setPicked( 0 );
		} catch ( e ) {
			setError( e.message || __( 'AI suggestion failed. Check your API key in Settings › Scrollytelling.', 'scrollytelling' ) );
		} finally {
			setLoading( false );
		}
	};

	const panelStyle = {
		background: '#f0f7f0',
		border: '1px solid #c3dcc3',
		borderRadius: '4px',
		padding: '10px 12px',
		marginTop: '8px',
	};

	return (
		<div>
			<div style={ { display: 'flex', alignItems: 'center', gap: '8px', marginTop: '8px' } }>
				<Button
					variant="secondary"
					onClick={ suggest }
					disabled={ loading }
					style={ { fontSize: '12px', gap: '4px' } }
				>
					{ loading ? <Spinner /> : '✨' }
					{ loading
						? __( 'Thinking…', 'scrollytelling' )
						: __( 'Auto-generate icon & colours', 'scrollytelling' )
					}
				</Button>
				{ suggestion && (
					<Button variant="link" onClick={ suggest } style={ { fontSize: '11px' } }>
						{ __( 'Try again', 'scrollytelling' ) }
					</Button>
				) }
			</div>

			{ error && (
				<p style={ { color: '#c62828', fontSize: '12px', marginTop: '6px' } }>{ error }</p>
			) }

			{ suggestion && (
				<div style={ panelStyle }>
					{ /* Emoji suggestion */ }
					<p style={ { margin: '0 0 6px', fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', color: '#2e7d32' } }>
						{ __( 'Suggested icon', 'scrollytelling' ) }
					</p>
					<div style={ { display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' } }>
						<span style={ { fontSize: '40px', lineHeight: 1 } }>{ suggestion.emoji }</span>
						<div style={ { flex: 1 } }>
							<p style={ { margin: '0 0 4px', fontSize: '12px', color: '#555', fontStyle: 'italic' } }>
								{ suggestion.emoji_rationale }
							</p>
							<Button
								variant="primary"
								onClick={ () => onApplyEmoji( suggestion.emoji ) }
								style={ { fontSize: '11px' } }
							>
								{ __( 'Use this icon', 'scrollytelling' ) }
							</Button>
						</div>
					</div>

					{ /* Colour suggestions */ }
					<p style={ { margin: '0 0 6px', fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', color: '#2e7d32' } }>
						{ __( 'Colour suggestions', 'scrollytelling' ) }
					</p>
					{ suggestion.colors.map( ( c, i ) => (
						<label
							key={ i }
							style={ {
								display: 'flex',
								alignItems: 'center',
								gap: '8px',
								marginBottom: '6px',
								cursor: 'pointer',
								padding: '5px 8px',
								borderRadius: '3px',
								background: picked === i ? 'rgba(0,0,0,0.06)' : 'transparent',
							} }
						>
							<input
								type="radio"
								name={ `sin-color-${ item.id }` }
								checked={ picked === i }
								onChange={ () => setPicked( i ) }
							/>
							<span style={ {
								display: 'inline-block',
								width: 20, height: 20,
								borderRadius: '50%',
								background: c.hex,
								border: '2px solid rgba(0,0,0,0.15)',
								flexShrink: 0,
							} } />
							<span style={ { fontSize: '12px' } }>
								<strong>{ c.name }</strong>
								<span style={ { color: '#888', marginLeft: '4px' } }>{ c.hex }</span>
								<br />
								<span style={ { color: '#666', fontSize: '11px' } }>{ c.rationale }</span>
							</span>
						</label>
					) ) }
					<Button
						variant="primary"
						onClick={ () => onApplyColor( suggestion.colors[ picked ].hex ) }
						style={ { marginTop: '4px', fontSize: '11px' } }
					>
						{ __( 'Apply colour', 'scrollytelling' ) }
					</Button>
				</div>
			) }
		</div>
	);
}

/* ── item editor panel ──────────────────────────────────────────────── */

function ItemEditor( { item, index, onUpdate, onRemove, isOpen, onToggle, blockColors, onApplyColor } ) {
	const upd = ( patch ) => onUpdate( index, patch );
	const labelStyle = { fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', color: '#757575', marginBottom: '4px', display: 'block' };

	return (
		<div style={ { border: '1px solid #e0e0e0', borderRadius: '4px', marginBottom: '8px', overflow: 'hidden' } }>
			{ /* header row */ }
			<div
				style={ { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 12px', background: '#fafafa', cursor: 'pointer' } }
				onClick={ onToggle }
				role="button"
				tabIndex={ 0 }
				onKeyDown={ ( e ) => e.key === 'Enter' && onToggle() }
			>
				<span style={ { fontWeight: 600, fontSize: '13px' } }>
					{ fmtNum( item ) }{ item.title ? ` — ${ item.title }` : '' }
				</span>
				<span style={ { color: '#888', fontSize: '12px' } }>{ isOpen ? '▲' : '▼' }</span>
			</div>

			{ isOpen && (
				<div style={ { padding: '12px', borderTop: '1px solid #e0e0e0' } }>

					{ /* ── Number settings ── */ }
					<p style={ { ...labelStyle, marginTop: 0 } }>{ __( 'Number', 'scrollytelling' ) }</p>
					<div style={ { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' } }>
						<TextControl
							label={ __( 'End value', 'scrollytelling' ) }
							type="number"
							value={ item.endValue }
							onChange={ ( v ) => upd( { endValue: parseFloat( v ) || 0 } ) }
						/>
						<TextControl
							label={ __( 'Start value', 'scrollytelling' ) }
							type="number"
							value={ item.startValue || 0 }
							onChange={ ( v ) => upd( { startValue: parseFloat( v ) || 0 } ) }
						/>
						<TextControl
							label={ __( 'Prefix', 'scrollytelling' ) }
							value={ item.prefix || '' }
							placeholder=">  $  ~"
							onChange={ ( v ) => upd( { prefix: v } ) }
						/>
						<TextControl
							label={ __( 'Suffix', 'scrollytelling' ) }
							value={ item.suffix || '' }
							placeholder="%  +  M"
							onChange={ ( v ) => upd( { suffix: v } ) }
						/>
					</div>
					<RangeControl
						label={ __( 'Decimal places', 'scrollytelling' ) }
						value={ item.decimals || 0 }
						onChange={ ( v ) => upd( { decimals: v } ) }
						min={ 0 }
						max={ 3 }
					/>
					<ToggleControl
						label={ __( 'Locale formatting (1,000)', 'scrollytelling' ) }
						checked={ item.useLocale !== false }
						onChange={ ( v ) => upd( { useLocale: v } ) }
					/>

					{ /* ── Emoji icon ── */ }
					<p style={ labelStyle }>{ __( 'Icon', 'scrollytelling' ) }</p>
					<div style={ { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' } }>
						<TextControl
							label=""
							value={ item.iconEmoji || '' }
							onChange={ ( v ) => upd( { iconEmoji: v } ) }
							placeholder="🌊"
							style={ { fontSize: '22px', width: '72px' } }
						/>
						{ item.iconEmoji && (
							<Button variant="link" isDestructive onClick={ () => upd( { iconEmoji: '' } ) } style={ { fontSize: '12px' } }>
								{ __( 'Clear', 'scrollytelling' ) }
							</Button>
						) }
						<span style={ { fontSize: '11px', color: '#888' } }>{ __( 'or upload image:', 'scrollytelling' ) }</span>
					</div>

					{ /* ── Image icon ── */ }
					{ item.iconUrl ? (
						<div style={ { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' } }>
							<img src={ item.iconUrl } alt="" style={ { width: 48, height: 48, objectFit: 'contain', border: '1px solid #e0e0e0' } } />
							<MediaUploadCheck>
								<MediaUpload
									onSelect={ ( media ) => upd( { iconUrl: media.url, iconId: media.id } ) }
									allowedTypes={ [ 'image' ] }
									value={ item.iconId }
									render={ ( { open } ) => (
										<Button variant="secondary" onClick={ open } style={ { fontSize: '12px' } }>
											{ __( 'Replace', 'scrollytelling' ) }
										</Button>
									) }
								/>
							</MediaUploadCheck>
							<Button variant="link" isDestructive onClick={ () => upd( { iconUrl: '', iconId: null } ) } style={ { fontSize: '12px' } }>
								{ __( 'Remove', 'scrollytelling' ) }
							</Button>
						</div>
					) : (
						<MediaUploadCheck>
							<MediaUpload
								onSelect={ ( media ) => upd( { iconUrl: media.url, iconId: media.id } ) }
								allowedTypes={ [ 'image' ] }
								value={ item.iconId }
								render={ ( { open } ) => (
									<Button variant="secondary" onClick={ open } style={ { width: '100%', marginBottom: '8px', fontSize: '12px' } }>
										{ __( 'Upload / Select Icon', 'scrollytelling' ) }
									</Button>
								) }
							/>
						</MediaUploadCheck>
					) }

					{ /* ── Title ── */ }
					<TextControl
						label={ __( 'Title / Label', 'scrollytelling' ) }
						value={ item.title || '' }
						onChange={ ( v ) => upd( { title: v } ) }
					/>

					{ /* ── Body text ── */ }
					<TextareaControl
						label={ __( 'Body text (optional — creates detail strip)', 'scrollytelling' ) }
						help={ __( 'If set, this stat gets its own full-width strip with the body alongside the number.', 'scrollytelling' ) }
						value={ item.body || '' }
						onChange={ ( v ) => upd( { body: v } ) }
						rows={ 4 }
					/>

					{ /* ── AI suggest ── */ }
					<div style={ { borderTop: '1px solid #e0e0e0', marginTop: '8px', paddingTop: '8px' } }>
						<AiSuggestPanel
							item={ item }
							blockColors={ blockColors }
							onApplyEmoji={ ( emoji ) => upd( { iconEmoji: emoji } ) }
							onApplyColor={ onApplyColor }
						/>
					</div>

					<Button variant="link" isDestructive onClick={ () => onRemove( index ) } style={ { marginTop: '12px' } }>
						{ __( 'Remove this item', 'scrollytelling' ) }
					</Button>
				</div>
			) }
		</div>
	);
}

/* ── main component ─────────────────────────────────────────────────── */

export default function Edit( { attributes, setAttributes } ) {
	const {
		items,
		backgroundColor, backgroundTransparent,
		stripPaddingY,
		textColor, numberColor, numberSize,
		titleAnimation, counterDuration,
		isRtl,
	} = attributes;

	const [ openItem, setOpenItem ] = useState( null );

	const blockProps = useBlockProps( {
		className: isRtl ? 'st-sin-editor st-sin--rtl' : 'st-sin-editor',
		style: isRtl ? { direction: 'rtl' } : {},
	} );

	const bg = backgroundTransparent ? 'transparent' : backgroundColor;
	const stripStyle = {
		background: bg,
		padding: `${ stripPaddingY }px 40px`,
		color: textColor,
	};

	const addItem = () => {
		const next = [ ...items, defaultItem() ];
		setAttributes( { items: next } );
		setOpenItem( next.length - 1 );
	};

	const removeItem = ( idx ) => {
		setAttributes( { items: items.filter( ( _, i ) => i !== idx ) } );
		setOpenItem( null );
	};

	const updateItem = ( idx, patch ) => {
		setAttributes( {
			items: items.map( ( it, i ) => i === idx ? { ...it, ...patch } : it ),
		} );
	};

	const groups = groupItems( items );

	return (
		<>
			<InspectorControls>

				{ /* ── Items ── */ }
				<PanelBody title={ __( 'Items', 'scrollytelling' ) } initialOpen>
					{ items.map( ( item, idx ) => (
						<ItemEditor
							key={ item.id }
							item={ item }
							index={ idx }
							onUpdate={ updateItem }
							onRemove={ removeItem }
							isOpen={ openItem === idx }
							onToggle={ () => setOpenItem( openItem === idx ? null : idx ) }
							blockColors={ { backgroundColor, textColor, numberColor } }
							onApplyColor={ ( hex ) => setAttributes( { numberColor: hex } ) }
						/>
					) ) }
					<Button
						variant="primary"
						onClick={ addItem }
						style={ { width: '100%', justifyContent: 'center', marginTop: '4px' } }
					>
						{ __( '+ Add Statistic', 'scrollytelling' ) }
					</Button>
				</PanelBody>

				{ /* ── Appearance ── */ }
				<PanelBody title={ __( 'Appearance', 'scrollytelling' ) } initialOpen={ false }>
					<ToggleControl
						label={ __( 'Transparent background', 'scrollytelling' ) }
						checked={ backgroundTransparent }
						onChange={ ( v ) => setAttributes( { backgroundTransparent: v } ) }
					/>
					{ ! backgroundTransparent && (
						<>
							<p style={ { fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', color: '#757575', margin: '8px 0 4px' } }>
								{ __( 'Background color', 'scrollytelling' ) }
							</p>
							<ColorPicker
								color={ backgroundColor }
								onChange={ ( v ) => setAttributes( { backgroundColor: v } ) }
								enableAlpha
							/>
						</>
					) }
					<p style={ { fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', color: '#757575', margin: '12px 0 4px' } }>
						{ __( 'Text color', 'scrollytelling' ) }
					</p>
					<ColorPicker
						color={ textColor }
						onChange={ ( v ) => setAttributes( { textColor: v } ) }
						enableAlpha={ false }
					/>
					<p style={ { fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', color: '#757575', margin: '12px 0 4px' } }>
						{ __( 'Number color', 'scrollytelling' ) }
					</p>
					<ColorPicker
						color={ numberColor }
						onChange={ ( v ) => setAttributes( { numberColor: v } ) }
						enableAlpha={ false }
					/>
					<RangeControl
						label={ __( 'Number font size (px)', 'scrollytelling' ) }
						value={ numberSize }
						onChange={ ( v ) => setAttributes( { numberSize: v } ) }
						min={ 24 }
						max={ 120 }
					/>
					<RangeControl
						label={ __( 'Vertical padding (px)', 'scrollytelling' ) }
						value={ stripPaddingY }
						onChange={ ( v ) => setAttributes( { stripPaddingY: v } ) }
						min={ 16 }
						max={ 160 }
					/>
				</PanelBody>

				{ /* ── Animation ── */ }
				<PanelBody title={ __( 'Animation', 'scrollytelling' ) } initialOpen={ false }>
					<SelectControl
						label={ __( 'Title / body animation', 'scrollytelling' ) }
						value={ titleAnimation }
						options={ ANIMATION_OPTIONS }
						onChange={ ( v ) => setAttributes( { titleAnimation: v } ) }
					/>
					<RangeControl
						label={ __( 'Counter duration (ms)', 'scrollytelling' ) }
						value={ counterDuration }
						onChange={ ( v ) => setAttributes( { counterDuration: v } ) }
						min={ 300 }
						max={ 5000 }
						step={ 100 }
					/>
				</PanelBody>

				{ /* ── Layout ── */ }
				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<ToggleControl
						label={ __( 'Right-to-left (RTL / Hebrew, Arabic)', 'scrollytelling' ) }
						checked={ isRtl }
						onChange={ ( v ) => setAttributes( { isRtl: v } ) }
					/>
				</PanelBody>

			</InspectorControls>

			{ /* ── Canvas preview ── */ }
			<div { ...blockProps }>
				{ items.length === 0 && (
					<div style={ { ...stripStyle, textAlign: 'center', opacity: 0.5, fontSize: '14px', borderRadius: '4px' } }>
						{ __( 'Add statistics using the sidebar →', 'scrollytelling' ) }
					</div>
				) }

				{ groups.map( ( group, gi ) => {
					if ( group.type === 'grid' ) {
						return (
							<div key={ gi } className="st-sin__strip" style={ stripStyle }>
								<div className="st-sin__grid">
									{ group.items.map( ( item ) => (
										<StatCard
											key={ item.id }
											item={ item }
											numberColor={ numberColor }
											numberSize={ numberSize }
										/>
									) ) }
								</div>
							</div>
						);
					}
					/* detail */
					const { item } = group;
					return (
						<div key={ gi } className="st-sin__strip st-sin__strip--detail" style={ stripStyle }>
							<div className="st-sin__detail">
								<div className="st-sin__detail-stat">
									<StatCard
										item={ item }
										numberColor={ numberColor }
										numberSize={ numberSize }
										isDetailMode
									/>
								</div>
								{ item.body && (
									<div className="st-sin__detail-body">
										<p style={ { margin: 0, lineHeight: 1.8 } }>{ item.body }</p>
									</div>
								) }
							</div>
						</div>
					);
				} ) }
			</div>
		</>
	);
}
