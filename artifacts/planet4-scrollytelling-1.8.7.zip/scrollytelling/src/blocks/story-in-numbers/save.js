import { useBlockProps } from '@wordpress/block-editor';

/* Groups consecutive no-body items; items with body each stand alone */
const groupItems = ( items ) => {
	const groups = [];
	let grid = null;
	items.forEach( ( item ) => {
		if ( item.body ) {
			if ( grid ) { groups.push( { type: 'grid', items: grid } ); grid = null; }
			groups.push( { type: 'detail', item } );
		} else {
			if ( ! grid ) grid = [];
			grid.push( item );
		}
	} );
	if ( grid ) groups.push( { type: 'grid', items: grid } );
	return groups;
};

const fmtNum = ( item ) => {
	const n = Number( item.endValue ) || 0;
	const dec = Number( item.decimals ) || 0;
	const s = item.useLocale !== false
		? n.toLocaleString( 'en', { minimumFractionDigits: dec, maximumFractionDigits: dec } )
		: n.toFixed( dec );
	return `${ item.prefix || '' }${ s }${ item.suffix || '' }`;
};

function StatNode( { item, numberSize, numberColor } ) {
	return (
		<div className="st-sin__stat">
			{ ( item.iconEmoji || item.iconUrl ) && (
				<div className="st-sin__icon-wrap">
					{ item.iconEmoji
						? <span className="st-sin__icon-emoji" role="img" aria-hidden="true">{ item.iconEmoji }</span>
						: <img src={ item.iconUrl } alt="" className="st-sin__icon" loading="lazy" />
					}
				</div>
			) }
			<div
				className="st-sin__number"
				data-sin-end={ item.endValue }
				data-sin-start={ item.startValue || 0 }
				data-sin-prefix={ item.prefix || '' }
				data-sin-suffix={ item.suffix || '' }
				data-sin-decimals={ item.decimals || 0 }
				data-sin-locale={ item.useLocale !== false ? '1' : '0' }
				style={ { color: numberColor, fontSize: numberSize + 'px' } }
			>
				{ fmtNum( item ) }
			</div>
			{ item.title && (
				<div className="st-sin__title st-sin-reveal" data-sin-anim={ null }>
					{ item.title }
				</div>
			) }
		</div>
	);
}

export default function Save( { attributes } ) {
	const {
		items,
		backgroundColor, backgroundTransparent,
		stripPaddingY,
		textColor, numberColor, numberSize,
		titleAnimation, counterDuration,
		isRtl,
	} = attributes;

	const blockProps = useBlockProps.save( {
		className: isRtl ? 'st-sin st-sin--rtl' : 'st-sin',
		dir: isRtl ? 'rtl' : undefined,
		'data-sin-duration':  counterDuration,
		'data-sin-animation': titleAnimation,
	} );

	const bg = backgroundTransparent ? 'transparent' : backgroundColor;
	const stripStyle = {
		background: bg,
		padding: `${ stripPaddingY }px 40px`,
		color: textColor,
	};

	const groups = groupItems( items );

	return (
		<section { ...blockProps }>
			{ groups.map( ( group, gi ) => {
				if ( group.type === 'grid' ) {
					return (
						<div key={ gi } className="st-sin__strip" style={ stripStyle }>
							<div className="st-sin__grid">
								{ group.items.map( ( item ) => (
									<StatNode
										key={ item.id }
										item={ item }
										numberColor={ numberColor }
										numberSize={ numberSize }
									/>
								) ) }
							</div>
						</div>
					);
				}

				/* detail strip */
				const { item } = group;
				return (
					<div key={ gi } className="st-sin__strip st-sin__strip--detail" style={ stripStyle }>
						<div className="st-sin__detail">
							<div className="st-sin__detail-stat">
								<StatNode
									item={ item }
									numberColor={ numberColor }
									numberSize={ numberSize }
								/>
							</div>
							<div className={ `st-sin__detail-body${ titleAnimation !== 'none' ? ' st-sin-reveal' : '' }` }
								data-sin-anim={ titleAnimation !== 'none' ? titleAnimation : undefined }
							>
								<p>{ item.body }</p>
							</div>
						</div>
					</div>
				);
			} ) }
		</section>
	);
}
