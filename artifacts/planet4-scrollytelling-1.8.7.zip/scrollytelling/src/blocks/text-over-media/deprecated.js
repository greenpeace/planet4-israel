import { useBlockProps } from '@wordpress/block-editor';
import { POSITION_CLASS } from '../../components/PositionPicker';

const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0,0,0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

/* v2: lazy-loading video but static title/body attributes (pre-InnerBlocks) */
function SaveV2( { attributes } ) {
	const {
		mediaUrl, mediaType,
		title, body, titleColor, bodyColor,
		textTheme, textPosition, textAlign,
		overlayColor, overlayOpacity,
		minHeight, isRtl, fixedBackground,
	} = attributes;

	const posClass   = POSITION_CLASS[ textPosition ] || 'st-pos--center';
	const alignClass = textAlign ? `st-align--${ textAlign }` : '';
	const themeClass = textTheme ? `st-tom--${ textTheme }` : '';

	const blockProps = useBlockProps.save( {
		className: `st-tom ${ posClass } ${ alignClass } ${ themeClass }`.replace( /\s+/g, ' ' ).trim(),
		style: { '--st-min-height': minHeight },
		dir: isRtl ? 'rtl' : undefined,
	} );

	return (
		<section { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video className={ `st-tom__bg st-lazy-video${ fixedBackground ? ' st-video-fixed' : '' }` } data-src={ mediaUrl } muted loop playsInline preload="none" aria-hidden="true" />
			) : mediaUrl ? (
				fixedBackground ? (
					<div className="st-tom__bg st-bg-fixed" style={ { backgroundImage: `url(${ mediaUrl })` } } aria-hidden="true" />
				) : (
					<img className="st-tom__bg" src={ mediaUrl } alt="" aria-hidden="true" />
				)
			) : null }
			<div className="st-tom__overlay" style={ { background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })` } } aria-hidden="true" />
			<div className="st-tom__content">
				{ title && <h2 className="st-tom__title" style={ { color: titleColor } }>{ title }</h2> }
				{ body && <p className="st-tom__body" style={ { color: bodyColor } }>{ body }</p> }
			</div>
		</section>
	);
}

/* v1: pre-lazy-loading — <video> had src + autoplay directly */
function SaveV1( { attributes } ) {
	const {
		mediaUrl, mediaType,
		title, body, titleColor, bodyColor,
		textTheme, textPosition, textAlign,
		overlayColor, overlayOpacity,
		minHeight, isRtl, fixedBackground,
	} = attributes;

	const posClass   = POSITION_CLASS[ textPosition ] || 'st-pos--center';
	const alignClass = textAlign ? `st-align--${ textAlign }` : '';
	const themeClass = textTheme ? `st-tom--${ textTheme }` : '';

	const blockProps = useBlockProps.save( {
		className: `st-tom ${ posClass } ${ alignClass } ${ themeClass }`.replace( /\s+/g, ' ' ).trim(),
		style: { '--st-min-height': minHeight },
		dir: isRtl ? 'rtl' : undefined,
	} );

	return (
		<section { ...blockProps }>
			{ mediaUrl && mediaType === 'video' ? (
				<video className={ `st-tom__bg${ fixedBackground ? ' st-video-fixed' : '' }` } src={ mediaUrl } autoPlay muted loop playsInline aria-hidden="true" />
			) : mediaUrl ? (
				fixedBackground ? (
					<div className="st-tom__bg st-bg-fixed" style={ { backgroundImage: `url(${ mediaUrl })` } } aria-hidden="true" />
				) : (
					<img className="st-tom__bg" src={ mediaUrl } alt="" aria-hidden="true" />
				)
			) : null }
			<div className="st-tom__overlay" style={ { background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })` } } aria-hidden="true" />
			<div className="st-tom__content">
				{ title && <h2 className="st-tom__title" style={ { color: titleColor } }>{ title }</h2> }
				{ body && <p className="st-tom__body" style={ { color: bodyColor } }>{ body }</p> }
			</div>
		</section>
	);
}

const ATTRS_WITH_TEXT = {
	mediaUrl:       { type: 'string',  default: '' },
	mediaId:        { type: 'number' },
	mediaType:      { type: 'string',  default: 'image' },
	title:          { type: 'string',  default: '' },
	body:           { type: 'string',  default: '' },
	titleColor:     { type: 'string',  default: '#ffffff' },
	bodyColor:      { type: 'string',  default: '#ffffff' },
	textPosition:   { type: 'string',  default: 'center' },
	textAlign:      { type: 'string',  default: 'center' },
	overlayColor:   { type: 'string',  default: '#000000' },
	overlayOpacity: { type: 'number',  default: 30 },
	minHeight:      { type: 'string',  default: '80vh' },
	textTheme:      { type: 'string',  default: 'light' },
	isRtl:          { type: 'boolean', default: false },
	fixedBackground:{ type: 'boolean', default: false },
};

export default [
	{ attributes: ATTRS_WITH_TEXT, save: SaveV2 },
	{ attributes: ATTRS_WITH_TEXT, save: SaveV1 },
];
