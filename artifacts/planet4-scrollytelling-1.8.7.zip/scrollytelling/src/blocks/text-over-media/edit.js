import { __ } from '@wordpress/i18n';
import {
	InspectorControls,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
	useInnerBlocksProps,
} from '@wordpress/block-editor';
import { Button, ColorPicker, PanelBody, RangeControl, SelectControl, ToggleControl } from '@wordpress/components';
import { PositionPicker, AlignPicker, POSITION_PREVIEW_STYLE } from '../../components/PositionPicker';

const hexToRgb = ( hex ) => {
	if ( ! hex || hex.length < 7 ) return '0,0,0';
	const r = parseInt( hex.slice( 1, 3 ), 16 );
	const g = parseInt( hex.slice( 3, 5 ), 16 );
	const b = parseInt( hex.slice( 5, 7 ), 16 );
	return `${ r }, ${ g }, ${ b }`;
};

const TEMPLATE = [
	[ 'core/heading', { level: 2, placeholder: __( 'Title…', 'scrollytelling' ) } ],
	[ 'core/paragraph', { placeholder: __( 'Body text…', 'scrollytelling' ) } ],
];

export default function Edit( { attributes, setAttributes } ) {
	const {
		mediaUrl, mediaType,
		textTheme, textPosition, textAlign,
		overlayColor, overlayOpacity,
		minHeight, isRtl, fixedBackground,
	} = attributes;

	const blockProps = useBlockProps( { className: 'st-tom-editor' } );

	const innerBlocksProps = useInnerBlocksProps(
		{
			className: `st-tom__content-editor${ textTheme === 'dark' ? ' st-tom--dark' : '' }`,
			style: {
				position: 'relative',
				zIndex: 2,
				maxWidth: '700px',
				padding: '40px',
				color: textTheme === 'dark' ? '#111' : '#fff',
			},
			dir: isRtl ? 'rtl' : 'ltr',
		},
		{ template: TEMPLATE, templateLock: false }
	);

	const positionPreviewStyle = POSITION_PREVIEW_STYLE[ textPosition ] || POSITION_PREVIEW_STYLE[ 'middle-center' ];

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Media', 'scrollytelling' ) } initialOpen>
					<MediaUploadCheck>
						<MediaUpload
							onSelect={ ( m ) => setAttributes( { mediaUrl: m.url, mediaId: m.id, mediaType: m.type === 'video' ? 'video' : 'image' } ) }
							allowedTypes={ [ 'image', 'video' ] }
							value={ attributes.mediaId }
							render={ ( { open } ) => (
								<Button variant="secondary" onClick={ open } style={ { width: '100%', marginBottom: '8px' } }>
									{ mediaUrl ? __( 'Replace Media', 'scrollytelling' ) : __( 'Upload / Select Media', 'scrollytelling' ) }
								</Button>
							) }
						/>
					</MediaUploadCheck>
					{ mediaUrl && (
						<Button isDestructive variant="link" onClick={ () => setAttributes( { mediaUrl: '', mediaId: undefined } ) }>
							{ __( 'Remove', 'scrollytelling' ) }
						</Button>
					) }
				</PanelBody>

				<PanelBody title={ __( 'Overlay', 'scrollytelling' ) } initialOpen={ false }>
					<p style={ { fontSize: '11px', color: '#757575', marginBottom: '8px' } }>{ __( 'Color', 'scrollytelling' ) }</p>
					<ColorPicker color={ overlayColor } onChange={ ( v ) => setAttributes( { overlayColor: v } ) } enableAlpha={ false } />
					<RangeControl label={ __( 'Opacity (%)', 'scrollytelling' ) } value={ overlayOpacity } onChange={ ( v ) => setAttributes( { overlayOpacity: v } ) } min={ 0 } max={ 90 } />
				</PanelBody>

				<PanelBody title={ __( 'Text', 'scrollytelling' ) } initialOpen={ false }>
					<SelectControl
						label={ __( 'Text theme', 'scrollytelling' ) }
						value={ textTheme }
						options={ [
							{ label: __( 'Light (white text)', 'scrollytelling' ), value: 'light' },
							{ label: __( 'Dark (black text)', 'scrollytelling' ),  value: 'dark'  },
						] }
						onChange={ ( v ) => setAttributes( { textTheme: v } ) }
						help={ __( 'Sets the default text colour. Override individual blocks for custom colours.', 'scrollytelling' ) }
					/>
					<PositionPicker value={ textPosition } onChange={ ( v ) => setAttributes( { textPosition: v } ) } />
					<AlignPicker value={ textAlign } onChange={ ( v ) => setAttributes( { textAlign: v } ) } />
					<SelectControl
						label={ __( 'Section Height', 'scrollytelling' ) }
						value={ minHeight }
						options={ [
							{ label: __( 'Full screen (100vh)', 'scrollytelling' ), value: '100vh' },
							{ label: __( 'Half screen (50vh)', 'scrollytelling' ),  value: '50vh'  },
							{ label: __( 'One third (34vh)', 'scrollytelling' ),    value: '34vh'  },
						] }
						onChange={ ( v ) => setAttributes( { minHeight: v } ) }
					/>
				</PanelBody>

				<PanelBody title={ __( 'Layout', 'scrollytelling' ) } initialOpen={ false }>
					<ToggleControl label={ __( 'Fixed background (parallax)', 'scrollytelling' ) } checked={ fixedBackground } onChange={ ( v ) => setAttributes( { fixedBackground: v } ) } />
					<ToggleControl
						label={ __( 'Right-to-left text (RTL / Hebrew)', 'scrollytelling' ) }
						help={ __( 'Enable for Hebrew, Arabic, and other RTL languages.', 'scrollytelling' ) }
						checked={ isRtl }
						onChange={ ( v ) => setAttributes( { isRtl: v } ) }
					/>
				</PanelBody>
			</InspectorControls>

			<div
				{ ...blockProps }
				style={ {
					position: 'relative',
					minHeight,
					display: 'flex',
					overflow: 'hidden',
					textAlign,
					...positionPreviewStyle,
				} }
			>
				{ mediaUrl ? (
					mediaType === 'video' ? (
						<video src={ mediaUrl } autoPlay muted loop playsInline style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 0 } } />
					) : (
						<img src={ mediaUrl } alt="" style={ { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 0 } } />
					)
				) : (
					<div style={ { position: 'absolute', inset: 0, background: '#2d2d2d', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#555', fontSize: '14px' } }>
						{ __( 'Upload media in the sidebar →', 'scrollytelling' ) }
					</div>
				) }
				<div style={ { position: 'absolute', inset: 0, background: `rgba(${ hexToRgb( overlayColor ) }, ${ overlayOpacity / 100 })`, zIndex: 1 } } />
				<div { ...innerBlocksProps } />
			</div>
		</>
	);
}
