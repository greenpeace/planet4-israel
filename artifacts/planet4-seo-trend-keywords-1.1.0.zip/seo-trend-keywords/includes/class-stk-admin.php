<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class STK_Admin {

	private static $instance = null;
	const NONCE_ACTION = 'stk_admin_action';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_post_stk_save_settings', array( $this, 'handle_save_settings' ) );
	}

	public function add_menu() {
		add_options_page(
			__( 'SEO Trend Keywords', 'stk' ),
			__( 'SEO Trend Keywords', 'stk' ),
			'manage_options',
			'stk-settings',
			array( $this, 'render_page' )
		);
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'stk' ) );
		}

		$settings = STK_Settings::get();

		?>
		<div class="wrap" dir="auto">
			<h1><?php esc_html_e( 'SEO Trend Keywords', 'stk' ); ?></h1>
			<p><?php esc_html_e( 'When an editor saves a post or page, this plugin asks Gemini to find phrases already in the content that could be swapped for a higher-value SEO keyword, cross-checks each replacement against Google Trends search interest, and shows the relevant ones as a sticky checklist at the top of the editor. Approving a suggestion swaps the text in place; ignoring it leaves the content untouched.', 'stk' ); ?></p>

			<?php if ( isset( $_GET['updated'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved successfully.', 'stk' ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( self::NONCE_ACTION ); ?>
				<input type="hidden" name="action" value="stk_save_settings" />
				<table class="form-table">

					<tr>
						<th><label for="stk_api_key"><?php esc_html_e( 'Gemini API key', 'stk' ); ?></label></th>
						<td>
							<input type="password" id="stk_api_key" name="gemini_api_key"
								class="regular-text" autocomplete="new-password"
								placeholder="<?php echo ! empty( $settings['gemini_api_key'] ) ? esc_attr__( '(saved — leave blank to keep)', 'stk' ) : ''; ?>"
								value="" />
							<p class="description">
								<?php esc_html_e( 'Used to extract candidate keyword phrases from page content. Leave blank to keep the existing key. Without a key, suggestions are silently skipped.', 'stk' ); ?>
							</p>
							<?php if ( ! empty( $settings['gemini_api_key'] ) ) : ?>
								<p class="description" style="color:#2ea44f;">&#10003; <?php esc_html_e( 'API key is set.', 'stk' ); ?></p>
							<?php else : ?>
								<p class="description" style="color:#cf222e;">&#9888; <?php esc_html_e( 'No API key — keyword suggestions are disabled.', 'stk' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>

					<tr>
						<th><label for="stk_model"><?php esc_html_e( 'Gemini model', 'stk' ); ?></label></th>
						<td>
							<input type="text" id="stk_model" name="gemini_model" class="regular-text" value="<?php echo esc_attr( $settings['gemini_model'] ); ?>" />
							<p class="description"><?php esc_html_e( 'This is a simple JSON-extraction task, so a non-reasoning "lite" model is the efficient choice — gemini-2.5-flash-lite (default) is the cheapest and used the fewest tokens in testing; gemini-3.1-flash-lite is a newer generation at a slightly higher token cost.', 'stk' ); ?></p>
						</td>
					</tr>

					<tr>
						<th><label for="stk_geo"><?php esc_html_e( 'Trends geo', 'stk' ); ?></label></th>
						<td>
							<input type="text" id="stk_geo" name="geo" class="small-text" maxlength="2" value="<?php echo esc_attr( $settings['geo'] ); ?>" />
							<p class="description"><?php esc_html_e( 'Two-letter Google Trends region code, e.g. IL, US.', 'stk' ); ?></p>
						</td>
					</tr>

					<tr>
						<th><label for="stk_hl"><?php esc_html_e( 'Trends language (hl)', 'stk' ); ?></label></th>
						<td>
							<input type="text" id="stk_hl" name="hl" class="small-text" value="<?php echo esc_attr( $settings['hl'] ); ?>" />
							<p class="description"><?php esc_html_e( 'Google Trends UI language code, e.g. iw (Hebrew), en.', 'stk' ); ?></p>
						</td>
					</tr>

					<tr>
						<th><label for="stk_min_interest"><?php esc_html_e( 'Minimum interest score', 'stk' ); ?></label></th>
						<td>
							<input type="number" id="stk_min_interest" name="min_interest" class="small-text" min="0" max="100" value="<?php echo esc_attr( $settings['min_interest'] ); ?>" />
							<p class="description"><?php esc_html_e( 'A candidate keyword is only suggested if its average Google Trends interest (0-100 scale) meets this minimum.', 'stk' ); ?></p>
						</td>
					</tr>

					<tr>
						<th><label for="stk_max_keywords"><?php esc_html_e( 'Max keywords per page', 'stk' ); ?></label></th>
						<td><input type="number" id="stk_max_keywords" name="max_keywords" class="small-text" min="1" max="20" value="<?php echo esc_attr( $settings['max_keywords'] ); ?>" /></td>
					</tr>

				</table>
				<?php submit_button( __( 'Save settings', 'stk' ), 'primary' ); ?>
			</form>
		</div>
		<?php
	}

	public function handle_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'stk' ), 403 );
		}
		check_admin_referer( self::NONCE_ACTION );

		STK_Settings::update( $_POST );

		wp_safe_redirect( admin_url( 'options-general.php?page=stk-settings&updated=1' ) );
		exit;
	}
}
