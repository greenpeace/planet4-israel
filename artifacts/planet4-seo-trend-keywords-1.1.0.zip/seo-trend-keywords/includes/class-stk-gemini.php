<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finds specific existing phrases in a post's content that could be swapped
 * for a higher-value SEO keyword phrase, via the Gemini API. Candidates
 * still need to be cross-checked against Google Trends (see STK_Trends)
 * before they're worth suggesting to an editor.
 */
class STK_Gemini {

	const MAX_WORDS = 700;

	/**
	 * @return array[] List of { existing: string, replacement: string },
	 *                 where `existing` is guaranteed to be a verbatim
	 *                 substring of $plain_text. Empty if no API key is
	 *                 configured or the call fails.
	 */
	public static function extract_candidates( $title, $plain_text, $settings ) {
		if ( empty( $settings['gemini_api_key'] ) ) {
			error_log( 'STK_Gemini: no Gemini API key configured' );
			return array();
		}

		$truncated = wp_trim_words( $plain_text, self::MAX_WORDS );

		$system_instruction = "You are an SEO expert.\n"
			. "Given an article's title and body, find short phrases (2-6 words) that appear VERBATIM in the article body and could be replaced with a better SEO keyword phrase — one with more realistic Google search volume — without changing the sentence's meaning.\n"
			. "Rules:\n"
			. "- \"existing\" must be copied character-for-character from the article body given below (same casing, same spacing). It will be rejected if it does not match exactly.\n"
			. "- \"replacement\" must be a realistic phrase people would type into Google, relevant to this specific article, and different from \"existing\".\n"
			. "- Suggest at most 8 replacements, only for phrases genuinely worth swapping — do not force it.\n"
			. "- Detect the article's language and keep both \"existing\" and \"replacement\" in that same language.\n"
			. "Output strictly as a JSON array of objects, nothing else. No markdown, no code fences, no commentary.\n"
			. 'Example output: [{"existing": "clean power sources", "replacement": "renewable energy subsidies"}]';

		$user_message = "Title: {$title}\n\nArticle:\n{$truncated}";

		$model    = ! empty( $settings['gemini_model'] ) ? $settings['gemini_model'] : 'gemini-2.5-flash-lite';
		$endpoint = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key="
			. rawurlencode( $settings['gemini_api_key'] );

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'system_instruction' => array(
							'parts' => array( array( 'text' => $system_instruction ) ),
						),
						'contents'           => array(
							array(
								'role'  => 'user',
								'parts' => array( array( 'text' => $user_message ) ),
							),
						),
						'generationConfig'   => array(
							'maxOutputTokens'  => 2048,
							'temperature'      => 0.4,
							'responseMimeType' => 'application/json',
							// Disable "thinking" tokens on reasoning-capable models (e.g.
							// gemini-2.5-flash) — they otherwise eat into maxOutputTokens
							// and can truncate the JSON before any answer text is produced.
							// Lite models are non-reasoning and ignore this harmlessly.
							'thinkingConfig'   => array( 'thinkingBudget' => 0 ),
						),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			error_log( 'STK_Gemini: wp_remote_post error — ' . $response->get_error_message() );
			return array();
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			error_log( "STK_Gemini: Gemini API returned HTTP {$code} — " . wp_remote_retrieve_body( $response ) );
			return array();
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$text = isset( $body['candidates'][0]['content']['parts'][0]['text'] )
			? trim( $body['candidates'][0]['content']['parts'][0]['text'] )
			: '';

		if ( '' === $text ) {
			error_log( 'STK_Gemini: empty text in response. Body: ' . wp_remote_retrieve_body( $response ) );
			return array();
		}

		// Strip markdown code fences in case the model adds them despite instructions.
		$text = preg_replace( '/^```[a-z]*\n?|```$/mi', '', trim( $text ) );

		$raw = json_decode( $text, true );
		if ( ! is_array( $raw ) ) {
			error_log( 'STK_Gemini: could not parse JSON array from response text: ' . $text );
			return array();
		}

		$candidates = array();
		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) || empty( $item['existing'] ) || empty( $item['replacement'] ) ) {
				continue;
			}
			$existing    = trim( (string) $item['existing'] );
			$replacement = trim( (string) $item['replacement'] );

			if ( '' === $existing || '' === $replacement ) {
				continue;
			}

			// Guard against hallucinated "existing" text: only keep candidates that
			// are genuinely findable in the article, so the editor-side replacement
			// step can locate and swap them deterministically. Match case-insensitively
			// (the model doesn't always preserve casing exactly) but then re-pull the
			// substring with the article's actual casing, so the editor's later exact
			// (case-sensitive) text search is guaranteed to find it.
			$pos = mb_stripos( $plain_text, $existing );
			if ( false === $pos ) {
				error_log( "STK_Gemini: dropping candidate — 'existing' text not found verbatim in content: {$existing}" );
				continue;
			}
			$existing = mb_substr( $plain_text, $pos, mb_strlen( $existing ) );

			$candidates[] = array(
				'existing'    => $existing,
				'replacement' => $replacement,
			);
		}

		return $candidates;
	}
}
