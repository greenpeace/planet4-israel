<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class STK_REST {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			'seo-trend-keywords/v1',
			'/suggest',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'suggest' ),
				'permission_callback' => array( $this, 'can_edit' ),
				'args'                => array(
					'id' => array(
						'required'          => true,
						'validate_callback' => function ( $value ) {
							return is_numeric( $value );
						},
					),
				),
			)
		);
	}

	public function can_edit( $request ) {
		$post_id = (int) $request->get_param( 'id' );
		return current_user_can( 'edit_post', $post_id );
	}

	public function suggest( $request ) {
		$post_id = (int) $request->get_param( 'id' );

		$result = STK_Suggester::suggest_for_post( $post_id );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response( array( 'keywords' => $result ) );
	}
}
