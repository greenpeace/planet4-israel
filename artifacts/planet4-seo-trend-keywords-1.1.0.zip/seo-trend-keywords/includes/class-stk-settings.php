<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class STK_Settings {

	const OPTION_KEY = 'stk_settings';

	public static function defaults() {
		return array(
			'gemini_api_key' => '',
			'gemini_model'   => 'gemini-2.5-flash-lite',
			'geo'            => 'IL',
			'hl'             => 'iw',
			'min_interest'   => 1,
			'max_keywords'   => 6,
		);
	}

	public static function get() {
		$settings = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		return wp_parse_args( $settings, self::defaults() );
	}

	public static function update( array $settings ) {
		$existing = self::get();

		$clean = array(
			'gemini_api_key' => ( isset( $settings['gemini_api_key'] ) && '' !== trim( $settings['gemini_api_key'] ) )
				? sanitize_text_field( wp_unslash( $settings['gemini_api_key'] ) )
				: $existing['gemini_api_key'],
			'gemini_model'   => isset( $settings['gemini_model'] ) && '' !== trim( $settings['gemini_model'] )
				? sanitize_text_field( wp_unslash( $settings['gemini_model'] ) )
				: $existing['gemini_model'],
			'geo'            => isset( $settings['geo'] )
				? strtoupper( sanitize_text_field( wp_unslash( $settings['geo'] ) ) )
				: $existing['geo'],
			'hl'             => isset( $settings['hl'] )
				? sanitize_text_field( wp_unslash( $settings['hl'] ) )
				: $existing['hl'],
			'min_interest'   => isset( $settings['min_interest'] )
				? max( 0, (int) $settings['min_interest'] )
				: $existing['min_interest'],
			'max_keywords'   => isset( $settings['max_keywords'] )
				? max( 1, (int) $settings['max_keywords'] )
				: $existing['max_keywords'],
		);

		update_option( self::OPTION_KEY, $clean );
	}
}
