<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Orchestrates a single "suggest replacements for this post" run: extract
 * existing-phrase -> replacement-keyword candidates from the content via
 * Gemini, filter them down to replacements with real Google Trends
 * interest, and merge the result into the post's checklist meta without
 * disturbing pairs the editor already included/ignored.
 */
class STK_Suggester {

	/**
	 * @return array The post's full, updated checklist (array of
	 *               { existing, replacement, status }), or a WP_Error if the
	 *               post doesn't exist.
	 */
	public static function suggest_for_post( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error( 'stk_no_post', 'Post not found', array( 'status' => 404 ) );
		}

		$checklist = get_post_meta( $post_id, STK_META_KEY, true );
		if ( ! is_array( $checklist ) ) {
			$checklist = array();
		}

		$plain_text = wp_strip_all_tags( $post->post_content );
		if ( '' === trim( $plain_text ) ) {
			return $checklist;
		}

		$settings   = STK_Settings::get();
		$candidates = STK_Gemini::extract_candidates( $post->post_title, $plain_text, $settings );
		if ( empty( $candidates ) ) {
			return $checklist;
		}

		$known_replacements = array_map( 'mb_strtolower', wp_list_pluck( $checklist, 'replacement' ) );
		$new_candidates      = array_values( array_filter( $candidates, function ( $candidate ) use ( $known_replacements ) {
			return ! in_array( mb_strtolower( $candidate['replacement'] ), $known_replacements, true );
		} ) );

		if ( empty( $new_candidates ) ) {
			return $checklist;
		}

		$replacement_keywords = wp_list_pluck( $new_candidates, 'replacement' );
		$trending_keywords    = STK_Trends::filter_by_interest( $replacement_keywords, $settings );
		$trending_lower       = array_map( 'mb_strtolower', $trending_keywords );

		$trending_candidates = array_values( array_filter( $new_candidates, function ( $candidate ) use ( $trending_lower ) {
			return in_array( mb_strtolower( $candidate['replacement'] ), $trending_lower, true );
		} ) );

		if ( empty( $trending_candidates ) ) {
			return $checklist;
		}

		$max_keywords  = isset( $settings['max_keywords'] ) ? (int) $settings['max_keywords'] : 6;
		$pending_count = count( array_filter( $checklist, function ( $item ) {
			return isset( $item['status'] ) && 'pending' === $item['status'];
		} ) );
		$room = $max_keywords - $pending_count;

		if ( $room <= 0 ) {
			return $checklist;
		}

		foreach ( array_slice( $trending_candidates, 0, $room ) as $candidate ) {
			$checklist[] = array(
				'existing'    => $candidate['existing'],
				'replacement' => $candidate['replacement'],
				'status'      => 'pending',
			);
		}

		update_post_meta( $post_id, STK_META_KEY, $checklist );

		return $checklist;
	}
}
