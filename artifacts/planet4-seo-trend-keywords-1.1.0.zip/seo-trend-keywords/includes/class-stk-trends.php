<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filters candidate keyword phrases down to the ones with real Google
 * search interest, using the same undocumented trends.google.com endpoints
 * the "google-trends-api" npm package scrapes. There is no official public
 * Google Trends API — this is unofficial and can break or get rate-limited,
 * so every failure mode fails open (keeps the candidate) rather than
 * silently dropping suggestions the editor should still see.
 */
class STK_Trends {

	const EXPLORE_URL   = 'https://trends.google.com/trends/api/explore';
	const MULTILINE_URL = 'https://trends.google.com/trends/api/widgetdata/multiline';
	const BATCH_SIZE    = 5; // Google Trends allows at most 5 comparisonItems per request.

	/**
	 * @param string[] $keywords
	 * @return string[] keywords whose average interest met the configured minimum
	 *                  (or that couldn't be checked, in which case they're kept).
	 */
	public static function filter_by_interest( array $keywords, array $settings ) {
		$keywords = array_values( array_unique( array_filter( array_map( 'trim', $keywords ) ) ) );
		if ( empty( $keywords ) ) {
			return array();
		}

		$geo          = ! empty( $settings['geo'] ) ? $settings['geo'] : 'IL';
		$hl           = ! empty( $settings['hl'] ) ? $settings['hl'] : 'iw';
		$min_interest = isset( $settings['min_interest'] ) ? (int) $settings['min_interest'] : 1;

		$scores = array();
		foreach ( array_chunk( $keywords, self::BATCH_SIZE ) as $batch ) {
			$batch_scores = self::fetch_batch_interest( $batch, $geo, $hl );

			if ( null === $batch_scores ) {
				error_log( 'STK_Trends: batch fetch failed, keeping candidates unfiltered: ' . implode( ', ', $batch ) );
				foreach ( $batch as $keyword ) {
					$scores[ $keyword ] = null; // null = "couldn't check, keep it".
				}
				continue;
			}

			$scores = array_merge( $scores, $batch_scores );
		}

		$kept = array();
		foreach ( $scores as $keyword => $score ) {
			if ( null === $score || $score >= $min_interest ) {
				$kept[] = $keyword;
			} else {
				error_log( "STK_Trends: dropping '{$keyword}' — interest {$score} below minimum {$min_interest}" );
			}
		}

		return $kept;
	}

	/**
	 * @return array<string,float>|null Map of keyword => average interest (0-100 scale),
	 *                                   or null if the batch could not be fetched at all.
	 */
	private static function fetch_batch_interest( array $batch, $geo, $hl ) {
		$comparison_items = array();
		foreach ( $batch as $keyword ) {
			$comparison_items[] = array(
				'keyword' => $keyword,
				'geo'     => $geo,
				'time'    => 'today 12-m',
			);
		}

		$explore_req = array(
			'comparisonItem' => $comparison_items,
			'category'       => 0,
			'property'       => '',
		);

		$explore_url = self::EXPLORE_URL . '?' . http_build_query( array(
			'hl'  => $hl,
			'tz'  => -120,
			'req' => wp_json_encode( $explore_req ),
		) );

		$explore_body = self::get( $explore_url );
		if ( null === $explore_body ) {
			return null;
		}

		$explore_json = self::strip_and_decode( $explore_body );
		if ( null === $explore_json || empty( $explore_json['widgets'] ) ) {
			error_log( 'STK_Trends: unexpected /explore response shape' );
			return null;
		}

		$timeseries_widget = null;
		foreach ( $explore_json['widgets'] as $widget ) {
			if ( isset( $widget['id'] ) && 'TIMESERIES' === $widget['id'] ) {
				$timeseries_widget = $widget;
				break;
			}
		}
		if ( ! $timeseries_widget || empty( $timeseries_widget['token'] ) || empty( $timeseries_widget['request'] ) ) {
			error_log( 'STK_Trends: no TIMESERIES widget in /explore response' );
			return null;
		}

		$multiline_url = self::MULTILINE_URL . '?' . http_build_query( array(
			'hl'    => $hl,
			'tz'    => -120,
			'req'   => wp_json_encode( $timeseries_widget['request'] ),
			'token' => $timeseries_widget['token'],
		) );

		$multiline_body = self::get( $multiline_url );
		if ( null === $multiline_body ) {
			return null;
		}

		$multiline_json = self::strip_and_decode( $multiline_body );
		if ( null === $multiline_json || empty( $multiline_json['default']['timelineData'] ) ) {
			error_log( 'STK_Trends: unexpected /widgetdata/multiline response shape' );
			return null;
		}

		$sums  = array_fill( 0, count( $batch ), 0 );
		$count = 0;
		foreach ( $multiline_json['default']['timelineData'] as $point ) {
			if ( empty( $point['value'] ) || ! is_array( $point['value'] ) ) {
				continue;
			}
			foreach ( $point['value'] as $i => $value ) {
				if ( isset( $sums[ $i ] ) ) {
					$sums[ $i ] += (int) $value;
				}
			}
			++$count;
		}
		if ( 0 === $count ) {
			return null;
		}

		$scores = array();
		foreach ( $batch as $i => $keyword ) {
			$scores[ $keyword ] = isset( $sums[ $i ] ) ? round( $sums[ $i ] / $count, 1 ) : 0.0;
		}
		return $scores;
	}

	private static function get( $url ) {
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 20,
				'headers' => array(
					// Google Trends' unofficial endpoints reject requests without a
					// browser-like User-Agent.
					'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			error_log( 'STK_Trends: request error — ' . $response->get_error_message() );
			return null;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			error_log( "STK_Trends: HTTP {$code} from {$url}" );
			return null;
		}

		return wp_remote_retrieve_body( $response );
	}

	private static function strip_and_decode( $body ) {
		// These endpoints prefix the JSON with ")]}'," to prevent naive JSON hijacking.
		$body = preg_replace( '/^\)\]\}\',?\s*/', '', (string) $body );
		$json = json_decode( $body, true );
		return is_array( $json ) ? $json : null;
	}
}
