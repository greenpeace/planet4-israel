<?php
/**
 * Plugin Name: SEO Trend Keywords
 * Description: On save, finds phrases in the page's content that could be swapped for a trending Google SEO keyword, and shows a sticky checklist in the editor until each replacement is approved or ignored.
 * Version: 1.1.0
 * Author: Elad Aybes
 * Text Domain: stk
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'STK_PLUGIN_FILE', __FILE__ );
define( 'STK_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'STK_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'STK_VERSION', '1.1.0' );
define( 'STK_META_KEY', '_stk_keywords' );

require_once STK_PLUGIN_DIR . 'includes/class-stk-settings.php';
require_once STK_PLUGIN_DIR . 'includes/class-stk-admin.php';
require_once STK_PLUGIN_DIR . 'includes/class-stk-gemini.php';
require_once STK_PLUGIN_DIR . 'includes/class-stk-trends.php';
require_once STK_PLUGIN_DIR . 'includes/class-stk-suggester.php';
require_once STK_PLUGIN_DIR . 'includes/class-stk-rest.php';

add_action( 'plugins_loaded', function () {
	STK_Admin::instance();
	STK_REST::instance();
} );

/**
 * Post meta holding the suggestion checklist: an array of
 * { existing: string, replacement: string, status: 'pending'|'included'|'ignored' }.
 * `existing` is a verbatim phrase from the post's content; `replacement` is
 * the higher-value SEO keyword phrase suggested in its place. Registered
 * with show_in_rest so the block editor can read/write it directly on the
 * post entity (the ticker persists decisions immediately, independent of
 * the post's own Save/Update cycle).
 */
add_action( 'init', function () {
	$schema = array(
		'type'  => 'array',
		'items' => array(
			'type'       => 'object',
			'properties' => array(
				'existing'    => array( 'type' => 'string' ),
				'replacement' => array( 'type' => 'string' ),
				'status'      => array(
					'type' => 'string',
					'enum' => array( 'pending', 'included', 'ignored' ),
				),
			),
		),
	);

	foreach ( array( 'post', 'page' ) as $post_type ) {
		register_post_meta(
			$post_type,
			STK_META_KEY,
			array(
				'type'          => 'array',
				'single'        => true,
				'default'       => array(),
				'show_in_rest'  => array( 'schema' => $schema ),
				'auth_callback' => function ( $allowed, $meta_key, $post_id ) {
					return current_user_can( 'edit_post', $post_id );
				},
			)
		);
	}
} );

add_action( 'enqueue_block_editor_assets', function () {
	$asset_file = STK_PLUGIN_DIR . 'build/index.asset.php';
	if ( ! file_exists( $asset_file ) ) {
		return;
	}
	$asset = require $asset_file;

	wp_enqueue_script(
		'stk-editor',
		STK_PLUGIN_URL . 'build/index.js',
		$asset['dependencies'],
		$asset['version'],
		true
	);

	wp_enqueue_style(
		'stk-editor',
		STK_PLUGIN_URL . 'build/style-index.css',
		array(),
		$asset['version']
	);

	wp_localize_script(
		'stk-editor',
		'stkData',
		array(
			'restNamespace' => 'seo-trend-keywords/v1',
			'metaKey'       => STK_META_KEY,
		)
	);
} );
