import { registerPlugin } from '@wordpress/plugins';
import { useSelect, useDispatch, subscribe } from '@wordpress/data';
import { useRef, useEffect } from '@wordpress/element';
import { createPortal } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { __, sprintf } from '@wordpress/i18n';
import './style.scss';

const META_KEY = ( window.stkData && window.stkData.metaKey ) || '_stk_keywords';

/**
 * Walks the current block tree (including nested innerBlocks) looking for a
 * string attribute containing `existing` verbatim, and swaps in
 * `replacement` on the first match found. Best-effort: if the editor's
 * content has changed since the suggestion was generated, the phrase may no
 * longer be found, in which case this returns false and the suggestion is
 * still marked resolved (the editor already made the call to approve it).
 */
function applyReplacementInBlocks( existing, replacement ) {
	const { getBlocks } = wp.data.select( 'core/block-editor' );
	const { updateBlockAttributes } = wp.data.dispatch( 'core/block-editor' );

	const walk = ( blocks ) => {
		for ( const block of blocks ) {
			const attributes = block.attributes || {};
			for ( const key of Object.keys( attributes ) ) {
				const value = attributes[ key ];
				if ( typeof value === 'string' && value.includes( existing ) ) {
					updateBlockAttributes( block.clientId, {
						[ key ]: value.replace( existing, replacement ),
					} );
					return true;
				}
			}
			if ( block.innerBlocks && block.innerBlocks.length && walk( block.innerBlocks ) ) {
				return true;
			}
		}
		return false;
	};

	return walk( getBlocks() );
}

function Ticker() {
	const { postId, postType, meta } = useSelect( ( select ) => {
		const editor = select( 'core/editor' );
		return {
			postId: editor.getCurrentPostId(),
			postType: editor.getCurrentPostType(),
			meta: editor.getEditedPostAttribute( 'meta' ) || {},
		};
	}, [] );

	const { editPost } = useDispatch( 'core/editor' );
	const { saveEntityRecord } = useDispatch( 'core' );

	const requestingRef = useRef( false );

	// After every successful (non-auto) save, ask the backend to (re)run
	// replacement suggestion for this post and merge any new results into meta.
	useEffect( () => {
		let wasSaving = false;

		return subscribe( () => {
			const editor = wp.data.select( 'core/editor' );
			const isSaving = editor.isSavingPost() && ! editor.isAutosavingPost();

			if ( wasSaving && ! isSaving && editor.didPostSaveRequestSucceed() && ! requestingRef.current ) {
				const id = editor.getCurrentPostId();
				if ( id ) {
					requestingRef.current = true;
					apiFetch( {
						path: '/seo-trend-keywords/v1/suggest',
						method: 'POST',
						data: { id },
					} )
						.then( ( response ) => {
							const current = wp.data.select( 'core/editor' ).getEditedPostAttribute( 'meta' ) || {};
							editPost( { meta: { ...current, [ META_KEY ]: response.keywords } } );
						} )
						.catch( () => {} )
						.finally( () => {
							requestingRef.current = false;
						} );
				}
			}

			wasSaving = isSaving;
		} );
	}, [ editPost ] );

	const checklist = Array.isArray( meta[ META_KEY ] ) ? meta[ META_KEY ] : [];
	// Defensively require non-empty existing/replacement strings — guards against
	// rendering blank chips if a post has leftover data from an older meta schema
	// (e.g. pre-1.1.0's flat `keyword` field) or any other malformed entry.
	const pending = checklist.filter(
		( item ) => item.status === 'pending' && item.existing && item.replacement
	);

	if ( ! pending.length ) {
		return null;
	}

	const resolve = ( target, status ) => {
		if ( status === 'included' ) {
			const applied = applyReplacementInBlocks( target.existing, target.replacement );
			if ( ! applied ) {
				// eslint-disable-next-line no-console
				console.warn(
					'SEO Trend Keywords: could not find the original text to replace (content may have changed since the suggestion was made).',
					target
				);
			}
		}

		const updated = checklist.map( ( item ) =>
			item.existing === target.existing && item.replacement === target.replacement
				? { ...item, status }
				: item
		);
		editPost( { meta: { ...meta, [ META_KEY ]: updated } } );
		saveEntityRecord( 'postType', postType, { id: postId, meta: { [ META_KEY ]: updated } } );
	};

	return createPortal(
		<div className="stk-ticker">
			<span className="stk-ticker__label">
				{ __( 'Trending SEO replacements for this page:', 'stk' ) }
			</span>
			{ pending.map( ( item ) => (
				<span className="stk-ticker__chip" key={ `${ item.existing }→${ item.replacement }` }>
					<span className="stk-ticker__word">
						{ sprintf(
							/* translators: 1: existing phrase, 2: suggested replacement phrase */
							__( '"%1$s" → "%2$s"', 'stk' ),
							item.existing,
							item.replacement
						) }
					</span>
					<button
						type="button"
						className="is-add"
						title={ __( 'Apply this replacement', 'stk' ) }
						onClick={ () => resolve( item, 'included' ) }
					>
						✓
					</button>
					<button
						type="button"
						className="is-ignore"
						title={ __( 'Keep the original text', 'stk' ) }
						onClick={ () => resolve( item, 'ignored' ) }
					>
						✕
					</button>
				</span>
			) ) }
		</div>,
		document.body
	);
}

registerPlugin( 'seo-trend-keywords', { render: Ticker } );
