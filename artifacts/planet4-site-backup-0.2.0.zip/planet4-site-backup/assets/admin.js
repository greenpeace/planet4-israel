(function () {
	'use strict';
	var $ = function (id) { return document.getElementById(id); };
	var E = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
	var CK = 'p4sb_resume:' + location.host;
	var CHECKPOINT_BYTES = 16 * 1048576;
	var token = '', aborted = false, running = false, allTables = [], budget = 8, wakeLock = null;
	var hasFS = !!(window.showSaveFilePicker && window.showOpenFilePicker);

	function fmt(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB'; }
	function log(m) { var l = $('p4sb-log'); l.style.display = 'block'; l.textContent += new Date().toLocaleTimeString() + '  ' + m + '\n'; l.scrollTop = l.scrollHeight; }
	function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
	function b64(s) { var bin = atob(s), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
	function store(k, v) { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
	function load(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }

	/* ---------- network (stateless server => retrying a step is always safe) ---------- */
	async function call(action, data) {
		var wait = 3000, lastErr;
		for (var attempt = 1; attempt <= 8; attempt++) {
			try {
				var fd = new FormData();
				fd.append('action', 'p4sb_' + action);
				fd.append('_ajax_nonce', P4SB.nonce);
				if (token) fd.append('token', token);
				Object.keys(data || {}).forEach(function (k) { fd.append(k, typeof data[k] === 'string' ? data[k] : JSON.stringify(data[k])); });
				if (action === 'step') fd.append('budget', String(budget));
				var res = await fetch(P4SB.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin', cache: 'no-store' });
				var text = await res.text(), json;
				try { json = JSON.parse(text); } catch (e) { throw new Error('HTTP ' + res.status + ' (not JSON – proxy/timeout)'); }
				if (!json.success) {
					var err = new Error(String(json.data));
					if (res.status === 401 || res.status === 403) { err.fatal = true; err.message = res.status === 401 ? 'פג תוקף האימות – רענן את העמוד ואמת מחדש (אפשר להמשיך את הגיבוי)' : 'נדחה: ' + json.data; }
					if (action === 'auth' || (res.status >= 400 && res.status < 500)) err.fatal = true;
					throw err;
				}
				return json.data;
			} catch (e) {
				if (e.fatal || aborted) throw e;
				lastErr = e;
				if (action === 'step') budget = Math.max(2, budget / 2); // server struggling → smaller steps
				log('שגיאה (' + e.message + ') – ניסיון ' + attempt + '/8, ממתין ' + wait / 1000 + ' שניות');
				await sleep(wait); wait = Math.min(wait * 2, 60000);
			}
		}
		throw lastErr;
	}

	/* ---------- UI helpers ---------- */
	function selectedTables() { return Array.prototype.map.call($('p4sb-tables').querySelectorAll('input:checked'), function (i) { return i.value; }); }

	async function loadTables() {
		var box = $('p4sb-tables');
		try {
			var d = await call('init', {});
			allTables = d.tables;
			var total = 0, html = '', extra = '';
			d.tables.forEach(function (t) {
				var line = '<label style="display:block"><input type="checkbox" ' + (t.prefixed ? 'checked' : '') + ' value="' + E(t.name) + '"> <code>' + E(t.name) + '</code> – ~' + Number(t.rows).toLocaleString() + ' שורות, ' + fmt(t.bytes) + '</label>';
				if (t.prefixed) { total += t.bytes; html += line; } else extra += line;
			});
			box.innerHTML = '<p><strong>' + d.tables.filter(function (t) { return t.prefixed; }).length + ' טבלאות, ~' + fmt(total) + ' (לפני דחיסה)</strong></p>' + html +
				(extra ? '<hr><p>טבלאות במסד הנתונים שאינן של האתר (לא מסומנות כברירת מחדל):</p>' + extra : '');
		} catch (e) { box.textContent = 'שגיאה בטעינת הטבלאות: ' + e.message; }
	}

	function stamp() { var d = new Date(), p = function (n) { return String(n).padStart(2, '0'); }; return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()); }
	function download(blob, name) { var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000); }

	/* ---------- integrity ---------- */
	var CRC_T = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); t[n] = c >>> 0; } return t; })();
	function crcAdd(reg, u8) { for (var i = 0; i < u8.length; i++) reg = CRC_T[(reg ^ u8[i]) & 255] ^ (reg >>> 8); return reg >>> 0; }
	function crcFinal(reg) { return ((reg ^ 0xFFFFFFFF) >>> 0).toString(16).padStart(8, '0'); }
	async function crcOfBlob(blob) { var rd = blob.stream().getReader(), reg = 0xFFFFFFFF; for (;;) { var r = await rd.read(); if (r.done) break; reg = crcAdd(reg, r.value); } return reg; }
	/** Every chunk is a complete gzip member: decompress it once to be sure it arrived intact (gzip carries its own CRC). */
	async function chunkOk(u8) {
		if (!window.DecompressionStream) return true;
		try { var ab = await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer(); return ab.byteLength > 0; } catch (e) { return false; }
	}

	function showResume() {
		var st = load(CK), box = $('p4sb-resume');
		if (!st || !hasFS) { box.style.display = 'none'; return; }
		box.style.display = 'block';
		box.innerHTML = '<p>נמצא גיבוי שהופסק: <code>' + E(st.fileName) + '</code> – נשמרו ' + fmt(st.committed) + ', הגיע לטבלה ' + (st.ti + 1) + ' מתוך ' + st.tables.length + '. ' +
			'<button class="button button-primary" id="p4sb-resume-btn">המשך</button> <button class="button" id="p4sb-resume-drop">מחק מצב שמור</button></p>';
		$('p4sb-resume-btn').onclick = function () { run(st); };
		$('p4sb-resume-drop').onclick = function () { store(CK, null); showResume(); };
	}

	/* ---------- main backup loop ---------- */
	async function run(resumeState) {
		if (running) return;
		var st, W = { handle: null, writer: null, parts: [], written: 0, since: 0, crc: 0xFFFFFFFF };

		// File pickers need the click's user gesture → do them before any other await.
		if (resumeState) {
			st = resumeState;
			try {
				var hs = await window.showOpenFilePicker({ types: [{ description: 'gzip SQL', accept: { 'application/gzip': ['.gz'] } }] });
				W.handle = hs[0];
				var f = await W.handle.getFile();
				if (f.size < st.committed) { alert('הקובץ שנבחר קטן מהמצב השמור (' + fmt(f.size) + ' < ' + fmt(st.committed) + '). בחר את הקובץ הנכון.'); return; }
				W.writer = await W.handle.createWritable({ keepExistingData: true });
				await W.writer.truncate(st.committed); await W.writer.seek(st.committed);
				W.written = st.committed; W.crc = await crcOfBlob(f.slice(0, st.committed));
			} catch (e) { if (e.name !== 'AbortError') alert('לא ניתן לפתוח את הקובץ: ' + e.message); return; }
		} else {
			var tables = selectedTables();
			if (!tables.length) { alert('לא נבחרו טבלאות'); return; }
			st = { fileName: location.hostname.replace(/[^a-z0-9.-]/gi, '_') + '-db-' + stamp() + '.sql.gz', tables: tables,
				opts: { skip_transients: $('p4sb-skip-transients').checked, compat: $('p4sb-compat').checked }, ti: 0, cursor: {}, rows: 0, dumped: {}, committed: 0, header: false };
			if (hasFS) {
				try {
					W.handle = await window.showSaveFilePicker({ suggestedName: st.fileName, types: [{ description: 'gzip SQL', accept: { 'application/gzip': ['.gz'] } }] });
					W.writer = await W.handle.createWritable();
				} catch (e) { if (e.name === 'AbortError') return; W.handle = null; W.writer = null; }
			}
		}

		async function put(s) { var u = b64(s); if (!(await chunkOk(u))) throw new Error('חלק פגום התקבל מהשרת (נבדק לפני כתיבה) – אפשר להמשיך מהנקודה האחרונה'); W.crc = crcAdd(W.crc, u); W.written += u.length; W.since += u.length; if (W.writer) await W.writer.write(u); else W.parts.push(u); }
		function saveState() { store(CK, { fileName: st.fileName, tables: st.tables, opts: st.opts, ti: st.ti, cursor: st.cursor, rows: st.rows, dumped: st.dumped, committed: W.written, savedAt: Date.now() }); }
		/** Commit what's been written so far to disk (a File System Access stream only persists on close) and remember where we are. */
		async function checkpoint() {
			if (!W.writer) return;
			await W.writer.close();
			W.writer = await W.handle.createWritable({ keepExistingData: true });
			await W.writer.seek(W.written);
			W.since = 0; saveState();
		}

		running = true; aborted = false;
		$('p4sb-start').disabled = true; $('p4sb-abort').style.display = ''; $('p4sb-summary').innerHTML = ''; $('p4sb-log').textContent = ''; $('p4sb-resume').style.display = 'none';
		$('p4sb-progress').style.display = 'block'; $('p4sb-bar').style.width = '0';
		var beforeUnload = function (e) { e.preventDefault(); e.returnValue = ''; };
		window.addEventListener('beforeunload', beforeUnload);
		try { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
		var t0 = Date.now(), finished = false;
		try {
			if (!hasFS) log('הדפדפן לא תומך בשמירה ישירה לדיסק (מומלץ Chrome/Edge): הגיבוי נשמר בזיכרון ולא ניתן להמשיך אם יופסק.');
			var init = await call('init', { start: 1 });
			var sizes = {}, estRows = {}, totalBytes = 0, doneBytes = 0;
			init.tables.forEach(function (t) { sizes[t.name] = t.bytes; estRows[t.name] = t.rows; });
			st.tables.forEach(function (t, i) { totalBytes += sizes[t] || 1; if (i < st.ti) doneBytes += sizes[t] || 1; });

			if (!st.header) { await put(init.header); st.header = true; await checkpoint(); }

			for (; st.ti < st.tables.length; st.ti++) {
				var name = st.tables[st.ti], done = false;
				if (!(name in sizes)) throw new Error('הטבלה ' + name + ' לא קיימת יותר');
				log((st.rows ? 'ממשיך: ' : 'מתחיל: ') + name);
				while (!done) {
					if (aborted) throw new Error('נעצר ע"י המשתמש');
					var r = await call('step', { table: name, cursor: st.cursor, opts: st.opts });
					await put(r.sql);
					st.cursor = r.cursor; st.rows += r.rows; done = r.done;
					budget = Math.min(8, budget + 0.5);
					var frac = done ? 1 : Math.min(0.95, st.rows / Math.max(1, estRows[name] || 1));
					$('p4sb-bar').style.width = (((doneBytes + (sizes[name] || 1) * frac) / totalBytes) * 100).toFixed(1) + '%';
					$('p4sb-status').textContent = 'טבלה ' + (st.ti + 1) + '/' + st.tables.length + ': ' + name + ' – ' + st.rows.toLocaleString() + ' שורות | נכתבו ' + fmt(W.written) + ' | ' + Math.round((Date.now() - t0) / 1000) + ' שנ׳';
					if (done) { st.dumped[name] = st.rows; }
					// state after this step must describe "next work to do": advance table pointer when finished
					if (done) { st.cursor = {}; st.rows = 0; }
					if (W.writer && W.since >= CHECKPOINT_BYTES) {
						// when done, saved state points at the *next* table (ti+1) with an empty cursor
						if (done) { st.ti++; await checkpoint(); st.ti--; } else await checkpoint();
					}
					await sleep(150);
				}
				doneBytes += sizes[name] || 1;
				log('הסתיים: ' + name + ' (' + st.dumped[name].toLocaleString() + ' שורות)');
			}

			var fin = await call('finish', { tables: st.tables, opts: st.opts });
			await put(fin.footer);
			var blob;
			if (W.writer) { await W.writer.close(); W.writer = null; blob = await W.handle.getFile(); }
			else { blob = new Blob(W.parts, { type: 'application/gzip' }); download(blob, st.fileName); }
			finished = true; store(CK, null);
			$('p4sb-bar').style.width = '100%';

			var bad = [], list = '';
			st.tables.forEach(function (t) {
				var ok = fin.expected[t] === st.dumped[t];
				if (!ok) bad.push(t);
				list += '<tr style="' + (ok ? '' : 'background:#fde8e8') + '"><td><code>' + E(t) + '</code></td><td>' + Number(st.dumped[t]).toLocaleString() + '</td><td>' + Number(fin.expected[t]).toLocaleString() + '</td><td>' + (ok ? '✓' : 'שונה') + '</td></tr>';
			});
			$('p4sb-status').textContent = 'מאמת את הקובץ…';
			var verified = null; // null = not verifiable (in-memory download)
			if (W.handle) { try { verified = blob.size === W.written && (await crcOfBlob(blob)) === W.crc; } catch (e) { verified = false; } }
			var manifest = { file: st.fileName, bytes_gz: W.written, crc32_gz: crcFinal(W.crc), verified: verified, seconds: Math.round((Date.now() - t0) / 1000), options: st.opts, site: fin.info,
				tables: st.tables.map(function (t) { return { name: t, rows_dumped: st.dumped[t], rows_in_db_at_end: fin.expected[t] }; }) };
			download(new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' }), st.fileName.replace(/\.sql\.gz$/, '') + '.manifest.json');
			$('p4sb-status').textContent = 'הסתיים: ' + st.fileName + ' (' + fmt(W.written) + ' דחוס)';
			$('p4sb-summary').innerHTML = '<h2>סיכום</h2>' +
				(verified === null ? '' : verified ? '<div class="notice notice-success inline"><p>אימות קובץ: מה שנקרא בחזרה מהדיסק זהה למה שהתקבל מהשרת ✓ (' + fmt(W.written) + ', CRC32 ' + crcFinal(W.crc) + ')</p></div>' : '<div class="notice notice-error inline"><p>אימות הקובץ נכשל – הקובץ בדיסק שונה ממה שהתקבל. הרץ שוב.</p></div>') +
				(bad.length ? '<div class="notice notice-warning inline"><p>בטבלאות הבאות מספר השורות בסוף שונה ממה שנשמר (נכתבו נתונים במהלך הגיבוי – טבלאות כמו Action Scheduler, לוגים וטפסים): <code>' + E(bad.join(', ')) + '</code></p></div>' : '<div class="notice notice-success inline"><p>כל הטבלאות תואמות ✓</p></div>') +
				'<p>מידע על המדיה: ' + Number(fin.info.attachments).toLocaleString() + ' קבצים בספרייה. כתובת בסיס: <code>' + E(fin.info.uploads_baseurl) + '</code> – המדיה לא כלולה בקובץ הזה (ראה README).</p>' +
				'<table class="widefat striped" style="max-width:760px;direction:ltr"><thead><tr><th>Table</th><th>Dumped</th><th>In DB now</th><th></th></tr></thead><tbody>' + list + '</tbody></table>';
		} catch (e) {
			$('p4sb-status').textContent = 'נעצר: ' + e.message; log('נעצר: ' + e.message);
			if (W.writer) { try { await W.writer.close(); } catch (x) {} }
			if (!finished && W.handle) { $('p4sb-status').textContent += ' — אפשר להמשיך מהנקודה האחרונה שנשמרה.'; }
		} finally {
			running = false; $('p4sb-start').disabled = false; $('p4sb-abort').style.display = 'none';
			window.removeEventListener('beforeunload', beforeUnload);
			if (wakeLock) { try { wakeLock.release(); } catch (e) {} wakeLock = null; }
			showResume();
		}
	}

	/* ---------- boot ---------- */
	function unlocked() { $('p4sb-auth').style.display = 'none'; $('p4sb-main').style.display = 'block'; loadTables(); showResume(); }
	$('p4sb-auth-btn').addEventListener('click', async function () {
		var msg = $('p4sb-auth-msg'); msg.textContent = '';
		try { var d = await call('auth', { password: $('p4sb-pw').value }); token = d.token; $('p4sb-pw').value = ''; unlocked(); }
		catch (e) { msg.textContent = e.message; }
	});
	$('p4sb-pw').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('p4sb-auth-btn').click(); });
	$('p4sb-start').addEventListener('click', function () { run(null); });
	$('p4sb-abort').addEventListener('click', function () { aborted = true; });
	if (!P4SB.needReauth) unlocked();
})();
