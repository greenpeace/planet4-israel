# Planet4 Site Backup – v0.3.0 (גיבוי מלא + שחזור לוורדפרס נקי)

**מה חדש:** Tools → גיבוי אתר → "גיבוי מלא" יוצר תיקייה: `database.sql.gz`, `code.tar.gz` (plugins, mu-plugins, themes, languages + drop-ins),
`manifest.json` (גרסאות, הגדרות, CRC), `restore.sh`, `RESTORE.md`. הקוד מוחרג מקבצים רגישים (`.env`, מפתחות, `*.json` של service accounts, `debug.log`, `.git`, `node_modules`).
סודות מ-wp-config אינם מיוצאים (רק שמות). המדיה: `backup_site.py` (ראה למטה).

**שחזור:** `bash restore.sh --target DIR --url https://new --db-name .. --db-user .. --db-pass .. [--media-dir uploads]` – ראה `RESTORE.md`.
ברירת מחדל = "העתק בטוח": ללא שליחת מיילים/קריאות ל-API חיצוניים, noindex, WP-Cron כבוי. `--live` לביטול.

---

# Planet4 Site Backup (v0.2.0)

גיבוי מלא של בסיס הנתונים מתוך wp-admin, בחלקים קטנים (ללא timeout של Cloudflare).
הקובץ **לא נשמר בשרת** – הוא עובר ישירות לדפדפן של מי שמריץ את הגיבוי ונכתב לדיסק שלו.

## יצירת גיבוי
1. wp-admin ← כלים ← **גיבוי אתר**.
2. הזן את סיסמת הוורדפרס שלך (אימות נוסף – הגיבוי מכיל מידע רגיש). אם אתה מתחבר דרך SSO ואין לך סיסמה: פרופיל ← הגדר סיסמה חדשה.
3. "התחל גיבוי" ← בחר היכן לשמור את הקובץ (Chrome / Edge – הקובץ נכתב ישירות לדיסק).
4. השאר את הלשונית פתוחה. אם היא נסגרה או שהחיבור נפל: חזור לעמוד, אמת, ולחץ **המשך** (ותבחר את אותו קובץ).
5. בסוף מופיע אימות: "מה שנקרא בחזרה מהדיסק זהה למה שהתקבל מהשרת ✓" ו"כל הטבלאות תואמות ✓". יורדים גם `*.manifest.json`.
6. בדיקה ידנית מומלצת: `gzip -t backup.sql.gz` (ללא פלט = תקין).

## מה בגיבוי ומה לא
| רכיב | איפה הוא מגובה |
|---|---|
| בסיס נתונים (תכנים, הגדרות, טפסים, משתמשים, תפריטים...) | הפלאגין הזה |
| קוד (תבנית, פלאגינים, גרסאות) | GitHub: `greenpeace/planet4-israel` + `production.json` (מומלץ לשמור tag של המצב הנוכחי) |
| מדיה (נשמרת בענן: `https://www.greenpeace.org/static/planet4-israel-stateless/...`) | `site-backup/backup_site.py` – מוריד את כל קבצי המדיה, כולל תמונות שמוזכרות בתוכן ולא בספרייה |

## שחזור בשרת אחר
1. הקם WordPress/Planet4 חדש מאותו קוד (repo `planet4-israel`, אותן גרסאות).
2. צור מסד נתונים ריק (utf8mb4) ובדוק את הקובץ: `gzip -t backup.sql.gz`.
3. ייבוא: `gunzip -c backup.sql.gz | mysql -u USER -p DBNAME`
   - אם נכשל על `Unknown collation: utf8mb4_0900_ai_ci` (MariaDB / MySQL ישן): הרץ גיבוי עם "תאימות" מסומן, או: `gunzip -c backup.sql.gz | sed 's/utf8mb4_0900_ai_ci/utf8mb4_unicode_520_ci/g' | mysql ...`
   - אם נכשל על `max_allowed_packet`: הגדל אותו בשרת היעד (למשל `--max_allowed_packet=256M`).
4. מדיה: האתר שומר מדיה בענן. בשרת חדש יש שתי דרכים:
   - **גישה ל-bucket המקורי / העתקה שלו:** הצבע את הגדרות ה-stateless של האתר החדש אליו.
   - **שרת עצמאי:** העתק את תיקיית `media/www.greenpeace.org/static/planet4-israel-stateless/` (מהסקריפט) אל `wp-content/uploads/`, כבה את מצב ה-stateless בפלאגין שמנהל את הענן, והחלף כתובות (שלב 5).
5. החלפת כתובות (ראשית כתובת האתר, ואז כתובת המדיה אם צריך):
   - `wp search-replace 'https://www.greenpeace.org/israel' 'https://NEW-DOMAIN/PATH' --all-tables --skip-columns=guid`
   - `wp search-replace 'https://www.greenpeace.org/static/planet4-israel-stateless' 'https://NEW-DOMAIN/wp-content/uploads' --all-tables --skip-columns=guid`
6. `wp cache flush` ו-`wp rewrite flush`. בדוק התחברות, עמוד בית, טופס אחד ותמונה.

## אבטחה (מה בנוי פנימה)
- נגיש רק למנהלים (`manage_options`; ב-multisite – Super Admin) + nonce בכל בקשה.
- אימות סיסמה לפני גיבוי → טוקן חתום (HMAC) שקשור למשתמש ולסשן ההתחברות, תקף 6 שעות. נעילה אחרי 5 ניסיונות כושלים ל-15 דקות.
- יומן פעילות (10 אחרונים מוצגים בעמוד, 50 נשמרים), רישום ב-error_log, והודעת מייל למנהל האתר על כל אימות. אפשר לכבות את המייל: `add_filter('p4sb_notify_email','__return_false');`
- שמות טבלאות רק מרשימת הטבלאות האמיתית של מסד הנתונים; ערכי סמן/היסט מאומתים; אין שום SQL מהקלט.
- שום קובץ לא נכתב בשרת (אין קובץ גיבוי חשוף לאינטרנט).
- הקובץ עצמו כולל גיבובי סיסמאות, מפתחות API ונתוני טפסים/תורמים – אחסן מוצפן. `backup_site.py` שומר גם טיוטות ותכנים פרטיים כשמריצים עם סיסמת אפליקציה.
- לביטול האימות הנוסף (לא מומלץ): `add_filter('p4sb_require_reauth','__return_false');`

## מגבלות
- אינו צילום רגע אחד: אם נכתבים נתונים בזמן הגיבוי, ייתכן הבדל קטן בספירת שורות (מסומן בסיכום).
- ללא Chrome/Edge (אין שמירה ישירה לדיסק) הגיבוי נשמר בזיכרון ואי אפשר להמשיך אם הופסק.
- לא נכללים טריגרים/פרוצדורות/אירועים של MySQL (אין כאלה בוורדפרס רגיל).
