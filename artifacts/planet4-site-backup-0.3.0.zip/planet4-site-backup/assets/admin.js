(function () {
	'use strict';
	var $ = function (id) { return document.getElementById(id); };
	var E = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
	var CK = 'p4sb_resume:' + location.host;
	var CHECKPOINT_BYTES = 16 * 1048576;
	var token = '', aborted = false, running = false, allTables = [], budget = 8, wakeLock = null;
	var hasFS = !!(window.showSaveFilePicker && window.showOpenFilePicker);

	function fmt(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB'; }
	function log(m) { var l = $('p4sb-log'); l.style.display = 'block'; l.textContent += new Date().toLocaleTimeString() + '  ' + m + '\n'; l.scrollTop = l.scrollHeight; }
	function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
	function b64(s) { var bin = atob(s), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
	function store(k, v) { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
	function load(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }

	/* ---------- network (stateless server => retrying a step is always safe) ---------- */
	async function call(action, data) {
		var wait = 3000, lastErr;
		for (var attempt = 1; attempt <= 8; attempt++) {
			try {
				var fd = new FormData();
				fd.append('action', 'p4sb_' + action);
				fd.append('_ajax_nonce', P4SB.nonce);
				if (token) fd.append('token', token);
				Object.keys(data || {}).forEach(function (k) { fd.append(k, typeof data[k] === 'string' ? data[k] : JSON.stringify(data[k])); });
				if (action === 'step') fd.append('budget', String(budget));
				var res = await fetch(P4SB.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin', cache: 'no-store' });
				var text = await res.text(), json;
				try { json = JSON.parse(text); } catch (e) { throw new Error('HTTP ' + res.status + ' (not JSON – proxy/timeout)'); }
				if (!json.success) {
					var err = new Error(String(json.data));
					if (res.status === 401 || res.status === 403) { err.fatal = true; err.message = res.status === 401 ? 'פג תוקף האימות – רענן את העמוד ואמת מחדש (אפשר להמשיך את הגיבוי)' : 'נדחה: ' + json.data; }
					if (action === 'auth' || (res.status >= 400 && res.status < 500)) err.fatal = true;
					throw err;
				}
				return json.data;
			} catch (e) {
				if (e.fatal || aborted) throw e;
				lastErr = e;
				if (action === 'step') budget = Math.max(2, budget / 2); // server struggling → smaller steps
				log('שגיאה (' + e.message + ') – ניסיון ' + attempt + '/8, ממתין ' + wait / 1000 + ' שניות');
				await sleep(wait); wait = Math.min(wait * 2, 60000);
			}
		}
		throw lastErr;
	}

	/* ---------- UI helpers ---------- */
	function selectedTables() { return Array.prototype.map.call($('p4sb-tables').querySelectorAll('input:checked'), function (i) { return i.value; }); }

	async function loadTables() {
		var box = $('p4sb-tables');
		try {
			var d = await call('init', {});
			allTables = d.tables;
			var total = 0, html = '', extra = '';
			d.tables.forEach(function (t) {
				var line = '<label style="display:block"><input type="checkbox" ' + (t.prefixed ? 'checked' : '') + ' value="' + E(t.name) + '"> <code>' + E(t.name) + '</code> – ~' + Number(t.rows).toLocaleString() + ' שורות, ' + fmt(t.bytes) + '</label>';
				if (t.prefixed) { total += t.bytes; html += line; } else extra += line;
			});
			box.innerHTML = '<p><strong>' + d.tables.filter(function (t) { return t.prefixed; }).length + ' טבלאות, ~' + fmt(total) + ' (לפני דחיסה)</strong></p>' + html +
				(extra ? '<hr><p>טבלאות במסד הנתונים שאינן של האתר (לא מסומנות כברירת מחדל):</p>' + extra : '');
		} catch (e) { box.textContent = 'שגיאה בטעינת הטבלאות: ' + e.message; }
	}

	function stamp() { var d = new Date(), p = function (n) { return String(n).padStart(2, '0'); }; return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()); }
	function download(blob, name) { var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000); }

	/* ---------- integrity ---------- */
	var CRC_T = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); t[n] = c >>> 0; } return t; })();
	function crcAdd(reg, u8) { for (var i = 0; i < u8.length; i++) reg = CRC_T[(reg ^ u8[i]) & 255] ^ (reg >>> 8); return reg >>> 0; }
	function crcFinal(reg) { return ((reg ^ 0xFFFFFFFF) >>> 0).toString(16).padStart(8, '0'); }
	async function crcOfBlob(blob) { var rd = blob.stream().getReader(), reg = 0xFFFFFFFF; for (;;) { var r = await rd.read(); if (r.done) break; reg = crcAdd(reg, r.value); } return reg; }
	/** Every chunk is a complete gzip member: decompress it once to be sure it arrived intact (gzip carries its own CRC). */
	async function chunkOk(u8) {
		if (!window.DecompressionStream) return true;
		try { var ab = await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer(); return ab.byteLength > 0; } catch (e) { return false; }
	}

	function showResume() {
		var st = load(CK), box = $('p4sb-resume');
		if (!st || !hasFS) { box.style.display = 'none'; return; }
		box.style.display = 'block';
		box.innerHTML = '<p>נמצא גיבוי שהופסק: <code>' + E(st.fileName) + '</code> – נשמרו ' + fmt(st.committed) + ', הגיע לטבלה ' + (st.ti + 1) + ' מתוך ' + st.tables.length + '. ' +
			'<button class="button button-primary" id="p4sb-resume-btn">המשך</button> <button class="button" id="p4sb-resume-drop">מחק מצב שמור</button></p>';
		$('p4sb-resume-btn').onclick = function () { run(st); };
		$('p4sb-resume-drop').onclick = function () { store(CK, null); showResume(); };
	}

	/* ---------- main backup loop ---------- */
	async function run(resumeState, ctx) {
		if (running) return null;
		var st, W = { handle: null, writer: null, parts: [], written: 0, since: 0, crc: 0xFFFFFFFF };

		// File pickers need the click's user gesture → do them before any other await.
		if (resumeState) {
			st = resumeState;
			try {
				var hs = await window.showOpenFilePicker({ types: [{ description: 'gzip SQL', accept: { 'application/gzip': ['.gz'] } }] });
				W.handle = hs[0];
				var f = await W.handle.getFile();
				if (f.size < st.committed) { alert('הקובץ שנבחר קטן מהמצב השמור (' + fmt(f.size) + ' < ' + fmt(st.committed) + '). בחר את הקובץ הנכון.'); return null; }
				W.writer = await W.handle.createWritable({ keepExistingData: true });
				await W.writer.truncate(st.committed); await W.writer.seek(st.committed);
				W.written = st.committed; W.crc = await crcOfBlob(f.slice(0, st.committed));
			} catch (e) { if (e.name !== 'AbortError') alert('לא ניתן לפתוח את הקובץ: ' + e.message); return null; }
		} else {
			var tables = selectedTables();
			if (!tables.length) { alert('לא נבחרו טבלאות'); return null; }
			st = { fileName: ctx ? 'database.sql.gz' : location.hostname.replace(/[^a-z0-9.-]/gi, '_') + '-db-' + stamp() + '.sql.gz', tables: tables,
				opts: { skip_transients: $('p4sb-skip-transients').checked, compat: $('p4sb-compat').checked }, ti: 0, cursor: {}, rows: 0, dumped: {}, committed: 0, header: false };
			if (ctx && ctx.dir) {
				W.handle = await ctx.dir.getFileHandle(st.fileName, { create: true });
				W.writer = await W.handle.createWritable();
			} else if (hasFS) {
				try {
					W.handle = await window.showSaveFilePicker({ suggestedName: st.fileName, types: [{ description: 'gzip SQL', accept: { 'application/gzip': ['.gz'] } }] });
					W.writer = await W.handle.createWritable();
				} catch (e) { if (e.name === 'AbortError') return null; W.handle = null; W.writer = null; }
			}
		}

		async function put(s) { var u = b64(s); if (!(await chunkOk(u))) throw new Error('חלק פגום התקבל מהשרת (נבדק לפני כתיבה) – אפשר להמשיך מהנקודה האחרונה'); W.crc = crcAdd(W.crc, u); W.written += u.length; W.since += u.length; if (W.writer) await W.writer.write(u); else W.parts.push(u); }
		function saveState() { store(CK, { fileName: st.fileName, tables: st.tables, opts: st.opts, ti: st.ti, cursor: st.cursor, rows: st.rows, dumped: st.dumped, committed: W.written, savedAt: Date.now() }); }
		/** Commit what's been written so far to disk (a File System Access stream only persists on close) and remember where we are. */
		async function checkpoint() {
			if (!W.writer) return;
			await W.writer.close();
			W.writer = await W.handle.createWritable({ keepExistingData: true });
			await W.writer.seek(W.written);
			W.since = 0; saveState();
		}

		running = true; aborted = false;
		$('p4sb-start').disabled = true; $('p4sb-abort').style.display = ''; $('p4sb-summary').innerHTML = ''; $('p4sb-log').textContent = ''; $('p4sb-resume').style.display = 'none';
		$('p4sb-progress').style.display = 'block'; $('p4sb-bar').style.width = '0';
		var beforeUnload = function (e) { e.preventDefault(); e.returnValue = ''; };
		window.addEventListener('beforeunload', beforeUnload);
		try { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
		var t0 = Date.now(), finished = false, result = null;
		try {
			if (!hasFS) log('הדפדפן לא תומך בשמירה ישירה לדיסק (מומלץ Chrome/Edge): הגיבוי נשמר בזיכרון ולא ניתן להמשיך אם יופסק.');
			var init = await call('init', { start: 1 });
			var sizes = {}, estRows = {}, totalBytes = 0, doneBytes = 0;
			init.tables.forEach(function (t) { sizes[t.name] = t.bytes; estRows[t.name] = t.rows; });
			st.tables.forEach(function (t, i) { totalBytes += sizes[t] || 1; if (i < st.ti) doneBytes += sizes[t] || 1; });

			if (!st.header) { await put(init.header); st.header = true; await checkpoint(); }

			for (; st.ti < st.tables.length; st.ti++) {
				var name = st.tables[st.ti], done = false;
				if (!(name in sizes)) throw new Error('הטבלה ' + name + ' לא קיימת יותר');
				log((st.rows ? 'ממשיך: ' : 'מתחיל: ') + name);
				while (!done) {
					if (aborted) throw new Error('נעצר ע"י המשתמש');
					var r = await call('step', { table: name, cursor: st.cursor, opts: st.opts });
					await put(r.sql);
					st.cursor = r.cursor; st.rows += r.rows; done = r.done;
					budget = Math.min(8, budget + 0.5);
					var frac = done ? 1 : Math.min(0.95, st.rows / Math.max(1, estRows[name] || 1));
					$('p4sb-bar').style.width = (((doneBytes + (sizes[name] || 1) * frac) / totalBytes) * 100).toFixed(1) + '%';
					$('p4sb-status').textContent = 'טבלה ' + (st.ti + 1) + '/' + st.tables.length + ': ' + name + ' – ' + st.rows.toLocaleString() + ' שורות | נכתבו ' + fmt(W.written) + ' | ' + Math.round((Date.now() - t0) / 1000) + ' שנ׳';
					if (done) { st.dumped[name] = st.rows; }
					// state after this step must describe "next work to do": advance table pointer when finished
					if (done) { st.cursor = {}; st.rows = 0; }
					if (W.writer && W.since >= CHECKPOINT_BYTES) {
						// when done, saved state points at the *next* table (ti+1) with an empty cursor
						if (done) { st.ti++; await checkpoint(); st.ti--; } else await checkpoint();
					}
					await sleep(150);
				}
				doneBytes += sizes[name] || 1;
				log('הסתיים: ' + name + ' (' + st.dumped[name].toLocaleString() + ' שורות)');
			}

			var fin = await call('finish', { tables: st.tables, opts: st.opts });
			await put(fin.footer);
			var blob;
			if (W.writer) { await W.writer.close(); W.writer = null; blob = await W.handle.getFile(); }
			else { blob = new Blob(W.parts, { type: 'application/gzip' }); if (!ctx || ctx.download) download(blob, (ctx && ctx.prefix || '') + st.fileName); }
			finished = true; store(CK, null);
			$('p4sb-bar').style.width = '100%';

			var bad = [], list = '';
			st.tables.forEach(function (t) {
				var ok = fin.expected[t] === st.dumped[t];
				if (!ok) bad.push(t);
				list += '<tr style="' + (ok ? '' : 'background:#fde8e8') + '"><td><code>' + E(t) + '</code></td><td>' + Number(st.dumped[t]).toLocaleString() + '</td><td>' + Number(fin.expected[t]).toLocaleString() + '</td><td>' + (ok ? '✓' : 'שונה') + '</td></tr>';
			});
			$('p4sb-status').textContent = 'מאמת את הקובץ…';
			var verified = null; // null = not verifiable (in-memory download)
			if (W.handle) { try { verified = blob.size === W.written && (await crcOfBlob(blob)) === W.crc; } catch (e) { verified = false; } }
			var manifest = { file: st.fileName, bytes_gz: W.written, crc32_gz: crcFinal(W.crc), verified: verified, seconds: Math.round((Date.now() - t0) / 1000), options: st.opts, site: fin.info,
				tables: st.tables.map(function (t) { return { name: t, rows_dumped: st.dumped[t], rows_in_db_at_end: fin.expected[t] }; }) };
			if (!ctx) download(new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' }), st.fileName.replace(/\.sql\.gz$/, '') + '.manifest.json');
				result = { file: st.fileName, bytes_gz: W.written, crc32_gz: crcFinal(W.crc), verified: verified, tables: st.tables.length, rows: st.tables.reduce(function (a, t) { return a + (st.dumped[t] || 0); }, 0), mismatched_tables: bad, site: fin.info, options: st.opts };
			$('p4sb-status').textContent = 'הסתיים: ' + st.fileName + ' (' + fmt(W.written) + ' דחוס)';
			if (!ctx) $('p4sb-summary').innerHTML = '<h2>סיכום</h2>' +
				(verified === null ? '' : verified ? '<div class="notice notice-success inline"><p>אימות קובץ: מה שנקרא בחזרה מהדיסק זהה למה שהתקבל מהשרת ✓ (' + fmt(W.written) + ', CRC32 ' + crcFinal(W.crc) + ')</p></div>' : '<div class="notice notice-error inline"><p>אימות הקובץ נכשל – הקובץ בדיסק שונה ממה שהתקבל. הרץ שוב.</p></div>') +
				(bad.length ? '<div class="notice notice-warning inline"><p>בטבלאות הבאות מספר השורות בסוף שונה ממה שנשמר (נכתבו נתונים במהלך הגיבוי – טבלאות כמו Action Scheduler, לוגים וטפסים): <code>' + E(bad.join(', ')) + '</code></p></div>' : '<div class="notice notice-success inline"><p>כל הטבלאות תואמות ✓</p></div>') +
				'<p>מידע על המדיה: ' + Number(fin.info.attachments).toLocaleString() + ' קבצים בספרייה. כתובת בסיס: <code>' + E(fin.info.uploads_baseurl) + '</code> – המדיה לא כלולה בקובץ הזה (ראה README).</p>' +
				'<table class="widefat striped" style="max-width:760px;direction:ltr"><thead><tr><th>Table</th><th>Dumped</th><th>In DB now</th><th></th></tr></thead><tbody>' + list + '</tbody></table>';
		} catch (e) {
			$('p4sb-status').textContent = 'נעצר: ' + e.message; log('נעצר: ' + e.message);
			if (W.writer) { try { await W.writer.close(); } catch (x) {} }
			if (!finished && W.handle) { $('p4sb-status').textContent += ' — אפשר להמשיך מהנקודה האחרונה שנשמרה.'; }
		} finally {
			running = false; $('p4sb-start').disabled = false; $('p4sb-abort').style.display = 'none';
			window.removeEventListener('beforeunload', beforeUnload);
			if (wakeLock) { try { wakeLock.release(); } catch (e) {} wakeLock = null; }
			showResume();
		}
		return result;
	}

	/* ---------- code export (tar.gz of plugins/themes/mu-plugins/languages) ---------- */
	async function codeExport(ctx) {
		var W = { handle: null, writer: null, parts: [], written: 0, crc: 0xFFFFFFFF }, name = 'code.tar.gz', t0 = Date.now();
		if (ctx && ctx.dir) { W.handle = await ctx.dir.getFileHandle(name, { create: true }); W.writer = await W.handle.createWritable(); }
		else if (hasFS && !ctx) {
			try { W.handle = await window.showSaveFilePicker({ suggestedName: location.hostname.replace(/[^a-z0-9.-]/gi, '_') + '-code-' + stamp() + '.tar.gz', types: [{ description: 'tar.gz', accept: { 'application/gzip': ['.gz'] } }] }); W.writer = await W.handle.createWritable(); }
			catch (e) { if (e.name === 'AbortError') return null; W.handle = null; W.writer = null; }
		}
		async function put(s) { var u = b64(s); if (!(await chunkOk(u))) throw new Error('חלק פגום התקבל מהשרת'); W.crc = crcAdd(W.crc, u); W.written += u.length; if (W.writer) await W.writer.write(u); else W.parts.push(u); }
		var inv = await call('files_list', {}), files = inv.files, raw = 0, warnings = [], total = files.reduce(function (a, f) { return a + f[2]; }, 0), sent = 0;
		log('קוד: ' + files.length + ' קבצים, ' + fmt(total) + ' (לפני דחיסה), ' + inv.excluded_total + ' קבצים הוחרגו (רגישים/מיותרים)');
		var fi = 0, off = 0, STEP = 4 * 1048576;
		try {
			while (fi < files.length) {
				if (aborted) throw new Error('נעצר ע"י המשתמש');
				var cap = Math.max(256 * 1024, Math.min(8 * 1048576 - 1024, Math.floor(STEP * budget / 8))), items = [], bytes = 0;
				while (fi < files.length && items.length < 500 && bytes < cap) {
					var f = files[fi], left = f[2] - off, take = Math.min(left, cap - bytes);
					if (take <= 0 && f[2] > 0) break;
					items.push({ r: f[0], p: f[1], o: off, l: f[2] === 0 ? 0 : take, s: f[2] });
					bytes += take; off += take;
					if (off >= f[2]) { fi++; off = 0; }
				}
				var r = await call('files_step', { items: items });
				await put(r.data); raw += r.raw_bytes; sent += bytes; (r.warnings || []).forEach(function (w) { warnings.push(w); });
				budget = Math.min(8, budget + 0.5);
				$('p4sb-bar').style.width = (total ? Math.min(99, sent / total * 100) : 99).toFixed(1) + '%';
				$('p4sb-status').textContent = 'קוד: ' + fi + '/' + files.length + ' קבצים | ' + fmt(sent) + ' מתוך ' + fmt(total) + ' | ' + Math.round((Date.now() - t0) / 1000) + ' שנ׳';
				await sleep(100);
			}
			var e = await call('files_end', {}); await put(e.data);
			var blob;
			if (W.writer) { await W.writer.close(); W.writer = null; blob = await W.handle.getFile(); } else { blob = new Blob(W.parts, { type: 'application/gzip' }); if (!ctx || ctx.download) download(blob, (ctx && ctx.prefix || '') + name); }
			var verified = null;
			if (W.handle) { try { verified = blob.size === W.written && (await crcOfBlob(blob)) === W.crc; } catch (x) { verified = false; } }
			return { file: name, files: files.length, bytes_raw: raw, bytes_gz: W.written, crc32_gz: crcFinal(W.crc), verified: verified, excluded_total: inv.excluded_total, excluded: inv.excluded, warnings: warnings.slice(0, 200), seconds: Math.round((Date.now() - t0) / 1000) };
		} catch (e) { if (W.writer) { try { await W.writer.close(); } catch (x) {} } throw e; }
	}

	async function writeText(dir, name, text) {
		if (dir) { var h = await dir.getFileHandle(name, { create: true }), w = await h.createWritable(); await w.write(text); await w.close(); }
		else download(new Blob([text], { type: 'text/plain' }), name);
	}
	function busy(on) {
		running = on; ['p4sb-full', 'p4sb-start', 'p4sb-code'].forEach(function (i) { $(i).disabled = on; });
		$('p4sb-abort').style.display = on ? '' : 'none';
		if (on) { aborted = false; $('p4sb-summary').innerHTML = ''; $('p4sb-log').textContent = ''; $('p4sb-resume').style.display = 'none'; $('p4sb-progress').style.display = 'block'; $('p4sb-bar').style.width = '0'; }
	}
	function tablesSelectedOk() { if (!selectedTables().length) { alert('לא נבחרו טבלאות'); return false; } return true; }

	async function codeOnly() {
		if (running) return;
		busy(true);
		var bu = function (e) { e.preventDefault(); e.returnValue = ''; }; window.addEventListener('beforeunload', bu);
		try { var c = await codeExport(null); if (c) { $('p4sb-bar').style.width = '100%'; $('p4sb-status').textContent = 'הסתיים: ' + fmt(c.bytes_gz) + ' דחוס, ' + c.files + ' קבצים' + (c.verified === false ? ' – האימות נכשל!' : ''); } }
		catch (e) { $('p4sb-status').textContent = 'נעצר: ' + e.message; log('נעצר: ' + e.message); }
		finally { busy(false); window.removeEventListener('beforeunload', bu); showResume(); }
	}

	/* ---------- full backup: folder with DB + code + manifest + restore kit ---------- */
	async function fullBackup() {
		if (running) return;
		var dir = null, sub = null, folder = location.hostname.replace(/[^a-z0-9.-]/gi, '_') + '-backup-' + stamp();
		if (window.showDirectoryPicker) {
			try { dir = await window.showDirectoryPicker({ mode: 'readwrite' }); sub = await dir.getDirectoryHandle(folder, { create: true }); }
			catch (e) { if (e.name === 'AbortError') return; sub = null; }
		}
		if (!tablesSelectedOk()) return;
		busy(true);
		var bu = function (e) { e.preventDefault(); e.returnValue = ''; }; window.addEventListener('beforeunload', bu);
		var ctx = { dir: sub, download: !sub, prefix: folder + '-' }, t0 = Date.now();
		try {
			if (!sub) log('הדפדפן לא תומך בשמירה לתיקייה (מומלץ Chrome/Edge): הקבצים יורדו בנפרד ויישמרו בזיכרון עד לסיום כל שלב.');
			else log('התיקייה: ' + folder);
			running = false; // run() manages its own lock; busy() above only prepared the UI
			log('שלב 1/3: מסד נתונים'); $('p4sb-status').textContent = 'שלב 1/3: מסד נתונים';
			var db = await run(null, ctx);
			if (!db) throw new Error(ctx.error || 'גיבוי מסד הנתונים לא הושלם');
			busy(true);
			try { if (navigator.wakeLock) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
			log('שלב 2/3: קוד (תוספים, תבניות, שפות)');
			var code = await codeExport(ctx);
			log('שלב 3/3: הגדרות וערכת שחזור');
			var env = await call('env', {}), kit = await call('kit', {});
			var manifest = { format: 1, created_utc: new Date().toISOString(), folder: folder, seconds: Math.round((Date.now() - t0) / 1000),
				site: Object.assign({}, db.site, { locale: env.env.locale, timezone: env.env.timezone, permalink: env.env.permalink }),
				database: { file: db.file, bytes_gz: db.bytes_gz, crc32_gz: db.crc32_gz, verified: db.verified, tables: db.tables, rows: db.rows, mismatched_tables: db.mismatched_tables, options: db.options },
				code: code, environment: env.env,
				media: { attachments: db.site.attachments, base_url: db.site.uploads_baseurl, note: 'Media is NOT inside this folder. Download it with backup_site.py (see README) and pass --media-dir to restore.sh.' } };
			if (kit['restore.sh']) await writeText(sub, 'restore.sh', kit['restore.sh']);
			if (kit['RESTORE.md']) await writeText(sub, 'RESTORE.md', kit['RESTORE.md']);
			await writeText(sub, 'manifest.json', JSON.stringify(manifest, null, 2));
			store(CK, null);
			$('p4sb-bar').style.width = '100%';
			var ok = function (v) { return v === null ? '–' : v ? '✓' : '<strong style="color:#b32d2e">נכשל</strong>'; };
			$('p4sb-status').textContent = 'הסתיים' + (sub ? ' – תיקייה: ' + folder : '');
			$('p4sb-summary').innerHTML = '<h2>סיכום</h2><div class="notice notice-success inline"><p>הגיבוי המלא הסתיים ב-' + Math.round((Date.now() - t0) / 1000) + ' שניות' + (sub ? ' ונשמר בתיקייה <code>' + E(folder) + '</code>' : '') + '.</p></div>' +
				'<table class="widefat striped" style="max-width:760px"><thead><tr><th>קובץ</th><th>תוכן</th><th>גודל</th><th>אימות</th></tr></thead><tbody>' +
				'<tr><td><code>database.sql.gz</code></td><td>' + db.tables + ' טבלאות, ' + db.rows.toLocaleString() + ' שורות</td><td>' + fmt(db.bytes_gz) + '</td><td>' + ok(db.verified) + '</td></tr>' +
				'<tr><td><code>code.tar.gz</code></td><td>' + code.files + ' קבצי קוד (' + manifest.environment.plugins.length + ' תוספים, ' + manifest.environment.themes.length + ' תבניות); הוחרגו ' + code.excluded_total + '</td><td>' + fmt(code.bytes_gz) + '</td><td>' + ok(code.verified) + '</td></tr>' +
				'<tr><td><code>manifest.json</code>, <code>restore.sh</code>, <code>RESTORE.md</code></td><td>הגדרות, גרסאות, ערכת שחזור</td><td>–</td><td>✓</td></tr></tbody></table>' +
				(db.mismatched_tables.length ? '<div class="notice notice-warning inline"><p>בטבלאות הבאות נכתבו נתונים במהלך הגיבוי (תקין עבור לוגים/תורים): <code>' + E(db.mismatched_tables.join(', ')) + '</code></p></div>' : '') +
				(code.warnings.length ? '<div class="notice notice-warning inline"><p>אזהרות קוד: ' + E(code.warnings.slice(0, 5).join('; ')) + '</p></div>' : '') +
				'<p><strong>המדיה (' + Number(db.site.attachments).toLocaleString() + ' קבצים) אינה בתיקייה</strong> – היא בענן (<code>' + E(db.site.uploads_baseurl) + '</code>). להורדתה: <code>backup_site.py</code> (ראה README). ללא הורדה, אתר משוחזר ימשיך להציג את התמונות מהענן המקורי.</p>' +
				'<p>לשחזור על וורדפרס נקי: פתח את <code>RESTORE.md</code> בתיקייה.</p>';
		} catch (e) {
			$('p4sb-status').textContent = 'נעצר: ' + e.message + (sub ? ' — התיקייה ' + folder + ' חלקית; הרץ שוב.' : '');
			log('נעצר: ' + e.message);
		} finally {
			busy(false); window.removeEventListener('beforeunload', bu);
			if (wakeLock) { try { wakeLock.release(); } catch (e) {} wakeLock = null; }
			showResume();
		}
	}

	/* ---------- boot ---------- */
	function unlocked() { $('p4sb-auth').style.display = 'none'; $('p4sb-main').style.display = 'block'; loadTables(); showResume(); }
	$('p4sb-auth-btn').addEventListener('click', async function () {
		var msg = $('p4sb-auth-msg'); msg.textContent = '';
		try { var d = await call('auth', { password: $('p4sb-pw').value }); token = d.token; $('p4sb-pw').value = ''; unlocked(); }
		catch (e) { msg.textContent = e.message; }
	});
	$('p4sb-pw').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('p4sb-auth-btn').click(); });
	$('p4sb-start').addEventListener('click', function () { run(null); });
	$('p4sb-full').addEventListener('click', fullBackup);
	$('p4sb-code').addEventListener('click', codeOnly);
	$('p4sb-abort').addEventListener('click', function () { aborted = true; });
	if (!P4SB.needReauth) unlocked();
})();
