<?php
/**
 * Admin page (Tools → גיבוי אתר) + AJAX endpoints. Admins only.
 *
 * Security model (a full DB dump contains password hashes, API keys and donor/form data):
 *  1. capability check (manage_options; super admin on multisite) on every request;
 *  2. WordPress nonce on every request;
 *  3. password re-confirmation → short-lived HMAC token bound to the user + login session,
 *     required for every data request (filter `p4sb_require_reauth` can disable it);
 *  4. brute-force lock on the password check, audit log, e-mail notification;
 *  5. no dump is ever written to the server: data is streamed to the admin's browser only;
 *  6. all SQL identifiers come from a whitelist (SHOW TABLE STATUS), values are validated.
 */

namespace P4SB;

defined( 'ABSPATH' ) || exit;

final class Admin {

	const SLUG       = 'p4-site-backup';
	const TOKEN_TTL  = 21600; // 6 hours.
	const MAX_FAILS  = 5;
	const LOCK_SECS  = 900;
	const AUDIT_OPT  = 'p4sb_audit';

	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		foreach ( array( 'auth', 'init', 'step', 'finish', 'files_list', 'files_step', 'files_end', 'env', 'kit' ) as $a ) {
			add_action( 'wp_ajax_p4sb_' . $a, array( __CLASS__, 'ajax_' . $a ) );
		}
	}

	private static function allowed(): bool {
		return is_multisite() ? is_super_admin() : current_user_can( 'manage_options' );
	}

	private static function require_reauth(): bool {
		return (bool) apply_filters( 'p4sb_require_reauth', true );
	}

	public static function menu(): void {
		if ( self::allowed() ) {
			add_management_page( 'גיבוי אתר', 'גיבוי אתר', 'manage_options', self::SLUG, array( __CLASS__, 'render' ) );
		}
	}

	public static function assets( string $hook ): void {
		if ( 'tools_page_' . self::SLUG !== $hook || ! self::allowed() ) {
			return;
		}
		wp_enqueue_script( 'p4sb-admin', P4SB_URL . 'assets/admin.js', array(), P4SB_VERSION, true );
		wp_localize_script( 'p4sb-admin', 'P4SB', array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'p4sb' ),
			'needReauth'  => self::require_reauth(),
		) );
	}

	/* ---------------- audit / notification ---------------- */

	private static function client_ip(): string {
		$ip = '';
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'REMOTE_ADDR' ) as $k ) {
			if ( ! empty( $_SERVER[ $k ] ) ) {
				$cand = trim( (string) wp_unslash( $_SERVER[ $k ] ) ); // phpcs:ignore
				if ( filter_var( $cand, FILTER_VALIDATE_IP ) ) {
					$ip = $cand;
					break;
				}
			}
		}
		return $ip;
	}

	private static function audit( string $event, string $detail = '' ): void {
		$user = wp_get_current_user();
		$row  = array( 'time' => gmdate( 'Y-m-d H:i:s' ), 'user' => $user && $user->exists() ? $user->user_login : '?', 'ip' => self::client_ip(), 'event' => $event, 'detail' => $detail );
		$log  = get_option( self::AUDIT_OPT, array() );
		$log  = is_array( $log ) ? $log : array();
		array_unshift( $log, $row );
		update_option( self::AUDIT_OPT, array_slice( $log, 0, 50 ), false );
		error_log( '[p4sb] ' . wp_json_encode( $row ) ); // phpcs:ignore
	}

	private static function notify( string $subject_tail ): void {
		$to = apply_filters( 'p4sb_notify_email', get_option( 'admin_email' ) );
		if ( ! $to || ! is_email( $to ) ) {
			return;
		}
		$user = wp_get_current_user();
		$body = "Planet4 Site Backup\n\nUser: {$user->user_login}\nIP: " . self::client_ip() . "\nTime (UTC): " . gmdate( 'Y-m-d H:i:s' ) . "\nSite: " . home_url() . "\n\nIf this was not you, change your password and review the users list immediately.";
		wp_mail( $to, '[' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . '] DB backup ' . $subject_tail, $body );
	}

	/* ---------------- token ---------------- */

	private static function make_token(): string {
		$exp = time() + self::TOKEN_TTL;
		$uid = get_current_user_id();
		return $exp . '.' . hash_hmac( 'sha256', $uid . '|' . $exp . '|' . wp_get_session_token(), wp_salt( 'auth' ) );
	}

	private static function token_ok( string $token ): bool {
		$parts = explode( '.', $token, 2 );
		if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) || (int) $parts[0] < time() ) {
			return false;
		}
		$expect = hash_hmac( 'sha256', get_current_user_id() . '|' . $parts[0] . '|' . wp_get_session_token(), wp_salt( 'auth' ) );
		return hash_equals( $expect, $parts[1] );
	}

	/* ---------------- page ---------------- */

	public static function render(): void {
		if ( ! self::allowed() ) {
			wp_die( 'אין הרשאה', 403 );
		}
		$log = get_option( self::AUDIT_OPT, array() );
		$log = is_array( $log ) ? array_slice( $log, 0, 10 ) : array();
		?>
		<div class="wrap" dir="rtl" id="p4sb">
			<h1>גיבוי אתר מלא</h1>
			<p>יוצר תיקיית גיבוי עם: מסד נתונים (<code>database.sql.gz</code>), קוד – תוספים, תבניות ושפות (<code>code.tar.gz</code>), דוח הגדרות ו-<code>manifest.json</code>, וסקריפט שחזור (<code>restore.sh</code>) לוורדפרס נקי. המדיה נשמרת בנפרד (README). הגיבוי נעשה בחלקים קטנים (כל בקשה נמשכת כמה שניות, כך שאין timeout).
				הקובץ עובר ישירות לדפדפן שלך ולא נשמר בשרת. <strong>השאר את הלשונית פתוחה</strong> עד לסיום.</p>
			<div class="notice notice-warning inline"><p>הקובץ מכיל מידע אישי (משתמשים, גיבובי סיסמאות, מפתחות API, נתוני טפסים/תורמים). שמור אותו מוצפן ובמקום מאובטח בלבד.</p></div>

			<div id="p4sb-auth" style="margin:1.2em 0;max-width:420px">
				<h2>אימות לפני גיבוי</h2>
				<p>הזן את סיסמת הוורדפרס שלך (<small>אם אתה מתחבר דרך SSO ואין לך סיסמה – הגדר אחת בפרופיל שלך</small>).</p>
				<p><input type="password" id="p4sb-pw" class="regular-text" autocomplete="current-password" style="direction:ltr">
				<button class="button button-primary" id="p4sb-auth-btn">אימות</button></p>
				<p id="p4sb-auth-msg" style="color:#b32d2e"></p>
			</div>

			<div id="p4sb-main" style="display:none">
				<div id="p4sb-resume" style="display:none" class="notice notice-info inline"></div>
				<p><label><input type="checkbox" id="p4sb-skip-transients" checked> דלג על transients (מטמון זמני – לא נדרש לשחזור, מקטין את הקובץ)</label></p>
				<p><label><input type="checkbox" id="p4sb-compat"> תאימות לשחזור ב-MariaDB / MySQL ישן (מחליף collation של MySQL 8)</label></p>
				<details style="margin:1em 0"><summary>בחירת טבלאות (ברירת מחדל: כל טבלאות האתר)</summary>
					<div id="p4sb-tables" style="max-height:260px;overflow:auto;margin-top:.5em">טוען…</div>
				</details>
				<p>
					<button class="button button-primary button-hero" id="p4sb-full">גיבוי מלא (מסד + קוד + הגדרות + ערכת שחזור)</button>
					<button class="button" id="p4sb-start">מסד נתונים בלבד</button>
					<button class="button" id="p4sb-code">קוד בלבד</button>
					<button class="button" id="p4sb-abort" style="display:none">עצור (אפשר להמשיך אחר כך)</button>
				</p>
				<div id="p4sb-progress" style="display:none;max-width:760px">
					<div style="background:#ddd;border-radius:4px;height:18px;overflow:hidden"><div id="p4sb-bar" style="background:#2271b1;height:100%;width:0"></div></div>
					<p id="p4sb-status" style="margin:.5em 0"></p>
				</div>
				<pre id="p4sb-log" style="display:none;max-height:300px;overflow:auto;background:#fff;border:1px solid #ccd0d4;padding:8px;direction:ltr;text-align:left"></pre>
				<div id="p4sb-summary"></div>
			</div>

			<?php if ( $log ) : ?>
				<h2>פעילות אחרונה</h2>
				<table class="widefat striped" style="max-width:760px;direction:ltr"><thead><tr><th>UTC</th><th>User</th><th>IP</th><th>Event</th><th></th></tr></thead><tbody>
				<?php foreach ( $log as $r ) : ?>
					<tr><td><?php echo esc_html( $r['time'] ?? '' ); ?></td><td><?php echo esc_html( $r['user'] ?? '' ); ?></td><td><?php echo esc_html( $r['ip'] ?? '' ); ?></td><td><?php echo esc_html( $r['event'] ?? '' ); ?></td><td><?php echo esc_html( $r['detail'] ?? '' ); ?></td></tr>
				<?php endforeach; ?>
				</tbody></table>
			<?php endif; ?>
		</div>
		<?php
	}

	/* ---------------- AJAX plumbing ---------------- */

	private static function fail( string $msg, int $code ): void {
		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}
		wp_send_json_error( $msg, $code );
	}

	private static function guard( bool $need_token ): void {
		nocache_headers();
		if ( ! is_user_logged_in() || ! self::allowed() ) {
			self::fail( 'forbidden', 403 );
		}
		if ( ! check_ajax_referer( 'p4sb', '_ajax_nonce', false ) ) {
			self::fail( 'bad nonce – reload the page', 403 );
		}
		if ( $need_token && self::require_reauth() ) {
			$tok = isset( $_POST['token'] ) ? (string) wp_unslash( $_POST['token'] ) : ''; // phpcs:ignore
			if ( ! self::token_ok( $tok ) ) {
				self::fail( 'auth expired', 401 );
			}
		}
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		@set_time_limit( 60 ); // phpcs:ignore
	}

	private static function reply( bool $need_token, callable $fn ): void {
		self::guard( $need_token );
		ob_start();
		$data  = null;
		$error = null;
		try {
			$data = $fn();
		} catch ( \Throwable $e ) {
			error_log( '[p4sb] ' . $e->getMessage() ); // phpcs:ignore
			$error = $e instanceof \RuntimeException ? $e->getMessage() : 'server error (see log)';
		}
		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}
		if ( null !== $error ) {
			self::fail( $error, 500 );
		}
		wp_send_json_success( $data );
	}

	private static function json_param( string $key ): array {
		$raw = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '[]'; // phpcs:ignore
		$v   = json_decode( (string) $raw, true );
		return is_array( $v ) ? $v : array();
	}

	private static function opts(): array {
		$o = self::json_param( 'opts' );
		return array( 'skip_transients' => ! empty( $o['skip_transients'] ), 'compat' => ! empty( $o['compat'] ) );
	}

	/* ---------------- AJAX endpoints ---------------- */

	public static function ajax_auth(): void {
		self::reply( false, static function () {
			$user = wp_get_current_user();
			$key  = 'p4sb_fail_' . $user->ID;
			$fail = (int) get_transient( $key );
			if ( $fail >= self::MAX_FAILS ) {
				self::audit( 'auth_locked' );
				throw new \RuntimeException( 'יותר מדי ניסיונות. נסה שוב בעוד ' . (int) ( self::LOCK_SECS / 60 ) . ' דקות.' );
			}
			$pw = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : ''; // phpcs:ignore
			if ( '' === $pw || ! wp_check_password( $pw, $user->user_pass, $user->ID ) ) {
				set_transient( $key, $fail + 1, self::LOCK_SECS );
				self::audit( 'auth_failed' );
				throw new \RuntimeException( 'סיסמה שגויה' );
			}
			delete_transient( $key );
			self::audit( 'auth_ok' );
			self::notify( 'authorization' );
			return array( 'token' => self::make_token() );
		} );
	}

	public static function ajax_init(): void {
		self::reply( true, static function () {
			if ( ! empty( $_POST['start'] ) ) { // phpcs:ignore
				self::audit( 'backup_started' );
			}
			return array(
				'info'   => Dumper::site_info(),
				'tables' => array_values( Dumper::tables() ),
				'header' => Dumper::header(),
			);
		} );
	}

	public static function ajax_step(): void {
		self::reply( true, static function () {
			$table  = isset( $_POST['table'] ) ? (string) wp_unslash( $_POST['table'] ) : ''; // phpcs:ignore
			$budget = isset( $_POST['budget'] ) ? (float) $_POST['budget'] : Dumper::DEFAULT_BUDGET; // phpcs:ignore
			return Dumper::step( $table, self::json_param( 'cursor' ), self::opts(), $budget );
		} );
	}

	public static function ajax_finish(): void {
		self::reply( true, static function () {
			$opts     = self::opts();
			$expected = array();
			$tables   = array_slice( self::json_param( 'tables' ), 0, 2000 );
			foreach ( $tables as $t ) {
				if ( is_string( $t ) ) {
					$expected[ $t ] = Dumper::expected_rows( $t, $opts );
				}
			}
			self::audit( 'backup_finished', count( $expected ) . ' tables' );
			return array(
				'footer'   => Dumper::footer(),
				'expected' => $expected,
				'info'     => Dumper::site_info(),
			);
		} );
	}

	/* ---------- code export + environment + restore kit ---------- */

	public static function ajax_files_list(): void {
		self::reply( true, static function () {
			@set_time_limit( 120 ); // phpcs:ignore
			return Files::inventory();
		} );
	}

	public static function ajax_files_step(): void {
		self::reply( true, static function () {
			return Files::step( self::json_param( 'items' ) );
		} );
	}

	public static function ajax_files_end(): void {
		self::reply( true, static function () {
			self::audit( 'code_export_finished' );
			return array( 'data' => Files::end() );
		} );
	}

	public static function ajax_env(): void {
		self::reply( true, static function () {
			return array( 'env' => Env::report(), 'info' => Dumper::site_info() );
		} );
	}

	/** Small text files that travel with the backup (restore script + instructions). */
	public static function ajax_kit(): void {
		self::reply( true, static function () {
			$out = array();
			foreach ( array( 'restore.sh', 'RESTORE.md' ) as $f ) {
				$path = P4SB_DIR . 'restore/' . $f;
				$out[ $f ] = is_readable( $path ) ? (string) file_get_contents( $path ) : '';
			}
			return $out;
		} );
	}
}
