<?php
/**
 * Stateless, chunked MySQL dumper.
 *
 * Every call to step() is independent: all state lives in the cursor that the
 * browser sends back, so it works behind multiple pods/load-balancers and any
 * step can safely be retried. Nothing is ever written to the server's disk.
 */

namespace P4SB;

defined( 'ABSPATH' ) || exit;

final class Dumper {

	const BATCH_ROWS     = 500;      // rows per SELECT.
	const STMT_BYTES     = 524288;   // max size of one INSERT statement (~512KB).
	const CHUNK_BYTES    = 3145728;  // stop a step after ~3MB of raw SQL.
	const DEFAULT_BUDGET = 8.0;      // seconds per step (Cloudflare cuts at 100s).

	private static function q( string $id ): string {
		return '`' . str_replace( '`', '``', $id ) . '`';
	}

	private static function esc( string $v ): string {
		global $wpdb;
		static $link = null;
		if ( null === $link ) {
			$link = ( isset( $wpdb->dbh ) && $wpdb->dbh instanceof \mysqli ) ? $wpdb->dbh : false;
		}
		return $link ? mysqli_real_escape_string( $link, $v ) : $wpdb->_real_escape( $v );
	}

	/**
	 * Make the DB session deterministic for dumping:
	 *  - UTC, so TIMESTAMP columns restore to the same instant (header sets UTC on import);
	 *  - no NO_BACKSLASH_ESCAPES, so our escaping matches what the import session expects.
	 */
	private static function prepare_session(): void {
		global $wpdb;
		static $done = false;
		if ( $done ) {
			return;
		}
		$wpdb->suppress_errors( true );
		$wpdb->query( "SET SESSION time_zone = '+00:00'" );
		$mode = (string) $wpdb->get_var( 'SELECT @@SESSION.sql_mode' );
		if ( false !== stripos( $mode, 'NO_BACKSLASH_ESCAPES' ) ) {
			$parts = array_filter( array_map( 'trim', explode( ',', $mode ) ), static function ( $m ) {
				return '' !== $m && 'NO_BACKSLASH_ESCAPES' !== strtoupper( $m );
			} );
			$wpdb->query( "SET SESSION sql_mode = '" . esc_sql( implode( ',', $parts ) ) . "'" );
		}
		$done = true;
	}

	/** All real tables (no views) in this DB. 'prefixed' = belongs to this WordPress install. @return array<string,array> */
	public static function tables(): array {
		global $wpdb;
		$wpdb->suppress_errors( true );
		$rows = $wpdb->get_results( 'SHOW TABLE STATUS', ARRAY_A );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			if ( empty( $r['Engine'] ) ) {
				continue; // a view.
			}
			$out[ $r['Name'] ] = array(
				'name'     => $r['Name'],
				'rows'     => (int) $r['Rows'],
				'bytes'    => (int) $r['Data_length'] + (int) $r['Index_length'],
				'prefixed' => 0 === strpos( $r['Name'], $wpdb->base_prefix ),
			);
		}
		ksort( $out );
		return $out;
	}

	private static function meta( string $table ): array {
		global $wpdb;
		$cols = $wpdb->get_results( 'SHOW COLUMNS FROM ' . self::q( $table ), ARRAY_A );
		$m    = array( 'names' => array(), 'bin' => array(), 'num' => array(), 'types' => array(), 'pk' => array(), 'key_mode' => false );
		foreach ( (array) $cols as $c ) {
			$n = $c['Field'];
			$t = strtolower( $c['Type'] );
			$m['types'][ $n ] = $t;
			if ( false !== stripos( (string) ( $c['Extra'] ?? '' ), 'GENERATED' ) ) {
				continue; // generated columns cannot be inserted; they are recomputed on import.
			}
			$m['names'][] = $n;
			if ( preg_match( '/(blob|binary|^bit)/', $t ) ) {
				$m['bin'][ $n ] = true;
			} elseif ( preg_match( '/^(tinyint|smallint|mediumint|int|bigint|decimal|numeric|float|double|real)/', $t ) ) {
				$m['num'][ $n ] = true;
			}
		}
		$keys = $wpdb->get_results( 'SHOW KEYS FROM ' . self::q( $table ) . " WHERE Key_name = 'PRIMARY'", ARRAY_A );
		usort( $keys, static function ( $a, $b ) {
			return (int) $a['Seq_in_index'] <=> (int) $b['Seq_in_index'];
		} );
		foreach ( (array) $keys as $k ) {
			$m['pk'][] = $k['Column_name'];
		}
		if ( 1 === count( $m['pk'] ) && isset( $m['types'][ $m['pk'][0] ] ) && preg_match( '/int/', $m['types'][ $m['pk'][0] ] ) ) {
			$m['key_mode'] = true; // fast keyset pagination.
		}
		return $m;
	}

	/** Optional row filter (skip transients in *_options tables). */
	private static function filter_sql( array $meta, array $opts ): string {
		if ( ! empty( $opts['skip_transients'] ) && in_array( 'option_name', $meta['names'], true ) ) {
			return '(`option_name` NOT LIKE \'\\_transient\\_%\' AND `option_name` NOT LIKE \'\\_site\\_transient\\_%\')';
		}
		return '';
	}

	private static function pack( string $sql ): string {
		return base64_encode( gzencode( $sql, 6 ) );
	}

	/** First chunk of the file: header with site info + session settings. */
	public static function header(): string {
		global $wpdb;
		$charset = preg_match( '/^[a-z0-9_]+$/i', (string) $wpdb->charset ) ? $wpdb->charset : 'utf8mb4';
		$clean   = static function ( $s ) {
			return preg_replace( '/[\r\n]+/', ' ', (string) $s );
		};
		$sql = '-- Planet4 Site Backup ' . P4SB_VERSION . "\n"
			. '-- Site:    ' . $clean( home_url() ) . "\n"
			. '-- siteurl: ' . $clean( site_url() ) . "\n"
			. '-- WP:      ' . $clean( get_bloginfo( 'version' ) ) . '   PHP: ' . PHP_VERSION . '   DB: ' . $clean( $wpdb->db_version() ) . "\n"
			. '-- Prefix:  ' . $clean( $wpdb->base_prefix ) . "\n"
			. '-- Date:    ' . gmdate( 'Y-m-d H:i:s' ) . " UTC\n\n"
			. "/*!40101 SET NAMES {$charset} */;\n"
			. "SET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\n"
			. "SET sql_mode='NO_AUTO_VALUE_ON_ZERO';\nSET time_zone='+00:00';\n\n";
		return self::pack( $sql );
	}

	public static function footer(): string {
		return self::pack( "\nSET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n-- Dump completed on " . gmdate( 'Y-m-d H:i:s' ) . " UTC\n" );
	}

	/** Info for the UI + manifest. */
	public static function site_info(): array {
		global $wpdb;
		$theme   = wp_get_theme();
		$uploads = wp_upload_dir( null, false );
		return array(
			'plugin_version' => P4SB_VERSION,
			'home'           => home_url(),
			'siteurl'        => site_url(),
			'wp_version'     => get_bloginfo( 'version' ),
			'php_version'    => PHP_VERSION,
			'db_version'     => $wpdb->db_version(),
			'prefix'         => $wpdb->base_prefix,
			'charset'        => $wpdb->charset,
			'collate'        => $wpdb->collate,
			'multisite'      => is_multisite(),
			'theme'          => $theme->get_stylesheet() . ' ' . $theme->get( 'Version' ),
			'active_plugins' => array_values( (array) get_option( 'active_plugins', array() ) ),
			'uploads_baseurl' => isset( $uploads['baseurl'] ) ? $uploads['baseurl'] : '',
			'attachments'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment'" ),
			'created_utc'    => gmdate( 'c' ),
		);
	}

	/** Exact row count (same filter as the dump) – used to verify the dump at the end. */
	public static function expected_rows( string $table, array $opts ): int {
		global $wpdb;
		$tables = self::tables();
		if ( ! isset( $tables[ $table ] ) ) {
			return -1;
		}
		self::prepare_session();
		$filter = self::filter_sql( self::meta( $table ), $opts );
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::q( $table ) . ( $filter ? ' WHERE ' . $filter : '' ) );
	}

	private static function row_sql( array $row, array $meta ): string {
		$vals = array();
		foreach ( $meta['names'] as $n ) {
			$v = $row[ $n ] ?? null;
			if ( null === $v ) {
				$vals[] = 'NULL';
			} elseif ( isset( $meta['bin'][ $n ] ) ) {
				$vals[] = '' === $v ? "''" : '0x' . bin2hex( $v );
			} elseif ( isset( $meta['num'][ $n ] ) && preg_match( '/^-?\d+(\.\d+)?([eE][-+]?\d+)?$/', $v ) ) {
				$vals[] = $v;
			} else {
				$vals[] = "'" . self::esc( (string) $v ) . "'";
			}
		}
		return '(' . implode( ',', $vals ) . ')';
	}

	/**
	 * Dump one slice of one table.
	 *
	 * @param string $table  Must be an existing table of this database.
	 * @param array  $cursor State from the previous call (empty for the first call).
	 * @param array  $opts   skip_transients (bool), compat (bool).
	 * @param float  $budget Seconds this step may take (clamped 2..15).
	 * @return array{sql:string,cursor:array,done:bool,rows:int,raw_bytes:int}
	 */
	public static function step( string $table, array $cursor, array $opts, float $budget = self::DEFAULT_BUDGET ): array {
		global $wpdb;

		$tables = self::tables();
		if ( ! isset( $tables[ $table ] ) ) {
			throw new \RuntimeException( 'Unknown table' );
		}
		self::prepare_session();
		$budget = max( 2.0, min( 15.0, $budget ) );
		$meta   = self::meta( $table );
		$filter = self::filter_sql( $meta, $opts );
		$t0     = microtime( true );

		$last = $cursor['last'] ?? null;
		if ( null !== $last && ( ! ( is_string( $last ) || is_int( $last ) ) || ! preg_match( '/^-?\d+$/', (string) $last ) ) ) {
			throw new \RuntimeException( 'Bad cursor' );
		}
		$cur = array(
			'started' => ! empty( $cursor['started'] ),
			'last'    => null === $last ? null : (string) $last,
			'offset'  => max( 0, (int) ( $cursor['offset'] ?? 0 ) ),
		);

		$sql = '';
		if ( ! $cur['started'] ) {
			$create = $wpdb->get_row( 'SHOW CREATE TABLE ' . self::q( $table ), ARRAY_N );
			if ( ! $create || empty( $create[1] ) ) {
				throw new \RuntimeException( 'SHOW CREATE TABLE failed' );
			}
			$ddl = $create[1];
			if ( ! empty( $opts['compat'] ) ) {
				// MySQL 8 collations that older MySQL / MariaDB cannot import.
				$ddl = str_replace( array( 'utf8mb4_0900_ai_ci', 'utf8mb4_0900_as_ci', 'utf8mb4_0900_as_cs', 'utf8mb4_0900_bin' ), 'utf8mb4_unicode_520_ci', $ddl );
			}
			$sql .= "\n--\n-- Table: " . preg_replace( '/[\r\n]+/', ' ', $table ) . "\n--\n\nDROP TABLE IF EXISTS " . self::q( $table ) . ";\n" . $ddl . ";\n\n";
			$cur['started'] = true;
		}

		$col_list = implode( ',', array_map( array( __CLASS__, 'q' ), $meta['names'] ) );
		$order    = $meta['pk'] ? ' ORDER BY ' . implode( ',', array_map( array( __CLASS__, 'q' ), $meta['pk'] ) ) : '';
		$head     = 'INSERT INTO ' . self::q( $table ) . " ({$col_list}) VALUES\n";
		$rows_out = 0;
		$done     = false;

		while ( true ) {
			$where = array();
			if ( $filter ) {
				$where[] = $filter;
			}
			if ( $meta['key_mode'] && null !== $cur['last'] ) {
				$where[] = self::q( $meta['pk'][0] ) . ' > ' . $cur['last']; // validated as digits above/below.
			}
			$limit = ' LIMIT ' . self::BATCH_ROWS . ( $meta['key_mode'] ? '' : ' OFFSET ' . (int) $cur['offset'] );
			$q     = 'SELECT ' . $col_list . ' FROM ' . self::q( $table ) . ( $where ? ' WHERE ' . implode( ' AND ', $where ) : '' ) . $order . $limit;

			$rows = $wpdb->get_results( $q, ARRAY_A );
			if ( $wpdb->last_error ) {
				error_log( '[p4sb] DB error while dumping ' . $table . ': ' . $wpdb->last_error ); // phpcs:ignore -- details stay server-side.
				throw new \RuntimeException( 'DB error (see server log)' );
			}
			if ( ! $rows ) {
				$done = true;
				break;
			}

			$stmt = '';
			$n    = 0;
			foreach ( $rows as $row ) {
				$stmt .= ( $n ? ",\n" : '' ) . self::row_sql( $row, $meta );
				++$n;
				if ( strlen( $stmt ) >= self::STMT_BYTES ) {
					$sql .= $head . $stmt . ";\n";
					$stmt = '';
					$n    = 0;
				}
			}
			if ( '' !== $stmt ) {
				$sql .= $head . $stmt . ";\n";
			}

			$count          = count( $rows );
			$rows_out      += $count;
			$cur['offset'] += $count;
			if ( $meta['key_mode'] ) {
				$cur['last'] = (string) $rows[ $count - 1 ][ $meta['pk'][0] ];
			}
			unset( $rows );

			if ( $count < self::BATCH_ROWS ) {
				$done = true;
				break;
			}
			if ( strlen( $sql ) >= self::CHUNK_BYTES || ( microtime( true ) - $t0 ) > $budget ) {
				break;
			}
		}

		return array(
			'sql'       => self::pack( $sql ),
			'cursor'    => $cur,
			'done'      => $done,
			'rows'      => $rows_out,
			'raw_bytes' => strlen( $sql ),
		);
	}
}
