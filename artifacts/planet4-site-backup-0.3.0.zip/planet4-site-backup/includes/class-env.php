<?php
/**
 * Environment report: everything needed to re-create the site's configuration that is NOT in the database
 * (PHP/WP versions, wp-config constants, env-var NAMES, plugin/theme inventory with versions, drop-ins).
 *
 * Secrets are never exported: constant values whose names look sensitive are redacted and
 * environment variables are listed by NAME only.
 */

namespace P4SB;

defined( 'ABSPATH' ) || exit;

final class Env {

	const SECRET_RE   = '/(KEY|SECRET|PASS|PWD|TOKEN|SALT|PRIVATE|AUTH|CREDENTIAL|JSON|CERT|DSN|HOST|USER|NAME_|LICENSE|SIGN|API)/i';
	const KEEP_RE     = '/^(WP_|WPLANG$|DISABLE_|DISALLOW_|ALLOW_|AUTOMATIC_UPDATER|CONCATENATE_|COMPRESS_|FORCE_SSL|DB_CHARSET$|DB_COLLATE$|MULTISITE$|SUBDOMAIN_INSTALL$|DOMAIN_CURRENT_SITE$|PATH_CURRENT_SITE$|UPLOADS$|EMPTY_TRASH_DAYS$|AUTOSAVE_INTERVAL$|MEDIA_TRASH$|SAVEQUERIES$|SCRIPT_DEBUG$|CORE_UPGRADE_SKIP_NEW_BUNDLED$|P4_|PLANET4_|WP_STATELESS_)/';

	private static function constants(): array {
		$out  = array();
		$user = get_defined_constants( true )['user'] ?? array();
		ksort( $user );
		foreach ( $user as $name => $val ) {
			if ( 0 === strpos( $name, 'P4SB_' ) || ! preg_match( self::KEEP_RE, $name ) ) {
				continue;
			}
			if ( preg_match( self::SECRET_RE, $name ) ) {
				$out[ $name ] = '[redacted]';
			} elseif ( is_scalar( $val ) || null === $val ) {
				$out[ $name ] = is_string( $val ) ? mb_substr( $val, 0, 200 ) : $val;
			} else {
				$out[ $name ] = '[' . gettype( $val ) . ']';
			}
		}
		return $out;
	}

	private static function env_names(): array {
		$names = array_keys( (array) getenv() );
		$names = array_filter( $names, static function ( $n ) {
			return is_string( $n ) && preg_match( '/^[A-Z][A-Z0-9_]*$/', $n ) && ! preg_match( '/^(PATH|HOME|PWD|OLDPWD|SHLVL|TERM|LANG|HOSTNAME|_)$/', $n );
		} );
		sort( $names );
		return array_values( $names );
	}

	public static function report(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$active  = (array) get_option( 'active_plugins', array() );
		$plugins = array();
		foreach ( get_plugins() as $file => $d ) {
			$plugins[] = array(
				'file'    => $file,
				'name'    => $d['Name'],
				'version' => $d['Version'],
				'author'  => wp_strip_all_tags( $d['Author'] ),
				'uri'     => $d['PluginURI'],
				'active'  => in_array( $file, $active, true ),
			);
		}
		$mu = array();
		foreach ( get_mu_plugins() as $file => $d ) {
			$mu[] = array( 'file' => $file, 'name' => $d['Name'], 'version' => $d['Version'] );
		}
		$themes = array();
		foreach ( wp_get_themes() as $slug => $t ) {
			$themes[] = array(
				'slug'    => $slug,
				'name'    => $t->get( 'Name' ),
				'version' => $t->get( 'Version' ),
				'parent'  => $t->parent() ? $t->parent()->get_stylesheet() : null,
				'active'  => get_stylesheet() === $slug,
			);
		}
		$dropins = array();
		foreach ( array_keys( (array) get_dropins() ) as $d ) {
			$dropins[] = $d;
		}
		$server = isset( $_SERVER['SERVER_SOFTWARE'] ) ? preg_replace( '/[^\x20-\x7E]/', '', (string) wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : ''; // phpcs:ignore
		return array(
			'php'              => array( 'version' => PHP_VERSION, 'extensions' => get_loaded_extensions(), 'memory_limit' => ini_get( 'memory_limit' ), 'upload_max_filesize' => ini_get( 'upload_max_filesize' ), 'post_max_size' => ini_get( 'post_max_size' ), 'max_execution_time' => ini_get( 'max_execution_time' ) ),
			'server_software'  => $server,
			'wp_constants'     => self::constants(),
			'env_var_names'    => self::env_names(),
			'plugins'          => $plugins,
			'mu_plugins'       => $mu,
			'dropins'          => $dropins,
			'themes'           => $themes,
			'permalink'        => get_option( 'permalink_structure' ),
			'locale'           => get_locale(),
			'timezone'         => wp_timezone_string(),
			'cron_disabled'    => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
			'notes'            => 'Server-level config (nginx/Apache rules, Cloudflare, Redis, Elasticsearch, bucket + service-account credentials, wp-config salts) is not readable from WordPress and is not in this backup.',
		);
	}
}
