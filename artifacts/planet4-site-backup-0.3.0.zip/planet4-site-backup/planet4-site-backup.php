<?php
/**
 * Plugin Name: Planet4 Site Backup
 * Description: Chunked, timeout-proof full-site backup from wp-admin (Tools → גיבוי אתר): database, plugins/themes code, environment report and a restore script. Admins only.
 * Version:     0.3.0
 * Author:      Greenpeace Israel Digital
 * Requires PHP: 7.4
 * License:     GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

define( 'P4SB_VERSION', '0.3.0' );
define( 'P4SB_URL', plugin_dir_url( __FILE__ ) );
define( 'P4SB_DIR', plugin_dir_path( __FILE__ ) );

require_once __DIR__ . '/includes/class-dumper.php';
require_once __DIR__ . '/includes/class-files.php';
require_once __DIR__ . '/includes/class-env.php';
require_once __DIR__ . '/includes/class-admin.php';

if ( is_admin() ) {
	\P4SB\Admin::init();
}
