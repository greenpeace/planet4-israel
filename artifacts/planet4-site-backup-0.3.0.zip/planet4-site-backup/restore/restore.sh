#!/usr/bin/env bash
# Planet4 Site Backup – restore onto a FRESH, EMPTY WordPress install.
# Needs: bash, php (>= 7.4), wp-cli (`wp`), mysql client, tar, gzip, an EMPTY database.
# Run `bash restore.sh --help` for options. Safe by default: the copy cannot send e-mail,
# cannot call payment/CRM APIs, is hidden from search engines and infra-bound plugins are off.
set -euo pipefail

BACKUP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET=""; URL=""; DBN=""; DBU=""; DBP=""; DBH="localhost"; MEDIA=""; LIVE=0; KEEP_CLOUD=0; DROPINS=0; ASSUME=0
ADMIN_USER="restore_admin"; WPBIN="${WP_CLI:-wp}"

usage() { cat <<U
Usage: bash restore.sh --target DIR --url https://new-site.example --db-name N --db-user U --db-pass P [options]
  --target DIR        empty directory that becomes the WordPress root (created if missing)
  --url URL           public address of the NEW site (no trailing slash)
  --db-name/--db-user/--db-pass/--db-host   EMPTY database (host default localhost)
  --media-dir DIR     folder with the downloaded media (output of backup_site.py: its uploads tree).
                      Copied to wp-content/uploads and media URLs are rewritten to the new site.
                      Without it media keeps pointing at the original cloud bucket (keep-cloud-media).
  --keep-cloud-media  leave media URLs pointing at the original cloud storage (default when no --media-dir)
  --with-dropins      also install drop-ins (object-cache.php etc.). Off by default: they need Redis/infra.
  --live              DISABLE replica safety (mail/API blocking, noindex). Use only for a real migration.
  --yes               don't ask for confirmation
U
}
while [ $# -gt 0 ]; do case "$1" in
  --target) TARGET="$2"; shift 2;; --url) URL="${2%/}"; shift 2;;
  --db-name) DBN="$2"; shift 2;; --db-user) DBU="$2"; shift 2;; --db-pass) DBP="$2"; shift 2;; --db-host) DBH="$2"; shift 2;;
  --media-dir) MEDIA="$2"; shift 2;; --keep-cloud-media) KEEP_CLOUD=1; shift;; --with-dropins) DROPINS=1; shift;;
  --live) LIVE=1; shift;; --yes) ASSUME=1; shift;; -h|--help) usage; exit 0;; *) echo "Unknown option: $1"; usage; exit 1;; esac; done

say() { printf '\n== %s\n' "$*"; }
die() { echo "ERROR: $*" >&2; exit 1; }
[ -n "$TARGET" ] && [ -n "$URL" ] && [ -n "$DBN" ] && [ -n "$DBU" ] || { usage; exit 1; }
for c in php mysql tar gzip "$WPBIN"; do command -v "$c" >/dev/null 2>&1 || die "'$c' is required but not installed"; done
case "$URL" in http://*|https://*) ;; *) die "--url must start with http:// or https://";; esac

SQL="$(ls "$BACKUP_DIR"/*database*.sql.gz "$BACKUP_DIR"/*-db-*.sql.gz 2>/dev/null | head -n1 || true)"
CODE="$(ls "$BACKUP_DIR"/*code*.tar.gz 2>/dev/null | head -n1 || true)"
MAN="$(ls "$BACKUP_DIR"/manifest.json "$BACKUP_DIR"/*manifest.json 2>/dev/null | head -n1 || true)"
[ -f "$SQL" ] || die "database dump (*.sql.gz) not found next to restore.sh"
[ -f "$MAN" ] || die "manifest.json not found next to restore.sh"
gzip -t "$SQL" || die "database dump is corrupt (gzip test failed)"
[ -z "$CODE" ] || gzip -t "$CODE" || die "code archive is corrupt (gzip test failed)"

# --- read facts from manifest (php, no jq dependency)
mj() { php -r '$m=json_decode(file_get_contents($argv[1]),true); $v=$m; foreach(explode(".",$argv[2]) as $k){ if(!is_array($v)||!isset($v[$k])){ $v=""; break;} $v=$v[$k]; } echo is_scalar($v)?$v:json_encode($v);' "$MAN" "$1"; }
WPV="$(mj site.wp_version)"; OLD_HOME="$(mj site.home)"; OLD_SITE="$(mj site.siteurl)"; OLD_UP="$(mj site.uploads_baseurl)"
LOCALE="$(mj site.locale)"
[ -n "$OLD_HOME" ] || die "manifest has no site.home – is this a Planet4 Site Backup manifest?"
echo "Original site : $OLD_HOME  (WordPress ${WPV:-?})"
echo "New site      : $URL"
echo "Mode          : $([ $LIVE = 1 ] && echo 'LIVE (no replica safety)' || echo 'REPLICA (mail/API blocked, noindex)')"
if [ $ASSUME = 0 ]; then read -r -p "Continue? database '$DBN' will be OVERWRITTEN [y/N] " a; [ "$a" = y ] || exit 1; fi

MYC=(mysql -h "$DBH" -u "$DBU" "--password=$DBP" "$DBN")
"${MYC[@]}" -e 'SELECT 1' >/dev/null || die "cannot connect to the database"
N="$("${MYC[@]}" -N -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE()")"
[ "$N" = 0 ] || [ $ASSUME = 1 ] || { read -r -p "Database is not empty ($N tables). Continue and overwrite? [y/N] " a; [ "$a" = y ] || exit 1; }

say "1/8 WordPress core ${WPV}"
mkdir -p "$TARGET"; cd "$TARGET"
if [ ! -f wp-load.php ]; then
  "$WPBIN" core download ${WPV:+--version="$WPV"} ${LOCALE:+--locale="$LOCALE"} --force --allow-root
fi

say "2/8 wp-config.php"
if [ ! -f wp-config.php ]; then
  "$WPBIN" config create --dbname="$DBN" --dbuser="$DBU" --dbpass="$DBP" --dbhost="$DBH" --dbcharset=utf8mb4 --skip-check --allow-root
  "$WPBIN" config set WP_HOME "$URL" --type=constant --allow-root
  "$WPBIN" config set WP_SITEURL "$URL" --type=constant --allow-root
  [ $LIVE = 1 ] || "$WPBIN" config set DISABLE_WP_CRON true --raw --type=constant --allow-root
fi

say "3/8 Database import (can take several minutes)"
"${MYC[@]}" -e "SET GLOBAL max_allowed_packet=1073741824" 2>/dev/null || echo "  (could not raise max_allowed_packet; relying on server default)"
gzip -dc "$SQL" | mysql -h "$DBH" -u "$DBU" "--password=$DBP" --max-allowed-packet=1G --default-character-set=utf8mb4 "$DBN"
echo "  tables now: $("${MYC[@]}" -N -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE()")  (backup had: $(mj database.tables))"

say "4/8 Code: plugins, themes, mu-plugins, languages"
if [ -n "$CODE" ]; then
  EXC=(); [ $DROPINS = 1 ] || EXC=(--exclude='wp-content/object-cache.php' --exclude='wp-content/advanced-cache.php' --exclude='wp-content/db.php' --exclude='wp-content/db-error.php' --exclude='wp-content/sunrise.php' --exclude='wp-content/maintenance.php' --exclude='wp-content/install.php' --exclude='wp-content/blog-deleted.php' --exclude='wp-content/blog-inactive.php' --exclude='wp-content/blog-suspended.php' --exclude='wp-content/fatal-error-handler.php')
  tar -xzf "$CODE" --no-same-owner "${EXC[@]}" -C "$TARGET"
else
  echo "  no code archive in backup – install plugins/themes manually from the manifest list"
fi

say "5/8 Media"
if [ -n "$MEDIA" ]; then
  [ -d "$MEDIA" ] || die "--media-dir not found"
  mkdir -p wp-content/uploads && cp -a "$MEDIA"/. wp-content/uploads/
  KEEP_CLOUD=0
else
  KEEP_CLOUD=1; echo "  no --media-dir: images keep loading from the original cloud bucket"
fi

say "6/8 Address and media URL rewrite"
SR=("$WPBIN" search-replace --all-tables-with-prefix --skip-columns=guid --precise --recurse-objects --report-changed-only --allow-root)
"${SR[@]}" "$OLD_HOME" "$URL" || true
[ "$OLD_SITE" = "$OLD_HOME" ] || "${SR[@]}" "$OLD_SITE" "$URL" || true
if [ $KEEP_CLOUD = 0 ]; then
  for B in "$OLD_UP" "https://www.greenpeace.org/static/planet4-israel-stateless" "https://storage.googleapis.com/planet4-israel-stateless" "https://storage.googleapis.com/planet4-israel-stateless-develop" "https://master.k8s.p4.greenpeace.org/israel/wp-content/uploads"; do
    [ -n "$B" ] || continue
    # stateless buckets keep files under YYYY/MM; local uploads keep the same relative layout
    "${SR[@]}" "${B%/}" "$URL/wp-content/uploads" || true
  done
fi
"$WPBIN" option update home "$URL" --allow-root; "$WPBIN" option update siteurl "$URL" --allow-root

say "7/8 Infrastructure-bound plugins and replica safety"
# plugins that need the original hosting (CDN, Redis, bucket credentials, search cluster, Google login...)
INFRA="cloudflare wp-stateless wp-stateless-gravity-forms-addon wp-redis wp-sentry-integration planet4-nginx-helper elasticpress google-apps-login indexnow bing-webmaster-tools"
if [ $KEEP_CLOUD = 0 ]; then :; else INFRA="${INFRA/wp-stateless /}"; INFRA="${INFRA/wp-stateless-gravity-forms-addon /}"; fi
for p in $INFRA; do "$WPBIN" plugin is-installed "$p" --allow-root 2>/dev/null && "$WPBIN" plugin deactivate "$p" --allow-root 2>/dev/null && echo "  deactivated $p" || true; done
if [ $LIVE = 0 ]; then
  mkdir -p wp-content/mu-plugins
  cat > wp-content/mu-plugins/p4sb-replica-safety.php <<'PHP'
<?php
/** Planet4 Site Backup – replica safety. Delete this file to turn the copy into a live site. */
add_filter( 'pre_wp_mail', '__return_false' );
add_filter( 'pre_http_request', function ( $pre, $args, $url ) {
	$host = (string) wp_parse_url( $url, PHP_URL_HOST );
	$ok   = array( 'api.wordpress.org', 'downloads.wordpress.org', 'wordpress.org', 'localhost', '127.0.0.1' );
	$site = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	if ( $host === $site || in_array( $host, $ok, true ) || substr( $host, -14 ) === '.wordpress.org' ) { return $pre; }
	return new WP_Error( 'p4sb_replica', 'External call blocked on replica: ' . $host );
}, 10, 3 );
add_action( 'admin_notices', function () { echo '<div class="notice notice-warning"><p><strong>REPLICA</strong> – mail and external services are blocked (mu-plugins/p4sb-replica-safety.php).</p></div>'; } );
PHP
  "$WPBIN" option update blog_public 0 --allow-root
  echo "  replica safety installed (delete wp-content/mu-plugins/p4sb-replica-safety.php to go live)"
fi

say "8/8 Finish"
"$WPBIN" core update-db --allow-root || true
PW="$(php -r 'echo bin2hex(random_bytes(10));')"
if "$WPBIN" user get "$ADMIN_USER" --allow-root >/dev/null 2>&1; then "$WPBIN" user update "$ADMIN_USER" --user_pass="$PW" --allow-root >/dev/null
else "$WPBIN" user create "$ADMIN_USER" "restore@invalid.local" --role=administrator --user_pass="$PW" --allow-root >/dev/null; fi
"$WPBIN" rewrite flush --allow-root 2>/dev/null || true
"$WPBIN" cache flush --allow-root 2>/dev/null || true
echo
echo "=============================================================="
echo " Done.  $URL/wp-admin"
echo " Login: $ADMIN_USER   Password: $PW   (all original users are also restored)"
echo " Point your web server's document root at: $TARGET"
echo " Not covered by a WordPress backup: web-server rules, Cloudflare, SSL, Redis/Elasticsearch, wp-config secrets."
echo "=============================================================="
