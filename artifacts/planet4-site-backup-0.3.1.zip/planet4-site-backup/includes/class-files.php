<?php
/**
 * Streams the site's CODE (plugins, themes, mu-plugins, languages, drop-ins) as a tar archive.
 *
 * Same model as the DB dumper: stateless, chunked, nothing written to the server's disk.
 * Every step returns a complete gzip member containing raw tar bytes; concatenated members
 * form a valid .tar.gz.
 *
 * Security:
 *  - the client only names files by (root label, relative path); the server re-resolves and
 *    validates every path (no "..", realpath must stay inside the allowed roots, regular files only);
 *  - secrets-looking files (.env, keys, credentials JSON) and VCS/dev folders are never exported;
 *  - wp-config.php, uploads and everything outside the roots are unreachable by design.
 */

namespace P4SB;

defined( 'ABSPATH' ) || exit;

final class Files {

	const MAX_ITEMS    = 600;
	const MAX_BYTES    = 8388608; // per step.
	const MAX_DEPTH    = 25;
	const DROPINS      = array( 'object-cache.php', 'advanced-cache.php', 'db.php', 'db-error.php', 'maintenance.php', 'install.php', 'sunrise.php', 'blog-deleted.php', 'blog-inactive.php', 'blog-suspended.php' );
	const DENY_DIRS    = array( '.git', '.svn', '.hg', 'node_modules', '.github', '.idea', '.vscode', '__MACOSX', '.circleci' );
	const DENY_FILE_RE = '/^(\.env(\..*)?|\.DS_Store|debug\.log|id_(rsa|dsa|ecdsa|ed25519)(\.pub)?)$|\.(pem|key|p12|pfx|ppk|log)$|(credentials?|service[-_.]?account|client[-_.]?secrets?|secrets?)[^\/]*\.json$/i';

	/** label => [absolute dir, archive prefix] */
	public static function roots(): array {
		$map = array(
			'plugins'    => array( WP_PLUGIN_DIR, 'wp-content/plugins' ),
			'mu-plugins' => array( defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins', 'wp-content/mu-plugins' ),
			'themes'     => array( get_theme_root(), 'wp-content/themes' ),
			'languages'  => array( defined( 'WP_LANG_DIR' ) ? WP_LANG_DIR : WP_CONTENT_DIR . '/languages', 'wp-content/languages' ),
			'dropins'    => array( WP_CONTENT_DIR, 'wp-content' ),
		);
		$out = array();
		foreach ( $map as $label => $v ) {
			$real = is_dir( $v[0] ) ? realpath( $v[0] ) : false;
			if ( $real ) {
				$out[ $label ] = array( 'dir' => $real, 'prefix' => $v[1] );
			}
		}
		return $out;
	}

	/** Real directories files may live in: the root itself + targets of top-level symlinks (e.g. vendor/plugins/x). */
	private static function bases( string $label, array $roots ): array {
		$b = array();
		if ( 'dropins' === $label ) {
			foreach ( $roots as $l => $r ) {
				if ( 'dropins' !== $l ) {
					$b[] = $r['dir'];
				}
			}
			$b[] = $roots['dropins']['dir'];
		} else {
			$b[] = $roots[ $label ]['dir'];
			foreach ( (array) @scandir( $roots[ $label ]['dir'] ) as $e ) {
				if ( '.' === $e || '..' === $e ) {
					continue;
				}
				$p = $roots[ $label ]['dir'] . '/' . $e;
				if ( is_link( $p ) && ( $t = realpath( $p ) ) && is_dir( $t ) ) {
					$b[] = $t;
				}
			}
		}
		return $b;
	}

	private static function inside( string $real, array $bases ): bool {
		foreach ( $bases as $b ) {
			if ( 0 === strpos( $real, rtrim( $b, '/' ) . '/' ) ) {
				return true;
			}
		}
		return false;
	}

	private static function denied_name( string $name ): bool {
		return (bool) preg_match( self::DENY_FILE_RE, $name );
	}

	private static function walk( string $dir, string $rel, array $bases, array &$files, array &$excl, array &$seen, int $depth, string $label, int $skip_levels = 0 ): void {
		if ( $depth > self::MAX_DEPTH ) {
			$excl[] = array( $label . '/' . $rel, 'too deep' );
			return;
		}
		$entries = @scandir( $dir, SCANDIR_SORT_ASCENDING );
		if ( ! is_array( $entries ) ) {
			return;
		}
		foreach ( $entries as $e ) {
			if ( '.' === $e || '..' === $e ) {
				continue;
			}
			$full = $dir . '/' . $e;
			$r    = ( '' === $rel ? '' : $rel . '/' ) . $e;
			$real = is_link( $full ) ? realpath( $full ) : $full;
			if ( ! $real ) {
				continue; // dangling symlink.
			}
			if ( is_link( $full ) && ! self::inside( $real, $bases ) && ! in_array( $real, $bases, true ) ) {
				$excl[] = array( $label . '/' . $r, 'symlink outside allowed roots' );
				continue;
			}
			if ( is_dir( $real ) ) {
				if ( in_array( $e, self::DENY_DIRS, true ) ) {
					continue;
				}
				if ( isset( $seen[ $real ] ) ) {
					continue; // loop guard.
				}
				$seen[ $real ] = true;
				self::walk( $full, $r, $bases, $files, $excl, $seen, $depth + 1, $label );
			} elseif ( is_file( $real ) ) {
				if ( self::denied_name( $e ) ) {
					$excl[] = array( $label . '/' . $r, 'sensitive/ignored file type' );
					continue;
				}
				$files[] = array( $label, $r, (int) filesize( $real ) );
			}
		}
	}

	/** Full inventory: [files => [[label, rel, size], ...], excluded => [[path, reason], ...]] */
	public static function inventory(): array {
		$roots = self::roots();
		$files = array();
		$excl  = array();
		foreach ( $roots as $label => $r ) {
			if ( 'dropins' === $label ) {
				foreach ( self::DROPINS as $name ) {
					$p = $r['dir'] . '/' . $name;
					if ( is_file( $p ) ) {
						$files[] = array( 'dropins', $name, (int) filesize( $p ) );
					}
				}
				continue;
			}
			$seen = array();
			self::walk( $r['dir'], '', self::bases( $label, $roots ), $files, $excl, $seen, 0, $label );
		}
		return array( 'files' => $files, 'excluded' => array_slice( $excl, 0, 500 ), 'excluded_total' => count( $excl ) );
	}

	/** Validate a client-supplied (label, rel) pair and return the real path. */
	private static function resolve( string $label, string $rel ): array {
		$roots = self::roots();
		if ( ! isset( $roots[ $label ] ) ) {
			throw new \RuntimeException( 'Unknown root' );
		}
		if ( '' === $rel || false !== strpos( $rel, "\0" ) || false !== strpos( $rel, '\\' ) || '/' === $rel[0] ) {
			throw new \RuntimeException( 'Bad path' );
		}
		$segments = explode( '/', $rel );
		foreach ( $segments as $s ) {
			if ( '' === $s || '.' === $s || '..' === $s ) {
				throw new \RuntimeException( 'Bad path' );
			}
		}
		if ( 'dropins' === $label && ( count( $segments ) !== 1 || ! in_array( $rel, self::DROPINS, true ) ) ) {
			throw new \RuntimeException( 'Bad path' );
		}
		foreach ( array_slice( $segments, 0, -1 ) as $s ) {
			if ( in_array( $s, self::DENY_DIRS, true ) ) {
				throw new \RuntimeException( 'Denied path' );
			}
		}
		if ( self::denied_name( end( $segments ) ) ) {
			throw new \RuntimeException( 'Denied path' );
		}
		$real = realpath( $roots[ $label ]['dir'] . '/' . $rel );
		if ( ! $real || ! is_file( $real ) || ! self::inside( $real, self::bases( $label, $roots ) ) ) {
			throw new \RuntimeException( 'File not available' );
		}
		return array( $real, $roots[ $label ]['prefix'] . '/' . $rel );
	}

	/** ustar header for $name; paths that do not fit ustar's name/prefix split get a PAX extended header (readable by GNU tar, bsdtar, busybox). */
	private static function tar_header( string $name, int $size, int $mtime, int $mode ): string {
		$prefix = '';
		$short  = $name;
		$pax    = '';
		if ( strlen( $name ) > 100 ) {
			$ok = false;
			for ( $i = strlen( $name ) - 1; $i > 0; $i-- ) {
				if ( '/' === $name[ $i ] && $i <= 155 && ( strlen( $name ) - $i - 1 ) <= 100 ) {
					$prefix = substr( $name, 0, $i );
					$short  = substr( $name, $i + 1 );
					$ok     = true;
					break;
				}
			}
			if ( ! $ok ) {
				$rec = ' path=' . $name . "\n";
				$len = strlen( $rec ) + 1;
				while ( strlen( (string) $len ) + strlen( $rec ) !== $len ) {
					$len = strlen( (string) $len ) + strlen( $rec );
				}
				$rec    = $len . $rec;
				$pax    = self::raw_header( 'PaxHeader/' . substr( md5( $name ), 0, 12 ), strlen( $rec ), $mtime, 0644, '', 'x' )
					. $rec . str_repeat( "\0", ( 512 - ( strlen( $rec ) % 512 ) ) % 512 );
				$short  = substr( $name, 0, 99 );
				$prefix = '';
			}
		}
		return $pax . self::raw_header( $short, $size, $mtime, $mode, $prefix, '0' );
	}

	private static function raw_header( string $name, int $size, int $mtime, int $mode, string $prefix, string $type ): string {
		$h = str_pad( $name, 100, "\0" )
			. sprintf( '%07o', $mode ) . "\0"
			. sprintf( '%07o', 0 ) . "\0"
			. sprintf( '%07o', 0 ) . "\0"
			. sprintf( '%011o', $size ) . "\0"
			. sprintf( '%011o', max( 0, $mtime ) ) . "\0"
			. '        '
			. $type
			. str_repeat( "\0", 100 )
			. "ustar\0" . '00'
			. str_pad( 'root', 32, "\0" ) . str_pad( 'root', 32, "\0" )
			. "0000000\0" . "0000000\0"
			. str_pad( $prefix, 155, "\0" )
			. str_repeat( "\0", 12 );
		$sum = 0;
		for ( $i = 0; $i < 512; $i++ ) {
			$sum += ord( $h[ $i ] );
		}
		return substr( $h, 0, 148 ) . sprintf( '%06o', $sum ) . "\0 " . substr( $h, 156 );
	}

	/**
	 * Build tar bytes for a batch of slices.
	 *
	 * @param array $items [ ['r'=>label,'p'=>rel,'o'=>offset,'l'=>length,'s'=>expected size], ... ]
	 * @return array{data:string,raw_bytes:int,warnings:array}
	 */
	public static function step( array $items ): array {
		if ( count( $items ) > self::MAX_ITEMS ) {
			throw new \RuntimeException( 'Too many items' );
		}
		$out   = '';
		$warn  = array();
		$total = 0;
		foreach ( $items as $it ) {
			if ( ! is_array( $it ) || ! isset( $it['r'], $it['p'] ) || ! is_string( $it['r'] ) || ! is_string( $it['p'] ) ) {
				throw new \RuntimeException( 'Bad item' );
			}
			$off = max( 0, (int) ( $it['o'] ?? 0 ) );
			$len = max( 0, (int) ( $it['l'] ?? 0 ) );
			$total += $len;
			if ( $total > self::MAX_BYTES ) {
				throw new \RuntimeException( 'Step too large' );
			}
			list( $real, $arc ) = self::resolve( $it['r'], $it['p'] );
			$size = (int) filesize( $real );
			if ( 0 === $off && $len >= $size ) {
				// whole file in one go: header is built from the bytes actually read (immune to concurrent changes).
				$data = (string) file_get_contents( $real );
				$size = strlen( $data );
				$out .= self::tar_header( $arc, $size, (int) filemtime( $real ), is_executable( $real ) ? 0755 : 0644 ) . $data;
				$out .= str_repeat( "\0", ( 512 - ( $size % 512 ) ) % 512 );
				continue;
			}
			if ( 0 === $off ) {
				$out .= self::tar_header( $arc, $size, (int) filemtime( $real ), is_executable( $real ) ? 0755 : 0644 );
			}
			if ( isset( $it['s'] ) && (int) $it['s'] !== $size ) {
				$warn[] = $it['r'] . '/' . $it['p'] . ' changed size during backup';
			}
			$chunk = '';
			$fh    = fopen( $real, 'rb' );
			if ( $fh ) {
				fseek( $fh, $off );
				$chunk = (string) fread( $fh, max( 0, min( $len, $size - $off ) ) );
				fclose( $fh );
			}
			$out .= str_pad( $chunk, $len, "\0" ); // keeps the archive structurally valid if the file shrank.
			if ( $off + $len >= $size ) {
				$out .= str_repeat( "\0", ( 512 - ( $size % 512 ) ) % 512 );
			}
		}
		return array( 'data' => base64_encode( gzencode( $out, 6 ) ), 'raw_bytes' => strlen( $out ), 'warnings' => $warn );
	}

	/** Two zero blocks = end of tar archive. */
	public static function end(): string {
		return base64_encode( gzencode( str_repeat( "\0", 1024 ), 6 ) );
	}
}
