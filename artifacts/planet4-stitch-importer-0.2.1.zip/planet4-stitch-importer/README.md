# Planet4 Stitch Importer (v0.2.1)

מייצר עמוד טיוטה ב-Planet4 ממבנה JSON שנגזר מעיצוב Google Stitch.
**סדר עדיפויות לכל מקטע:** בלוק Planet4 ← פטרן Planet4 (בלוקי ליבה + מחלקות התמה) ← בלוק ליבה ← HTML (מוצא אחרון).
בכל הרצה מתקבל דו"ח מיפוי שמראה מה מופה לאן.

## זרימת עבודה (v0.2: ישירות מה-ZIP של Stitch)
1. ב-Stitch: Export → הורדת ה-ZIP (code.html + DESIGN.md + screen.png).
2. ב-WP: **עמודים ← Stitch → Planet4**, מעלים את ה-ZIP (אפשר להזין מזהה טופס Gravity Forms).
3. "תצוגה מקדימה": דו"ח מיפוי + הערות על העיצוב + JSON שנוצר (ניתן לעריכה).
4. "צור עמוד טיוטה". מסמנים "ייבא תמונות" כדי להעביר תמונות Stitch לספריית המדיה.
ה-ZIP נקרא בזיכרון בלבד (רק code.html ו-DESIGN.md), בלי חילוץ לדיסק.
אפשר גם להדביק JSON ידנית בלי ZIP.

## מה הפרסר מזהה ב-code.html
Header/Footer מדולגים (התמה מספקת). פס התקדמות ("45,230 / 50,000") ← Counter. אזור עם h1 ← Page Header (+ טופס אם יש). טופס ← Gravity Forms. רצועת קישור ← כפתור. כותרת+טקסט+תמונה ← Side image. קבוצת כרטיסים חוזרים ← Columns. כל השאר ← טקסט, או דולג עם הערה.
טוקנים: צבעי DESIGN.md מושווים לפלטת Planet4; גבולות/צללים/פינות חדות מוחלים כ-CSS ברמת העמוד בלבד (`body.p4si-stitch`). פונטים לא נטענים.

## סוגי מקטעים (`type`)
| type | מופה אל | שדות עיקריים |
|---|---|---|
| `page_header` | פטרן Page Header | title, text, image, media_position, button |
| `quick_links` | פטרן Quick Links | title, items[title,image], background |
| `side_image` | פטרן Side image + CTA | title, text, image, media_position, background, button |
| `highlighted_cta` | פטרן Highlighted CTA | title, image, background, button |
| `reality_check` | פטרן Reality Check | items[title,text,image] |
| `issues` | פטרן Issues | title, text, items[title,image], button |
| `columns` | Columns (ליבה) | title, columns[image,title,text,button] |
| `text` | ליבה | title, level, paragraphs[], button |
| `accordion` | `planet4-blocks/accordion` | title, items[headline,text] |
| `counter` | `planet4-blocks/counter` | title, completed, target, text |
| `gallery` | `planet4-blocks/gallery` | title, layout, images[] |
| `carousel_header` | `planet4-blocks/carousel-header` | slides[title,text,image,button] |
| `take_action` | `planet4-blocks/take-action-boxout` | title, text, image, button |
| `timeline` | `planet4-blocks/timeline` | title, google_sheets_url |
| `spacer` | ליבה | height |
| `html` | HTML (fallback) | html, reason |

`button`: `{text, url, style: cta|secondary|transparent}`. `background`/צבעים: שם צבע מהפלטה או hex.
Hex שקרוב לצבע מותג (מרחק RGB ≤ 36) מומר אוטומטית לצבע הפלטה; אחרת נשמר כצבע מותאם.
מפתח `css` ברמת העמוד: CSS נקודתי שנטען רק בעמוד זה (לטוקנים שאינם בתמה).

## בדיקות
`php tests/run-mapper.php examples/sample-page.json out.html` מריץ את המפה מחוץ ל-WP.
ה-markup אומת מול `@wordpress/block-library` (0 בלוקים לא תקינים בדוגמה).

## מחוץ לטווח בגרסה זו
Posts List / Query Loop, טפסי Gravity Forms, Happypoint, ניווט משני, ופרסום אוטומטי (העמוד נוצר כטיוטה בלבד).
