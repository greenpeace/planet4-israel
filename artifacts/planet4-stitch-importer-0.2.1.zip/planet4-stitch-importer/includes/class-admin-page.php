<?php
/**
 * Admin UI: paste a design spec (JSON), preview the block mapping, create a draft page.
 *
 * @package P4StitchImporter
 */

namespace P4StitchImporter;

defined( 'ABSPATH' ) || exit;

/**
 * Class Admin_Page
 */
class Admin_Page {

	public const SLUG     = 'p4-stitch-importer';
	public const CSS_META = '_p4si_page_css';

	/**
	 * Request-level cache for sideloaded images.
	 *
	 * @var array<string,array>
	 */
	private array $image_cache = [];

	/**
	 * Hook everything.
	 */
	public function init(): void {
		add_action( 'admin_menu', [ $this, 'menu' ] );
		add_action( 'wp_head', [ $this, 'print_page_css' ], 99 );
		add_filter( 'body_class', [ $this, 'body_class' ] );
	}

	/**
	 * Register the menu entry under Pages.
	 */
	public function menu(): void {
		$hook = add_pages_page( 'Stitch → Planet4', 'Stitch → Planet4', 'edit_pages', self::SLUG, [ $this, 'render' ] );
		if ( $hook ) {
			// Runs before wp-admin prints any output, so redirects work.
			add_action( 'load-' . $hook, [ $this, 'process' ] );
		}
	}

	/**
	 * Adds .p4si-stitch to pages that carry generated CSS.
	 *
	 * @param string[] $classes Body classes.
	 * @return string[]
	 */
	public function body_class( array $classes ): array {
		if ( is_singular( 'page' ) && get_post_meta( get_queried_object_id(), self::CSS_META, true ) ) {
			$classes[] = 'p4si-stitch';
		}
		return $classes;
	}

	/**
	 * Reads code.html and DESIGN.md out of an uploaded Stitch ZIP without extracting to disk.
	 *
	 * @param string $tmp_path Uploaded file path.
	 * @return array{html:string,design:string}|\WP_Error
	 */
	private function read_zip( string $tmp_path ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new \WP_Error( 'p4si_zip', 'התוסף PHP ZipArchive אינו זמין בשרת.' );
		}
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $tmp_path ) ) {
			return new \WP_Error( 'p4si_zip', 'לא ניתן לפתוח את קובץ ה-ZIP.' );
		}
		$out = [ 'html' => '', 'design' => '' ];
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$stat = $zip->statIndex( $i );
			$base = strtolower( basename( (string) $stat['name'] ) );
			if ( $stat['size'] > 3 * MB_IN_BYTES ) {
				continue;
			}
			if ( 'code.html' === $base && '' === $out['html'] ) {
				$out['html'] = (string) $zip->getFromIndex( $i );
			} elseif ( 'design.md' === $base && '' === $out['design'] ) {
				$out['design'] = (string) $zip->getFromIndex( $i );
			}
		}
		$zip->close();
		if ( '' === $out['html'] ) {
			return new \WP_Error( 'p4si_zip', 'לא נמצא code.html בתוך ה-ZIP (האם זה ייצוא של Stitch?).' );
		}
		return $out;
	}

	/**
	 * Print the optional per-page CSS (design tokens that are not in the theme).
	 */
	public function print_page_css(): void {
		if ( ! is_singular( 'page' ) ) {
			return;
		}
		$css = get_post_meta( get_queried_object_id(), self::CSS_META, true );
		if ( $css ) {
			echo '<style id="p4si-page-css">' . str_replace( [ '<', '>' ], '', $css ) . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	/**
	 * Image resolver used by the mapper.
	 *
	 * @param mixed $img  String URL or array.
	 * @param bool  $sideload Import into the media library.
	 */
	public function resolve_image( $img, bool $sideload ): ?array {
		$alt = '';
		if ( is_array( $img ) ) {
			$alt = (string) ( $img['alt'] ?? '' );
			$img = $img['url'] ?? '';
		}
		$url = esc_url_raw( (string) $img );
		if ( '' === $url ) {
			return null;
		}
		if ( ! $sideload || 0 !== strpos( $url, 'http' ) || 0 === strpos( $url, home_url() ) ) {
			return [ 'url' => $url, 'id' => 0, 'alt' => $alt ];
		}
		if ( isset( $this->image_cache[ $url ] ) ) {
			return $this->image_cache[ $url ];
		}
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$id = media_sideload_image( $url, 0, $alt, 'id' );
		if ( is_wp_error( $id ) ) {
			$result = [ 'url' => $url, 'id' => 0, 'alt' => $alt ];
		} else {
			$result = [ 'url' => wp_get_attachment_url( $id ), 'id' => (int) $id, 'alt' => $alt ];
		}
		$this->image_cache[ $url ] = $result;
		return $result;
	}

	/**
	 * Form state shared between process() and render().
	 *
	 * @var array
	 */
	private array $state = [
		'json'      => '',
		'title'     => '',
		'sideload'  => false,
		'apply_css' => true,
		'form_id'   => 0,
		'result'    => null,
		'error'     => '',
		'notes'     => [],
	];

	/**
	 * Handle the submitted form. Hooked on load-{page}, i.e. before any output.
	 */
	public function process(): void {
		if ( ! current_user_can( 'edit_pages' ) ) {
			return;
		}
		$json      = '';
		$title     = '';
		$sideload  = false;
		$apply_css = true;
		$form_id   = 0;
		$result    = null;
		$error     = '';
		$notes     = [];

		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['p4si_action'] ) ) {
			check_admin_referer( 'p4si_run' );
			$json      = wp_unslash( $_POST['p4si_json'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$title     = sanitize_text_field( wp_unslash( $_POST['p4si_title'] ?? '' ) );
			$sideload  = ! empty( $_POST['p4si_sideload'] );
			$apply_css = ! empty( $_POST['p4si_apply_css'] );
			$form_id   = absint( $_POST['p4si_form_id'] ?? 0 );

			// A ZIP from Stitch takes precedence over pasted JSON.
			if ( ! empty( $_FILES['p4si_zip']['tmp_name'] ) && UPLOAD_ERR_OK === (int) $_FILES['p4si_zip']['error'] ) {
				$ext = strtolower( pathinfo( (string) $_FILES['p4si_zip']['name'], PATHINFO_EXTENSION ) );
				$zip = 'zip' === $ext ? $this->read_zip( $_FILES['p4si_zip']['tmp_name'] ) : new \WP_Error( 'p4si_zip', 'יש להעלות קובץ ZIP.' ); // phpcs:ignore
				if ( is_wp_error( $zip ) ) {
					$error = $zip->get_error_message();
				} else {
					$parser = new Stitch_Parser();
					$parsed = $parser->parse( $zip['html'], $zip['design'], [ 'form_id' => $form_id ] );
					$notes  = $parsed['notes'];
					if ( $apply_css ) {
						$parsed['css'] = Stitch_Parser::build_css( $parsed['traits'] );
					}
					unset( $parsed['traits'], $parsed['notes'] );
					$json  = wp_json_encode( $parsed, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
					$title = $title ?: (string) ( $parsed['title'] ?? '' );
				}
			}

			$spec = $error ? null : json_decode( $json, true );

			if ( ! $error && ( ! is_array( $spec ) || empty( $spec['sections'] ) ) ) {
				$error = 'לא נמצאו מקטעים: העלה ZIP של Stitch או הדבק JSON תקין עם המפתח "sections".';
			} elseif ( ! $error ) {
				$title  = $title ?: (string) ( $spec['title'] ?? 'עמוד חדש מ-Stitch' );
				$mapper = new Section_Mapper( fn( $img ) => $this->resolve_image( $img, $sideload ) );
				$result = $mapper->map( $spec );

				if ( 'create' === $_POST['p4si_action'] ) {
					$post_id = wp_insert_post(
						[
							'post_type'    => 'page',
							'post_status'  => 'draft',
							'post_title'   => $title,
							'post_content' => wp_slash( $result['content'] ),
						],
						true
					);
					if ( is_wp_error( $post_id ) ) {
						$error = $post_id->get_error_message();
					} else {
						if ( ! empty( $spec['css'] ) ) {
							update_post_meta( $post_id, self::CSS_META, wp_strip_all_tags( (string) $spec['css'] ) );
						}
						wp_safe_redirect( get_edit_post_link( $post_id, 'raw' ) );
						exit;
					}
				}
			}
		}

		$this->state = compact( 'json', 'title', 'sideload', 'apply_css', 'form_id', 'result', 'error', 'notes' );
	}

	/**
	 * Render page.
	 */
	public function render(): void {
		if ( ! current_user_can( 'edit_pages' ) ) {
			wp_die( esc_html__( 'אין הרשאה.', 'p4-stitch-importer' ) );
		}
		// phpcs:ignore WordPress.PHP.DontExtract
		extract( $this->state, EXTR_OVERWRITE );

		$labels = [
			'p4-block'   => '🟢 בלוק Planet4',
			'p4-pattern' => '🟢 פטרן Planet4',
			'core'       => '🟡 בלוק ליבה',
			'fallback'   => '🔴 HTML מותאם',
			'skipped'    => '⚪ דולג',
		];
		?>
		<div class="wrap" dir="rtl">
			<h1>Stitch → Planet4</h1>
			<p>הדבק מבנה עמוד (JSON) שנוצר מעיצוב Stitch. הפלאגאין ימפה כל מקטע לבלוק או פטרן של Planet4, ורק אם אין התאמה - לבלוק ליבה או HTML.</p>

			<?php if ( $error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<form method="post" enctype="multipart/form-data">
				<?php wp_nonce_field( 'p4si_run' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="p4si_zip">ייצוא Stitch (ZIP)</label></th>
						<td>
							<input type="file" id="p4si_zip" name="p4si_zip" accept=".zip">
							<p class="description">ה-ZIP שמורידים מ-Stitch (code.html + DESIGN.md + screen.png). מנותח אוטומטית למקטעים.</p>
						</td>
					</tr>
					<tr>
						<th><label for="p4si_title">כותרת העמוד</label></th>
						<td><input type="text" id="p4si_title" name="p4si_title" class="regular-text" value="<?php echo esc_attr( $title ); ?>"></td>
					</tr>
					<tr>
						<th><label for="p4si_form_id">מזהה טופס Gravity Forms</label></th>
						<td><input type="number" id="p4si_form_id" name="p4si_form_id" min="0" class="small-text" value="<?php echo $form_id ? (int) $form_id : ''; ?>">
							<p class="description">אם העיצוב כולל טופס (עצומה), הזן מזהה של טופס קיים. ריק = יישמר מקום לטופס.</p></td>
					</tr>
					<tr>
						<th>אפשרויות</th>
						<td>
							<label><input type="checkbox" name="p4si_sideload" value="1" <?php checked( $sideload ); ?>> ייבא תמונות חיצוניות לספריית המדיה (מומלץ; נדרש לבלוק Gallery)</label><br>
							<label><input type="checkbox" name="p4si_apply_css" value="1" <?php checked( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || $apply_css ); ?>> החל סגנון Stitch (גבולות, צללים, כפתורים) כ-CSS ברמת העמוד בלבד</label>
						</td>
					</tr>
					<tr>
						<th><label for="p4si_json">מבנה העמוד (JSON)</label></th>
						<td><textarea id="p4si_json" name="p4si_json" rows="14" class="large-text code" dir="ltr"><?php echo esc_textarea( $json ); ?></textarea>
							<p class="description">נוצר אוטומטית מה-ZIP לאחר "תצוגה מקדימה" וניתן לעריכה לפני יצירת העמוד. אפשר גם להדביק JSON ידנית (בלי ZIP).</p></td>
					</tr>
				</table>
				<p>
					<button class="button" name="p4si_action" value="preview">תצוגה מקדימה של המיפוי</button>
					<button class="button button-primary" name="p4si_action" value="create">צור עמוד טיוטה</button>
				</p>
			</form>

			<?php if ( $notes ) : ?>
				<div class="notice notice-warning inline"><p><strong>הערות על העיצוב:</strong></p><ul style="list-style:disc;margin-inline-start:24px">
					<?php foreach ( $notes as $n ) : ?>
						<li><?php echo esc_html( $n ); ?></li>
					<?php endforeach; ?>
				</ul></div>
			<?php endif; ?>

			<?php if ( $result ) : ?>
				<h2>דו"ח מיפוי</h2>
				<table class="widefat striped" style="max-width:900px">
					<thead><tr><th>#</th><th>מקטע</th><th>מופה אל</th><th>פירוט</th></tr></thead>
					<tbody>
					<?php foreach ( $result['report'] as $row ) : ?>
						<tr>
							<td><?php echo (int) $row['index']; ?></td>
							<td><code><?php echo esc_html( $row['type'] ); ?></code></td>
							<td><?php echo esc_html( $labels[ $row['via'] ] ?? $row['via'] ); ?></td>
							<td><?php echo esc_html( $row['what'] ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<h2>Markup</h2>
				<textarea readonly rows="14" class="large-text code" dir="ltr"><?php echo esc_textarea( $result['content'] ); ?></textarea>
			<?php endif; ?>
		</div>
		<?php
	}
}
