<?php
/**
 * Serializes Gutenberg block markup (core blocks + Planet4 dynamic blocks).
 *
 * Output follows the exact save() markup of the core blocks, so the editor
 * does not flag "unexpected content" on the generated page.
 *
 * @package P4StitchImporter
 */

namespace P4StitchImporter;

defined( 'ABSPATH' ) || exit;

/**
 * Class Block_Builder
 */
class Block_Builder {

	/**
	 * Planet4 palette (slug => hex). Mirrors planet4-master-theme theme.json.
	 */
	public const PALETTE = [
		'gp-green-100'      => '#d9f1c5',
		'gp-green-200'      => '#b9e696',
		'green-400'         => '#80d643',
		'green-500'         => '#66cc00',
		'green-800'         => '#198700',
		'dark-green-800'    => '#1f4912',
		'dark-green-900'    => '#1a3c10',
		'blue-green-800'    => '#167f82',
		'action-yellow-100' => '#fff6bd',
		'action-yellow-500' => '#ffe100',
		'action-yellow-600' => '#fece00',
		'action-yellow-700' => '#fcb600',
		'red-100'           => '#fad1da',
		'red-500'           => '#d43b57',
		'beige-100'         => '#f6f4ef',
		'white'             => '#ffffff',
	];

	/**
	 * Encodes block-comment attributes the same way WordPress does.
	 *
	 * @param array $attrs Attributes.
	 */
	public static function encode_attrs( array $attrs ): string {
		if ( empty( $attrs ) ) {
			return '';
		}
		if ( function_exists( 'serialize_block_attributes' ) ) {
			return ' ' . serialize_block_attributes( $attrs );
		}
		$json = json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return ' ' . strtr(
			$json,
			[
				'--'  => '\u002d\u002d',
				'<'   => '\u003c',
				'>'   => '\u003e',
				'&'   => '\u0026',
				'\\"' => '\u0022',
			]
		);
	}

	/**
	 * Wraps HTML in block comments.
	 *
	 * @param string $name  Block name, e.g. core/group.
	 * @param array  $attrs Attributes.
	 * @param string $html  Saved HTML.
	 */
	public static function wrap( string $name, array $attrs, string $html ): string {
		$short = 0 === strpos( $name, 'core/' ) ? substr( $name, 5 ) : $name;
		return '<!-- wp:' . $short . self::encode_attrs( $attrs ) . " -->\n" . $html . "\n<!-- /wp:" . $short . ' -->';
	}

	/**
	 * Self-closing (dynamic) block.
	 *
	 * @param string $name  Block name.
	 * @param array  $attrs Attributes.
	 */
	public static function dynamic( string $name, array $attrs ): string {
		return '<!-- wp:' . $name . self::encode_attrs( $attrs ) . ' /-->';
	}

	/**
	 * Join inner blocks.
	 *
	 * @param array $blocks Block strings.
	 */
	public static function join( array $blocks ): string {
		return implode( "\n\n", array_filter( $blocks ) );
	}

	/**
	 * Limited inline HTML for text fields.
	 *
	 * @param string $text Raw text.
	 */
	public static function inline( string $text ): string {
		$allowed = [
			'strong' => [],
			'em'     => [],
			'b'      => [],
			'i'      => [],
			'br'     => [],
			'a'      => [ 'href' => [] ],
		];
		if ( function_exists( 'wp_kses' ) ) {
			return wp_kses( $text, $allowed );
		}
		return strip_tags( $text, '<strong><em><b><i><br><a>' );
	}

	/**
	 * Resolves a colour to a palette slug (or a custom hex when too far).
	 *
	 * @param string|null $color Slug, or hex / rgb value.
	 * @return array{slug:?string,hex:?string,exact:bool}|null
	 */
	public static function resolve_color( ?string $color ): ?array {
		if ( null === $color || '' === trim( $color ) ) {
			return null;
		}
		$color = strtolower( trim( $color ) );
		if ( isset( self::PALETTE[ $color ] ) ) {
			return [
				'slug'  => $color,
				'hex'   => self::PALETTE[ $color ],
				'exact' => true,
			];
		}
		$rgb = self::hex_to_rgb( $color );
		if ( ! $rgb ) {
			return null;
		}
		$best      = null;
		$best_dist = PHP_INT_MAX;
		foreach ( self::PALETTE as $slug => $hex ) {
			$p    = self::hex_to_rgb( $hex );
			$dist = sqrt( ( $rgb[0] - $p[0] ) ** 2 + ( $rgb[1] - $p[1] ) ** 2 + ( $rgb[2] - $p[2] ) ** 2 );
			if ( $dist < $best_dist ) {
				$best_dist = $dist;
				$best      = $slug;
			}
		}
		// Close enough to a brand colour: use the palette (keeps the page on-brand).
		if ( $best_dist <= 36 ) {
			return [
				'slug'  => $best,
				'hex'   => self::PALETTE[ $best ],
				'exact' => false,
			];
		}
		return [
			'slug'  => null,
			'hex'   => sprintf( '#%02x%02x%02x', $rgb[0], $rgb[1], $rgb[2] ),
			'exact' => true,
		];
	}

	/**
	 * Hex / rgb() to [r,g,b].
	 *
	 * @param string $value Colour.
	 * @return int[]|null
	 */
	public static function hex_to_rgb( string $value ): ?array {
		if ( preg_match( '/^#([0-9a-f]{3})$/', $value, $m ) ) {
			$h = $m[1];
			return [ hexdec( $h[0] . $h[0] ), hexdec( $h[1] . $h[1] ), hexdec( $h[2] . $h[2] ) ];
		}
		if ( preg_match( '/^#([0-9a-f]{6})$/', $value, $m ) ) {
			return [ hexdec( substr( $m[1], 0, 2 ) ), hexdec( substr( $m[1], 2, 2 ) ), hexdec( substr( $m[1], 4, 2 ) ) ];
		}
		if ( preg_match( '/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/', $value, $m ) ) {
			return [ (int) $m[1], (int) $m[2], (int) $m[3] ];
		}
		return null;
	}

	/**
	 * Common decoration (colours, font size, spacing) for text/group blocks.
	 *
	 * Supported keys: textColor, backgroundColor, fontSize, marginTop, marginBottom,
	 * paddingTop, paddingBottom, className.
	 *
	 * @param array $o Options.
	 * @return array{attrs:array,classes:string[],css:string}
	 */
	public static function decor( array $o ): array {
		$attrs   = [];
		$classes = [];
		$style   = [];
		$css     = [];

		if ( ! empty( $o['className'] ) ) {
			$attrs['className'] = $o['className'];
		}

		foreach ( [
			'textColor'       => [ 'color', 'text', 'color' ],
			'backgroundColor' => [ 'background-color', 'background', 'background-color' ],
		] as $key => $def ) {
			$c = self::resolve_color( $o[ $key ] ?? null );
			if ( ! $c ) {
				continue;
			}
			if ( 'backgroundColor' === $key ) {
				$classes[] = 'has-background';
			} else {
				$classes[] = 'has-text-color';
			}
			if ( $c['slug'] ) {
				$attrs[ $key ] = $c['slug'];
				$classes[]     = 'has-' . $c['slug'] . '-' . $def[2];
			} else {
				$style['color'][ $def[1] ] = $c['hex'];
				$css[]                     = $def[0] . ':' . $c['hex'];
			}
		}

		if ( ! empty( $o['fontSize'] ) ) {
			$style['typography']['fontSize'] = $o['fontSize'];
			$css[]                           = 'font-size:' . $o['fontSize'];
		}

		foreach ( [ 'margin' => [ 'Top', 'Bottom' ], 'padding' => [ 'Top', 'Bottom' ] ] as $prop => $sides ) {
			foreach ( $sides as $side ) {
				$k = $prop . $side;
				if ( isset( $o[ $k ] ) && '' !== $o[ $k ] ) {
					$style['spacing'][ $prop ][ strtolower( $side ) ] = $o[ $k ];
					$css[] = $prop . '-' . strtolower( $side ) . ':' . $o[ $k ];
				}
			}
		}

		if ( $style ) {
			$attrs['style'] = $style;
		}

		return [
			'attrs'   => $attrs,
			'classes' => $classes,
			'css'     => implode( ';', $css ),
		];
	}

	/**
	 * Builds class="" and style="" attribute strings.
	 *
	 * @param string[] $classes Classes.
	 * @param string   $css     Inline CSS.
	 */
	public static function html_attrs( array $classes, string $css = '' ): string {
		$classes = array_values( array_unique( array_filter( $classes ) ) );
		$out     = $classes ? ' class="' . esc_attr( implode( ' ', $classes ) ) . '"' : '';
		if ( '' !== $css ) {
			$out .= ' style="' . esc_attr( $css ) . '"';
		}
		return $out;
	}

	/**
	 * Heading.
	 *
	 * @param string $text  Text (inline HTML allowed).
	 * @param int    $level 1-6.
	 * @param array  $o     Options (+ align).
	 */
	public static function heading( string $text, int $level = 2, array $o = [] ): string {
		if ( '' === trim( $text ) ) {
			return '';
		}
		$d = self::decor( $o );
		$a = $d['attrs'];
		if ( 2 !== $level ) {
			$a = [ 'level' => $level ] + $a;
		}
		$classes = [ 'wp-block-heading' ];
		if ( ! empty( $o['align'] ) ) {
			$a['textAlign'] = $o['align'];
			$classes[]      = 'has-text-align-' . $o['align'];
		}
		$classes = array_merge( $classes, $d['classes'], isset( $o['className'] ) ? explode( ' ', $o['className'] ) : [] );
		$tag     = 'h' . $level;
		return self::wrap( 'core/heading', $a, '<' . $tag . self::html_attrs( $classes, $d['css'] ) . '>' . self::inline( $text ) . '</' . $tag . '>' );
	}

	/**
	 * Paragraph.
	 *
	 * @param string $text Text.
	 * @param array  $o    Options (+ align).
	 */
	public static function paragraph( string $text, array $o = [] ): string {
		if ( '' === trim( $text ) ) {
			return '';
		}
		$d       = self::decor( $o );
		$a       = $d['attrs'];
		$classes = [];
		if ( ! empty( $o['align'] ) ) {
			$a['align'] = $o['align'];
			$classes[]  = 'has-text-align-' . $o['align'];
		}
		$classes = array_merge( $classes, $d['classes'], isset( $o['className'] ) ? explode( ' ', $o['className'] ) : [] );
		return self::wrap( 'core/paragraph', $a, '<p' . self::html_attrs( $classes, $d['css'] ) . '>' . nl2br( self::inline( $text ), false ) . '</p>' );
	}

	/**
	 * Buttons group with one button.
	 *
	 * @param string|null $text  Label.
	 * @param string|null $url   URL.
	 * @param string      $style cta|secondary|transparent.
	 * @param bool        $center Centre the button.
	 */
	public static function button( ?string $text, ?string $url, string $style = 'cta', bool $center = false ): string {
		if ( empty( $text ) ) {
			return '';
		}
		$cls   = 'is-style-' . $style;
		$btn   = self::wrap(
			'core/button',
			[ 'className' => $cls ],
			'<div class="wp-block-button ' . $cls . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $url ?: '#' ) . '">' . esc_html( $text ) . '</a></div>'
		);
		$attrs = $center ? [ 'layout' => [ 'type' => 'flex', 'justifyContent' => 'center' ] ] : [];
		return self::wrap( 'core/buttons', $attrs, '<div class="wp-block-buttons">' . $btn . '</div>' );
	}

	/**
	 * Spacer.
	 *
	 * @param int $px Height in px.
	 */
	public static function spacer( int $px ): string {
		return self::wrap( 'core/spacer', [ 'height' => $px . 'px' ], '<div style="height:' . $px . 'px" aria-hidden="true" class="wp-block-spacer"></div>' );
	}

	/**
	 * Image.
	 *
	 * @param array|null $img ['url','id','alt'].
	 * @param array      $o   Options: align, className.
	 */
	public static function image( ?array $img, array $o = [] ): string {
		if ( empty( $img['url'] ) ) {
			return '';
		}
		$a       = [];
		$classes = [ 'wp-block-image' ];
		if ( ! empty( $o['align'] ) ) {
			$a['align'] = $o['align'];
			$classes[]  = 'align' . $o['align'];
		}
		$img_class = '';
		if ( ! empty( $img['id'] ) ) {
			$a['id']              = (int) $img['id'];
			$a['sizeSlug']        = 'full';
			$a['linkDestination'] = 'none';
			$classes[]            = 'size-full';
			$img_class            = ' class="wp-image-' . (int) $img['id'] . '"';
		} else {
			$a['linkDestination'] = 'none';
		}
		if ( ! empty( $o['className'] ) ) {
			$a['className'] = $o['className'];
			$classes        = array_merge( $classes, explode( ' ', $o['className'] ) );
		}
		$html = '<figure' . self::html_attrs( $classes ) . '><img src="' . esc_url( $img['url'] ) . '" alt="' . esc_attr( $img['alt'] ?? '' ) . '"' . $img_class . '/></figure>';
		return self::wrap( 'core/image', $a, $html );
	}

	/**
	 * Group.
	 *
	 * @param string[] $inner Inner blocks.
	 * @param array    $o     Options (+ align = full).
	 */
	public static function group( array $inner, array $o = [] ): string {
		$d       = self::decor( $o );
		$a       = $d['attrs'];
		$classes = [ 'wp-block-group' ];
		if ( ! empty( $o['align'] ) ) {
			$a['align'] = $o['align'];
			$classes[]  = 'align' . $o['align'];
		}
		if ( ! empty( $o['className'] ) ) {
			$classes = array_merge( $classes, explode( ' ', $o['className'] ) );
		}
		$classes = array_merge( $classes, $d['classes'] );
		return self::wrap( 'core/group', $a, '<div' . self::html_attrs( $classes, $d['css'] ) . '>' . self::join( $inner ) . '</div>' );
	}

	/**
	 * Columns with column contents.
	 *
	 * @param array[] $cols Each item: array of inner block strings.
	 * @param array   $o    Options (className, isStackedOnMobile).
	 */
	public static function columns( array $cols, array $o = [] ): string {
		$a       = [];
		$classes = [ 'wp-block-columns' ];
		if ( isset( $o['isStackedOnMobile'] ) && false === $o['isStackedOnMobile'] ) {
			$a['isStackedOnMobile'] = false;
			$classes[]              = 'is-not-stacked-on-mobile';
		}
		if ( ! empty( $o['className'] ) ) {
			$a['className'] = $o['className'];
			$classes        = array_merge( $classes, explode( ' ', $o['className'] ) );
		}
		$html = [];
		foreach ( $cols as $inner ) {
			$html[] = self::wrap( 'core/column', [], '<div class="wp-block-column">' . self::join( $inner ) . '</div>' );
		}
		return self::wrap( 'core/columns', $a, '<div' . self::html_attrs( $classes ) . '>' . self::join( $html ) . '</div>' );
	}

	/**
	 * Media & Text.
	 *
	 * @param array|null $img   Image.
	 * @param string[]   $inner Inner blocks (content side).
	 * @param array      $o     Options: position (left|right), className.
	 */
	public static function media_text( ?array $img, array $inner, array $o = [] ): string {
		$a       = [];
		$classes = [ 'wp-block-media-text' ];
		if ( 'right' === ( $o['position'] ?? 'left' ) ) {
			$a['mediaPosition'] = 'right';
			$classes[]          = 'has-media-on-the-right';
		}
		$classes[] = 'is-stacked-on-mobile';
		$img_html  = '';
		if ( ! empty( $img['url'] ) ) {
			$a['mediaType'] = 'image';
			$cls            = '';
			if ( ! empty( $img['id'] ) ) {
				$a['mediaId'] = (int) $img['id'];
				$cls          = ' class="wp-image-' . (int) $img['id'] . '"';
			}
			$a['mediaLink'] = '';
			$img_html       = '<figure class="wp-block-media-text__media"><img src="' . esc_url( $img['url'] ) . '" alt="' . esc_attr( $img['alt'] ?? '' ) . '"' . $cls . '/></figure>';
		}
		if ( ! empty( $o['className'] ) ) {
			$a['className'] = $o['className'];
			$classes        = array_merge( $classes, explode( ' ', $o['className'] ) );
		}
		$d = self::decor( [ 'backgroundColor' => $o['backgroundColor'] ?? null ] );
		if ( isset( $d['attrs']['backgroundColor'] ) ) {
			$a['backgroundColor'] = $d['attrs']['backgroundColor'];
		}
		if ( isset( $d['attrs']['style'] ) ) {
			$a['style'] = $d['attrs']['style'];
		}
		$classes = array_merge( $classes, $d['classes'] );
		if ( ! empty( $o['align'] ) ) {
			$a['align'] = $o['align'];
			$classes[]  = 'align' . $o['align'];
		}
		$content = '<div class="wp-block-media-text__content">' . self::join( $inner ) . '</div>';
		// core save(): media first, except when it sits on the right.
		$body = 'right' === ( $o['position'] ?? 'left' ) ? $content . $img_html : $img_html . $content;
		$html = '<div' . self::html_attrs( $classes, $d['css'] ) . '>' . $body . '</div>';
		return self::wrap( 'core/media-text', $a, $html );
	}
}
