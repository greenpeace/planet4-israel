<?php
/**
 * Maps design-spec sections to Planet4 blocks.
 *
 * Priority (per section):
 *  1. Planet4 custom block   (planet4-blocks/*)            -> via = "p4-block"
 *  2. Planet4 pattern layout (core blocks + P4 classes,
 *     identical to the theme's block-templates)             -> via = "p4-pattern"
 *  3. Plain core blocks                                     -> via = "core"
 *  4. Sanitized HTML block (last resort)                    -> via = "fallback"
 *
 * @package P4StitchImporter
 */

namespace P4StitchImporter;

defined( 'ABSPATH' ) || exit;

use P4StitchImporter\Block_Builder as B;

/**
 * Class Section_Mapper
 */
class Section_Mapper {

	/**
	 * Image resolver: receives a string URL or array, returns ['url','id','alt'] or null.
	 *
	 * @var callable
	 */
	private $image_resolver;

	/**
	 * Mapping report.
	 *
	 * @var array
	 */
	private array $report = [];

	/**
	 * Constructor.
	 *
	 * @param callable|null $image_resolver Image resolver.
	 */
	public function __construct( ?callable $image_resolver = null ) {
		$this->image_resolver = $image_resolver ?? static function ( $img ) {
			if ( is_string( $img ) && '' !== $img ) {
				return [ 'url' => $img, 'id' => 0, 'alt' => '' ];
			}
			if ( is_array( $img ) && ! empty( $img['url'] ) ) {
				return [ 'url' => $img['url'], 'id' => (int) ( $img['id'] ?? 0 ), 'alt' => $img['alt'] ?? '' ];
			}
			return null;
		};
	}

	/**
	 * Map the whole spec.
	 *
	 * @param array $spec Decoded spec.
	 * @return array{content:string,report:array}
	 */
	public function map( array $spec ): array {
		$this->report = [];
		$out          = [];
		foreach ( $spec['sections'] ?? [] as $i => $section ) {
			$type   = $section['type'] ?? '';
			$method = 'section_' . $type;
			if ( ! method_exists( $this, $method ) ) {
				$this->note( $i, $type, 'skipped', 'סוג מקטע לא מוכר - דולג' );
				continue;
			}
			$markup = $this->$method( $section, $i );
			if ( '' !== $markup ) {
				$out[] = $markup;
			}
		}
		return [
			'content' => B::join( $out ),
			'report'  => $this->report,
		];
	}

	/**
	 * Add a report row.
	 *
	 * @param int    $i    Index.
	 * @param string $type Section type.
	 * @param string $via  Mapping tier.
	 * @param string $what Description.
	 */
	private function note( int $i, string $type, string $via, string $what ): void {
		$this->report[] = [
			'index' => $i + 1,
			'type'  => $type,
			'via'   => $via,
			'what'  => $what,
		];
	}

	/**
	 * Resolve an image.
	 *
	 * @param mixed $img Image input.
	 */
	private function img( $img ): ?array {
		return $img ? call_user_func( $this->image_resolver, $img ) : null;
	}

	/**
	 * Button helper from a spec button array.
	 *
	 * @param array|null $btn    ['text','url','style'].
	 * @param bool       $center Centre.
	 */
	private function btn( ?array $btn, bool $center = false ): string {
		if ( empty( $btn['text'] ) ) {
			return '';
		}
		return B::button( $btn['text'], $btn['url'] ?? '#', $btn['style'] ?? 'cta', $center );
	}

	/**
	 * Hero / page header (P4 "Page Header" pattern).
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_page_header( array $s, int $i ): string {
		$img   = $this->img( $s['image'] ?? null );
		$inner = [
			B::group( [ B::heading( $s['title'] ?? '', 1, [ 'backgroundColor' => 'white' ] ) ] ),
			B::paragraph( $s['text'] ?? '', [ 'fontSize' => '1.25rem' ] ),
			$this->btn( $s['button'] ?? null ),
		];
		$mt    = B::media_text(
			$img,
			$inner,
			[
				'position'  => $s['media_position'] ?? 'right',
				'className' => 'is-pattern-p4-page-header is-style-parallax',
				'align'     => 'full',
			]
		);
		$this->note( $i, 'page_header', 'p4-pattern', 'Page Header (Media&Text + parallax)' . ( $img ? '' : ' - ללא תמונה' ) );
		return B::group( [ B::group( [ $mt ], [ 'className' => 'container' ] ) ], [ 'align' => 'full' ] );
	}

	/**
	 * Quick links (circle icons row).
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_quick_links( array $s, int $i ): string {
		$cols = [];
		foreach ( $s['items'] ?? [] as $item ) {
			$cols[] = [
				B::group(
					[
						B::image( $this->img( $item['image'] ?? null ), [ 'align' => 'center', 'className' => 'is-style-rounded-90 force-no-lightbox force-no-caption mb-0' ] ),
						B::spacer( 16 ),
						B::heading( $item['title'] ?? '', 3, [ 'align' => 'center', 'fontSize' => '1rem' ] ),
					],
					[ 'className' => 'group-stretched-link' ]
				),
			];
		}
		$inner = [
			B::spacer( 24 ),
			B::heading( $s['title'] ?? '', 2, [ 'fontSize' => '1.75rem' ] ),
			B::columns( $cols, [ 'isStackedOnMobile' => false, 'className' => 'is-style-mobile-carousel quick-links' ] ),
		];
		$this->note( $i, 'quick_links', 'p4-pattern', 'Quick Links (' . count( $cols ) . ' פריטים)' );
		return B::group(
			[ B::group( $inner, [ 'className' => 'container' ] ) ],
			[ 'className' => 'block', 'align' => 'full', 'backgroundColor' => $s['background'] ?? 'beige-100' ]
		);
	}

	/**
	 * Side image with text and CTA.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_side_image( array $s, int $i ): string {
		$this->note( $i, 'side_image', 'p4-pattern', 'Side image with text and CTA' );
		return B::media_text(
			$this->img( $s['image'] ?? null ),
			[
				B::heading( $s['title'] ?? '', 2 ),
				B::paragraph( $s['text'] ?? '' ),
				$this->btn( $s['button'] ?? null ),
			],
			[
				'position'        => $s['media_position'] ?? 'left',
				'backgroundColor' => $s['background'] ?? null,
			]
		);
	}

	/**
	 * Highlighted CTA band.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_highlighted_cta( array $s, int $i ): string {
		$this->note( $i, 'highlighted_cta', 'p4-pattern', 'Highlighted CTA' );
		$inner = [
			B::spacer( 40 ),
			B::image( $this->img( $s['image'] ?? null ), [ 'align' => 'center', 'className' => 'force-no-lightbox force-no-caption' ] ),
			! empty( $s['image'] ) ? B::spacer( 32 ) : '',
			B::heading( $s['title'] ?? '', 2, [ 'align' => 'center', 'textColor' => 'white', 'fontSize' => '1.75rem' ] ),
			B::spacer( 24 ),
			$this->btn( $s['button'] ?? null, true ),
			B::spacer( 40 ),
		];
		return B::group( $inner, [ 'className' => 'block', 'backgroundColor' => $s['background'] ?? 'dark-green-800' ] );
	}

	/**
	 * Reality check: big numbers / facts in columns.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_reality_check( array $s, int $i ): string {
		$cols = [];
		foreach ( $s['items'] ?? [] as $item ) {
			$cols[] = [
				B::group(
					[
						B::image( $this->img( $item['image'] ?? null ), [ 'align' => 'center', 'className' => 'mb-0 force-no-lightbox force-no-caption' ] ),
						B::heading( $item['title'] ?? '', 3, [ 'align' => 'center', 'fontSize' => '4rem' ] ),
						B::paragraph( $item['text'] ?? '', [ 'align' => 'center' ] ),
						B::spacer( 16 ),
					]
				),
			];
		}
		$this->note( $i, 'reality_check', 'p4-pattern', 'Reality Check (' . count( $cols ) . ' עמודות)' );
		return B::join(
			[
				B::heading( $s['title'] ?? 'Reality check', 2, [ 'className' => 'visually-hidden' ] ),
				B::columns( $cols, [ 'className' => 'block' ] ),
			]
		);
	}

	/**
	 * Issues grid (white cards on beige).
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_issues( array $s, int $i ): string {
		$items = [];
		foreach ( $s['items'] ?? [] as $item ) {
			$items[] = B::group(
				[
					B::image( $this->img( $item['image'] ?? null ), [ 'className' => 'force-no-lightbox force-no-caption my-0 square-40' ] ),
					B::heading( $item['title'] ?? '', 3, [ 'className' => 'w-auto', 'fontSize' => '1rem', 'align' => 'left' ] ),
				],
				[ 'backgroundColor' => 'white' ]
			);
		}
		$this->note( $i, 'issues', 'p4-pattern', 'Issues (' . count( $items ) . ' פריטים)' );
		return B::group(
			[
				B::group(
					[
						B::heading( $s['title'] ?? '', 2, [ 'align' => 'center', 'marginBottom' => '24px' ] ),
						B::paragraph( $s['text'] ?? '', [ 'align' => 'center', 'className' => 'my-0' ] ),
						B::group( $items, [ 'className' => 'is-style-space-evenly', 'paddingTop' => '40px', 'paddingBottom' => '56px' ] ),
						$this->btn( $s['button'] ?? null, true ),
					],
					[ 'className' => 'container' ]
				),
			],
			[ 'align' => 'full', 'className' => 'block', 'backgroundColor' => $s['background'] ?? 'beige-100', 'paddingTop' => '80px', 'paddingBottom' => '80px' ]
		);
	}

	/**
	 * Cards in columns (image + title + text + button).
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_columns( array $s, int $i ): string {
		$cols = [];
		foreach ( $s['columns'] ?? [] as $c ) {
			$cols[] = [
				B::image( $this->img( $c['image'] ?? null ) ),
				B::heading( $c['title'] ?? '', 3 ),
				B::paragraph( $c['text'] ?? '' ),
				$this->btn( $c['button'] ?? null ),
			];
		}
		$this->note( $i, 'columns', 'core', 'Columns (' . count( $cols ) . ') - בלוק Columns של הליבה עם סגנון התמה' );
		$class = 'block' . ( ! empty( $s['cards'] ) ? ' p4si-cards' : '' );
		return B::join( [ B::heading( $s['title'] ?? '', 2 ), B::columns( $cols, [ 'className' => $class ] ) ] );
	}

	/**
	 * Plain text section.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_text( array $s, int $i ): string {
		$this->note( $i, 'text', 'core', 'כותרת + פסקאות' );
		$blocks = [ B::heading( $s['title'] ?? '', (int) ( $s['level'] ?? 2 ) ) ];
		foreach ( (array) ( $s['paragraphs'] ?? ( isset( $s['text'] ) ? [ $s['text'] ] : [] ) ) as $p ) {
			$blocks[] = B::paragraph( $p );
		}
		$blocks[] = $this->btn( $s['button'] ?? null );
		return B::join( $blocks );
	}

	/**
	 * FAQ -> Planet4 Accordion.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_accordion( array $s, int $i ): string {
		$tabs = [];
		foreach ( $s['items'] ?? [] as $item ) {
			$tab = [
				'headline' => $item['headline'] ?? ( $item['title'] ?? '' ),
				'text'     => $item['text'] ?? '',
			];
			if ( ! empty( $item['button']['text'] ) ) {
				$tab['button'] = [
					'button_text'    => $item['button']['text'],
					'button_url'     => $item['button']['url'] ?? '',
					'button_new_tab' => false,
				];
			}
			$tabs[] = $tab;
		}
		$this->note( $i, 'accordion', 'p4-block', 'planet4-blocks/accordion (' . count( $tabs ) . ' פריטים)' );
		return B::dynamic( 'planet4-blocks/accordion', [ 'title' => $s['title'] ?? '', 'description' => $s['description'] ?? '', 'tabs' => $tabs ] );
	}

	/**
	 * Counter block.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_counter( array $s, int $i ): string {
		$this->note( $i, 'counter', 'p4-block', 'planet4-blocks/counter' );
		return B::dynamic(
			'planet4-blocks/counter',
			array_filter(
				[
					'title'       => $s['title'] ?? '',
					'description' => $s['description'] ?? '',
					'completed'   => isset( $s['completed'] ) ? (int) $s['completed'] : null,
					'target'      => isset( $s['target'] ) ? (int) $s['target'] : null,
					'text'        => $s['text'] ?? '',
				],
				static fn( $v ) => null !== $v && '' !== $v
			)
		);
	}

	/**
	 * Gallery: P4 gallery needs attachment IDs, otherwise fall back to columns of images.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_gallery( array $s, int $i ): string {
		$imgs = [];
		foreach ( $s['images'] ?? [] as $raw ) {
			$r = $this->img( $raw );
			if ( $r ) {
				$imgs[] = $r;
			}
		}
		$ids = array_values( array_filter( array_map( static fn( $r ) => (int) $r['id'], $imgs ) ) );
		if ( $ids && count( $ids ) === count( $imgs ) ) {
			$this->note( $i, 'gallery', 'p4-block', 'planet4-blocks/gallery (' . count( $ids ) . ' תמונות)' );
			return B::dynamic(
				'planet4-blocks/gallery',
				[
					'className'           => 'is-style-' . ( $s['layout'] ?? 'grid' ),
					'gallery_block_title' => $s['title'] ?? '',
					'multiple_image'      => implode( ',', $ids ),
				]
			);
		}
		$this->note( $i, 'gallery', 'core', 'אין מזהי מדיה (הפעל "ייבא תמונות לספריית המדיה") - נבנה כגריד תמונות של הליבה' );
		$cols = array_map( static fn( $r ) => [ B::image( $r ) ], array_slice( $imgs, 0, 4 ) );
		return B::join( [ B::heading( $s['title'] ?? '', 2 ), B::columns( $cols ) ] );
	}

	/**
	 * Carousel header.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_carousel_header( array $s, int $i ): string {
		$slides = [];
		foreach ( $s['slides'] ?? [] as $slide ) {
			$r        = $this->img( $slide['image'] ?? null );
			$slides[] = array_filter(
				[
					'image'            => $r['id'] ?? 0,
					'image_url'        => $r['url'] ?? '',
					'image_alt'        => $r['alt'] ?? '',
					'header'           => $slide['title'] ?? '',
					'description'      => $slide['text'] ?? '',
					'link_text'        => $slide['button']['text'] ?? '',
					'link_url'         => $slide['button']['url'] ?? '',
					'link_url_new_tab' => false,
					'focal_points'     => [ 'x' => '50', 'y' => '50' ],
				],
				static fn( $v ) => '' !== $v && 0 !== $v
			);
		}
		$this->note( $i, 'carousel_header', 'p4-block', 'planet4-blocks/carousel-header (' . count( $slides ) . ' שקפים)' );
		return B::dynamic( 'planet4-blocks/carousel-header', [ 'carousel_autoplay' => false, 'slides' => $slides ] );
	}

	/**
	 * Take Action boxout with manual content.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_take_action( array $s, int $i ): string {
		$r = $this->img( $s['image'] ?? null );
		$this->note( $i, 'take_action', 'p4-block', 'planet4-blocks/take-action-boxout (תוכן ידני)' );
		return B::dynamic(
			'planet4-blocks/take-action-boxout',
			array_filter(
				[
					'title'    => $s['title'] ?? '',
					'excerpt'  => $s['text'] ?? '',
					'link'     => $s['button']['url'] ?? '',
					'linkText' => $s['button']['text'] ?? '',
					'imageId'  => $r['id'] ?? 0,
					'imageUrl' => $r['url'] ?? '',
					'imageAlt' => $r['alt'] ?? '',
				],
				static fn( $v ) => '' !== $v && 0 !== $v
			)
		);
	}

	/**
	 * Timeline (Google Sheets driven).
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_timeline( array $s, int $i ): string {
		$this->note( $i, 'timeline', 'p4-block', 'planet4-blocks/timeline (נדרש Google Sheet)' );
		return B::dynamic(
			'planet4-blocks/timeline',
			[
				'timeline_title'    => $s['title'] ?? '',
				'description'       => $s['description'] ?? '',
				'google_sheets_url' => $s['google_sheets_url'] ?? '',
			]
		);
	}

	/**
	 * Centered standalone button (anchor strips etc.).
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_button_row( array $s, int $i ): string {
		$this->note( $i, 'button_row', 'core', 'כפתור ממורכז (Buttons)' );
		return B::join( [ B::spacer( 16 ), $this->btn( $s['button'] ?? null, true ), B::spacer( 16 ) ] );
	}

	/**
	 * Form section (Gravity Forms, same layout as the P4 "gravity form with text" template).
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_form( array $s, int $i ): string {
		$form_id = (int) ( $s['form_id'] ?? 0 );
		$fields  = $s['fields'] ?? [];
		if ( $form_id ) {
			$right = B::dynamic( 'gravityforms/form', [ 'formId' => (string) $form_id, 'title' => false, 'description' => false ] );
			$this->note( $i, 'form', 'p4-block', 'Gravity Forms (טופס #' . $form_id . ')' );
		} else {
			$right = B::paragraph( '[כאן יוצג טופס - הוסף בלוק Gravity Forms ובחר טופס]', [ 'align' => 'center' ] );
			$this->note( $i, 'form', 'core', 'מקום שמור לטופס - לא הוזן מזהה Gravity Forms. השדות בעיצוב: ' . implode( ', ', $fields ) . ( ! empty( $s['submit'] ) ? ' | כפתור: ' . $s['submit'] : '' ) );
		}
		return B::group(
			[
				B::group(
					[
						B::columns(
							[
								[ B::heading( $s['title'] ?? '', 2, [ 'fontSize' => '40px' ] ), B::paragraph( $s['text'] ?? '' ) ],
								[ $right ],
							]
						),
					],
					[ 'className' => 'container' ]
				),
			],
			[ 'align' => 'full', 'backgroundColor' => $s['background'] ?? 'beige-100', 'paddingTop' => '80px', 'paddingBottom' => '50px' ]
		);
	}

	/**
	 * Spacer.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_spacer( array $s, int $i ): string {
		$this->note( $i, 'spacer', 'core', 'Spacer' );
		return B::spacer( (int) ( $s['height'] ?? 40 ) );
	}

	/**
	 * Last-resort HTML block.
	 *
	 * @param array $s Section.
	 * @param int   $i Index.
	 */
	private function section_html( array $s, int $i ): string {
		$html = function_exists( 'wp_kses_post' ) ? wp_kses_post( $s['html'] ?? '' ) : strip_tags( $s['html'] ?? '' );
		$this->note( $i, 'html', 'fallback', 'בלוק HTML מותאם - אין התאמה לבלוק Planet4. ' . ( $s['reason'] ?? '' ) );
		return B::wrap( 'core/html', [], $html );
	}
}
