<?php
/**
 * Parses a Google Stitch export (code.html + DESIGN.md) into the section spec
 * consumed by Section_Mapper. Deterministic: no network, no AI.
 *
 * Heuristics are intentionally conservative. Anything not recognised becomes a
 * plain `text` section (or is reported as skipped) instead of being guessed.
 *
 * @package P4StitchImporter
 */

namespace P4StitchImporter;

defined( 'ABSPATH' ) || exit;

/**
 * Class Stitch_Parser
 */
class Stitch_Parser {

	/**
	 * Notes for the user (things that were skipped / need manual work).
	 *
	 * @var string[]
	 */
	private array $notes = [];

	/**
	 * Style traits detected in the design (drive the optional page CSS).
	 *
	 * @var array
	 */
	private array $traits = [];

	/**
	 * Parse.
	 *
	 * @param string $html        code.html content.
	 * @param string $design_md   DESIGN.md content (optional).
	 * @param array  $options     form_id.
	 * @return array Spec.
	 */
	public function parse( string $html, string $design_md = '', array $options = [] ): array {
		$this->notes  = [];
		$this->traits = [];

		$doc = new \DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="utf-8"?>' . $html );
		libxml_clear_errors();
		$xp = new \DOMXPath( $doc );

		$title_node = $xp->query( '//title' )->item( 0 );
		$title      = $title_node ? trim( $title_node->textContent ) : '';

		if ( $xp->query( '//header' )->length || $xp->query( '//footer' )->length ) {
			$this->notes[] = 'Header ו-Footer של העיצוב לא יובאו - התמה של Planet4 מספקת אותם.';
		}

		$main = $xp->query( '//main' )->item( 0 );
		if ( ! $main ) {
			$main = $xp->query( '//body' )->item( 0 );
		}

		$sections = [];
		if ( $main ) {
			foreach ( $this->top_level_blocks( $main ) as $node ) {
				if ( in_array( $node->nodeName, [ 'header', 'footer', 'nav', 'script', 'style' ], true ) ) {
					continue;
				}
				foreach ( $this->classify( $node, $xp, $options ) as $section ) {
					$sections[] = $section;
				}
			}
		}

		$this->color_notes( $design_md );
		$this->font_notes( $design_md );

		return [
			'title'    => $title,
			'sections' => $sections,
			'traits'   => $this->traits,
			'notes'    => array_values( array_unique( $this->notes ) ),
		];
	}

	/**
	 * Direct children of <main>, unwrapping single-child wrappers.
	 *
	 * @param \DOMNode $main Main.
	 * @return \DOMElement[]
	 */
	private function top_level_blocks( \DOMNode $main ): array {
		$out = [];
		foreach ( $main->childNodes as $c ) {
			if ( XML_ELEMENT_NODE === $c->nodeType ) {
				$out[] = $c;
			}
		}
		if ( 1 === count( $out ) && $out[0]->nodeName === 'div' ) {
			return $this->top_level_blocks( $out[0] );
		}
		return $out;
	}

	/**
	 * Turn one top-level block into 0..n sections.
	 *
	 * @param \DOMElement $node Node.
	 * @param \DOMXPath   $xp   XPath.
	 * @param array       $o    Options.
	 * @return array[]
	 */
	private function classify( \DOMElement $node, \DOMXPath $xp, array $o ): array {
		$text = $this->clean( $node->textContent );
		if ( '' === $text && ! $xp->query( './/img', $node )->length ) {
			return [];
		}

		$this->detect_traits( $node );

		// 1. Progress bar: "45,230 / 50,000 ...".
		if ( ! $xp->query( './/h1|.//h2|.//h3|.//form', $node )->length && preg_match( '/([\d][\d,\.]*)\s*\/\s*([\d][\d,\.]*)/', $text, $m ) ) {
			$this->notes[] = 'פס ההתקדמות מופה לבלוק Counter - הערך "completed_api" לא הוגדר, העדכון ידני.';
			return [
				[
					'type'      => 'counter',
					'title'     => 'Progress',
					'completed' => (int) preg_replace( '/\D/', '', $m[1] ),
					'target'    => (int) preg_replace( '/\D/', '', $m[2] ),
				],
			];
		}

		$h1   = $xp->query( './/h1', $node )->item( 0 );
		$form = $xp->query( './/form', $node )->item( 0 );

		// 2. Hero (h1), possibly with a petition form.
		if ( $h1 ) {
			$sections = [];
			$hero     = [
				'type'  => 'page_header',
				'title' => $this->inline_text( $h1 ),
				'text'  => $this->first_paragraph( $node, $xp, $form ),
			];
			$img      = $this->first_image( $node, $xp, $form );
			if ( $img ) {
				$hero['image'] = $img;
			}
			$hero['media_position'] = 'right';
			$sections[]             = $hero;
			if ( $form ) {
				$sections[] = $this->form_section( $form, $xp, $o );
			}
			return $sections;
		}

		// 3. Standalone form.
		if ( $form ) {
			return [ $this->form_section( $form, $xp, $o ) ];
		}

		// 4. Link-only strip (e.g. "Read the crisis" anchor).
		$links = $xp->query( './/a', $node );
		if ( 1 === $links->length && ! $xp->query( './/h1|.//h2|.//h3|.//p|.//img', $node )->length ) {
			$a = $links->item( 0 );
			return [
				[
					'type'   => 'button_row',
					'button' => [
						'text'  => $this->clean( preg_replace( '/\b(arrow_\w+|expand_\w+|chevron_\w+)\b/', '', $a->textContent ) ),
						'url'   => $a->getAttribute( 'href' ) ?: '#',
						'style' => 'secondary',
					],
				],
			];
		}

		// 5. Content section: heading + text + image + repeated cards.
		return $this->content_section( $node, $xp );
	}

	/**
	 * Heading / lead / image / cards section.
	 *
	 * @param \DOMElement $node Section.
	 * @param \DOMXPath   $xp   XPath.
	 * @return array[]
	 */
	private function content_section( \DOMElement $node, \DOMXPath $xp ): array {
		$cards      = $this->find_cards( $node, $xp );
		$card_nodes = array_column( $cards, 'node' );

		$title = '';
		$h2    = $xp->query( './/h2', $node )->item( 0 );
		if ( $h2 && ! $this->inside_any( $h2, $card_nodes ) ) {
			$title = $this->inline_text( $h2 );
		}

		$paragraphs = [];
		foreach ( $xp->query( './/p', $node ) as $p ) {
			if ( ! $this->inside_any( $p, $card_nodes ) ) {
				$t = $this->clean( $p->textContent );
				if ( '' !== $t ) {
					$paragraphs[] = $t;
				}
			}
		}

		$image = null;
		foreach ( $xp->query( './/img', $node ) as $img ) {
			if ( ! $this->inside_any( $img, $card_nodes ) && $img->getAttribute( 'src' ) ) {
				$image = [ 'url' => $img->getAttribute( 'src' ), 'alt' => $img->getAttribute( 'alt' ) ];
				break;
			}
		}

		$sections = [];

		if ( count( $cards ) >= 2 ) {
			if ( $title || $paragraphs || $image ) {
				$side = [ 'type' => 'side_image', 'title' => $title, 'text' => implode( "\n\n", $paragraphs ) ];
				if ( $image ) {
					$side['image']          = $image;
					$side['media_position'] = 'right';
				}
				$sections[] = $side;
			}
			$cols = [];
			foreach ( $cards as $card ) {
				$cols[] = [ 'title' => $card['title'], 'text' => $card['text'] ];
			}
			// Card chrome (border / hard shadow) is read from the card element itself.
			$cls = $cards[0]['node'] instanceof \DOMElement ? $cards[0]['node']->getAttribute( 'class' ) : '';
			if ( preg_match( '/\bborder-(\d)\b/', $cls, $bm ) ) {
				$this->traits['card_border'] = (int) $bm[1];
			}
			if ( preg_match( '/shadow-\[(\d+)px_/', $cls, $sm ) ) {
				$this->traits['card_shadow'] = (int) $sm[1];
			}
			$sections[]    = [ 'type' => 'columns', 'cards' => true, 'columns' => $cols ];
			$this->notes[] = 'אייקוני Material Symbols בכרטיסים לא יובאו (אין להם מקבילה בבלוקים). אפשר להחליף בתמונות ידנית.';
			return $sections;
		}

		if ( $image && ( $title || $paragraphs ) ) {
			return [
				[
					'type'           => 'side_image',
					'title'          => $title,
					'text'           => implode( "\n\n", $paragraphs ),
					'image'          => $image,
					'media_position' => 'left',
				],
			];
		}

		if ( $title || $paragraphs ) {
			return [ [ 'type' => 'text', 'title' => $title, 'paragraphs' => $paragraphs ] ];
		}

		$this->notes[] = 'מקטע שלא זוהה דולג: "' . mb_substr( $this->clean( $node->textContent ), 0, 40 ) . '..."';
		return [];
	}

	/**
	 * Finds repeated card-like groups (heading h3/h4 + paragraph) among siblings.
	 *
	 * @param \DOMElement $section Section.
	 * @param \DOMXPath   $xp      XPath.
	 * @return array[] Each: node,title,text.
	 */
	private function find_cards( \DOMElement $section, \DOMXPath $xp ): array {
		$cards = [];
		$seen  = [];
		foreach ( $xp->query( './/h3|.//h4', $section ) as $h ) {
			$node = $h;
			while ( $node->parentNode && $node->parentNode !== $section ) {
				$parent = $node->parentNode;
				$sibs   = 0;
				foreach ( $parent->childNodes as $sib ) {
					if ( XML_ELEMENT_NODE === $sib->nodeType && $sib !== $node && $xp->query( './/h3|.//h4|self::h3|self::h4', $sib )->length ) {
						++$sibs;
					}
				}
				if ( $sibs > 0 ) {
					break;
				}
				$node = $parent;
			}
			if ( $node === $section || $node === $h ) {
				continue;
			}
			$id = spl_object_id( $node );
			if ( isset( $seen[ $id ] ) ) {
				continue;
			}
			$seen[ $id ] = true;
			$p           = $xp->query( './/p', $node )->item( 0 );
			$cards[]     = [
				'node'  => $node,
				'title' => $this->inline_text( $h ),
				'text'  => $p ? $this->clean( $p->textContent ) : '',
			];
		}
		return $cards;
	}

	/**
	 * Form section from a <form>: keeps the heading/intro, lists fields for the report.
	 *
	 * @param \DOMElement $form Form.
	 * @param \DOMXPath   $xp   XPath.
	 * @param array       $o    Options.
	 * @return array
	 */
	private function form_section( \DOMElement $form, \DOMXPath $xp, array $o ): array {
		$box   = $form->parentNode;
		$title = '';
		$text  = '';
		if ( $box ) {
			$h = $xp->query( './/h2|.//h3', $box )->item( 0 );
			$p = $xp->query( './p', $box )->item( 0 );
			if ( $h ) {
				$title = $this->inline_text( $h );
			}
			if ( $p ) {
				$text = $this->clean( $p->textContent );
			}
		}
		$fields = [];
		foreach ( $xp->query( './/label', $form ) as $label ) {
			$fields[] = trim( $this->clean( $label->textContent ) );
		}
		$btn = $xp->query( './/button[@type="submit"]', $form )->item( 0 );
		return [
			'type'    => 'form',
			'title'   => $title,
			'text'    => $text,
			'form_id' => (int) ( $o['form_id'] ?? 0 ),
			'fields'  => array_values( array_filter( $fields ) ),
			'submit'  => $btn ? $this->clean( $btn->textContent ) : '',
		];
	}

	/**
	 * First paragraph in the section that is not inside the form.
	 *
	 * @param \DOMElement      $node Section.
	 * @param \DOMXPath        $xp   XPath.
	 * @param \DOMElement|null $form Form to exclude.
	 */
	private function first_paragraph( \DOMElement $node, \DOMXPath $xp, ?\DOMElement $form ): string {
		foreach ( $xp->query( './/p', $node ) as $p ) {
			if ( $form && $this->inside_any( $p, [ $form->parentNode ] ) ) {
				continue;
			}
			return $this->clean( $p->textContent );
		}
		return '';
	}

	/**
	 * First image: <img> or Tailwind bg-[url('...')].
	 *
	 * @param \DOMElement      $node Section.
	 * @param \DOMXPath        $xp   XPath.
	 * @param \DOMElement|null $form Form to exclude.
	 */
	private function first_image( \DOMElement $node, \DOMXPath $xp, ?\DOMElement $form ): ?array {
		foreach ( $xp->query( './/*[@class]', $node ) as $el ) {
			if ( preg_match( "/bg-\[url\('([^']+)'\)\]/", $el->getAttribute( 'class' ), $m ) ) {
				return [ 'url' => html_entity_decode( $m[1] ), 'alt' => $el->getAttribute( 'data-alt' ) ];
			}
		}
		foreach ( $xp->query( './/img', $node ) as $img ) {
			if ( $img->getAttribute( 'src' ) && ( ! $form || ! $this->inside_any( $img, [ $form->parentNode ] ) ) ) {
				return [ 'url' => $img->getAttribute( 'src' ), 'alt' => $img->getAttribute( 'alt' ) ];
			}
		}
		return null;
	}

	/**
	 * Is $node inside (or equal to) any of $containers.
	 *
	 * @param \DOMNode   $node       Node.
	 * @param \DOMNode[] $containers Containers.
	 */
	private function inside_any( \DOMNode $node, array $containers ): bool {
		for ( $n = $node; $n; $n = $n->parentNode ) {
			foreach ( $containers as $c ) {
				if ( $c === $n ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Text of an element, <br> turned into spaces.
	 *
	 * @param \DOMElement $el Element.
	 */
	private function inline_text( \DOMElement $el ): string {
		$clone = $el->cloneNode( true );
		foreach ( iterator_to_array( $clone->getElementsByTagName( 'br' ) ) as $br ) {
			$br->parentNode->replaceChild( $clone->ownerDocument->createTextNode( ' ' ), $br );
		}
		return $this->clean( $clone->textContent );
	}

	/**
	 * Collapse whitespace.
	 *
	 * @param string $s String.
	 */
	private function clean( string $s ): string {
		return trim( preg_replace( '/\s+/u', ' ', $s ) );
	}

	/**
	 * Detect Tailwind style traits used for the optional CSS.
	 *
	 * @param \DOMElement $node Node.
	 */
	private function detect_traits( \DOMElement $node ): void {
		$xp = new \DOMXPath( $node->ownerDocument );
		foreach ( $xp->query( './/*[@class]', $node ) as $el ) {
			$c = $el->getAttribute( 'class' );
			if ( preg_match( '/\bborder-(\d)\b/', $c, $m ) && false !== strpos( $c, 'border-black' ) ) {
				$this->traits['border'] = max( (int) ( $this->traits['border'] ?? 0 ), (int) $m[1] );
			}
			if ( preg_match( '/shadow-\[(\d+)px_(\d+)px_0px_(#[0-9a-fA-F]{3,6})\]/', $c, $m ) ) {
				$this->traits['shadow'] = max( (int) ( $this->traits['shadow'] ?? 0 ), (int) $m[1] );
			}
			if ( false !== strpos( $c, 'rounded-none' ) ) {
				$this->traits['sharp'] = true;
			}
			if ( false !== strpos( $c, 'uppercase' ) ) {
				$this->traits['uppercase'] = true;
			}
		}
	}

	/**
	 * Report DESIGN.md colours vs. the Planet4 palette.
	 *
	 * @param string $md DESIGN.md.
	 */
	private function color_notes( string $md ): void {
		if ( '' === $md || ! preg_match_all( '/#[0-9a-fA-F]{6}\b/', substr( $md, strpos( $md, '## ' ) ?: 0 ), $m ) ) {
			return;
		}
		foreach ( array_unique( array_map( 'strtolower', $m[0] ) ) as $hex ) {
			if ( in_array( $hex, [ '#000000', '#ffffff' ], true ) ) {
				continue;
			}
			$c = Block_Builder::resolve_color( $hex );
			if ( $c && $c['slug'] && $c['exact'] ) {
				$this->notes[] = "צבע $hex = צבע פלטה {$c['slug']} (זהה).";
			} elseif ( $c && $c['slug'] ) {
				$this->notes[] = "צבע $hex הוחלף בצבע הפלטה הקרוב {$c['slug']} ({$c['hex']}).";
			} elseif ( $c ) {
				$this->notes[] = "צבע $hex אינו קרוב לפלטת Planet4 - יישמר כצבע מותאם רק אם נעשה בו שימוש ישיר.";
			}
		}
	}

	/**
	 * Report fonts that are not available on the site.
	 *
	 * @param string $md DESIGN.md.
	 */
	private function font_notes( string $md ): void {
		if ( preg_match_all( '/fontFamily:\s*([A-Za-z ]+)/', $md, $m ) ) {
			$fonts = array_unique( array_map( 'trim', $m[1] ) );
			if ( $fonts ) {
				$this->notes[] = 'פונטים בעיצוב (' . implode( ', ', $fonts ) . ') לא נטענו - נשארים פונטי Planet4 (נמנע טעינה מ-Google Fonts מטעמי פרטיות/CSP).';
			}
		}
	}

	/**
	 * Page-scoped CSS for the detected Stitch style traits ("Activist Modern" look).
	 * Scoped under .p4si-stitch (added to <body> of the generated page only).
	 *
	 * @param array $t Traits from parse().
	 */
	public static function build_css( array $t ): string {
		$css = [];
		$b   = (int) ( $t['border'] ?? 0 );
		$sh  = (int) ( $t['shadow'] ?? 0 );
		$cb  = (int) ( $t['card_border'] ?? 0 );
		$csh = (int) ( $t['card_shadow'] ?? 0 );
		if ( $cb || $csh ) {
			$rule = 'background:#fff;padding:32px;border-radius:0;';
			if ( $cb ) {
				$rule .= 'border:' . $cb . 'px solid #000;';
			}
			if ( $csh ) {
				$rule .= 'box-shadow:' . $csh . 'px ' . $csh . 'px 0 #000;';
			}
			$css[] = '.p4si-stitch .p4si-cards>.wp-block-column{' . $rule . '}';
			$css[] = '.p4si-stitch .p4si-cards{gap:32px}';
		}
		if ( ! empty( $t['sharp'] ) || $b ) {
			$btn = 'border-radius:0;border:2px solid #000;';
			if ( $sh ) {
				$btn .= 'box-shadow:2px 2px 0 #000;';
			}
			if ( ! empty( $t['uppercase'] ) ) {
				$btn .= 'text-transform:uppercase;';
			}
			$css[] = '.p4si-stitch .wp-block-button__link{' . $btn . '}';
			$css[] = '.p4si-stitch .wp-block-media-text__media img{border-radius:0}';
		}
		if ( ! empty( $t['uppercase'] ) ) {
			$css[] = '.p4si-stitch .wp-block-heading{text-transform:uppercase}';
		}
		return implode( "\n", $css );
	}
}
