<?php
/**
 * Plugin Name:       Planet4 Stitch Importer
 * Description:       Turns a Google Stitch design (as a JSON page spec) into a draft Planet4 page, preferring Planet4 blocks and patterns over custom markup.
 * Version:           0.2.1
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Greenpeace Israel Digital
 * License:           GPL-2.0-or-later
 * Text Domain:       p4-stitch-importer
 *
 * @package P4StitchImporter
 */

defined( 'ABSPATH' ) || exit;

define( 'P4SI_VERSION', '0.2.1' );
define( 'P4SI_DIR', plugin_dir_path( __FILE__ ) );

require_once P4SI_DIR . 'includes/class-block-builder.php';
require_once P4SI_DIR . 'includes/class-section-mapper.php';
require_once P4SI_DIR . 'includes/class-stitch-parser.php';
require_once P4SI_DIR . 'includes/class-admin-page.php';

add_action(
	'plugins_loaded',
	static function () {
		( new P4StitchImporter\Admin_Page() )->init();
	}
);
