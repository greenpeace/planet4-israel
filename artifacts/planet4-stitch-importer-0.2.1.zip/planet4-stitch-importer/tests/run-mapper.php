<?php
// CLI harness: minimal WP shims so the builder/mapper can run outside WordPress.
define( 'ABSPATH', __DIR__ . '/' );
function esc_attr( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); }
function esc_html( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); }
function esc_url( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); }
require __DIR__ . '/../includes/class-block-builder.php';
require __DIR__ . '/../includes/class-section-mapper.php';
$spec   = json_decode( file_get_contents( $argv[1] ), true );
$mapper = new P4StitchImporter\Section_Mapper();
$out    = $mapper->map( $spec );
file_put_contents( $argv[2], $out['content'] );
foreach ( $out['report'] as $r ) { echo "{$r['index']} {$r['type']} [{$r['via']}] {$r['what']}\n"; }
