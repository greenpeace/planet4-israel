<?php
// CLI harness: Stitch folder (code.html + DESIGN.md) -> spec -> block markup.
define( 'ABSPATH', __DIR__ . '/' );
function esc_attr( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); }
function esc_html( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); }
function esc_url( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); }
require __DIR__ . '/../includes/class-block-builder.php';
require __DIR__ . '/../includes/class-section-mapper.php';
require __DIR__ . '/../includes/class-stitch-parser.php';
$dir    = rtrim( $argv[1], '/' );
$parser = new P4StitchImporter\Stitch_Parser();
$spec   = $parser->parse( file_get_contents( "$dir/code.html" ), file_get_contents( "$dir/DESIGN.md" ), [ 'form_id' => (int) ( $argv[3] ?? 0 ) ] );
$spec['css'] = P4StitchImporter\Stitch_Parser::build_css( $spec['traits'] );
file_put_contents( $argv[2] . '.spec.json', json_encode( $spec, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) );
$out = ( new P4StitchImporter\Section_Mapper() )->map( $spec );
file_put_contents( $argv[2], $out['content'] );
echo "--- notes\n" . implode( "\n", $spec['notes'] ) . "\n--- report\n";
foreach ( $out['report'] as $r ) { echo "{$r['index']} {$r['type']} [{$r['via']}] {$r['what']}\n"; }
echo "--- css\n{$spec['css']}\n";
