<?php
/**
 * Plugin Name: Scrollytelling
 * Description: Scrollytelling blocks for posts and pages — hero, sticky-background scroll, scrollmation, text-over-media, and text sections. This plugin was created by Elad Aybes / Greenpeace MED.
 * Version: 1.8.0
 * Requires at least: 6.3
 * Requires PHP: 8.0
 * Text Domain: scrollytelling
 */

defined( 'ABSPATH' ) || exit;

define( 'SCROLLYTELLING_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCROLLYTELLING_URL', plugin_dir_url( __FILE__ ) );
define( 'SCROLLYTELLING_VERSION', '1.7.3' );

require_once SCROLLYTELLING_DIR . 'includes/class-shorthand-importer.php';
require_once SCROLLYTELLING_DIR . 'includes/shorthand-import-admin.php';
require_once SCROLLYTELLING_DIR . 'includes/class-ai-planner.php';
require_once SCROLLYTELLING_DIR . 'includes/class-doc-importer.php';
require_once SCROLLYTELLING_DIR . 'includes/doc-to-page-admin.php';
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once SCROLLYTELLING_DIR . 'includes/class-shorthand-import-cli.php';
}

// Run after the Planet4 theme's allowed_block_types_all filter (priority 10) so we can append our blocks.
add_filter( 'allowed_block_types_all', 'scrollytelling_allow_blocks', 20 );
function scrollytelling_allow_blocks( $allowed ) {
	if ( ! is_array( $allowed ) ) {
		return $allowed; // true = all blocks already allowed
	}
	return array_merge( $allowed, [
		'scrollytelling/hero',
		'scrollytelling/section-text',
		'scrollytelling/background-scroll',
		'scrollytelling/scrollmation',
		'scrollytelling/text-over-media',
		'scrollytelling/reveal',
		'scrollytelling/slideshow',
		'scrollytelling/scrollpoints',
		'scrollytelling/css-handler',
		'scrollytelling/video-scrub',
		'scrollytelling/media',
		'scrollytelling/story-in-numbers',
	] );
}

add_filter( 'block_categories_all', 'scrollytelling_register_category' );
function scrollytelling_register_category( $categories ) {
	return array_merge(
		[ [ 'slug' => 'scrollytelling', 'title' => 'Scrollytelling', 'icon' => null ] ],
		$categories
	);
}

add_action( 'init', 'scrollytelling_register_assets' );
function scrollytelling_register_assets() {
	$asset_file = SCROLLYTELLING_DIR . 'build/index.asset.php';
	$asset      = file_exists( $asset_file ) ? require $asset_file : [ 'dependencies' => [], 'version' => SCROLLYTELLING_VERSION ];

	wp_register_script(
		'scrollytelling-editor',
		SCROLLYTELLING_URL . 'build/index.js',
		$asset['dependencies'],
		$asset['version']
	);

	wp_register_style(
		'scrollytelling-style',
		SCROLLYTELLING_URL . 'build/style-index.css',
		[],
		$asset['version']
	);
}

add_action( 'init', 'scrollytelling_register_blocks', 20 );
function scrollytelling_register_blocks() {
	$blocks = [
		[
			'name'        => 'scrollytelling/hero',
			'title'       => 'Hero Section',
			'description' => 'Full-screen hero with background image, title, subtitle, and byline.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'hero', 'cover', 'scrollytelling', 'fullscreen' ],
			'attributes'  => [
				'mediaUrl'       => [ 'type' => 'string',  'default' => '' ],
				'mediaId'        => [ 'type' => 'number' ],
				'mediaType'      => [ 'type' => 'string',  'default' => 'image' ],
				'title'          => [ 'type' => 'string',  'default' => '' ],
				'subtitle'       => [ 'type' => 'string',  'default' => '' ],
				'byline'         => [ 'type' => 'string',  'default' => '' ],
				'titleColor'     => [ 'type' => 'string',  'default' => '#ffffff' ],
				'subtitleColor'  => [ 'type' => 'string',  'default' => '#ffffff' ],
				'bylineColor'    => [ 'type' => 'string',  'default' => '#ffffff' ],
				'textPosition'   => [ 'type' => 'string',  'default' => 'center' ],
				'textAlign'      => [ 'type' => 'string',  'default' => 'center' ],
				'overlayColor'   => [ 'type' => 'string',  'default' => '#000000' ],
				'overlayOpacity' => [ 'type' => 'number',  'default' => 40 ],
				'minHeight'      => [ 'type' => 'string',  'default' => '100vh' ],
				'isRtl'          => [ 'type' => 'boolean', 'default' => false ],
				'fixedBackground'=> [ 'type' => 'boolean', 'default' => false ],
				'logoUrl'          => [ 'type' => 'string',  'default' => '' ],
				'logoId'           => [ 'type' => 'number' ],
				'logoPosition'     => [ 'type' => 'string',  'default' => 'before-title' ],
				'logoSize'         => [ 'type' => 'number',  'default' => 120 ],
				'zoomedBackground' => [ 'type' => 'boolean', 'default' => false ],
				'backgroundBlur'   => [ 'type' => 'number',  'default' => 0 ],
			],
			'supports' => [ 'align' => [ 'full', 'wide' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/section-text',
			'title'       => 'Text Section',
			'description' => 'A clean, readable text section for long-form storytelling.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'text', 'prose', 'reading', 'scrollytelling' ],
			'attributes'  => [
				'content'         => [ 'type' => 'string', 'default' => '' ],
				'backgroundColor' => [ 'type' => 'string', 'default' => '#ffffff' ],
				'textColor'       => [ 'type' => 'string', 'default' => '#1a1a1a' ],
				'maxWidth'        => [ 'type' => 'string', 'default' => '680px' ],
				'paddingY'        => [ 'type' => 'number', 'default' => 80 ],
			],
			'supports' => [ 'align' => [ 'wide', 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/background-scroll',
			'title'       => 'Background Scroll',
			'description' => 'Sticky background image or video with scrolling text panels on top.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'sticky', 'parallax', 'scroll', 'scrollytelling', 'background' ],
			'attributes'  => [
				'mediaUrl'      => [ 'type' => 'string', 'default' => '' ],
				'mediaId'       => [ 'type' => 'number' ],
				'mediaType'     => [ 'type' => 'string', 'default' => 'image' ],
				'mediaHeight'   => [ 'type' => 'string', 'default' => 'full' ],
				'focalPoint'    => [ 'type' => 'object', 'default' => [ 'x' => 0.5, 'y' => 0.5 ] ],
				'overlayColor'    => [ 'type' => 'string', 'default' => '#000000' ],
				'overlayOpacity'  => [ 'type' => 'number', 'default' => 30 ],
				'fixedBackground' => [ 'type' => 'boolean', 'default' => false ],
				'panelTitleColor'    => [ 'type' => 'string', 'default' => '#1a1a1a' ],
				'panelBodyColor'     => [ 'type' => 'string', 'default' => '#333333' ],
				'panelTextAlign'     => [ 'type' => 'string', 'default' => 'left' ],
				'panelBgColor'       => [ 'type' => 'string', 'default' => '#ffffff' ],
				'panelBgOpacity'     => [ 'type' => 'number', 'default' => 95 ],
				'panelBorderColor'   => [ 'type' => 'string', 'default' => '#cccccc' ],
				'panelBorderWidth'   => [ 'type' => 'number', 'default' => 0 ],
				'gradientStyle'      => [ 'type' => 'string', 'default' => 'none' ],
				'gradientColor'      => [ 'type' => 'string', 'default' => '#000000' ],
				'gradientOpacity'    => [ 'type' => 'number', 'default' => 60 ],
				'panels'             => [
					'type'    => 'array',
					'default' => [ [ 'id' => 'panel-1', 'title' => '', 'body' => '' ] ],
					'items'   => [ 'type' => 'object' ],
				],
				'panelPosition' => [ 'type' => 'string',  'default' => 'right' ],
				'panelWidth'    => [ 'type' => 'number',  'default' => 40 ],
				'isRtl'         => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/scrollmation',
			'title'       => 'Scrollmation',
			'description' => 'Sticky image sequence alongside scrolling text — images advance as the reader scrolls.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'scrollmation', 'animation', 'frames', 'sequence', 'scrollytelling', 'two-column' ],
			'attributes'  => [
				'frames'    => [ 'type' => 'array',   'default' => [], 'items' => [ 'type' => 'object' ] ],
				'content'   => [ 'type' => 'string',  'default' => '' ],
				'imageSide' => [ 'type' => 'string',  'default' => 'right' ],
				'textColor' => [ 'type' => 'string',  'default' => '#1a1a1a' ],
				'bgColor'   => [ 'type' => 'string',  'default' => '#ffffff' ],
				'objectFit' => [ 'type' => 'string',  'default' => 'cover' ],
				'imageBg'         => [ 'type' => 'string',  'default' => '#000000' ],
				'imageFullHeight' => [ 'type' => 'boolean', 'default' => true ],
				'isRtl'           => [ 'type' => 'boolean', 'default' => false ],
				'textAlign'       => [ 'type' => 'string',  'default' => 'start' ],
			],
			'supports' => [ 'align' => [ 'wide', 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/text-over-media',
			'title'       => 'Text Over Media',
			'description' => 'Full-width image or video with positioned text overlay.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'text over media', 'overlay', 'image text', 'scrollytelling' ],
			'attributes'  => [
				'mediaUrl'       => [ 'type' => 'string', 'default' => '' ],
				'mediaId'        => [ 'type' => 'number' ],
				'mediaType'      => [ 'type' => 'string', 'default' => 'image' ],
				'title'          => [ 'type' => 'string', 'default' => '' ],
				'body'           => [ 'type' => 'string', 'default' => '' ],
				'titleColor'     => [ 'type' => 'string', 'default' => '#ffffff' ],
				'bodyColor'      => [ 'type' => 'string', 'default' => '#ffffff' ],
				'textPosition'   => [ 'type' => 'string', 'default' => 'center' ],
				'textAlign'      => [ 'type' => 'string', 'default' => 'center' ],
				'overlayColor'   => [ 'type' => 'string', 'default' => '#000000' ],
				'overlayOpacity' => [ 'type' => 'number', 'default' => 30 ],
				'minHeight'      => [ 'type' => 'string',  'default' => '80vh' ],
				'textTheme'      => [ 'type' => 'string',  'default' => 'light' ],
				'isRtl'          => [ 'type' => 'boolean', 'default' => false ],
				'fixedBackground'=> [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'wide', 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/reveal',
			'title'       => 'Reveal',
			'description' => 'Full-screen image or video that fades and scales into view as the reader scrolls to it.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'reveal', 'fullscreen', 'fade', 'image', 'scrollytelling' ],
			'attributes'  => [
				'mediaUrl'  => [ 'type' => 'string',  'default' => '' ],
				'mediaId'   => [ 'type' => 'number' ],
				'mediaType' => [ 'type' => 'string',  'default' => 'image' ],
				'caption'        => [ 'type' => 'string',  'default' => '' ],
				'height'         => [ 'type' => 'string',  'default' => 'full' ],
				'objectFit'      => [ 'type' => 'string',  'default' => 'cover' ],
				'isRtl'          => [ 'type' => 'boolean', 'default' => false ],
				'fixedBackground'=> [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full', 'wide' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/slideshow',
			'title'       => 'Slideshow',
			'description' => 'Image or video carousel with prev/next navigation and optional per-slide captions.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'slideshow', 'gallery', 'carousel', 'images', 'scrollytelling' ],
			'attributes'  => [
				'slides' => [ 'type' => 'array', 'default' => [], 'items' => [ 'type' => 'object' ] ],
				'height' => [ 'type' => 'string',  'default' => 'full' ],
				'isRtl'  => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full', 'wide' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/scrollpoints',
			'title'       => 'Scrollpoints',
			'description' => 'Pan and zoom a large image to multiple focal points as the reader scrolls.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'scrollpoints', 'pan', 'zoom', 'image', 'scrollytelling' ],
			'attributes'  => [
				'imageUrl'       => [ 'type' => 'string',  'default' => '' ],
				'imageId'        => [ 'type' => 'number' ],
				'imageAlt'       => [ 'type' => 'string',  'default' => '' ],
				'points'         => [ 'type' => 'array',   'default' => [], 'items' => [ 'type' => 'object' ] ],
				'textPosition'   => [ 'type' => 'string',  'default' => 'right' ],
				'panelWidth'     => [ 'type' => 'number',  'default' => 38 ],
				'textColor'      => [ 'type' => 'string',  'default' => '#1a1a1a' ],
				'bgColor'        => [ 'type' => 'string',  'default' => '#ffffff' ],
				'bgOpacity'      => [ 'type' => 'number',  'default' => 92 ],
				'overlayColor'   => [ 'type' => 'string',  'default' => '#000000' ],
				'overlayOpacity' => [ 'type' => 'number',  'default' => 0 ],
				'isRtl'          => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/css-handler',
			'title'       => 'Custom CSS',
			'description' => 'Add custom CSS styling to the page. Applies site-wide on the page, regardless of where this block is placed.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'css', 'style', 'custom css', 'css handler', 'scrollytelling' ],
			'attributes'  => [
				'css' => [ 'type' => 'string', 'default' => '' ],
			],
			'supports' => [ 'html' => false, 'customClassName' => false, 'align' => false ],
		],
		[
			'name'        => 'scrollytelling/video-scrub',
			'title'       => 'Video Scrubbing',
			'description' => 'A video whose frame is driven by mouse movement instead of playing normally. Background mode takes over the full screen; Block mode is a horizontal strip within the page.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'video', 'scrub', 'scrubbing', 'mouse', 'interactive', 'scrollytelling' ],
			'attributes'  => [
				'mediaUrl'        => [ 'type' => 'string',  'default' => '' ],
				'mediaId'         => [ 'type' => 'number' ],
				'mode'                => [ 'type' => 'string',  'default' => 'background' ],
				'scrubAxis'           => [ 'type' => 'string',  'default' => 'horizontal' ],
				'horizontalDirection' => [ 'type' => 'string',  'default' => 'right' ],
				'verticalDirection'   => [ 'type' => 'string',  'default' => 'down' ],
				'blockHeight'     => [ 'type' => 'number',  'default' => 60 ],
				'fixedPosition'   => [ 'type' => 'boolean', 'default' => false ],
				'focalPoint'      => [ 'type' => 'object',  'default' => [ 'x' => 0.5, 'y' => 0.5 ] ],
				'hasInnerContent' => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'full' ], 'html' => false ],
		],
		[
			'name'        => 'scrollytelling/story-in-numbers',
			'title'       => 'Story in Numbers',
			'description' => 'Animated statistics strips — numbers count up on scroll, grid or detail layout, RTL/LTR ready.',
			'category'    => 'scrollytelling',
			'keywords'    => [ 'numbers', 'statistics', 'counter', 'data', 'facts', 'scrollytelling' ],
			'attributes'  => [
				'items'                => [ 'type' => 'array',   'default' => [], 'items' => [ 'type' => 'object' ] ],
				'backgroundColor'      => [ 'type' => 'string',  'default' => '#f5f5f5' ],
				'backgroundTransparent'=> [ 'type' => 'boolean', 'default' => false ],
				'stripPaddingY'        => [ 'type' => 'number',  'default' => 64 ],
				'textColor'            => [ 'type' => 'string',  'default' => '#1a1a1a' ],
				'numberColor'          => [ 'type' => 'string',  'default' => '#1a6632' ],
				'numberSize'           => [ 'type' => 'number',  'default' => 64 ],
				'titleAnimation'       => [ 'type' => 'string',  'default' => 'fade-up' ],
				'counterDuration'      => [ 'type' => 'number',  'default' => 2000 ],
				'isRtl'                => [ 'type' => 'boolean', 'default' => false ],
			],
			'supports' => [ 'align' => [ 'wide', 'full' ], 'html' => false ],
		],
	];

	foreach ( $blocks as $block ) {
		register_block_type( $block['name'], [
			'title'           => $block['title'],
			'description'     => $block['description'],
			'category'        => $block['category'],
			'keywords'        => $block['keywords'],
			'attributes'      => $block['attributes'],
			'supports'        => $block['supports'],
			'editor_script'   => 'scrollytelling-editor',
			'style'           => 'scrollytelling-style',
		] );
	}
}

add_action( 'wp_enqueue_scripts', 'scrollytelling_frontend_assets' );
function scrollytelling_frontend_assets() {
	$scrollytelling_blocks = [
		'scrollytelling/hero',
		'scrollytelling/section-text',
		'scrollytelling/background-scroll',
		'scrollytelling/scrollmation',
		'scrollytelling/text-over-media',
		'scrollytelling/reveal',
		'scrollytelling/slideshow',
		'scrollytelling/scrollpoints',
		'scrollytelling/css-handler',
		'scrollytelling/video-scrub',
		'scrollytelling/story-in-numbers',
	];

	$has_block = false;
	foreach ( $scrollytelling_blocks as $block_name ) {
		if ( has_block( $block_name ) ) {
			$has_block = true;
			break;
		}
	}

	// The Ease In & Out animator and the Floating/Parallax effect can both
	// be applied to ANY block, including plain core blocks (paragraph,
	// image, group, ...) — has_block() above only matches block NAMES, so
	// it can't detect that. Fall back to a direct scan of the post content
	// for the marker classes those filters add only when actually
	// configured (see extensions/ease-animator.js and float-parallax.js).
	if ( ! $has_block ) {
		$post = get_post();
		if ( $post && ( str_contains( $post->post_content, 'st-animate' ) || str_contains( $post->post_content, 'st-float' ) ) ) {
			$has_block = true;
		}
	}

	if ( ! $has_block ) return;

	// Use webpack's content-hash version (same pattern as the editor script
	// above) so browsers reliably bust their cache for frontend.js whenever
	// it changes — the static SCROLLYTELLING_VERSION constant never changes
	// between builds, so visitors could otherwise keep an old cached copy
	// indefinitely after an update.
	$frontend_asset_file = SCROLLYTELLING_DIR . 'build/frontend.asset.php';
	$frontend_asset       = file_exists( $frontend_asset_file ) ? require $frontend_asset_file : [ 'dependencies' => [], 'version' => SCROLLYTELLING_VERSION ];

	wp_enqueue_script(
		'scrollytelling-frontend',
		SCROLLYTELLING_URL . 'build/frontend.js',
		[],
		$frontend_asset['version'],
		true
	);
}

/* ─── Story in Numbers: RTL back-compat ─────────────────────────── */
// Blocks saved before isRtl defaulted to true lack the st-sin--rtl class.
// Inject it server-side so existing posts don't need to be re-saved.
add_filter( 'render_block_scrollytelling/story-in-numbers', function ( $html, $block ) {
	$is_rtl = $block['attrs']['isRtl'] ?? true;
	if ( ! $is_rtl || str_contains( $html, 'st-sin--rtl' ) ) {
		return $html;
	}
	// Add class to the section wrapper.
	$html = preg_replace( '/\bst-sin\b/', 'st-sin st-sin--rtl', $html, 1 );
	// Replace dir="ltr" with dir="rtl", or add dir="rtl" if absent.
	// dir="rtl" on the section makes flex-direction:row naturally put the stat on the right.
	if ( str_contains( $html, 'dir="ltr"' ) ) {
		$html = str_replace( 'dir="ltr"', 'dir="rtl"', $html );
	} elseif ( ! str_contains( $html, 'dir="rtl"' ) ) {
		$html = preg_replace( '/<section\b/', '<section dir="rtl"', $html, 1 );
	}
	return $html;
}, 10, 2 );

/* ─── Settings page ──────────────────────────────────────────────── */

add_action( 'admin_menu', 'scrollytelling_add_settings_page' );
function scrollytelling_add_settings_page() {
	add_options_page(
		__( 'Scrollytelling', 'scrollytelling' ),
		__( 'Scrollytelling', 'scrollytelling' ),
		'manage_options',
		'scrollytelling-settings',
		'scrollytelling_render_settings_page'
	);
}

add_action( 'admin_init', 'scrollytelling_register_settings' );
function scrollytelling_register_settings() {
	register_setting( 'scrollytelling_settings', 'scrollytelling_claude_api_key', [
		'type'              => 'string',
		'sanitize_callback' => 'sanitize_text_field',
		'default'           => '',
	] );
	add_settings_section( 'scrollytelling_ai', __( 'AI Features', 'scrollytelling' ), '__return_false', 'scrollytelling-settings' );
	add_settings_field(
		'scrollytelling_claude_api_key',
		__( 'Claude API Key', 'scrollytelling' ),
		'scrollytelling_render_api_key_field',
		'scrollytelling-settings',
		'scrollytelling_ai'
	);
}

function scrollytelling_render_api_key_field() {
	$key = get_option( 'scrollytelling_claude_api_key', '' );
	printf(
		'<input type="password" name="scrollytelling_claude_api_key" value="%s" class="regular-text" autocomplete="off" />
		<p class="description">%s <a href="https://console.anthropic.com/account/keys" target="_blank">console.anthropic.com</a>.<br>%s</p>',
		esc_attr( $key ),
		esc_html__( 'Required for AI icon & colour suggestions in the Story in Numbers block. Get a key at', 'scrollytelling' ),
		esc_html__( 'You can also set the constant SCROLLYTELLING_CLAUDE_API_KEY in wp-config.php instead.', 'scrollytelling' )
	);
}

function scrollytelling_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) return;
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Scrollytelling Settings', 'scrollytelling' ); ?></h1>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'scrollytelling_settings' );
			do_settings_sections( 'scrollytelling-settings' );
			submit_button();
			?>
		</form>
	</div>
	<?php
}

/* ─── REST endpoint: AI icon + colour suggestions ────────────────── */

add_action( 'rest_api_init', 'scrollytelling_register_rest_routes' );
function scrollytelling_register_rest_routes() {
	register_rest_route( 'scrollytelling/v1', '/ai-suggest', [
		'methods'             => 'POST',
		'callback'            => 'scrollytelling_ai_suggest',
		'permission_callback' => function () { return current_user_can( 'edit_posts' ); },
		'args'                => [
			'title'           => [ 'type' => 'string', 'default' => '' ],
			'body'            => [ 'type' => 'string', 'default' => '' ],
			'endValue'        => [ 'type' => 'number', 'default' => 0 ],
			'prefix'          => [ 'type' => 'string', 'default' => '' ],
			'suffix'          => [ 'type' => 'string', 'default' => '' ],
			'backgroundColor' => [ 'type' => 'string', 'default' => '#f5f5f5' ],
			'textColor'       => [ 'type' => 'string', 'default' => '#1a1a1a' ],
			'numberColor'     => [ 'type' => 'string', 'default' => '#1a6632' ],
		],
	] );
}

function scrollytelling_ai_suggest( WP_REST_Request $request ) {
	// Prefer constant → fall back to DB option
	$api_key = defined( 'SCROLLYTELLING_CLAUDE_API_KEY' )
		? SCROLLYTELLING_CLAUDE_API_KEY
		: get_option( 'scrollytelling_claude_api_key', '' );

	if ( empty( $api_key ) ) {
		return new WP_Error(
			'no_api_key',
			__( 'Claude API key not configured. Go to Settings › Scrollytelling to add your key.', 'scrollytelling' ),
			[ 'status' => 400 ]
		);
	}

	$number_display = trim( $request['prefix'] . $request['endValue'] . $request['suffix'] );
	$title          = sanitize_text_field( $request['title'] );
	$body           = sanitize_textarea_field( $request['body'] );
	$bg             = sanitize_text_field( $request['backgroundColor'] );
	$text           = sanitize_text_field( $request['textColor'] );
	$num_color      = sanitize_text_field( $request['numberColor'] );

	$prompt = "You are helping a web editor choose an icon and accent colour for a statistics block on a Greenpeace / environmental nonprofit website.

Given this statistic:
- Number displayed: {$number_display}
- Title / label: {$title}" . ( $body ? "\n- Body text: {$body}" : '' ) . "

Current block colours:
- Background: {$bg}
- Text: {$text}
- Number (current): {$num_color}

Return ONLY valid JSON (no markdown, no extra text) with this exact structure:
{
  \"emoji\": \"🌊\",
  \"emoji_rationale\": \"One sentence explaining why this emoji fits\",
  \"colors\": [
    { \"hex\": \"#1a6632\", \"name\": \"Forest green\", \"rationale\": \"Environmental trust\" },
    { \"hex\": \"#1565c0\", \"name\": \"Ocean blue\",   \"rationale\": \"Water / urgency\" },
    { \"hex\": \"#e65100\", \"name\": \"Ember orange\", \"rationale\": \"Alarm / heat\" }
  ]
}

Rules:
- emoji: 1-2 emoji that best represent the stat's theme. Prefer universally supported emoji.
- colors: exactly 3 options that contrast well with background {$bg} and complement the overall page tone. Each must be a valid 6-digit hex.
- Do NOT repeat the current number colour as one of the three options unless it is clearly the best choice.";

	$response = wp_remote_post(
		'https://api.anthropic.com/v1/messages',
		[
			'timeout' => 30,
			'headers' => [
				'x-api-key'         => $api_key,
				'anthropic-version' => '2023-06-01',
				'content-type'      => 'application/json',
			],
			'body' => wp_json_encode( [
				'model'      => 'claude-haiku-4-5-20251001',
				'max_tokens' => 300,
				'messages'   => [
					[ 'role' => 'user', 'content' => $prompt ],
				],
			] ),
		]
	);

	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'api_error', $response->get_error_message(), [ 'status' => 502 ] );
	}

	$body_raw = wp_remote_retrieve_body( $response );
	$data     = json_decode( $body_raw, true );

	if ( empty( $data['content'][0]['text'] ) ) {
		return new WP_Error( 'bad_response', __( 'Unexpected response from Claude API.', 'scrollytelling' ), [ 'status' => 502 ] );
	}

	$result = json_decode( $data['content'][0]['text'], true );
	if ( ! $result || ! isset( $result['emoji'], $result['colors'] ) ) {
		return new WP_Error( 'parse_error', __( 'Could not parse AI response. Try again.', 'scrollytelling' ), [ 'status' => 500 ] );
	}

	return rest_ensure_response( $result );
}
