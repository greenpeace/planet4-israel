<?php

declare(strict_types=1);

namespace Timesuite\Services\Notifications;

use Timesuite\Core\Settings;
use Timesuite\Core\Support\MonthEndReminderSchedule;
use Timesuite\Core\Support\RuntimeEnvironment;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;

/**
 * Email notification service for timesheet events.
 *
 * Sends email notifications for submissions, approvals, denials, and reminders.
 */
class EmailNotifier
{
    public const QUEUE_OPTION = 'timesuite_email_queue';
    public const LAST_FAILURE_OPTION = 'timesuite_email_last_failure';
    private const MAX_QUEUE_SIZE = 100;
    private const MAX_ATTEMPTS = 5;
    private const RETRY_BASE_DELAY = 300;

    public function __construct(
        private Settings $settings,
        private ?ApprovalLogRepository $logRepository = null
    ) {
        if (! has_action('wp_mail_failed', [$this, 'handleMailFailed'])) {
            add_action('wp_mail_failed', [$this, 'handleMailFailed']);
        }
    }

    /**
     * Notify manager when an employee submits a timesheet.
     */
    public function notifySubmission(int $employeeId, int $managerId, int $year, int $month): bool
    {
        $employee = get_user_by('id', $employeeId);
        $manager  = get_user_by('id', $managerId);

        if (! $employee || ! $manager) {
            return false;
        }

        $monthName = wp_date('F Y', strtotime("{$year}-{$month}-01"));
        $subject   = sprintf(
            /* translators: 1: employee name, 2: month/year */
            __('[Timesuite] %1$s submitted timesheet for %2$s', 'timesuite'),
            $employee->display_name,
            $monthName
        );

        $body = $this->renderTemplate('submission', [
            'employee_name' => $employee->display_name,
            'manager_name'  => $manager->display_name,
            'month_year'    => $monthName,
            'review_url'    => $this->getManagerUrl(),
        ]);

        return $this->send($manager->user_email, $subject, $body, 'submission');
    }

    /**
     * Notify employee when their timesheet is approved.
     */
    public function notifyApproval(int $employeeId, int $approverId, int $year, int $month): bool
    {
        $employee = get_user_by('id', $employeeId);
        $approver = get_user_by('id', $approverId);

        if (! $employee) {
            return false;
        }

        $monthName    = wp_date('F Y', strtotime("{$year}-{$month}-01"));
        $approverName = $approver ? $approver->display_name : __('HR', 'timesuite');

        $subject = sprintf(
            /* translators: %s: month/year */
            __('[Timesuite] Your %s timesheet was approved', 'timesuite'),
            $monthName
        );

        $body = $this->renderTemplate('approval', [
            'employee_name' => $employee->display_name,
            'approver_name' => $approverName,
            'month_year'    => $monthName,
            'view_url'      => $this->getTimesheetUrl(),
        ]);

        return $this->send($employee->user_email, $subject, $body, 'approval');
    }

    /**
     * Notify employee when their timesheet is denied.
     */
    public function notifyDenial(int $employeeId, int $denierId, int $year, int $month, string $reason): bool
    {
        $employee = get_user_by('id', $employeeId);
        $denier   = get_user_by('id', $denierId);

        if (! $employee) {
            return false;
        }

        $monthName  = wp_date('F Y', strtotime("{$year}-{$month}-01"));
        $denierName = $denier ? $denier->display_name : __('HR', 'timesuite');

        $subject = sprintf(
            /* translators: %s: month/year */
            __('[Timesuite] Your %s timesheet needs revision', 'timesuite'),
            $monthName
        );

        $body = $this->renderTemplate('denial', [
            'employee_name' => $employee->display_name,
            'denier_name'   => $denierName,
            'month_year'    => $monthName,
            'reason'        => $reason,
            'edit_url'      => $this->getTimesheetUrl(),
        ]);

        return $this->send($employee->user_email, $subject, $body, 'denial');
    }

    /**
     * Notify manager that an employee asked to re-edit a locked month.
     */
    public function notifyReeditRequest(
        int $employeeId,
        int $managerId,
        int $year,
        int $month,
        string $reason
    ): bool {
        $employee = get_user_by('id', $employeeId);
        $manager  = get_user_by('id', $managerId);

        if (! $employee || ! $manager) {
            return false;
        }

        $monthName = wp_date('F Y', strtotime("{$year}-{$month}-01"));
        $subject   = sprintf(
            /* translators: 1: employee name, 2: month/year */
            __('[Timesuite] %1$s asked to re-edit %2$s', 'timesuite'),
            $employee->display_name,
            $monthName
        );

        $body = $this->renderTemplate('reedit_request', [
            'employee_name' => $employee->display_name,
            'manager_name'  => $manager->display_name,
            'month_year'    => $monthName,
            'reason'        => $reason,
            'review_url'    => $this->getManagerUrl(),
        ]);

        return $this->send($manager->user_email, $subject, $body, 'reedit_request');
    }

    /**
     * Notify employee of a manager decision on a re-edit request.
     */
    public function notifyReeditDecision(
        int $employeeId,
        int $managerId,
        int $year,
        int $month,
        bool $approved,
        string $managerReason = ''
    ): bool {
        $employee = get_user_by('id', $employeeId);
        $manager  = get_user_by('id', $managerId);

        if (! $employee) {
            return false;
        }

        $monthName   = wp_date('F Y', strtotime("{$year}-{$month}-01"));
        $managerName = $manager ? $manager->display_name : __('Manager', 'timesuite');

        if ($approved) {
            $subject = sprintf(
                /* translators: %s: month/year */
                __('[Timesuite] Re-edit approved for %s', 'timesuite'),
                $monthName
            );

            $body = $this->renderTemplate('reedit_approved', [
                'employee_name' => $employee->display_name,
                'manager_name'  => $managerName,
                'month_year'    => $monthName,
                'reason'        => $managerReason,
                'edit_url'      => $this->getTimesheetUrl(),
            ]);

            return $this->send($employee->user_email, $subject, $body, 'reedit_approved');
        }

        $subject = sprintf(
            /* translators: %s: month/year */
            __('[Timesuite] Re-edit request denied for %s', 'timesuite'),
            $monthName
        );

        $body = $this->renderTemplate('reedit_denied', [
            'employee_name' => $employee->display_name,
            'manager_name'  => $managerName,
            'month_year'    => $monthName,
            'reason'        => $managerReason,
            'view_url'      => $this->getTimesheetUrl(),
        ]);

        return $this->send($employee->user_email, $subject, $body, 'reedit_denied');
    }

    /**
     * Send a month-end reminder to an employee who has not submitted.
     *
     * Which day each stage falls on is decided by
     * {@see MonthEndReminderSchedule}; this method only renders it. The
     * schedule is the single owner of that rule, so there is no second copy
     * here that could silently disagree and veto a send.
     *
     * @param string $stage MonthEndReminderSchedule::STAGE_FIRST|STAGE_FINAL.
     */
    public function notifyDeadlineReminder(int $employeeId, int $year, int $month, string $stage): bool
    {
        $employee = get_user_by('id', $employeeId);

        if (! $employee) {
            return false;
        }

        $monthName = wp_date('F Y', strtotime("{$year}-{$month}-01"));
        $isFinal   = MonthEndReminderSchedule::STAGE_FINAL === $stage;

        // Deliberately says the month is ending rather than naming a due date:
        // submission stays open until the configured cutoff, so promising a
        // deadline here would be wrong.
        $subject = $isFinal
            ? sprintf(
                /* translators: %s: month/year */
                __('[Timesuite] Last day to submit your %s timesheet', 'timesuite'),
                $monthName
            )
            : sprintf(
                /* translators: %s: month/year */
                __('[Timesuite] %s ends tomorrow - submit your timesheet', 'timesuite'),
                $monthName
            );

        $body = $this->renderTemplate('reminder', [
            'employee_name' => $employee->display_name,
            'month_year'    => $monthName,
            'is_final'      => $isFinal,
            'submit_url'    => $this->getEmployeeTimesheetUrl(),
        ]);

        return $this->send($employee->user_email, $subject, $body, 'reminder');
    }

    /**
     * Notify HR when a period is ready for locking.
     */
    public function notifyPeriodReadyForLock(array $hrEmails, int $year, int $month, int $approvedCount): bool
    {
        if (empty($hrEmails)) {
            return false;
        }

        $monthName = wp_date('F Y', strtotime("{$year}-{$month}-01"));

        $subject = sprintf(
            /* translators: %s: month/year */
            __('[Timesuite] %s period ready for review', 'timesuite'),
            $monthName
        );

        $body = $this->renderTemplate('period_ready', [
            'month_year'     => $monthName,
            'approved_count' => $approvedCount,
            'review_url'     => $this->getManagerUrl(),
        ]);

        $success = true;

        foreach ($hrEmails as $email) {
            if (! $this->send($email, $subject, $body, 'period_ready')) {
                $success = false;
            }
        }

        return $success;
    }

    /**
     * Send an email using WordPress mail.
     *
     * @param string $type Notification type for logging (e.g., 'submission', 'approval').
     */
    private function send(
        string $to,
        string $subject,
        string $body,
        string $type = 'notification',
        bool $queueOnFailure = true
    ): bool
    {
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $this->getFromAddress(),
        ];

        /**
         * Filter the email before sending.
         *
         * @param array  $email   Email data (to, subject, body, headers).
         * @param string $type    Notification type.
         */
        $email = apply_filters('timesuite_notification_email', [
            'to'      => $to,
            'subject' => $subject,
            'body'    => $body,
            'headers' => $headers,
        ], $type);

        if (empty($email)) {
            $this->logEmailResult($to, $type, false, 'Cancelled by filter');

            return false;
        }

        $result = wp_mail($email['to'], $email['subject'], $email['body'], $email['headers']);

        if (! $result) {
            $error = 'wp_mail returned false';
            $this->recordLastFailure($email['to'], $type, $error);
            $this->logEmailResult($to, $type, false, $error);

            if ($queueOnFailure) {
                $this->enqueueEmail($email, $type, $error);
            }

            return false;
        }

        $this->logEmailResult($to, $type, true, null);

        return true;
    }

    /**
     * Handle wp_mail failure errors for logging visibility.
     */
    public function handleMailFailed(\WP_Error $error): void
    {
        $data = $error->get_error_data();
        $to = is_array($data) ? ($data['to'] ?? '') : '';
        $type = is_array($data) && is_string($data['type'] ?? null) ? $data['type'] : 'notification';
        $message = $error->get_error_message();

        $this->recordLastFailure($to, $type, $message ?: 'wp_mail_failed');
    }

    /**
     * Process queued email retries.
     *
     * @return array{sent: int, failed: int, remaining: int}
     */
    public function processQueue(): array
    {
        $queue = $this->getQueue();
        $now = time();
        $sent = 0;
        $failed = 0;
        $remaining = [];

        foreach ($queue as $item) {
            if (! is_array($item)) {
                continue;
            }

            $nextRetry = (int) ($item['next_retry'] ?? 0);

            if ($nextRetry > $now) {
                $remaining[] = $item;
                continue;
            }

            if ($this->queuedReminderBlockedOutsideProduction($item)) {
                continue;
            }

            $attempts = (int) ($item['attempts'] ?? 0);
            $attempts = max(1, $attempts + 1);

            $success = $this->sendQueuedEmail($item);

            if ($success) {
                $sent++;
                continue;
            }

            $failed++;

            if ($attempts >= self::MAX_ATTEMPTS) {
                continue;
            }

            $item['attempts'] = $attempts;
            $item['next_retry'] = $now + $this->getRetryDelay($attempts);
            $item['last_error'] = $item['last_error'] ?? 'wp_mail returned false';
            $remaining[] = $item;
        }

        $this->saveQueue($remaining);

        return [
            'sent' => $sent,
            'failed' => $failed,
            'remaining' => count($remaining),
        ];
    }

    /**
     * Log email send result for debugging.
     */
    private function logEmailResult(string|array $to, string $type, bool $success, ?string $error = null): void
    {
        if (! $this->logRepository) {
            return;
        }

        $this->logRepository->log(
            'email_' . ($success ? 'sent' : 'failed'),
            0, // No specific user ID for system actions
            get_current_user_id() ?: null,
            [
                'type'  => $type,
                'recipients' => $this->countRecipients($to),
                'error' => $error,
            ]
        );
    }

    /**
     * @param array<string, mixed> $email
     */
    private function enqueueEmail(array $email, string $type, string $error): void
    {
        $queue = $this->getQueue();
        $queue[] = [
            'id' => uniqid('ts_mail_', true),
            'to' => is_array($email['to']) ? array_values($email['to']) : [$email['to']],
            'subject' => (string) $email['subject'],
            'body' => (string) $email['body'],
            'headers' => $email['headers'],
            'type' => $type,
            'attempts' => 1,
            'next_retry' => time() + self::RETRY_BASE_DELAY,
            'last_error' => $error,
            'created_at' => time(),
        ];

        $queue = $this->pruneQueue($queue);
        $this->saveQueue($queue);

        if ($this->logRepository) {
            $this->logRepository->log('email_queued', 0, get_current_user_id() ?: null, [
                'type' => $type,
                'recipients' => $this->countRecipients($email['to']),
            ]);
        }
    }

    /**
     * @param array<string, mixed> $item
     */
    private function sendQueuedEmail(array $item): bool
    {
        $to = $item['to'] ?? [];
        $subject = (string) ($item['subject'] ?? '');
        $body = (string) ($item['body'] ?? '');
        $headers = $item['headers'] ?? [];
        $type = (string) ($item['type'] ?? 'notification');

        $result = wp_mail($to, $subject, $body, $headers);

        if (! $result) {
            $error = 'wp_mail returned false';
            $this->recordLastFailure($to, $type, $error);
            $this->logEmailResult($to, $type, false, $error);

            return false;
        }

        $this->logEmailResult($to, $type, true, null);

        if ($this->logRepository) {
            $this->logRepository->log('email_retry_sent', 0, get_current_user_id() ?: null, [
                'type' => $type,
                'recipients' => $this->countRecipients($to),
            ]);
        }

        return true;
    }

    /**
     * @param array<string, mixed> $item
     */
    private function queuedReminderBlockedOutsideProduction(array $item): bool
    {
        $type = (string) ($item['type'] ?? 'notification');

        if ($type !== 'reminder') {
            return false;
        }

        if (RuntimeEnvironment::allowsAutomatedReminderEmails()) {
            return false;
        }

        $to = $item['to'] ?? [];
        $this->logEmailResult(is_array($to) ? $to : (string) $to, $type, false, 'Suppressed outside production');

        return true;
    }

    private function countRecipients(string|array $to): int
    {
        if (is_array($to)) {
            return count(array_filter($to));
        }

        return '' === trim($to) ? 0 : 1;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function getQueue(): array
    {
        $queue = get_option(self::QUEUE_OPTION, []);

        return is_array($queue) ? $queue : [];
    }

    /**
     * @param array<int, array<string, mixed>> $queue
     */
    private function saveQueue(array $queue): void
    {
        update_option(self::QUEUE_OPTION, array_values($queue));
    }

    /**
     * @param array<int, array<string, mixed>> $queue
     *
     * @return array<int, array<string, mixed>>
     */
    private function pruneQueue(array $queue): array
    {
        if (count($queue) <= self::MAX_QUEUE_SIZE) {
            return $queue;
        }

        return array_slice($queue, -self::MAX_QUEUE_SIZE);
    }

    private function getRetryDelay(int $attempts): int
    {
        $delay = self::RETRY_BASE_DELAY * (2 ** max(0, $attempts - 1));

        return min($delay, 86400);
    }

    private function recordLastFailure(array|string $to, string $type, string $error): void
    {
        $recipients = is_array($to) ? implode(',', $to) : (string) $to;

        update_option(self::LAST_FAILURE_OPTION, [
            'time' => gmdate('c'),
            'to' => $recipients,
            'type' => $type,
            'error' => $error,
        ]);
    }

    /**
     * Send a test email to verify configuration.
     *
     * @return array{success: bool, message: string}
     */
    public function sendTestEmail(string $to): array
    {
        if (! is_email($to)) {
            return [
                'success' => false,
                'message' => __('Invalid email address.', 'timesuite'),
            ];
        }

        $subject = sprintf(
            /* translators: %s: site name */
            __('[Timesuite] Test email from %s', 'timesuite'),
            get_bloginfo('name')
        );

        $body = $this->renderTemplate('test', [
            'site_name' => get_bloginfo('name'),
            'from_name' => $this->settings->getEmailFromName(),
            'from_email' => $this->settings->getEmailFromAddress(),
        ]);

        $result = $this->send($to, $subject, $body, 'test');

        if ($result) {
            return [
                'success' => true,
                'message' => sprintf(
                    /* translators: %s: email address */
                    __('Test email sent to %s. Check your inbox (and spam folder).', 'timesuite'),
                    $to
                ),
            ];
        }

        return [
            'success' => false,
            'message' => __('Failed to send test email. Check your WordPress email configuration.', 'timesuite'),
        ];
    }

    /**
     * Render an email template.
     *
     * @param string               $template Template name.
     * @param array<string, mixed> $data     Template variables.
     */
    private function renderTemplate(string $template, array $data): string
    {
        $siteName = get_bloginfo('name');
        $logoUrl  = ''; // Could be made configurable

        // Base HTML template
        $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { border-bottom: 2px solid #4f46e5; padding-bottom: 15px; margin-bottom: 20px; }
        .header h1 { color: #4f46e5; font-size: 24px; margin: 0; }
        .content { padding: 20px 0; }
        .button { display: inline-block; background: #4f46e5; color: #fff !important; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 15px 0; }
        .button:hover { background: #4338ca; }
        .alert { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 15px 0; }
        .footer { border-top: 1px solid #e5e7eb; padding-top: 15px; margin-top: 30px; font-size: 12px; color: #6b7280; }
        .reason { background: #f3f4f6; padding: 15px; border-radius: 6px; margin: 15px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>' . esc_html($siteName) . ' - Timesuite</h1>
    </div>
    <div class="content">
        ' . $this->getTemplateContent($template, $data) . '
    </div>
    <div class="footer">
        <p>' . esc_html__('This is an automated message from Timesuite. Please do not reply to this email.', 'timesuite') . '</p>
        <p>' . esc_html($siteName) . '</p>
    </div>
</body>
</html>';

        return $html;
    }

    /**
     * Get content for a specific template.
     */
    private function getTemplateContent(string $template, array $data): string
    {
        switch ($template) {
            case 'submission':
                return sprintf(
                    '<p>' . esc_html__('Hello %s,', 'timesuite') . '</p>
                    <p>' . esc_html__('%s has submitted their timesheet for %s and is waiting for your review.', 'timesuite') . '</p>
                    <a href="%s" class="button">' . esc_html__('Review Timesheet', 'timesuite') . '</a>',
                    esc_html($data['manager_name']),
                    esc_html($data['employee_name']),
                    esc_html($data['month_year']),
                    esc_url($data['review_url'])
                );

            case 'approval':
                return sprintf(
                    '<p>' . esc_html__('Hello %s,', 'timesuite') . '</p>
                    <p>' . esc_html__('Great news! Your timesheet for %s has been approved by %s.', 'timesuite') . '</p>
                    <a href="%s" class="button">' . esc_html__('View Timesheet', 'timesuite') . '</a>',
                    esc_html($data['employee_name']),
                    esc_html($data['month_year']),
                    esc_html($data['approver_name']),
                    esc_url($data['view_url'])
                );

            case 'denial':
                return sprintf(
                    '<p>' . esc_html__('Hello %s,', 'timesuite') . '</p>
                    <p>' . esc_html__('Your timesheet for %s requires some changes.', 'timesuite') . '</p>
                    <div class="reason"><strong>' . esc_html__('Feedback from %s:', 'timesuite') . '</strong><br>%s</div>
                    <p>' . esc_html__('Please review the feedback and resubmit your timesheet.', 'timesuite') . '</p>
                    <a href="%s" class="button">' . esc_html__('Edit Timesheet', 'timesuite') . '</a>',
                    esc_html($data['employee_name']),
                    esc_html($data['month_year']),
                    esc_html($data['denier_name']),
                    esc_html($data['reason']),
                    esc_url($data['edit_url'])
                );

            case 'reedit_request':
                return sprintf(
                    '<p>' . esc_html__('Hello %s,', 'timesuite') . '</p>
                    <p>' . esc_html__('%s asked to re-edit their locked timesheet for %s.', 'timesuite') . '</p>
                    <div class="reason"><strong>' . esc_html__('Employee reason:', 'timesuite') . '</strong><br>%s</div>
                    <a href="%s" class="button">' . esc_html__('Review Request', 'timesuite') . '</a>',
                    esc_html($data['manager_name']),
                    esc_html($data['employee_name']),
                    esc_html($data['month_year']),
                    esc_html($data['reason']),
                    esc_url($data['review_url'])
                );

            case 'reedit_approved':
                return sprintf(
                    '<p>' . esc_html__('Hello %s,', 'timesuite') . '</p>
                    <p>' . esc_html__('Your request to re-edit %s was approved by %s.', 'timesuite') . '</p>
                    %s
                    <a href="%s" class="button">' . esc_html__('Edit Timesheet', 'timesuite') . '</a>',
                    esc_html($data['employee_name']),
                    esc_html($data['month_year']),
                    esc_html($data['manager_name']),
                    ! empty($data['reason'])
                        ? '<div class="reason"><strong>' . esc_html__('Manager note:', 'timesuite') . '</strong><br>' . esc_html($data['reason']) . '</div>'
                        : '',
                    esc_url($data['edit_url'])
                );

            case 'reedit_denied':
                return sprintf(
                    '<p>' . esc_html__('Hello %s,', 'timesuite') . '</p>
                    <p>' . esc_html__('Your request to re-edit %s was denied by %s.', 'timesuite') . '</p>
                    <div class="reason"><strong>' . esc_html__('Reason:', 'timesuite') . '</strong><br>%s</div>
                    <a href="%s" class="button">' . esc_html__('View Timesheet', 'timesuite') . '</a>',
                    esc_html($data['employee_name']),
                    esc_html($data['month_year']),
                    esc_html($data['manager_name']),
                    esc_html($data['reason']),
                    esc_url($data['view_url'])
                );

            case 'reminder':
                $isFinal = ! empty($data['is_final']);

                return sprintf(
                    '<p>' . esc_html__('Hello %s,', 'timesuite') . '</p>
                    <div class="alert"><strong>%s</strong></div>
                    <p>%s</p>
                    <a href="%s" class="button">' . esc_html__('Submit Timesheet', 'timesuite') . '</a>',
                    esc_html($data['employee_name']),
                    $isFinal
                        ? esc_html__('Today is the last day of the month!', 'timesuite')
                        : esc_html__('The month ends tomorrow!', 'timesuite'),
                    $isFinal
                        ? sprintf(
                            /* translators: %s: month/year */
                            esc_html__('Today is the last day of %s. Please submit your timesheet if you have not already.', 'timesuite'),
                            esc_html($data['month_year'])
                        )
                        : sprintf(
                            /* translators: %s: month/year */
                            esc_html__('%s ends tomorrow. Please log any remaining hours and submit your timesheet.', 'timesuite'),
                            esc_html($data['month_year'])
                        ),
                    esc_url($data['submit_url'])
                );

            case 'period_ready':
                return sprintf(
                    '<p>' . esc_html__('Hello,', 'timesuite') . '</p>
                    <p>' . esc_html__('The %s period has %d approved timesheets ready for final review and locking.', 'timesuite') . '</p>
                    <a href="%s" class="button">' . esc_html__('Review Period', 'timesuite') . '</a>',
                    esc_html($data['month_year']),
                    (int) $data['approved_count'],
                    esc_url($data['review_url'])
                );

            case 'test':
                return sprintf(
                    '<p>' . esc_html__('Hello!', 'timesuite') . '</p>
                    <p>' . esc_html__('This is a test email from Timesuite to verify your email configuration is working correctly.', 'timesuite') . '</p>
                    <div class="reason">
                        <strong>' . esc_html__('Configuration Details:', 'timesuite') . '</strong><br>
                        ' . esc_html__('Site:', 'timesuite') . ' %s<br>
                        ' . esc_html__('From Name:', 'timesuite') . ' %s<br>
                        ' . esc_html__('From Email:', 'timesuite') . ' %s
                    </div>
                    <p>' . esc_html__('If you received this email, your notification settings are configured correctly.', 'timesuite') . '</p>',
                    esc_html($data['site_name']),
                    esc_html($data['from_name']),
                    esc_html($data['from_email'])
                );

            default:
                return '<p>' . esc_html__('Notification from Timesuite.', 'timesuite') . '</p>';
        }
    }

    /**
     * Get the from email address formatted for headers.
     */
    private function getFromAddress(): string
    {
        $name  = $this->settings->getEmailFromName();
        $email = $this->settings->getEmailFromAddress();

        return sprintf('%s <%s>', $name, $email);
    }

    /**
     * Get URL to the timesheet page.
     */
    private function getTimesheetUrl(): string
    {
        return admin_url('admin.php?page=timesuite');
    }

    /**
     * Get URL to the employee timesheet page.
     */
    private function getEmployeeTimesheetUrl(): string
    {
        return admin_url('admin.php?page=timesuite-timesheet');
    }

    /**
     * Get URL to the manager view.
     */
    private function getManagerUrl(): string
    {
        return admin_url('admin.php?page=timesuite-manager');
    }
}

