# Changelog

All notable changes to Timesuite will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.17] - 2026-07-30

### Changed
- Month-end reminder emails now state the organisation's deadline plainly: timesheets are due by the end of the month ("due tomorrow" on the second-to-last day, "due today" on the last). The previous wording only noted that the month was ending, which read as informational rather than as a deadline.
- `period_cutoff_day` is treated as a grace period for late edits, not as the deadline communicated to employees. Stating the month-end expectation keeps the message true if someone later learns of the cutoff, so the urgency is not discredited.

## [0.1.16] - 2026-07-30

### Fixed
- **Deadline reminder emails were never being sent.** The schedule derived the deadline from the reporting period (the cutoff day of the *following* month) but only ever evaluated it from inside the current month, so the gap could never fall within the 3-day window unless `period_cutoff_day` was 1-3. At the configured value of 7, no reminder had ever fired. Reminders are now driven purely by month end and fire for any cutoff value.
- Reminder scheduling no longer measures elapsed seconds divided by 86400, which lost a day across daylight-saving transitions.
- Removed a duplicate copy of the timing rule in `EmailNotifier`, which could silently veto a send that the schedule had approved.

### Changed
- Employees who have not submitted are now nudged **twice** as the month closes: on the second-to-last day ("the month ends tomorrow") and on the last day ("today is the last day"). Anyone who has already submitted is skipped, so the second nudge only reaches those still outstanding.
- Reminders are now independent of `period_cutoff_day` and of the "default to previous month before the cutoff" toggle. The cutoff governs how long a finished month stays editable for payroll; the reminder is about logging hours while they are fresh, which is a month-end concern. This also removes all cross-month date arithmetic, and with it the class of bug above.
- Reminder emails no longer state a due date, since submission remains open until the cutoff. They say the month is ending instead.

### Notes
- The two stages are tracked under separate user meta keys, so the existing `timesuite_last_reminder_period` keeps its exact meaning and format and any stored value stays valid. No migration is required.
- `MonthlyTimesheetService::sendDeadlineReminders()` now accepts an optional injectable date. Production passes nothing and uses the clock; the parameter exists so the schedule's date maths is testable, which it previously was not.

## [0.1.15] - 2026-07-30

### Fixed
- Environment detection for automated reminder emails now reads the deploy environment Planet 4 actually exposes. The 0.1.14 guard checked the `APP_ENVIRONMENT` variable, but Planet 4 names it `APP_ENV` at runtime and its PHP-FPM pools run with `clear_env = yes`, so `getenv()` could not see it during a web request. Detection now prefers the `WP_APP_ENV` constant that Planet 4 bakes into `wp-config.php`, which is unaffected by `clear_env`, and falls back to environment variables for CLI (WP-CLI cron) and to the site host as before.
- Dev and staging blocking no longer depends solely on the hostname containing `www-dev.`/`www-stage.`. A non-production environment is now detected even when the host is renamed, closing a gap where a dev site could have started emailing real employees.

### Notes
- Production behaviour is unchanged: the live site is still detected as production and continues to send reminders. Detection remains fail-open, so an install that declares no environment at all keeps sending rather than going silently quiet.

## [0.1.14] - 2026-07-16

### Changed
- Payroll Matrix now marks each employee's own non-working days in their cells, while the Date column remains a date-only reference.

### Fixed
- Dashboard links to My Timesheet now open the employee timesheet screen.
- Automated deadline reminder emails are now sent only from production, including queued retries. Other Timesuite workflow emails remain available for dev and staging testing.

## [0.1.13] - 2026-07-02

### Changed
- Improved Manager View approval errors so self-approval, missing manager assignments, and wrong month statuses explain the next step.
- Improved Admin Rescue action errors so stale or inapplicable rescue actions explain the current month state and what to do instead.

## [0.1.12] - 2026-07-02

### Added
- Added Admin Rescue tools for HR and Technical Admin users to diagnose and safely repair stuck timesheet months.
- Added a CLI-only legacy month backfill command for materializing old user-meta timesheet months into the canonical tables.
- Added cutoff-aware default-period handling so timesheet, manager, and HR views can open on the relevant prior month before cutoff.

### Changed
- Improved monthly editability reasons and manager-facing status messaging for submitted, draft, locked, and failed-load states.
- Improved Time in Lieu handling during rescue and status transitions so ledger credits/debits stay synchronized.
- Improved policy settings for previous-month cutoff visibility, independent paid-time-off and sick carryover caps, and circular manager assignment controls.

### Fixed
- Fixed a data-loss bug where an approve/deny/undo-submit/reset/finalize action could silently overwrite a month's real submission history with an empty draft, if that month had never been opened through the employee's own timesheet page first
- Fixed the HR Dashboard showing "Not submitted" for months an employee had genuinely submitted, when that month predated the current storage table
- Manager View no longer shows a misleading "Draft / 0 pending / 0 reviewed" state when an employee's timesheet fails to load — it now shows a clear error instead
- Manager View now explains when a month simply hasn't been submitted yet, instead of showing an unexplained empty calendar
- Submit attempts (success, auto-lock, and failure) are now recorded in the audit log with before/after status, so submission issues can be diagnosed from the log alone
- Fixed SuperAccess users being shown full UI access but rejected by some REST endpoints.
- Fixed local/frontend asset loading in WordPress admin by loading the Timesuite app bundle as a JavaScript module.

## [0.1.11] - 2026-06-23

### Changed
- Hide employee carryover override fields when their policy cap is disabled
- Explain that disabled caps preserve the full balance
- Clarify that blank employee overrides use the policy default

## [0.1.10] - 2026-06-22

### Changed
- Show the previous-month cutoff day only when previous-month editing is enabled
- Split paid time off and sick-day carryover caps into independent controls
- Preserve the full prior-year balance when a carryover cap is disabled
- Remove the raw Org CSV export button while retaining Org CSV import support

## [0.1.9] - 2026-06-21

### Changed
- Moved the circular manager assignment toggle into Periods and submissions
- Kept Org CSV focused on organization mappings
- Added employment start and end dates to the HR summary export

## [0.1.8] - 2026-06-21

### Added
- Optional employment start and end dates with timesheet, payroll, accrual, and CSV support
- Annual vacation and sick carryover caps with per-employee overrides
- Configurable circular manager assignment policy
- Scoped, opt-in diagnostics mode on the System Status page
- Custom leave coverage for half-working days
- Formula-based payroll matrix summary rows

### Changed
- Separated Timesuite roles from WordPress roles
- Improved manager review messaging and employee undo-submit behavior
- Restricted holiday and non-working-day choices to valid options
- Improved month-selection guidance and payroll export summaries
- Reduced audit-log overhead and improved retention handling

### Fixed
- Locale-dependent working-day detection
- Draft months appearing actionable in manager review
- Salesforce-style circular co-manager assignments when explicitly allowed
- Leave deductions for employees with custom short working days

### Added
- **Bootstrap Mode**: Automatic first-time setup when no tech admin exists
  - WordPress administrators get temporary access to set up the first Timesuite admin
  - Automatically exits bootstrap mode once configured
  - Prevents lockout when moving plugin between environments
  - All bootstrap actions logged to audit trail
- Dashboard overview screen with pending approvals and submission status
- Audit log UI for HR and administrators
- Email notifications for timesheet submissions, approvals, and denials
- Health check endpoint (`/timesuite/v1/health`) for monitoring
- Export versioning (v1/v2) with additional metadata fields
- Timezone setting for organization-wide date handling
- Optimistic locking to prevent concurrent edit conflicts
- Audit log retention policy with configurable cleanup
- More granular capabilities (org.view, org.edit, org.import, org.delete, etc.)
- Rate limiting presets for different action types
- SECURITY.md with responsible disclosure guidelines
- CHANGELOG.md for tracking releases

### Changed
- Improved error messages to be more user-friendly and actionable
- Empty states now explain what to do next
- Build-required preflight screen shows clear setup instructions
- GitHub Actions CI now runs on every push/PR

### Fixed
- TypeScript strict mode compliance for all frontend code
- Rate limiting now properly scoped per endpoint type

### Security
- CSRF protection verified on all state-changing endpoints
- Database indexes added for frequently queried columns

## [0.1.0] - 2024-12-30

### Added
- Initial release
- Employee timesheet entry with monthly calendar view
- Manager approval workflow (approve/deny/reset)
- HR period locking and payroll exports (CSV/XLSX)
- Org directory management
- Policy settings (work week, holidays, rounding, cutoffs)
- Bulk import for timesheets (XLSX) and org mappings (CSV)
- REST API for all operations
- React/Vite frontend with dark mode support
- Custom WordPress roles and capabilities
- Internationalization support (translation-ready)

[Unreleased]: https://github.com/greenpeace/timesuite/compare/v0.1.17...HEAD
[0.1.17]: https://github.com/greenpeace/timesuite/compare/v0.1.16...v0.1.17
[0.1.16]: https://github.com/greenpeace/timesuite/compare/v0.1.15...v0.1.16
[0.1.15]: https://github.com/greenpeace/timesuite/compare/v0.1.14...v0.1.15
[0.1.14]: https://github.com/greenpeace/timesuite/compare/v0.1.13...v0.1.14
[0.1.13]: https://github.com/greenpeace/timesuite/compare/v0.1.12...v0.1.13
[0.1.12]: https://github.com/greenpeace/timesuite/compare/v0.1.11...v0.1.12
[0.1.11]: https://github.com/greenpeace/timesuite/compare/v0.1.10...v0.1.11
[0.1.10]: https://github.com/greenpeace/timesuite/compare/v0.1.9...v0.1.10
[0.1.9]: https://github.com/greenpeace/timesuite/compare/v0.1.8...v0.1.9
[0.1.8]: https://github.com/greenpeace/timesuite/compare/v0.1.4...v0.1.8
[0.1.0]: https://github.com/greenpeace/timesuite/releases/tag/v0.1.0
