<?php

declare(strict_types=1);

namespace Timesuite\Domain\Reports;

use Timesuite\Core\Settings;
use Timesuite\Domain\Timesheets\DayState;
use Timesuite\Domain\Timesheets\Services\CompTimeService;
use Timesuite\Domain\Timesheets\Services\DayStateService;
use Timesuite\Domain\Timesheets\Services\HolidayRangeService;
use Timesuite\Domain\Timesheets\Services\MonthlyTimesheetService;
use Timesuite\Domain\Timesheets\Services\VacationService;

/**
 * Service for generating timesheet report data.
 * 
 * This service aggregates data from existing services to produce
 * export-ready data structures. It does NOT contain business logic -
 * all calculations come from the underlying services.
 */
class TimesheetReportService
{
    public function __construct(
        private MonthlyTimesheetService $timesheetService,
        private VacationService $vacationService,
        private CompTimeService $compTimeService,
        private DayStateService $dayStateService,
        private HolidayRangeService $holidayRangeService,
        private Settings $settings
    ) {
    }

    /**
     * Generate report data for a single employee's timesheet.
     *
     * @return array{
     *   metadata: array,
     *   daily_entries: array[],
     *   summary: array
     * }
     */
    public function generateEmployeeReport(
        int $userId,
        int $year,
        int $month,
        int $exportedBy
    ): array {
        $user = get_user_by('id', $userId);
        $exporter = get_user_by('id', $exportedBy);

        if (! $user) {
            throw new \InvalidArgumentException('User not found');
        }

        // Get timesheet data
        $timesheet = $this->timesheetService->getMonth($userId, $year, $month);
        $workWeek = $this->dayStateService->getUserWorkWeek($userId);
        $startDate = sprintf('%04d-%02d-01', $year, $month);
        $endDate = sprintf('%04d-%02d-%02d', $year, $month, $this->daysInMonth($year, $month));
        $holidays = array_keys($this->holidayRangeService->getHolidayMapForRange($startDate, $endDate));
        $dailyHours = $this->settings->getDailyHours();
        $leaveStandardDayHours = $this->settings->getLeaveStandardDayHours() > 0
            ? $this->settings->getLeaveStandardDayHours()
            : $dailyHours;

        // Get day states for the month
        $dayStates = $this->dayStateService->computeMonthStates(
            $year,
            $month,
            $workWeek,
            $holidays,
            false, // We'll check lock status per entry
            [],
            $timesheet['status'],
            $timesheet['submitted_at'] ?? null,
            null,
            $timesheet['approved_at'] ?? null,
            $timesheet['denied_comment'] ?? null,
            'employee'
        );

        // Build daily entries with all relevant data
        $dailyEntries = [];
        $summary = [
            'total_working_days' => 0,
            'total_worked_days' => 0,
            'total_planned_hours' => 0,
            'total_worked_hours' => 0,
            'vacation_days_used' => 0.0,
            'sick_days_used' => 0.0,
            'half_day_count' => 0,
        ];
        $vacationHoursUsedInPeriod = 0.0;
        $sickHoursUsedInPeriod = 0.0;

        $types = $this->timesheetService->getDayTypes();
        $partDaySources = $this->timesheetService->getPartDaySources();

        foreach ($timesheet['entries'] as $entry) {
            $date = $entry['date'];
            $dayState = $dayStates[$date] ?? ['state' => DayState::EDITABLE, 'reason' => null];
            $dayOfWeek = gmdate('D', strtotime($date));
            $scheduledHours = isset($entry['scheduled_hours']) && is_numeric($entry['scheduled_hours'])
                ? (float) $entry['scheduled_hours']
                : $dailyHours;

            $dailyEntry = [
                'date' => $date,
                'day_of_week' => $dayOfWeek,
                'day_state' => $dayState['state'],
                'day_state_reason' => $dayState['reason'],
                'day_type' => $entry['type'],
                'day_type_label' => $types[$entry['type']] ?? $entry['type'],
                'planned_hours' => $entry['type'] === 'not_employed'
                    ? 0
                    : ($this->isWorkingDay($dayState['state'], $workWeek, $date) ? $scheduledHours : 0),
                'worked_hours' => $this->calculateWorkedHours($entry, $scheduledHours),
                'part_day_hours' => $entry['hours'] ?? null,
                'coverage_source' => $entry['coverage_source'] ?? null,
                'coverage_source_label' => isset($entry['coverage_source'])
                    ? ($partDaySources[$entry['coverage_source']] ?? $entry['coverage_source'])
                    : null,
                'in_office' => $entry['in_office'] ?? null,
                'notes' => $entry['notes'] ?? '',
                'approval_status' => $entry['approval_status'] ?? null,
                'needs_approval' => $entry['needs_approval'] ?? false,
            ];

            $dailyEntries[] = $dailyEntry;

            // Update summary
            if ($dayState['state'] !== DayState::DISABLED && $entry['type'] !== 'not_employed') {
                $summary['total_working_days']++;
                $summary['total_planned_hours'] += $dailyEntry['planned_hours'];
            }

            if (in_array($entry['type'], ['working_day', 'half_working', 'half_holiday'], true)) {
                if ($entry['type'] === 'working_day') {
                    $summary['total_worked_days']++;
                    $summary['total_worked_hours'] += $scheduledHours;
                } elseif (in_array($entry['type'], ['half_working', 'half_holiday'], true)) {
                    $summary['half_day_count']++;
                    $summary['total_worked_hours'] += (float) ($entry['hours'] ?? 0);
                }
            } elseif ($entry['type'] === 'overtime') {
                $summary['total_worked_days']++;
                $summary['total_worked_hours'] += $scheduledHours + (float) ($entry['hours'] ?? 0);
            }

            $entryApproved = $this->isEntryApproved($timesheet['status'] ?? 'draft', $entry['approval_status'] ?? null);
            if ($entryApproved) {
                if (in_array($entry['type'], ['day_off', 'pto', 'vacation', 'annual_leave'], true)
                    && $dayState['state'] !== DayState::DISABLED) {
                    $vacationHoursUsedInPeriod += $scheduledHours;
                }

                if (in_array($entry['type'], ['sick_day', 'sick', 'illness'], true)) {
                    $sickHoursUsedInPeriod += $scheduledHours;
                }

                if ($entry['type'] === 'half_working') {
                    $coverageSource = $entry['coverage_source'] ?? null;
                    $coveredHours = round(max(0.0, $scheduledHours - (float) ($entry['hours'] ?? ($scheduledHours / 2))), 2);
                    if ($coverageSource === 'half_day_off' && $dayState['state'] !== DayState::DISABLED) {
                        $vacationHoursUsedInPeriod += $coveredHours;
                    } elseif ($coverageSource === 'half_sick_day' && $dayState['state'] !== DayState::DISABLED) {
                        $sickHoursUsedInPeriod += $coveredHours;
                    }
                }
            }
        }

        // Get vacation and sick stats
        $vacationContract = $this->vacationService->getVacationDaysContract($userId);
        $vacationUsedYTD = $this->vacationService->getVacationDaysUsedInYear($userId, $year);
        $vacationRemaining = $this->vacationService->getVacationDaysRemaining($userId, $year);

        $sickContract = $this->vacationService->getSickDaysContract($userId);
        $sickUsedYTD = $this->vacationService->getSickDaysUsedInYear($userId, $year);
        $sickRemaining = $this->vacationService->getSickDaysRemaining($userId, $year);

        // Get comp time balance
        $currentDate = gmdate('Y-m-d');
        $compTimeBalance = $this->compTimeService->getAvailableMinutes($userId, $currentDate);

        // Build final summary
        $summary['vacation_days_used'] = round($vacationHoursUsedInPeriod / $leaveStandardDayHours, 1);
        $summary['sick_days_used'] = round($sickHoursUsedInPeriod / $leaveStandardDayHours, 1);
        $summary['vacation_contract_days'] = $vacationContract;
        $summary['vacation_used_ytd'] = $vacationUsedYTD;
        $summary['vacation_remaining'] = $vacationRemaining;
        $summary['sick_contract_days'] = $sickContract;
        $summary['sick_used_ytd'] = $sickUsedYTD;
        $summary['sick_remaining'] = $sickRemaining;
        $summary['comp_time_balance_minutes'] = $compTimeBalance;
        $summary['comp_time_balance_hours'] = round($compTimeBalance / 60, 2);
        $summary['timesheet_status'] = $timesheet['status'];
        $summary['submitted_at'] = $timesheet['submitted_at'] ?? null;
        $summary['approved_at'] = $timesheet['approved_at'] ?? null;
        $summary['denied_at'] = $timesheet['denied_at'] ?? null;
        $summary['denied_comment'] = $timesheet['denied_comment'] ?? null;

        // Get manager info
        $managerId = (int) get_user_meta($userId, 'timesuite_manager_id', true);
        $manager = $managerId ? get_user_by('id', $managerId) : null;

        return [
            'metadata' => [
                'exported_at' => gmdate('Y-m-d H:i:s'),
                'exported_by' => $exporter ? $exporter->display_name : 'Unknown',
                'exported_by_email' => $exporter ? $exporter->user_email : '',
                'employee_name' => $user->display_name,
                'employee_email' => $user->user_email,
                'employee_id' => $userId,
                'manager_name' => $manager ? $manager->display_name : null,
                'department' => get_user_meta($userId, 'timesuite_department', true) ?: null,
                'period_year' => $year,
                'period_month' => $month,
                'period_label' => gmdate('F Y', strtotime("$year-$month-01")),
                'work_week' => $workWeek,
                'daily_hours_setting' => $dailyHours,
            ],
            'daily_entries' => $dailyEntries,
            'summary' => $summary,
        ];
    }

    /**
     * Generate HR summary report for multiple employees.
     *
     * @param int[] $userIds
     * @return array{metadata: array, employees: array[]}
     */
    public function generateHrSummaryReport(
        array $userIds,
        int $year,
        int $month,
        int $exportedBy,
        ?string $departmentFilter = null
    ): array {
        $exporter = get_user_by('id', $exportedBy);
        $employees = [];

        // Get bulk stats for efficiency
        $vacationStats = $this->vacationService->getBulkVacationStats($userIds, $year);
        $sickStats = $this->vacationService->getBulkSickStats($userIds, $year);
        $currentDate = gmdate('Y-m-d');
        $compTimeBalances = $this->compTimeService->getBulkAvailableMinutes($userIds, $currentDate);

        $dailyHours = $this->settings->getDailyHours();
        $leaveStandardDayHours = $this->settings->getLeaveStandardDayHours() > 0
            ? $this->settings->getLeaveStandardDayHours()
            : $dailyHours;
        $startDate = sprintf('%04d-%02d-01', $year, $month);
        $endDate = sprintf('%04d-%02d-%02d', $year, $month, $this->daysInMonth($year, $month));
        $holidayMap = $this->holidayRangeService->getHolidayMapForRange($startDate, $endDate);

        foreach ($userIds as $userId) {
            $user = get_user_by('id', $userId);
            if (! $user) {
                continue;
            }

            $department = get_user_meta($userId, 'timesuite_department', true) ?: '';

            // Apply department filter if specified
            if ($departmentFilter !== null && $department !== $departmentFilter) {
                continue;
            }

            // Get timesheet data
            $timesheet = $this->timesheetService->getMonth($userId, $year, $month);
            $workWeek = $this->dayStateService->getUserWorkWeek($userId);

            // Calculate period stats
            $workingDays = 0;
            $workedDays = 0;
            $workedHours = 0;
            $vacationHoursInPeriod = 0.0;
            $sickHoursInPeriod = 0.0;
            $hasPendingApprovals = false;

            foreach ($timesheet['entries'] as $entry) {
                $dayOfWeek = gmdate('D', strtotime($entry['date']));
                $scheduledHours = isset($entry['scheduled_hours']) && is_numeric($entry['scheduled_hours'])
                    ? (float) $entry['scheduled_hours']
                    : $dailyHours;
                if (($entry['type'] ?? '') === 'not_employed') {
                    continue;
                }
                if (in_array($dayOfWeek, $workWeek, true)) {
                    $workingDays++;
                }

                if ($entry['type'] === 'working_day') {
                    $workedDays++;
                    $workedHours += $scheduledHours;
                } elseif (in_array($entry['type'], ['half_working', 'half_holiday'], true)) {
                    $workedHours += (float) ($entry['hours'] ?? 0);
                } elseif ($entry['type'] === 'overtime') {
                    $workedDays++;
                    $workedHours += $scheduledHours + (float) ($entry['hours'] ?? 0);
                }

                $entryApproved = $this->isEntryApproved($timesheet['status'] ?? 'draft', $entry['approval_status'] ?? null);
                if ($entryApproved) {
                    if (in_array($entry['type'], ['day_off', 'pto', 'vacation', 'annual_leave'], true)) {
                        $entryDate = $entry['date'] ?? null;
                        if ($entryDate && ! isset($holidayMap[$entryDate]) && in_array($dayOfWeek, $workWeek, true)) {
                            $vacationHoursInPeriod += $scheduledHours;
                        }
                    } elseif ($entry['type'] === 'half_working') {
                        $entryDate = $entry['date'] ?? null;
                        if ($entryDate && ! isset($holidayMap[$entryDate]) && in_array($dayOfWeek, $workWeek, true)) {
                            if (($entry['coverage_source'] ?? null) === 'half_day_off') {
                                $vacationHoursInPeriod += (float) ($entry['hours'] ?? ($scheduledHours / 2));
                            } elseif (($entry['coverage_source'] ?? null) === 'half_sick_day') {
                                $sickHoursInPeriod += (float) ($entry['hours'] ?? ($scheduledHours / 2));
                            }
                        }
                    }

                    if (in_array($entry['type'], ['sick_day', 'sick', 'illness'], true)) {
                        $sickHoursInPeriod += $scheduledHours;
                    }
                }

                if (($entry['needs_approval'] ?? false) && ! $entry['approval_status']) {
                    $hasPendingApprovals = true;
                }
            }

            // Get manager info
            $managerId = $this->getManagerId($userId);
            $manager = $managerId ? get_user_by('id', $managerId) : null;
            $customDailyHours = get_user_meta($userId, 'timesuite_daily_hours_by_day', true);
            $timesuiteRole = (string) get_user_meta($userId, 'timesuite_access_role', true);
            $employmentStartDate = (string) get_user_meta($userId, 'timesuite_hire_date', true);
            $employmentEndDate = (string) get_user_meta($userId, 'timesuite_employment_end_date', true);

            $employees[] = [
                'employee_id' => $userId,
                'employee_name' => $user->display_name,
                'employee_email' => $user->user_email,
                'department' => $department,
                'employment_start_date' => $employmentStartDate,
                'employment_end_date' => $employmentEndDate,
                'manager_name' => $manager ? $manager->display_name : null,
                'has_custom_daily_hours' => is_array($customDailyHours) && ! empty($customDailyHours),
                'timesuite_role' => $timesuiteRole !== '' ? $timesuiteRole : null,
                'vacation_contract_days' => $this->vacationService->getVacationDaysContract($userId),
                'sick_contract_days' => $this->vacationService->getSickDaysContract($userId),
                'work_week' => implode(', ', $workWeek),
                'working_days_in_period' => $workingDays,
                'worked_days' => $workedDays,
                'planned_hours' => round(array_reduce(
                    $timesheet['entries'],
                    static function (float $carry, array $entry) use ($workWeek, $dailyHours): float {
                        if (($entry['type'] ?? '') === 'not_employed') {
                            return $carry;
                        }

                        $dayOfWeek = gmdate('D', strtotime((string) $entry['date']));
                        if (! in_array($dayOfWeek, $workWeek, true)) {
                            return $carry;
                        }

                        $scheduledHours = isset($entry['scheduled_hours']) && is_numeric($entry['scheduled_hours'])
                            ? (float) $entry['scheduled_hours']
                            : $dailyHours;

                        return $carry + $scheduledHours;
                    },
                    0.0
                ), 2),
                'worked_hours' => $workedHours,
                'vacation_used_period' => round($vacationHoursInPeriod / $leaveStandardDayHours, 1),
                'vacation_used_ytd' => $vacationStats[$userId]['used'] ?? 0,
                'vacation_remaining' => $vacationStats[$userId]['remaining'] ?? 0,
                'sick_used_period' => round($sickHoursInPeriod / $leaveStandardDayHours, 1),
                'sick_used_ytd' => $sickStats[$userId]['used'] ?? 0,
                'sick_remaining' => $sickStats[$userId]['remaining'] ?? 0,
                'comp_time_balance_minutes' => $compTimeBalances[$userId] ?? 0,
                'comp_time_balance_hours' => round(($compTimeBalances[$userId] ?? 0) / 60, 2),
                'timesheet_status' => $timesheet['status'],
                'has_pending_approvals' => $hasPendingApprovals,
                'submitted_at' => $timesheet['submitted_at'] ?? null,
                'approved_at' => $timesheet['approved_at'] ?? null,
            ];
        }

        return [
            'metadata' => [
                'exported_at' => gmdate('Y-m-d H:i:s'),
                'exported_by' => $exporter ? $exporter->display_name : 'Unknown',
                'exported_by_email' => $exporter ? $exporter->user_email : '',
                'period_year' => $year,
                'period_month' => $month,
                'period_label' => gmdate('F Y', strtotime("$year-$month-01")),
                'department_filter' => $departmentFilter,
                'employee_count' => count($employees),
                'daily_hours_setting' => $dailyHours,
            ],
            'employees' => $employees,
        ];
    }

    /**
     * Generate a payroll matrix report for HR.
     *
     * Includes all employees in scope as stable columns. Only locked months are populated;
     * employees without a locked month remain blank so HR can spot missing submissions.
     *
     * @param int[] $userIds
     * @return array{
     *   metadata: array,
     *   employees: array<int, array<string, mixed>>,
     *   rows: array<int, array{date:string, cells: array<int, array{worked:string|float, type:string, hours_off:string|float}>}>
     * }
     */
    public function generatePayrollMatrixReport(
        array $userIds,
        int $year,
        int $month,
        int $exportedBy
    ): array {
        $exporter = get_user_by('id', (string) $exportedBy);
        $types = $this->timesheetService->getDayTypes();
        $customLeaveKeys = array_flip($this->timesheetService->getCustomLeaveTypeKeys());
        $dates = $this->buildMonthDates($year, $month);
        $leaveStandardDayHours = max(
            1.0,
            round(
                max(
                    $this->settings->getLeaveStandardDayHours(),
                    $this->settings->getDailyHours()
                ),
                2
            )
        );
        $holidayMap = $this->holidayRangeService->getHolidayMapForRange(
            sprintf('%04d-%02d-01', $year, $month),
            sprintf('%04d-%02d-%02d', $year, $month, $this->daysInMonth($year, $month))
        );

        $employees = [];
        foreach ($userIds as $userId) {
            $user = get_user_by('id', (string) $userId);

            if (! $user) {
                continue;
            }

            $employees[] = [
                'user_id' => (int) $userId,
                'name' => (string) ($user->display_name ?: $user->user_login),
                'email' => (string) $user->user_email,
            ];
        }

        usort(
            $employees,
            static function (array $a, array $b): int {
                $nameCompare = strcasecmp((string) $a['name'], (string) $b['name']);
                if ($nameCompare !== 0) {
                    return $nameCompare;
                }

                return strcasecmp((string) $a['email'], (string) $b['email']);
            }
        );

        $matrixByUser = [];
        $summaryByUser = [];
        $lockedCount = 0;

        foreach ($employees as &$employee) {
            $userId = (int) $employee['user_id'];
            $meta = $this->timesheetService->getMonthMeta($userId, $year, $month);
            $isLocked = (($meta['status'] ?? 'draft') === 'locked');
            $employee['has_locked_month'] = $isLocked;
            $employee['status'] = (string) ($meta['status'] ?? 'draft');

            if (! $isLocked) {
                $matrixByUser[$userId] = [];
                continue;
            }

            $lockedCount++;
            $timesheet = $this->timesheetService->getMonth($userId, $year, $month);
            $workWeek = $this->dayStateService->getUserWorkWeek($userId);
            $summaryByUser[$userId] = [
                'payable_hours' => 0.0,
                'worked_days' => 0,
                'vacation_hours' => 0.0,
                'sick_hours' => 0.0,
                'other_paid_leave_hours' => 0.0,
            ];
            $entriesByDate = [];

            foreach ($timesheet['entries'] as $entry) {
                $entriesByDate[(string) $entry['date']] = $entry;
            }

            foreach ($dates as $date) {
                $entry = $entriesByDate[$date] ?? null;

                if (! is_array($entry)) {
                    $matrixByUser[$userId][$date] = $this->blankPayrollMatrixCell();
                    continue;
                }

                $matrixByUser[$userId][$date] = $this->buildPayrollMatrixCell(
                    $entry,
                    $date,
                    $workWeek,
                    $holidayMap,
                    $types,
                    $customLeaveKeys
                );

                $this->accumulatePayrollMatrixSummary(
                    $summaryByUser[$userId],
                    $entry,
                    $date,
                    $workWeek,
                    $holidayMap,
                    $customLeaveKeys
                );
            }
        }
        unset($employee);

        $rows = [];
        foreach ($dates as $date) {
            $cells = [];
            foreach ($employees as $employee) {
                $userId = (int) $employee['user_id'];
                $cells[] = $matrixByUser[$userId][$date] ?? $this->blankPayrollMatrixCell();
            }

            $rowContext = $this->getPayrollMatrixRowContext($date, $holidayMap);

            $rows[] = [
                'date' => $rowContext['label'],
                'row_kind' => $rowContext['kind'],
                'cells' => $cells,
            ];
        }

        $summaryRows = [
            [
                'label' => 'Payable Hours',
                'column' => 'worked',
                'formula_key' => 'payable_hours',
                'values' => [],
            ],
            [
                'label' => 'Worked Days',
                'column' => 'worked',
                'formula_key' => 'worked_days',
                'values' => [],
            ],
            [
                'label' => 'Vacation Used (days)',
                'column' => 'hours_off',
                'formula_key' => 'vacation_days',
                'values' => [],
            ],
            [
                'label' => 'Sick Used (days)',
                'column' => 'hours_off',
                'formula_key' => 'sick_days',
                'values' => [],
            ],
            [
                'label' => 'Other Paid Leave (days)',
                'column' => 'hours_off',
                'formula_key' => 'other_paid_leave_days',
                'values' => [],
            ],
        ];

        foreach ($employees as $employee) {
            $userId = (int) $employee['user_id'];

            if (empty($employee['has_locked_month'])) {
                foreach ($summaryRows as &$summaryRow) {
                    $summaryRow['values'][$userId] = '';
                }
                unset($summaryRow);
                continue;
            }

            $summary = $summaryByUser[$userId] ?? [
                'payable_hours' => 0.0,
                'worked_days' => 0,
                'vacation_hours' => 0.0,
                'sick_hours' => 0.0,
                'other_paid_leave_hours' => 0.0,
            ];

            $summaryRows[0]['values'][$userId] = $this->normalizePayrollSummaryValue($summary['payable_hours']);
            $summaryRows[1]['values'][$userId] = $summary['worked_days'] > 0 ? (float) $summary['worked_days'] : '';
            $summaryRows[2]['values'][$userId] = $this->normalizePayrollSummaryValue($summary['vacation_hours'] / $leaveStandardDayHours);
            $summaryRows[3]['values'][$userId] = $this->normalizePayrollSummaryValue($summary['sick_hours'] / $leaveStandardDayHours);
            $summaryRows[4]['values'][$userId] = $this->normalizePayrollSummaryValue($summary['other_paid_leave_hours'] / $leaveStandardDayHours);
        }

        return [
            'metadata' => [
                'exported_at' => gmdate('Y-m-d H:i:s'),
                'exported_by' => $exporter ? $exporter->display_name : 'Unknown',
                'exported_by_email' => $exporter ? $exporter->user_email : '',
                'period_year' => $year,
                'period_month' => $month,
                'period_label' => gmdate('F Y', strtotime("$year-$month-01")),
                'employee_count' => count($employees),
                'locked_employee_count' => $lockedCount,
                'missing_locked_count' => count($employees) - $lockedCount,
                'leave_standard_day_hours' => $leaveStandardDayHours,
            ],
            'employees' => $employees,
            'rows' => $rows,
            'summary_rows' => $summaryRows,
        ];
    }

    /**
     * Calculate worked hours for an entry.
     */
    private function calculateWorkedHours(array $entry, float $dailyHours): float
    {
        if ($entry['type'] === 'working_day') {
            return $dailyHours;
        }

        if (in_array($entry['type'], ['half_working', 'half_holiday'], true)) {
            return (float) ($entry['hours'] ?? 0);
        }

        if ($entry['type'] === 'overtime') {
            return $dailyHours + (float) ($entry['hours'] ?? 0);
        }

        return 0;
    }

    /**
     * Check if a day is a working day based on state and work week.
     */
    private function isWorkingDay(string $state, array $workWeek, string $date): bool
    {
        if ($state === DayState::DISABLED) {
            return false;
        }

        $dayOfWeek = gmdate('D', strtotime($date));
        return in_array($dayOfWeek, $workWeek, true);
    }

    /**
     * Get manager ID for a user.
     */
    private function getManagerId(int $userId): ?int
    {
        global $wpdb;

        $managerId = $wpdb->get_var($wpdb->prepare(
            "SELECT org_unit_id FROM {$wpdb->prefix}timesuite_users_org 
             WHERE user_id = %d AND removed_at IS NULL 
             ORDER BY id DESC LIMIT 1",
            $userId
        ));

        return $managerId ? (int) $managerId : null;
    }

    private function isEntryApproved(string $timesheetStatus, ?string $approvalStatus): bool
    {
        $approvalStatus = strtolower((string) $approvalStatus);
        if ($approvalStatus === 'approved') {
            return true;
        }

        $status = strtolower($timesheetStatus);

        return in_array($status, ['approved', 'locked'], true);
    }

    /**
     * @return string[]
     */
    private function buildMonthDates(int $year, int $month): array
    {
        $days = $this->daysInMonth($year, $month);
        $dates = [];

        for ($day = 1; $day <= $days; $day++) {
            $dates[] = sprintf('%04d-%02d-%02d', $year, $month, $day);
        }

        return $dates;
    }

    /**
     * @param array<string, mixed> $entry
     * @param string[] $workWeek
     * @param array<string, string> $holidayMap
     * @param array<string, string> $types
     * @param array<string, int> $customLeaveKeys
     * @return array{worked:string|float, type:string, hours_off:string|float}
     */
    private function buildPayrollMatrixCell(
        array $entry,
        string $date,
        array $workWeek,
        array $holidayMap,
        array $types,
        array $customLeaveKeys
    ): array {
        $type = (string) ($entry['type'] ?? 'working_day');
        if ($type === 'not_employed') {
            return $this->blankPayrollMatrixCell();
        }

        $scheduledHours = isset($entry['scheduled_hours']) && is_numeric($entry['scheduled_hours'])
            ? round((float) $entry['scheduled_hours'], 2)
            : round($this->settings->getDailyHours(), 2);
        $entryHours = isset($entry['hours']) && is_numeric($entry['hours'])
            ? round((float) $entry['hours'], 2)
            : null;
        $coverageSource = (string) ($entry['coverage_source'] ?? '');
        $dayCode = gmdate('D', strtotime($date . ' UTC'));
        $isScheduledWorkDay = in_array($dayCode, $workWeek, true);

        if (! $isScheduledWorkDay && $type !== 'overtime') {
            return $this->nonWorkingPayrollMatrixCell();
        }

        return match ($type) {
            'working_day' => [
                'worked' => $scheduledHours,
                'type' => '',
                'hours_off' => '',
                'scheduled_hours' => $scheduledHours,
            ],
            'overtime' => [
                'worked' => round(($isScheduledWorkDay ? $scheduledHours : 0.0) + ($entryHours ?? 0.0), 2),
                'type' => 'OT',
                'hours_off' => '',
                'scheduled_hours' => $scheduledHours,
            ],
            'day_off' => [
                'worked' => 0.0,
                'type' => 'VAC',
                'hours_off' => $scheduledHours,
                'scheduled_hours' => $scheduledHours,
            ],
            'time_in_lieu' => [
                'worked' => 0.0,
                'type' => 'COMP',
                'hours_off' => $scheduledHours,
                'scheduled_hours' => $scheduledHours,
            ],
            'sick_day' => [
                'worked' => 0.0,
                'type' => 'SICK',
                'hours_off' => $scheduledHours,
                'scheduled_hours' => $scheduledHours,
            ],
            'holiday' => [
                'worked' => 0.0,
                'type' => isset($holidayMap[$date]) ? 'HOL' : '',
                'hours_off' => '',
                'scheduled_hours' => $scheduledHours,
            ],
            'half_holiday' => $this->buildPartialPayrollMatrixCell(
                $entryHours ?? round($scheduledHours / 2, 2),
                $scheduledHours,
                'HOL_HALF',
                false
            ),
            'half_working' => $this->buildPartialPayrollMatrixCell(
                $entryHours ?? round($scheduledHours / 2, 2),
                $scheduledHours,
                match ($coverageSource) {
                    'half_day_off' => 'VAC_HALF',
                    'half_sick_day' => 'SICK_HALF',
                    'time_in_lieu' => 'COMP_HALF',
                    default => isset($customLeaveKeys[$coverageSource])
                        ? ($types[$coverageSource] ?? $coverageSource)
                        : 'WORK_HALF',
                },
                match ($coverageSource) {
                    'half_day_off', 'half_sick_day', 'time_in_lieu' => true,
                    default => isset($customLeaveKeys[$coverageSource]),
                }
            ),
            default => isset($customLeaveKeys[$type]) ? [
                'worked' => 0.0,
                'type' => $types[$type] ?? $type,
                'hours_off' => $scheduledHours,
                'scheduled_hours' => $scheduledHours,
            ] : $this->blankPayrollMatrixCell(),
        };
    }

    /**
     * @return array{worked:string|float, type:string, hours_off:string|float}
     */
    private function buildPartialPayrollMatrixCell(
        float $worked,
        float $scheduledHours,
        string $type,
        bool $includeHoursOff = true
    ): array
    {
        $worked = round(max(0.0, $worked), 2);
        $hoursOff = round(max(0.0, $scheduledHours - $worked), 2);

        return [
            'worked' => $worked,
            'type' => $type,
            'hours_off' => ($includeHoursOff && $hoursOff > 0) ? $hoursOff : '',
            'scheduled_hours' => $scheduledHours,
        ];
    }

    /**
     * @return array{worked:string, type:string, hours_off:string}
     */
    private function blankPayrollMatrixCell(): array
    {
        return [
            'worked' => '',
            'type' => '',
            'hours_off' => '',
            'scheduled_hours' => '',
        ];
    }

    /**
     * @return array{worked:string, type:string, hours_off:string, scheduled_hours:string, cell_kind:string}
     */
    private function nonWorkingPayrollMatrixCell(): array
    {
        return [
            'worked' => '',
            'type' => 'Non-working day',
            'hours_off' => '',
            'scheduled_hours' => '',
            'cell_kind' => 'non_working',
        ];
    }

    /**
     * @param array<string, float|int> $summary
     * @param array<string, mixed> $entry
     * @param string[] $workWeek
     * @param array<string, string> $holidayMap
     * @param array<string, int> $customLeaveKeys
     */
    private function accumulatePayrollMatrixSummary(
        array &$summary,
        array $entry,
        string $date,
        array $workWeek,
        array $holidayMap,
        array $customLeaveKeys
    ): void {
        $type = (string) ($entry['type'] ?? 'working_day');
        if ($type === 'not_employed') {
            return;
        }

        $scheduledHours = isset($entry['scheduled_hours']) && is_numeric($entry['scheduled_hours'])
            ? round((float) $entry['scheduled_hours'], 2)
            : round($this->settings->getDailyHours(), 2);
        $entryHours = isset($entry['hours']) && is_numeric($entry['hours'])
            ? round((float) $entry['hours'], 2)
            : null;
        $coverageSource = (string) ($entry['coverage_source'] ?? '');
        $dayCode = gmdate('D', strtotime($date . ' UTC'));
        $isScheduledWorkDay = in_array($dayCode, $workWeek, true);
        $isHoliday = isset($holidayMap[$date]);

        if (! $isScheduledWorkDay && ! $isHoliday && $type !== 'overtime') {
            return;
        }

        $workedForDay = 0.0;

        switch ($type) {
            case 'working_day':
                $summary['payable_hours'] += $scheduledHours;
                $workedForDay = $scheduledHours;
                break;

            case 'overtime':
                $summary['payable_hours'] += round(($isScheduledWorkDay ? $scheduledHours : 0.0) + ($entryHours ?? 0.0), 2);
                $workedForDay = round(($isScheduledWorkDay ? $scheduledHours : 0.0) + ($entryHours ?? 0.0), 2);
                break;

            case 'day_off':
                if (! $isScheduledWorkDay) {
                    return;
                }
                $summary['payable_hours'] += $scheduledHours;
                $summary['vacation_hours'] += $scheduledHours;
                break;

            case 'time_in_lieu':
                if (! $isScheduledWorkDay) {
                    return;
                }
                $summary['payable_hours'] += $scheduledHours;
                break;

            case 'sick_day':
                if (! $isScheduledWorkDay) {
                    return;
                }
                $summary['payable_hours'] += $scheduledHours;
                $summary['sick_hours'] += $scheduledHours;
                break;

            case 'holiday':
                if (! $isHoliday) {
                    return;
                }
                $summary['payable_hours'] += $scheduledHours;
                break;

            case 'half_holiday':
                if (! $isHoliday) {
                    return;
                }
                $summary['payable_hours'] += $scheduledHours;
                $workedForDay = $entryHours ?? round($scheduledHours / 2, 2);
                break;

            case 'half_working':
                if (! $isScheduledWorkDay) {
                    return;
                }

                $worked = $entryHours ?? round($scheduledHours / 2, 2);
                $covered = round(max(0.0, $scheduledHours - $worked), 2);
                $workedForDay = $worked;

                switch ($coverageSource) {
                    case 'half_day_off':
                        $summary['payable_hours'] += $scheduledHours;
                        $summary['vacation_hours'] += $covered;
                        break;

                    case 'half_sick_day':
                        $summary['payable_hours'] += $scheduledHours;
                        $summary['sick_hours'] += $covered;
                        break;

                    case 'time_in_lieu':
                        $summary['payable_hours'] += $scheduledHours;
                        break;

                    default:
                        if (isset($customLeaveKeys[$coverageSource])) {
                            $summary['payable_hours'] += $scheduledHours;
                            $summary['other_paid_leave_hours'] += $covered;
                        } else {
                            $summary['payable_hours'] += $worked;
                        }
                        break;
                }

                break;

            default:
                if (isset($customLeaveKeys[$type]) && $isScheduledWorkDay) {
                    $summary['payable_hours'] += $scheduledHours;
                    $summary['other_paid_leave_hours'] += $scheduledHours;
                }
                break;
        }

        if ($workedForDay > 0.0) {
            $summary['worked_days']++;
        }
    }

    /**
     * @return float|string
     */
    private function normalizePayrollSummaryValue(float $value): float|string
    {
        $rounded = round($value, 2);

        if ($rounded <= 0.0) {
            return '';
        }

        return $rounded;
    }

    /**
     * @param string[] $defaultWorkWeek
     * @param array<string, string> $holidayMap
     * @return array{label: string, kind: string}
     */
    private function getPayrollMatrixRowContext(string $date, array $holidayMap): array
    {
        $dayCode = gmdate('D', strtotime($date . ' UTC'));
        $label = $date . ' ' . $dayCode;

        if (isset($holidayMap[$date])) {
            return [
                'label' => $label . ' (Holiday)',
                'kind' => 'holiday',
            ];
        }

        return [
            'label' => $label,
            'kind' => 'working',
        ];
    }

    private function daysInMonth(int $year, int $month): int
    {
        $date = new \DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month), new \DateTimeZone('UTC'));

        return (int) $date->format('t');
    }
}
