<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Services;

use Timesuite\Core\Settings;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Timesheets\Contracts\TimesheetApprovalServiceInterface;
use Timesuite\Domain\Timesheets\Repositories\MonthlyTimesheetRepository;
use Timesuite\Services\Notifications\EmailNotifier;

/**
 * Handles timesheet approval workflow operations.
 */
class TimesheetApprovalService implements TimesheetApprovalServiceInterface
{
    private const IN_OFFICE_ALLOWED_DAY_TYPES = ['working_day', 'half_working', 'overtime'];
    private const USER_META_DAILY_HOURS_BY_DAY = 'timesuite_daily_hours_by_day';
    /** Must match MonthlyTimesheetService::META_PREFIX — see loadLegacyMonth(). */
    private const LEGACY_META_PREFIX = 'timesuite_month_';
    private const LEGACY_PART_DAY_SOURCE_MAP = [
        'comp_time' => 'time_in_lieu',
        'pto' => 'half_day_off',
        'unpaid' => 'half_day_off',
    ];
    public function __construct(
        private Settings $settings,
        private HolidayRangeService $holidayRangeService,
        private MonthlyTimesheetRepository $monthlyRepository,
        private ?EmailNotifier $emailNotifier = null
    ) {
    }

    /**
     * @inheritDoc
     */
    public function updateMonthStatus(
        int $userId,
        int $year,
        int $month,
        string $status,
        ?int $actorId = null,
        ?string $comment = null
    ): array {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $status = $this->normalizeMonthStatus($status);

        $data = $this->loadMonth($userId, $year, $month);
        $data['entries'] = isset($data['entries']) && is_array($data['entries']) ? $data['entries'] : [];

        $now = current_time('mysql', true);
        $data['status'] = $status;
        $data['updated_at'] = $now;
        $data['updated_by'] = $actorId ?: $userId;

        if ('submitted' === $status) {
            $data['submitted_at'] = $now;
            $data['submitted_by'] = $actorId ?: $userId;
            $data['approved_at'] = null;
            $data['approved_by'] = null;
            $data['denied_at'] = null;
            $data['denied_by'] = null;
            $data['denied_comment'] = null;
        }

        if ('approved' === $status || 'locked' === $status) {
            $data['approved_at'] = $now;
            $data['approved_by'] = $actorId ?: $userId;
            if ('locked' === $status && empty($data['submitted_at'])) {
                $data['submitted_at'] = $now;
                $data['submitted_by'] = $actorId ?: $userId;
            }
            $data['denied_at'] = null;
            $data['denied_by'] = null;
            $data['denied_comment'] = null;
        }

        if ('denied' === $status) {
            $data['denied_at'] = $now;
            $data['denied_by'] = $actorId ?: $userId;
            $data['denied_comment'] = $comment ? sanitize_textarea_field($comment) : null;
            $data['approved_at'] = null;
            $data['approved_by'] = null;
        }

        if ('draft' === $status) {
            $data['submitted_at'] = null;
            $data['submitted_by'] = null;
            $data['approved_at'] = null;
            $data['approved_by'] = null;
            $data['denied_at'] = null;
            $data['denied_by'] = null;
            $data['denied_comment'] = null;
            $data['approvals'] = [];
        }

        $this->persistMonth($userId, $year, $month, $data);

        if (in_array($status, ['approved', 'locked'], true)) {
            $this->sendApprovalNotification($userId, $year, $month, $actorId ?: $userId);
        } elseif ('denied' === $status) {
            $this->sendDenialNotification($userId, $year, $month, $actorId ?: $userId, $comment);
        }

        return $this->getMonthResult($userId, $year, $month);
    }

    /**
     * @inheritDoc
     */
    public function updateDayApproval(
        int $userId,
        int $year,
        int $month,
        string $date,
        string $status,
        int $actorId,
        ?string $comment = null
    ): array {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $days = $this->buildDaysList($year, $month);

        if (! isset($days[$date])) {
            throw new ValidationException(__('Invalid date supplied.', 'timesuite'));
        }

        $data = $this->loadMonth($userId, $year, $month);
        $currentStatus = $data['status'] ?? 'draft';

        if (! in_array($currentStatus, ['submitted', 'approved', 'denied'], true)) {
            throw new ValidationException(__('Timesheet must be submitted before approvals.', 'timesuite'));
        }

        if (! isset($data['entries'][$date]) || ! is_array($data['entries'][$date])) {
            throw new ValidationException(__('Timesheet entry not found.', 'timesuite'));
        }

        $entryType = (string) ($data['entries'][$date]['type'] ?? '');

        if (! $this->requiresApprovalForDate($date, $entryType, $this->getWorkWeekForUser($userId), $this->getHolidayMapForMonth($year, $month))) {
            throw new ValidationException(__('This day does not require approval.', 'timesuite'));
        }

        $approvals = isset($data['approvals']) && is_array($data['approvals']) ? $data['approvals'] : [];
        $now = current_time('mysql', true);

        $approvals[$date] = [
            'status' => $status,
            'by' => $actorId,
            'at' => $now,
            'comment' => $comment ? sanitize_textarea_field($comment) : null,
        ];

        $data['approvals'] = $approvals;
        $data['updated_at'] = $now;
        $data['updated_by'] = $actorId;
        $data = $this->applyOverallStatus($data, 'submitted', $actorId);

        $this->persistMonth($userId, $year, $month, $data);

        return $this->getMonthResult($userId, $year, $month);
    }

    /**
     * Reset approval status for a single day.
     *
     * @return array<string, mixed>
     */
    public function resetDayApproval(
        int $userId,
        int $year,
        int $month,
        string $date,
        int $actorId
    ): array {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $days = $this->buildDaysList($year, $month);

        if (! isset($days[$date])) {
            throw new ValidationException(__('Invalid date supplied.', 'timesuite'));
        }

        $data = $this->loadMonth($userId, $year, $month);
        $currentStatus = $data['status'] ?? 'draft';

        if (! in_array($currentStatus, ['submitted', 'approved', 'denied'], true)) {
            throw new ValidationException(__('Timesheet must be submitted before approvals.', 'timesuite'));
        }

        if (! isset($data['entries'][$date]) || ! is_array($data['entries'][$date])) {
            throw new ValidationException(__('Timesheet entry not found.', 'timesuite'));
        }

        $approvals = isset($data['approvals']) && is_array($data['approvals']) ? $data['approvals'] : [];
        unset($approvals[$date]);

        $data['approvals'] = $approvals;
        $data['updated_at'] = current_time('mysql', true);
        $data['updated_by'] = $actorId;
        $data = $this->applyOverallStatus($data, 'submitted', $actorId);

        $this->persistMonth($userId, $year, $month, $data);

        return $this->getMonthResult($userId, $year, $month);
    }

    /**
     * @inheritDoc
     */
    public function approveAllDays(int $userId, int $year, int $month, int $actorId): array
    {
        return $this->updateAllApprovals($userId, $year, $month, $actorId, 'approved');
    }

    /**
     * @inheritDoc
     */
    public function denyAllDays(int $userId, int $year, int $month, int $actorId, ?string $comment = null): array
    {
        return $this->updateAllApprovals($userId, $year, $month, $actorId, 'denied', $comment);
    }

    /**
     * @inheritDoc
     */
    public function resetAllApprovals(int $userId, int $year, int $month, int $actorId): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);

        $data = $this->loadMonth($userId, $year, $month);
        $currentStatus = $data['status'] ?? 'draft';

        if (! in_array($currentStatus, ['submitted', 'approved', 'denied'], true)) {
            throw new ValidationException(__('Timesheet must be submitted before approvals.', 'timesuite'));
        }

        $now = current_time('mysql', true);

        $data['approvals'] = [];
        $data['status'] = 'submitted';
        $data['updated_at'] = $now;
        $data['updated_by'] = $actorId;
        $data['approved_at'] = null;
        $data['approved_by'] = null;
        $data['denied_at'] = null;
        $data['denied_by'] = null;
        $data['denied_comment'] = null;

        $this->persistMonth($userId, $year, $month, $data);

        return $this->getMonthResult($userId, $year, $month);
    }

    /**
     * @return array<string, mixed>
     */
    private function updateAllApprovals(
        int $userId,
        int $year,
        int $month,
        int $actorId,
        string $status,
        ?string $comment = null
    ): array {
        [$year, $month] = $this->normalizeYearMonth($year, $month);

        $data = $this->loadMonth($userId, $year, $month);
        $currentStatus = $data['status'] ?? 'draft';

        if (! in_array($currentStatus, ['submitted', 'approved', 'denied'], true)) {
            throw new ValidationException(__('Timesheet must be submitted before approvals.', 'timesuite'));
        }

        $entries = isset($data['entries']) && is_array($data['entries']) ? $data['entries'] : [];
        $workWeek   = $this->getWorkWeekForUser($userId);
        $holidayMap = $this->getHolidayMapForMonth($year, $month);
        $targets = $this->collectApprovalTargets($entries, $workWeek, $holidayMap);
        $approvals = isset($data['approvals']) && is_array($data['approvals']) ? $data['approvals'] : [];
        $now = current_time('mysql', true);

        foreach ($targets as $date) {
            $approvals[$date] = [
                'status' => $status,
                'by' => $actorId,
                'at' => $now,
                'comment' => $comment,
            ];
        }

        $data['approvals'] = $approvals;
        $data['updated_at'] = $now;
        $data['updated_by'] = $actorId;

        $data = $this->applyOverallStatus($data, 'submitted', $actorId);

        $this->persistMonth($userId, $year, $month, $data);

        return $this->getMonthResult($userId, $year, $month);
    }

    /**
     * Finalize manager review after all approval-required days were reviewed.
     *
     * @return array<string, mixed>
     */
    public function finalizeReview(
        int $userId,
        int $year,
        int $month,
        int $actorId,
        ?string $comment = null
    ): array {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $data = $this->loadMonth($userId, $year, $month);
        $currentStatus = $data['status'] ?? 'draft';

        if ('locked' === $currentStatus) {
            return $this->getMonthResult($userId, $year, $month);
        }

        if (! in_array($currentStatus, ['submitted', 'approved', 'denied'], true)) {
            throw new ValidationException(__('Timesheet must be submitted before review can be finalized.', 'timesuite'));
        }

        $entries = isset($data['entries']) && is_array($data['entries']) ? $data['entries'] : [];
        $approvals = isset($data['approvals']) && is_array($data['approvals']) ? $data['approvals'] : [];
        $workWeek = $this->getWorkWeekForUser($userId);
        $holidayMap = $this->getHolidayMapForMonth($year, $month);
        $targets = $this->collectApprovalTargets($entries, $workWeek, $holidayMap);

        if (empty($targets)) {
            $data = $this->applyOverallStatus($data, 'locked', $actorId);
            $this->persistMonth($userId, $year, $month, $data);
            $this->sendApprovalNotification($userId, $year, $month, $actorId);

            return $this->getMonthResult($userId, $year, $month);
        }

        $hasDenied = false;
        $pending = [];
        $firstDeniedComment = null;

        foreach ($targets as $date) {
            $status = $this->resolveApprovalStatus($approvals, $date);

            if ($status === null) {
                $pending[] = $date;
                continue;
            }

            if ($status === 'denied') {
                $hasDenied = true;

                if ($firstDeniedComment === null && isset($approvals[$date]['comment']) && is_string($approvals[$date]['comment'])) {
                    $candidate = trim((string) $approvals[$date]['comment']);
                    if ($candidate !== '') {
                        $firstDeniedComment = $candidate;
                    }
                }
            }
        }

        if (! empty($pending)) {
            throw new ValidationException(
                __('Please review all approval-required days before submitting the manager review.', 'timesuite')
            );
        }

        if ($hasDenied) {
            $reason = trim((string) ($comment ?? ''));

            if ($reason === '') {
                $reason = $firstDeniedComment ?: __('Manager requested changes.', 'timesuite');
            }

            $data = $this->applyOverallStatus($data, 'denied', $actorId);
            $data['denied_comment'] = sanitize_textarea_field($reason);
            $this->persistMonth($userId, $year, $month, $data);
            $this->sendDenialNotification($userId, $year, $month, $actorId, $reason);

            return $this->getMonthResult($userId, $year, $month);
        }

        $data = $this->applyOverallStatus($data, 'locked', $actorId);
        $this->persistMonth($userId, $year, $month, $data);
        $this->sendApprovalNotification($userId, $year, $month, $actorId);

        return $this->getMonthResult($userId, $year, $month);
    }

    /**
     * @return array{0:int,1:int}
     */
    private function normalizeYearMonth(int $year, int $month): array
    {
        if ($year < 2000 || $year > 2100) {
            throw new ValidationException(__('Year out of supported range.', 'timesuite'));
        }

        if ($month < 1 || $month > 12) {
            throw new ValidationException(__('Month must be between 1 and 12.', 'timesuite'));
        }

        return [$year, $month];
    }

    /**
     * @return array<string, array{label: string}>
     */
    private function buildDaysList(int $year, int $month): array
    {
        $daysInMonth = $this->daysInMonth($year, $month);
        $list        = [];

        for ($day = 1; $day <= $daysInMonth; ++$day) {
            $date  = sprintf('%04d-%02d-%02d', $year, $month, $day);
            $label = wp_date('D, M j', strtotime($date . ' UTC'));
            $list[$date] = ['label' => $label];
        }

        return $list;
    }

    /**
     * @return string[]
     */
    public function getWorkWeekForUser(int $userId): array
    {
        $stored = get_user_meta($userId, 'timesuite_work_week', true);
        $stored = Settings::normalizeWorkWeekDays($stored);

        if (! empty($stored)) {
            return $stored;
        }

        return Settings::normalizeWorkWeekDays($this->settings->getWorkWeek());
    }

    private function resolveScheduledHoursForDate(int $userId, string $date, array $storedEntry = []): float
    {
        if (isset($storedEntry['scheduled_hours']) && is_numeric($storedEntry['scheduled_hours'])) {
            $stored = round((float) $storedEntry['scheduled_hours'], 2);

            if ($stored > 0) {
                return $stored;
            }
        }

        return $this->getDailyHoursForUserDate($userId, $date);
    }

    private function getDailyHoursForUserDate(int $userId, string $date): float
    {
        $dayCode = gmdate('D', strtotime($date . ' UTC'));
        $default = round($this->settings->getDailyHours(), 2);
        $stored = get_user_meta($userId, self::USER_META_DAILY_HOURS_BY_DAY, true);

        if (! is_array($stored)) {
            return $default;
        }

        $hours = $stored[$dayCode] ?? null;

        if (! is_numeric($hours)) {
            return $default;
        }

        $resolved = round((float) $hours, 2);

        if ($resolved < 1 || $resolved > 24) {
            return $default;
        }

        return $resolved;
    }

    /**
     * @return array<string, string> Map of Y-m-d => holiday type.
     */
    public function getHolidayMapForMonth(int $year, int $month): array
    {
        $daysInMonth = $this->daysInMonth($year, $month);
        $startDate = sprintf('%04d-%02d-01', $year, $month);
        $endDate = sprintf('%04d-%02d-%02d', $year, $month, $daysInMonth);

        return $this->holidayRangeService->getHolidayMapForRange($startDate, $endDate);
    }

    /**
     * @param array<string, string> $holidayMap
     */
    private function isWorkingDay(string $date, array $workWeek, array $holidayMap): bool
    {
        if (isset($holidayMap[$date])) {
            return false;
        }

        $dayCode = gmdate('D', strtotime($date . ' UTC'));

        return in_array($dayCode, $workWeek, true);
    }

    /**
     * @param array<string, string> $holidayMap
     */
    public function requiresApprovalForDate(string $date, string $type, array $workWeek, array $holidayMap): bool
    {
        if (isset($holidayMap[$date])) {
            $defaultType = $holidayMap[$date] === 'half_holiday' ? 'half_holiday' : 'holiday';

            return $type !== $defaultType;
        }

        if ($type === 'working_day' || $type === 'holiday' || $type === 'half_holiday' || $type === 'not_employed') {
            return false;
        }

        if ($type === 'day_off' && ! $this->isWorkingDay($date, $workWeek, $holidayMap)) {
            return false;
        }

        return true;
    }

    /**
     * @param array<string, array<string, mixed>> $entries
     *
     * @return string[]
     */
    private function collectApprovalTargets(array $entries, array $workWeek, array $holidayMap): array
    {
        $targets = [];

        foreach ($entries as $date => $entry) {
            $type = isset($entry['type']) ? (string) $entry['type'] : '';

            if ($this->requiresApprovalForDate($date, $type, $workWeek, $holidayMap)) {
                $targets[] = $date;
            }
        }

        return $targets;
    }

    /**
     * @param array<string, mixed> $approvals
     */
    private function resolveApprovalStatus(array $approvals, string $date): ?string
    {
        if (! isset($approvals[$date]) || ! is_array($approvals[$date])) {
            return null;
        }

        $status = $approvals[$date]['status'] ?? null;

        if (! is_string($status)) {
            return null;
        }

        $status = strtolower($status);

        if (! in_array($status, ['approved', 'denied'], true)) {
            return null;
        }

        return $status;
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    private function recalculateApprovalStatus(array $data, int $actorId, array $workWeek, array $holidayMap): array
    {
        $entries = isset($data['entries']) && is_array($data['entries']) ? $data['entries'] : [];
        $approvals = isset($data['approvals']) && is_array($data['approvals']) ? $data['approvals'] : [];
        $targets = $this->collectApprovalTargets($entries, $workWeek, $holidayMap);
        $hasDenied = false;
        $approvedCount = 0;

        foreach ($targets as $date) {
            $status = $this->resolveApprovalStatus($approvals, $date);

            if ('denied' === $status) {
                $hasDenied = true;
                break;
            }

            if ('approved' === $status) {
                $approvedCount++;
            }
        }

        if ($hasDenied) {
            return $this->applyOverallStatus($data, 'denied', $actorId);
        }

        if (! empty($targets) && $approvedCount === count($targets)) {
            return $this->applyOverallStatus($data, 'locked', $actorId);
        }

        return $this->applyOverallStatus($data, 'submitted', $actorId);
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    private function applyOverallStatus(array $data, string $status, int $actorId): array
    {
        $now = current_time('mysql', true);
        $status = $this->normalizeMonthStatus($status);

        $data['status'] = $status;
        $data['updated_at'] = $now;
        $data['updated_by'] = $actorId;

        if ('approved' === $status || 'locked' === $status) {
            $data['approved_at'] = $now;
            $data['approved_by'] = $actorId;
            if ('locked' === $status && empty($data['submitted_at'])) {
                $data['submitted_at'] = $now;
                $data['submitted_by'] = $actorId;
            }
            $data['denied_at'] = null;
            $data['denied_by'] = null;
            $data['denied_comment'] = null;
        } elseif ('denied' === $status) {
            $data['denied_at'] = $now;
            $data['denied_by'] = $actorId;
            $data['approved_at'] = null;
            $data['approved_by'] = null;
        } elseif ('submitted' === $status) {
            if (empty($data['submitted_at'])) {
                $data['submitted_at'] = $now;
                $data['submitted_by'] = $actorId;
            }
            $data['approved_at'] = null;
            $data['approved_by'] = null;
            $data['denied_at'] = null;
            $data['denied_by'] = null;
            $data['denied_comment'] = null;
        } elseif ('draft' === $status) {
            $data['submitted_at'] = null;
            $data['submitted_by'] = null;
            $data['approved_at'] = null;
            $data['approved_by'] = null;
            $data['denied_at'] = null;
            $data['denied_by'] = null;
            $data['denied_comment'] = null;
        }

        return $data;
    }

    private function normalizeMonthStatus(string $status): string
    {
        $normalized = strtolower(trim($status));

        return match ($normalized) {
            'draft', 'submitted', 'approved', 'denied', 'locked' => $normalized,
            default => 'draft',
        };
    }

    /**
     * IMPORTANT — legacy-data safety:
     *
     * This must mirror the legacy-user-meta fallback in
     * MonthlyTimesheetService::loadMonth(). A month that predates the
     * wp_timesuite_monthly_timesheets table only exists as WordPress
     * user-meta ('timesuite_month_YYYY_MM'); until something reads it once
     * through that fallback (which materializes it into the new table), the
     * new table has no row for it.
     *
     * Before this fallback was added here, EVERY write path in this class
     * (approve, deny, undo-submit, reset, finalize) called this loader
     * directly, saw "no row", and treated the month as a brand-new empty
     * draft — then persisted that empty draft, permanently overwriting the
     * real (possibly submitted/locked) legacy history the first time any
     * approval action touched a legacy-only month. That is a live
     * data-corruption path, not just a stale-read/display bug: it explains
     * how a month an employee genuinely submitted could end up canonically
     * 'draft' after an otherwise-unrelated manager/HR action ran first.
     *
     * Keep this branch in sync with MonthlyTimesheetService::loadLegacyMonth()
     * / loadMonth() if either changes. See docs/timesheet-status-investigation.md.
     *
     * @return array<string, mixed>
     */
    private function loadMonth(int $userId, int $year, int $month): array
    {
        $header = $this->monthlyRepository->getHeader($userId, $year, $month);

        if ($header) {
            $entries = $this->monthlyRepository->getEntries((int) $header['id']);

            return $this->hydrateMonth($header, $entries);
        }

        $legacy = $this->loadLegacyMonth($userId, $year, $month);

        if ($legacy) {
            // Materialize into the new table now, same as the primary
            // service does, so it becomes canonical for every future reader.
            $this->persistMonth($userId, $year, $month, $legacy);

            return $legacy;
        }

        return [
            'entries' => [],
            'approvals' => [],
            'status'  => 'draft',
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    private function loadLegacyMonth(int $userId, int $year, int $month): ?array
    {
        $data = get_user_meta($userId, self::LEGACY_META_PREFIX . sprintf('%04d_%02d', $year, $month), true);

        if (! is_array($data)) {
            return null;
        }

        if (! isset($data['entries']) || ! is_array($data['entries'])) {
            $data['entries'] = [];
        }

        if (! isset($data['approvals']) || ! is_array($data['approvals'])) {
            $data['approvals'] = [];
        }

        return $data;
    }

    /**
     * @param array<string, mixed> $data
     */
    private function persistMonth(int $userId, int $year, int $month, array $data): void
    {
        $header = $this->normalizeHeader($data);
        $entries = isset($data['entries']) && is_array($data['entries']) ? $data['entries'] : [];
        $approvals = isset($data['approvals']) && is_array($data['approvals']) ? $data['approvals'] : [];

        $timesheetId = $this->monthlyRepository->upsertHeader($userId, $year, $month, $header);
        $this->monthlyRepository->upsertEntries($timesheetId, $userId, $entries, $approvals);
    }

    /**
     * @param array<string, mixed> $header
     * @param array<int, array<string, mixed>> $entryRows
     *
     * @return array<string, mixed>
     */
    private function hydrateMonth(array $header, array $entryRows): array
    {
        $data = $this->normalizeHeader($header);
        $entries = [];
        $approvals = [];

        foreach ($entryRows as $row) {
            $date = (string) ($row['work_date'] ?? '');

            if ('' === $date) {
                continue;
            }

            $hours = $row['hours'] ?? null;
            $entries[$date] = [
                'type' => (string) ($row['type'] ?? 'working_day'),
                'notes' => (string) ($row['notes'] ?? ''),
                'hours' => $hours === null ? null : (float) $hours,
                'scheduled_hours' => isset($row['scheduled_hours']) && $row['scheduled_hours'] !== null
                    ? (float) $row['scheduled_hours']
                    : null,
                'coverage_source' => $row['coverage_source'] ?? null,
                'in_office' => ! empty($row['in_office']),
            ];

            if (! empty($row['approval_status'])) {
                $approvals[$date] = [
                    'status' => (string) $row['approval_status'],
                    'by' => isset($row['approval_by']) ? (int) $row['approval_by'] : null,
                    'at' => $row['approval_at'] ?? null,
                    'comment' => $row['approval_comment'] ?? null,
                ];
            }
        }

        $data['entries'] = $entries;
        $data['approvals'] = $approvals;

        if (! isset($data['status'])) {
            $data['status'] = 'draft';
        }

        return $data;
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    private function normalizeHeader(array $data): array
    {
        $keys = [
            'status',
            'updated_at',
            'updated_by',
            'submitted_at',
            'submitted_by',
            'approved_at',
            'approved_by',
            'denied_at',
            'denied_by',
            'denied_comment',
            'created_at',
        ];

        $normalized = [];

        foreach ($keys as $key) {
            if (array_key_exists($key, $data)) {
                $normalized[$key] = $data[$key];
            }
        }

        return $normalized;
    }

    /**
     * Build and return the full month result.
     * This is a simplified version - the full result would typically come from MonthlyTimesheetService.
     *
     * @return array<string, mixed>
     */
    private function getMonthResult(int $userId, int $year, int $month): array
    {
        $data = $this->loadMonth($userId, $year, $month);
        $days = $this->buildDaysList($year, $month);
        $entries = [];
        $workWeek = $this->getWorkWeekForUser($userId);
        $holidayMap = $this->getHolidayMapForMonth($year, $month);
        $approvals = isset($data['approvals']) && is_array($data['approvals']) ? $data['approvals'] : [];

        foreach ($days as $date => $info) {
            $defaultType = $this->defaultTypeForDate($date, $workWeek, $holidayMap);
            $storedOffice = $data['entries'][$date]['in_office'] ?? null;
            $storedEntry = isset($data['entries'][$date]) && is_array($data['entries'][$date])
                ? $data['entries'][$date]
                : [];
            $entryType = $storedEntry['type'] ?? $defaultType;
            if (! isset($holidayMap[$date]) && in_array($entryType, ['holiday', 'half_holiday'], true)) {
                $entryType = $defaultType;
            }
            $needsApproval = $this->requiresApprovalForDate($date, $entryType, $workWeek, $holidayMap);
            $approvalStatus = $needsApproval ? $this->resolveApprovalStatus($approvals, $date) : null;
            $scheduledHours = $this->resolveScheduledHoursForDate($userId, $date, $storedEntry);
            $entryHours = $storedEntry['hours'] ?? null;
            if (($entryType === 'half_working' || $entryType === 'half_holiday') && $entryHours === null) {
                $entryHours = $this->normalizeHalfDayHours($scheduledHours);
            }
            $coverageSource = $this->normalizeCoverageSource($storedEntry['coverage_source'] ?? null);
            $entries[] = [
                'date'  => $date,
                'label' => $info['label'],
                'type'  => $entryType,
                'notes' => $storedEntry['notes'] ?? '',
                'hours' => $entryHours,
                'scheduled_hours' => $scheduledHours,
                'coverage_source' => $coverageSource,
                'in_office' => $this->typeSupportsInOffice($entryType)
                    ? $this->normalizeInOffice($storedOffice)
                    : false,
                'approval_status' => $approvalStatus,
                'needs_approval' => $needsApproval,
            ];
        }

        return [
            'user_id'    => $userId,
            'year'       => $year,
            'month'      => $month,
            'days_count' => count($days),
            'entries'    => $entries,
            'status'     => $data['status'] ?? 'draft',
            'updated_at' => $data['updated_at'] ?? null,
            'submitted_at' => $data['submitted_at'] ?? null,
            'approved_at' => $data['approved_at'] ?? null,
            'denied_at' => $data['denied_at'] ?? null,
            'denied_comment' => $data['denied_comment'] ?? null,
        ];
    }

    /**
     * @param array<string, string> $holidayMap
     */
    private function defaultTypeForDate(string $date, array $workWeek, array $holidayMap): string
    {
        if (! $this->isWorkingDay($date, $workWeek, $holidayMap)) {
            if (isset($holidayMap[$date])) {
                return $holidayMap[$date] === 'half_holiday' ? 'half_holiday' : 'holiday';
            }

            return 'day_off';
        }

        return 'working_day';
    }

    private function normalizeInOffice(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return (int) $value === 1;
        }

        if (is_string($value)) {
            $normalized = strtolower(trim($value));

            return in_array($normalized, ['1', 'true', 'yes', 'on'], true);
        }

        return false;
    }

    private function typeSupportsInOffice(string $type): bool
    {
        return in_array($type, self::IN_OFFICE_ALLOWED_DAY_TYPES, true);
    }

    private function normalizeCoverageSource(mixed $value): ?string
    {
        if (! is_string($value) || '' === trim($value)) {
            return null;
        }

        $value = sanitize_key($value);

        if (isset(self::LEGACY_PART_DAY_SOURCE_MAP[$value])) {
            $value = self::LEGACY_PART_DAY_SOURCE_MAP[$value];
        }

        if (! array_key_exists($value, $this->getPartDaySources())) {
            return null;
        }

        return $value;
    }

    /**
     * @return array<string, string>
     */
    private function getPartDaySources(): array
    {
        return array_merge($this->getBuiltInPartDaySources(), $this->getCustomLeaveTypeMap());
    }

    /**
     * @return array<string, string>
     */
    private function getBuiltInPartDaySources(): array
    {
        return [
            'half_day_off'  => __('Half day off', 'timesuite'),
            'half_sick_day' => __('Half sick day', 'timesuite'),
            'time_in_lieu'  => __('Time in lieu', 'timesuite'),
        ];
    }

    /**
     * @return array<string, string>
     */
    private function getCustomLeaveTypeMap(): array
    {
        $types = [];

        foreach ($this->settings->getCustomLeaveTypes() as $item) {
            $key = isset($item['key']) ? sanitize_key((string) $item['key']) : '';
            $label = isset($item['label']) ? sanitize_text_field((string) $item['label']) : '';

            if ($key === '' || $label === '') {
                continue;
            }

            $types[$key] = $label;
        }

        return $types;
    }

    private function normalizeHalfDayHours(float $dailyHours): float
    {
        return round($dailyHours / 2, 2);
    }

    private function daysInMonth(int $year, int $month): int
    {
        $date = new \DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month), new \DateTimeZone('UTC'));

        return (int) $date->format('t');
    }

    /**
     * Send approval notification to the employee.
     */
    private function sendApprovalNotification(int $userId, int $year, int $month, int $actorId): void
    {
        if (! $this->emailNotifier) {
            return;
        }

        if (! $this->settings->shouldNotifyOnApprove()) {
            return;
        }

        try {
            $this->emailNotifier->notifyApproval($userId, $actorId, $year, $month);
        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Timesuite: Failed to send approval notification: ' . $e->getMessage());
            }
        }
    }

    /**
     * Send denial notification to the employee.
     */
    private function sendDenialNotification(int $userId, int $year, int $month, int $actorId, ?string $comment = null): void
    {
        if (! $this->emailNotifier) {
            return;
        }

        if (! $this->settings->shouldNotifyOnDeny()) {
            return;
        }

        try {
            $this->emailNotifier->notifyDenial($userId, $actorId, $year, $month, $comment ?? '');
        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Timesuite: Failed to send denial notification: ' . $e->getMessage());
            }
        }
    }
}
