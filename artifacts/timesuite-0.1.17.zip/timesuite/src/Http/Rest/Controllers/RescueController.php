<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use Timesuite\Domain\Timesheets\Repositories\ReeditRequestRepository;
use Timesuite\Domain\Timesheets\Services\MonthlyTimesheetService;
use Timesuite\Http\Rest\AbstractRestController;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * REST controller for admin "rescue" actions (P3.1) -- a safe, audited,
 * HR/Tech-Admin-only set of manual repair actions for a single stuck
 * employee/month. See docs/p3.1-admin-rescue-actions-plan.md.
 *
 * Every action is gated by hasOrgManagementPowers() (held by both HR and
 * Tech-Admin, and by SuperAccess -- see AuthorizationService::userHasCapability())
 * -- deliberately NOT scoped to a manager relationship the way Manager View
 * is; rescue is an org-wide tool. Do not gate on timesuite.system.view --
 * that is Tech-Admin-only and would exclude HR. See §0 of the plan.
 *
 * Every action that changes status delegates to a dedicated
 * MonthlyTimesheetService rescue method (rescueSubmitOnBehalf,
 * rescueForceLock, reopenMonthToDraft, recalculateMonthStatus) -- never to
 * the shallow updateMonthStatus(), which does not maintain the comp-time
 * (Time-in-Lieu) ledger invariant. See §1.1 of the plan.
 */
class RescueController extends AbstractRestController
{
    public function __construct(
        private MonthlyTimesheetService $service,
        private AuthorizationService $authService,
        private ReeditRequestRepository $reeditRequestRepository,
        private ApprovalLogRepository $approvalLogRepository
    ) {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/rescue/diagnose',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'diagnose'],
                'permission_callback' => [$this, 'checkRescuePermission'],
                'args'                => $this->rescueArgs(),
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/rescue/submit-on-behalf',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'submitOnBehalf'],
                'permission_callback' => [$this, 'checkRescuePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/rescue/force-lock',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'forceLock'],
                'permission_callback' => [$this, 'checkRescuePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/rescue/reopen-draft',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'reopenDraft'],
                'permission_callback' => [$this, 'checkRescuePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/rescue/unlock',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'unlock'],
                'permission_callback' => [$this, 'checkRescuePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/rescue/recalculate',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'recalculate'],
                'permission_callback' => [$this, 'checkRescuePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/rescue/clear-reedit-request',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'clearReeditRequest'],
                'permission_callback' => [$this, 'checkRescuePermission'],
            ]
        );
    }

    /**
     * Read-only diagnosis (§3.1 of the plan) -- no writes, no nonce check
     * (same convention as the other READABLE routes in this plugin, e.g.
     * TimesheetApprovalController::listApprovals()).
     */
    public function diagnose(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        $diagnosis = $this->service->diagnoseMonth($targetUser, $year, $month);
        $pending = $this->reeditRequestRepository->getPendingForMonth($targetUser, $year, $month);

        $diagnosis['user_id'] = $targetUser;
        $diagnosis['year'] = $year;
        $diagnosis['month'] = $month;
        $diagnosis['pending_reedit_request'] = $pending ? [
            'id' => (int) ($pending['id'] ?? 0),
            'requested_at' => $pending['requested_at'] ?? null,
        ] : null;
        $diagnosis['recommended_action'] = $this->recommendAction($diagnosis, $pending !== null);

        return new WP_REST_Response($diagnosis, 200);
    }

    public function submitOnBehalf(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $from  = 'draft';
        $to    = 'draft';

        try {
            $meta = $this->service->getMonthMeta($targetUser, $year, $month);
            $from = (string) ($meta['status'] ?? 'draft');

            if (! in_array($from, ['draft', 'denied'], true)) {
                return $this->validationError($this->submitOnBehalfUnavailableMessage($from));
            }

            // Reuses the comp-time-aware rescue method -- NOT updateMonthStatus().
            $result = $this->service->rescueSubmitOnBehalf($targetUser, $year, $month, $currentUser);
            $to = (string) ($result['to'] ?? 'submitted');
        } catch (ValidationException $e) {
            // e.g. "Not enough comp time balance…" from an unfunded time-in-lieu day.
            return $this->validationError($e);
        }

        $this->logRescue('rescue_submit_on_behalf', $targetUser, $currentUser, $year, $month, $from, $to);

        return new WP_REST_Response(
            [
                'ok' => true,
                'action' => 'submit_on_behalf',
                'changed' => true,
                'timesheet' => ['user_id' => $targetUser, 'year' => $year, 'month' => $month, 'status' => $to],
            ],
            200
        );
    }

    public function forceLock(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $from  = 'draft';

        try {
            $meta = $this->service->getMonthMeta($targetUser, $year, $month);
            $from = (string) ($meta['status'] ?? 'draft');

            if ('locked' === $from) {
                return $this->validationError($this->forceLockUnavailableMessage($from));
            }

            // Reuses the comp-time-aware rescue method -- NOT updateMonthStatus().
            $this->service->rescueForceLock($targetUser, $year, $month, $currentUser);
        } catch (ValidationException $e) {
            return $this->validationError($e);
        }

        $this->logRescue('rescue_force_lock', $targetUser, $currentUser, $year, $month, $from, 'locked');

        return new WP_REST_Response(
            [
                'ok' => true,
                'action' => 'force_lock',
                'changed' => true,
                'timesheet' => ['user_id' => $targetUser, 'year' => $year, 'month' => $month, 'status' => 'locked'],
            ],
            200
        );
    }

    public function reopenDraft(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $from  = 'draft';

        try {
            $meta = $this->service->getMonthMeta($targetUser, $year, $month);
            $from = (string) ($meta['status'] ?? 'draft');

            if (! in_array($from, ['submitted', 'denied'], true)) {
                return $this->validationError($this->reopenDraftUnavailableMessage($from));
            }

            $this->service->reopenMonthToDraft($targetUser, $year, $month, $currentUser);
        } catch (ValidationException $e) {
            return $this->validationError($e);
        }

        $this->logRescue('rescue_reopen_draft', $targetUser, $currentUser, $year, $month, $from, 'draft');

        return new WP_REST_Response(
            [
                'ok' => true,
                'action' => 'reopen_draft',
                'changed' => true,
                'timesheet' => ['user_id' => $targetUser, 'year' => $year, 'month' => $month, 'status' => 'draft'],
            ],
            200
        );
    }

    public function unlock(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $meta = $this->service->getMonthMeta($targetUser, $year, $month);
            $from = (string) ($meta['status'] ?? 'draft');

            if ('locked' !== $from) {
                return $this->validationError($this->unlockUnavailableMessage($from));
            }

            $this->service->reopenLockedMonth($targetUser, $year, $month, $currentUser);
        } catch (ValidationException $e) {
            return $this->validationError($e);
        }

        $this->logRescue('rescue_unlock', $targetUser, $currentUser, $year, $month, 'locked', 'draft');

        return new WP_REST_Response(
            [
                'ok' => true,
                'action' => 'unlock',
                'changed' => true,
                'timesheet' => ['user_id' => $targetUser, 'year' => $year, 'month' => $month, 'status' => 'draft'],
            ],
            200
        );
    }

    public function recalculate(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $result = $this->service->recalculateMonthStatus($targetUser, $year, $month, $currentUser);
        } catch (ValidationException $e) {
            return $this->validationError($e);
        }

        $changed = (bool) ($result['changed'] ?? false);

        if ($changed) {
            $this->logRescue(
                'rescue_recalculate',
                $targetUser,
                $currentUser,
                $year,
                $month,
                (string) ($result['from'] ?? 'submitted'),
                (string) ($result['to'] ?? 'locked')
            );
        }

        return new WP_REST_Response(
            [
                'ok' => true,
                'action' => 'recalculate',
                'changed' => $changed,
                'timesheet' => [
                    'user_id' => $targetUser,
                    'year' => $year,
                    'month' => $month,
                    'status' => (string) ($result['to'] ?? 'submitted'),
                ],
            ],
            200
        );
    }

    public function clearReeditRequest(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        $pending = $this->reeditRequestRepository->getPendingForMonth($targetUser, $year, $month);

        if (! $pending) {
            return new WP_REST_Response(
                [
                    'ok' => true,
                    'action' => 'clear_reedit_request',
                    'changed' => false,
                    'message' => __('There is no pending re-edit request for this employee/month. Nothing was changed.', 'timesuite'),
                ],
                200
            );
        }

        $requestId = (int) ($pending['id'] ?? 0);
        $cancelled = $this->reeditRequestRepository->cancelPending($requestId, $currentUser);

        if ($cancelled) {
            $this->approvalLogRepository->log(
                'rescue_reedit_cleared',
                $targetUser,
                $currentUser,
                ['year' => $year, 'month' => $month, 'request_id' => $requestId, 'source' => 'rescue']
            );
        }

        return new WP_REST_Response(
            ['ok' => true, 'action' => 'clear_reedit_request', 'changed' => $cancelled, 'request_id' => $requestId],
            200
        );
    }

    /**
     * Permission callback shared by every rescue route (§0 of the plan):
     * HR and Tech-Admin both hold at least one of settings.manage /
     * period.lock / org.edit, so hasOrgManagementPowers() admits both (and
     * SuperAccess). A plain Manager holds none of these three and is
     * correctly excluded -- rescue is deliberately not manager-level.
     *
     * @return bool|WP_Error
     */
    public function checkRescuePermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to use rescue actions.', 'timesuite'),
                ['status' => 401]
            );
        }

        if ($this->authService->hasOrgManagementPowers(get_current_user_id())) {
            return true;
        }

        return new WP_Error(
            'timesuite_forbidden',
            __('You do not have permission to use rescue actions.', 'timesuite'),
            ['status' => 403]
        );
    }

    private function resolveTargetUserId(WP_REST_Request $request): WP_Error|int
    {
        $userId = $request->get_param('user_id');
        $target = $userId ? (int) $userId : 0;

        if ($target <= 0) {
            return $this->validationError(__('Unknown target user.', 'timesuite'));
        }

        $user = get_user_by('id', $target);

        if (! $user) {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        return $target;
    }

    private function logRescue(
        string $action,
        int $targetUser,
        int $actorId,
        int $year,
        int $month,
        string $previousStatus,
        string $newStatus
    ): void {
        $this->approvalLogRepository->log($action, $targetUser, $actorId, [
            'year' => $year,
            'month' => $month,
            'previous_status' => $previousStatus,
            'new_status' => $newStatus,
            'source' => 'rescue',
        ]);
    }

    private function submitOnBehalfUnavailableMessage(string $status): string
    {
        if ('locked' === $status) {
            return __('This month is currently Locked. Use Unlock if the employee needs to edit it, or no rescue action is needed if the month is final.', 'timesuite');
        }

        if ('submitted' === $status) {
            return __('This month is already Submitted. Use Recalculate Status if it should have auto-locked, or continue with normal manager review.', 'timesuite');
        }

        return sprintf(
            __('This month is currently %s. Submit on Behalf is only for Draft or Denied months.', 'timesuite'),
            $this->statusLabel($status)
        );
    }

    private function forceLockUnavailableMessage(string $status): string
    {
        if ('locked' === $status) {
            return __('This month is already Locked. No rescue action is needed.', 'timesuite');
        }

        return sprintf(
            __('This month is currently %s. Force Lock can only be used when the month is not already locked.', 'timesuite'),
            $this->statusLabel($status)
        );
    }

    private function reopenDraftUnavailableMessage(string $status): string
    {
        if ('locked' === $status) {
            return __('This month is currently Locked. Use Unlock to return it to Draft.', 'timesuite');
        }

        if ('draft' === $status || '' === $status) {
            return __('This month is already Draft. No reopen action is needed.', 'timesuite');
        }

        return sprintf(
            __('This month is currently %s. Reopen to Draft is only for Submitted or Denied months.', 'timesuite'),
            $this->statusLabel($status)
        );
    }

    private function unlockUnavailableMessage(string $status): string
    {
        if ('draft' === $status || '' === $status) {
            return __('This month is already Draft. No unlock action is needed.', 'timesuite');
        }

        if ('submitted' === $status) {
            return __('This month is currently Submitted. Use Reopen to Draft if you need to return it to the employee, or continue with normal manager review.', 'timesuite');
        }

        if ('denied' === $status) {
            return __('This month is currently Denied. Use Reopen to Draft if the employee needs to correct it.', 'timesuite');
        }

        return sprintf(
            __('This month is currently %s. Unlock is only for Locked months.', 'timesuite'),
            $this->statusLabel($status)
        );
    }

    private function statusLabel(string $status): string
    {
        return match ($status) {
            'submitted' => __('Submitted', 'timesuite'),
            'approved' => __('Approved', 'timesuite'),
            'denied' => __('Denied', 'timesuite'),
            'locked' => __('Locked', 'timesuite'),
            'draft', '' => __('Draft', 'timesuite'),
            'not_started' => __('Not started', 'timesuite'),
            default => ucwords(str_replace('_', ' ', $status)),
        };
    }

    /**
     * @param array<string, mixed> $diagnosis
     */
    private function recommendAction(array $diagnosis, bool $hasPendingReedit): ?string
    {
        // A cross-layer mismatch means the canonical row's own status (and
        // therefore its entries) may not be trustworthy -- every other
        // heuristic below assumes the canonical data is correct and just
        // needs a status/ledger nudge, which is the wrong thing to
        // recommend here. None of the six rescue actions touch entry data
        // (see the plan's §6 "explicitly out of scope"), so there is no
        // one-click fix for this case; surface it for manual investigation
        // instead of silently recommending nothing. See
        // docs/timesheet-status-investigation.md §5 for the kind of
        // read-only check this actually requires.
        if (! empty($diagnosis['cross_layer_mismatch'])) {
            return 'manual_review';
        }

        if (! empty($diagnosis['should_have_auto_locked'])) {
            return 'recalculate';
        }

        if (empty($diagnosis['comptime_consistent'])) {
            return 'recalculate';
        }

        if ($hasPendingReedit && 'locked' !== ($diagnosis['status'] ?? '')) {
            return 'clear_reedit_request';
        }

        return null;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function rescueArgs(): array
    {
        return [
            'year' => [
                'required'          => true,
                'validate_callback' => static fn ($value): bool => (int) $value >= 2000,
            ],
            'month' => [
                'required'          => true,
                'validate_callback' => static fn ($value): bool => (int) $value >= 1 && (int) $value <= 12,
            ],
        ];
    }
}
