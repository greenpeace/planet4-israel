<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class CreateCompTimeLedger extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_02_000009';
    }

    public function up(wpdb $wpdb): void
    {
        $tableName = $wpdb->prefix . 'timesuite_comp_time_ledger';
        $collation = $wpdb->get_charset_collate() ?: $this->getDefaultCollation();

        $sql = "CREATE TABLE {$tableName} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            direction varchar(12) NOT NULL,
            minutes int NOT NULL,
            source_type varchar(32) NOT NULL,
            source_key varchar(64) DEFAULT NULL,
            work_date date DEFAULT NULL,
            expires_on date DEFAULT NULL,
            notes text DEFAULT NULL,
            created_at datetime NOT NULL,
            created_by bigint(20) unsigned DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY user_source (user_id, source_type, source_key, direction),
            KEY user_id (user_id),
            KEY expires_on (expires_on)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($sql);
    }
}
