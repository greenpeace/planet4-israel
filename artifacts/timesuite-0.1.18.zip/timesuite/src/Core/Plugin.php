<?php

declare(strict_types=1);

namespace Timesuite\Core;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Core\Access\BootstrapService;
use Timesuite\Core\Access\CapabilityGrant;
use Timesuite\Core\Access\RoleAssignmentService;
use Timesuite\Core\DB\MigrationsRunner;
use Timesuite\Core\Monitoring\ProductionAlertMonitor;
use Timesuite\Core\Monitoring\DiagnosticsService;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use Timesuite\Domain\Timesheets\Repositories\MonthlyTimesheetRepository;
use Timesuite\Domain\Timesheets\Services\CompTimeService;
use Timesuite\Domain\Timesheets\Services\DayStateService;
use Timesuite\Domain\Timesheets\Services\LegacyMonthBackfillService;
use Timesuite\Domain\Timesheets\Services\TimesheetApprovalService;
use Timesuite\Domain\Timesheets\Services\VacationService;
use Timesuite\Http\Admin\Menu;
use Timesuite\Domain\Reports\ExcelExportService;
use Timesuite\Domain\Reports\TimesheetReportService;
use Timesuite\Http\Rest\Controllers\AuditController;
use Timesuite\Http\Rest\Controllers\BootstrapController;
use Timesuite\Http\Rest\Controllers\DashboardController;
use Timesuite\Http\Rest\Controllers\DirectoryController;
use Timesuite\Http\Rest\Controllers\ExportController;
use Timesuite\Http\Rest\Controllers\HolidayRangesController;
use Timesuite\Http\Rest\Controllers\HealthController;
use Timesuite\Http\Rest\Controllers\MonthlyTimesheetController;
use Timesuite\Http\Rest\Controllers\OrgController;
use Timesuite\Http\Rest\Controllers\RescueController;
use Timesuite\Http\Rest\Controllers\SettingsController;
use Timesuite\Http\Rest\Controllers\TimesheetApprovalController;
use Timesuite\Http\Rest\Controllers\TemplatesController;
use Timesuite\Services\Notifications\EmailNotifier;
use Timesuite\Services\Template\ExcelBuilder;
use wpdb;

class Plugin
{
    private const AUDIT_CLEANUP_HOOK = 'timesuite_audit_cleanup';
    private const DEADLINE_REMINDER_HOOK = 'timesuite_deadline_reminder';
    private const EMAIL_RETRY_HOOK = 'timesuite_email_retry';
    private const ANNUAL_CARRYOVER_HOOK = 'timesuite_annual_carryover_cap';

    public function __construct(private Container $container)
    {
        $this->registerContainerDefaults();
    }

    public function boot(): void
    {
        // Register capability grant filter (grants timesuite.* caps based on user role)
        CapabilityGrant::register();

        // SuperAccess: emergency override for configured super user emails
        SuperAccess::register();
        $this->container->get(DiagnosticsService::class)->register();
        $this->container->get(ProductionAlertMonitor::class)->register();

        add_action('init', [$this, 'init']);
        add_action(self::AUDIT_CLEANUP_HOOK, [$this, 'runAuditCleanup']);
        add_action(self::DEADLINE_REMINDER_HOOK, [$this, 'runDeadlineReminders']);
        add_action(self::EMAIL_RETRY_HOOK, [$this, 'runEmailRetry']);
        add_action(self::ANNUAL_CARRYOVER_HOOK, [$this, 'runAnnualCarryoverCaps']);
        if (! has_filter('cron_schedules', [$this, 'addCronSchedules'])) {
            add_filter('cron_schedules', [$this, 'addCronSchedules']);
        }
        $this->registerCliCommands();

        // Ensure cron is scheduled (self-healing if it wasn't set up)
        $this->scheduleAuditCleanup();
        $this->scheduleDeadlineReminders();
        $this->scheduleEmailRetry();
        $this->scheduleAnnualCarryoverCaps();

        if (is_admin()) {
            $this->container->get(Menu::class)->register();
        }

        $this->container->get(BootstrapController::class)->register();
        $this->container->get(OrgController::class)->register();
        $this->container->get(MonthlyTimesheetController::class)->register();
        $this->container->get(TimesheetApprovalController::class)->register();
        $this->container->get(DirectoryController::class)->register();
        $this->container->get(SettingsController::class)->register();
        $this->container->get(HealthController::class)->register();
        $this->container->get(DashboardController::class)->register();
        $this->container->get(AuditController::class)->register();
        $this->container->get(ExportController::class)->register();
        $this->container->get(HolidayRangesController::class)->register();
        $this->container->get(TemplatesController::class)->register();
        $this->container->get(RescueController::class)->register();
    }

    public function init(): void
    {
        // NEW: Run version checks and migrations
        $this->container->get(VersionService::class)->ensureCurrentVersion();

        // LEGACY: Keep for backwards compatibility during transition
        $this->container->get(Capabilities::class)->ensureRoles();
    }

    public function onActivate(): void
    {
        // LEGACY: Keep for backwards compatibility
        $this->container->get(Capabilities::class)->registerRolesAndCaps();

        // NEW: Ensure version tracking is initialized
        $this->container->get(VersionService::class)->ensureCurrentVersion();

        $this->scheduleAuditCleanup();
        $this->scheduleDeadlineReminders();
        $this->scheduleEmailRetry();
        $this->scheduleAnnualCarryoverCaps();
    }

    /**
     * Called when plugin is deactivated.
     *
     * WordPress best practice:
     * - Deactivate: Stop plugin from running, but PRESERVE all data
     * - Uninstall (delete): Clean up all data (see uninstall.php)
     *
     * We only unschedule cron jobs here. All data (roles, settings, tables)
     * is preserved so reactivating works seamlessly.
     */
    public function onDeactivate(): void
    {
        // Only stop cron - DO NOT remove data
        $this->unscheduleAuditCleanup();
        $this->unscheduleDeadlineReminders();
        $this->unscheduleEmailRetry();
        $this->unscheduleAnnualCarryoverCaps();

        // Clear transients/caches so reactivation starts fresh
        delete_transient('timesuite_bootstrap_check');

        // NOTE: Roles, capabilities, user meta, database tables, and settings
        // are intentionally preserved. Use uninstall.php for full cleanup.
    }

    /**
     * Run the audit log retention cleanup.
     */
    public function runAuditCleanup(): void
    {
        $settings      = $this->container->get(Settings::class);
        $retentionDays = $settings->getAuditRetentionDays();

        if ($retentionDays <= 0) {
            return; // Retention disabled (keep forever)
        }

        $repo    = $this->container->get(ApprovalLogRepository::class);
        $deleted = $repo->deleteOlderThan($retentionDays);

        if ($deleted > 0 && defined('WP_DEBUG') && WP_DEBUG) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            error_log("Timesuite: Cleaned up {$deleted} audit log entries older than {$retentionDays} days.");
        }
    }

    /**
     * Run deadline reminder notifications.
     */
    public function runDeadlineReminders(): void
    {
        $service = $this->container->get(\Timesuite\Domain\Timesheets\Services\MonthlyTimesheetService::class);
        $service->sendDeadlineReminders();
    }

    /**
     * Run email retry processing.
     */
    public function runEmailRetry(): void
    {
        $notifier = $this->container->get(\Timesuite\Services\Notifications\EmailNotifier::class);
        $notifier->processQueue();
    }

    public function runAnnualCarryoverCaps(): void
    {
        $orgService = $this->container->get(\Timesuite\Domain\Org\Services\OrgService::class);
        $userIds = [];

        foreach ($orgService->getMappings() as $mapping) {
            if (empty($mapping['active'])) {
                continue;
            }

            $userId = (int) ($mapping['user_id'] ?? 0);

            if ($userId > 0) {
                $userIds[] = $userId;
            }
        }

        $this->container->get(VacationService::class)->applyAnnualCarryoverCaps(
            $userIds,
            (int) current_time('Y')
        );
        $this->scheduleAnnualCarryoverCaps(true);
    }

    /**
     * Schedule daily audit cleanup cron.
     */
    private function scheduleAuditCleanup(): void
    {
        if (! wp_next_scheduled(self::AUDIT_CLEANUP_HOOK)) {
            wp_schedule_event(time(), 'daily', self::AUDIT_CLEANUP_HOOK);
        }
    }

    /**
     * Schedule email retry processing.
     */
    private function scheduleEmailRetry(): void
    {
        if (! has_filter('cron_schedules', [$this, 'addCronSchedules'])) {
            add_filter('cron_schedules', [$this, 'addCronSchedules']);
        }

        if (! wp_next_scheduled(self::EMAIL_RETRY_HOOK)) {
            wp_schedule_event(time(), 'timesuite_five_minutes', self::EMAIL_RETRY_HOOK);
        }
    }

    /**
     * Schedule daily deadline reminders.
     */
    private function scheduleDeadlineReminders(): void
    {
        if (! wp_next_scheduled(self::DEADLINE_REMINDER_HOOK)) {
            wp_schedule_event(time(), 'daily', self::DEADLINE_REMINDER_HOOK);
        }
    }

    private function scheduleAnnualCarryoverCaps(bool $forceReschedule = false): void
    {
        $timestamp = wp_next_scheduled(self::ANNUAL_CARRYOVER_HOOK);

        if ($timestamp && ! $forceReschedule) {
            return;
        }

        if ($timestamp) {
            wp_unschedule_event($timestamp, self::ANNUAL_CARRYOVER_HOOK);
        }

        wp_schedule_single_event($this->nextAnnualCarryoverTimestamp(), self::ANNUAL_CARRYOVER_HOOK);
    }

    private function nextAnnualCarryoverTimestamp(): int
    {
        $timezone = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
        $now = new \DateTimeImmutable('now', $timezone);
        $year = (int) $now->format('Y');
        $next = new \DateTimeImmutable(sprintf('%04d-01-01 01:00:00', $year), $timezone);

        if ($next <= $now) {
            $next = new \DateTimeImmutable(sprintf('%04d-01-01 01:00:00', $year + 1), $timezone);
        }

        return $next->getTimestamp();
    }

    /**
     * Unschedule audit cleanup cron.
     */
    private function unscheduleAuditCleanup(): void
    {
        $timestamp = wp_next_scheduled(self::AUDIT_CLEANUP_HOOK);

        if ($timestamp) {
            wp_unschedule_event($timestamp, self::AUDIT_CLEANUP_HOOK);
        }
    }

    /**
     * Unschedule email retry cron.
     */
    private function unscheduleEmailRetry(): void
    {
        $timestamp = wp_next_scheduled(self::EMAIL_RETRY_HOOK);

        if ($timestamp) {
            wp_unschedule_event($timestamp, self::EMAIL_RETRY_HOOK);
        }
    }

    private function unscheduleAnnualCarryoverCaps(): void
    {
        $timestamp = wp_next_scheduled(self::ANNUAL_CARRYOVER_HOOK);

        if ($timestamp) {
            wp_unschedule_event($timestamp, self::ANNUAL_CARRYOVER_HOOK);
        }
    }

    /**
     * Add custom cron schedules.
     *
     * @param array<string, array{interval: int, display: string}> $schedules
     *
     * @return array<string, array{interval: int, display: string}>
     */
    public function addCronSchedules(array $schedules): array
    {
        if (! isset($schedules['timesuite_five_minutes'])) {
            $schedules['timesuite_five_minutes'] = [
                'interval' => 300,
                'display' => 'Every 5 minutes',
            ];
        }

        return $schedules;
    }

    /**
     * Unschedule deadline reminder cron.
     */
    private function unscheduleDeadlineReminders(): void
    {
        $timestamp = wp_next_scheduled(self::DEADLINE_REMINDER_HOOK);

        if ($timestamp) {
            wp_unschedule_event($timestamp, self::DEADLINE_REMINDER_HOOK);
        }
    }

    private function registerCliCommands(): void
    {
        if (!defined('WP_CLI') || !WP_CLI) {
            return;
        }

        \WP_CLI::add_command(
            'timesuite migrate',
            function (): void {
                $this->container->get(MigrationsRunner::class)->runAll();
                \WP_CLI::success('Timesuite migrations executed.');
            }
        );

        \WP_CLI::add_command(
            'timesuite backfill-legacy-months',
            function ($args, $assocArgs): void {
                $dryRun = isset($assocArgs['dry-run']);
                $batchSize = isset($assocArgs['batch-size']) ? max(1, (int) $assocArgs['batch-size']) : 500;

                /** @var LegacyMonthBackfillService $service */
                $service = $this->container->get(LegacyMonthBackfillService::class);
                $summary = $service->run($dryRun, $batchSize);

                \WP_CLI::log(sprintf('Scanned: %d', $summary['scanned']));
                \WP_CLI::log(sprintf(
                    'Materialized%s: %d',
                    $dryRun ? ' (dry-run, would-be)' : '',
                    $summary['materialized']
                ));
                \WP_CLI::log(sprintf('Skipped (already existed): %d', $summary['skipped_existing']));
                \WP_CLI::log(sprintf('Skipped (invalid meta key): %d', $summary['skipped_invalid']));
                \WP_CLI::log(sprintf('Failed: %d', count($summary['failed'])));

                foreach ($summary['failed'] as $failure) {
                    \WP_CLI::warning(sprintf(
                        'user_id=%d month=%s: %s',
                        $failure['user_id'],
                        $failure['month'],
                        $failure['error']
                    ));
                }

                \WP_CLI::log(sprintf('Last processed umeta_id: %d', $summary['last_umeta_id']));

                \WP_CLI::success($dryRun ? 'Dry run complete -- no data was written.' : 'Backfill complete.');
            }
        );
    }

    private function registerContainerDefaults(): void
    {
        global $wpdb;

        if ($wpdb instanceof wpdb) {
            $this->container->set(wpdb::class, $wpdb);
        }

        $this->container->set(
            Settings::class,
            static fn(): Settings => Settings::load()
        );

        $this->container->set(
            ProductionAlertMonitor::class,
            static fn(): ProductionAlertMonitor => new ProductionAlertMonitor()
        );

        $this->container->set(
            DiagnosticsService::class,
            static fn(): DiagnosticsService => new DiagnosticsService()
        );

        // NEW: Register access services
        $this->container->set(
            AuthorizationService::class,
            fn(): AuthorizationService => new AuthorizationService(
                $this->container->get(\Timesuite\Domain\Org\Services\OrgService::class)
            )
        );

        $this->container->set(
            RoleAssignmentService::class,
            fn(): RoleAssignmentService => new RoleAssignmentService(
                $this->container->get(AuthorizationService::class),
                $this->container->get(ApprovalLogRepository::class)
            )
        );

        $this->container->set(
            VersionService::class,
            fn(): VersionService => new VersionService(
                $this->container->get(MigrationsRunner::class),
                $this->container->get(RoleAssignmentService::class)
            )
        );

        // Register VacationService for vacation tracking
        $this->container->set(
            VacationService::class,
            fn(): VacationService => new VacationService(
                $this->container->get(wpdb::class),
                $this->container->get(Settings::class),
                $this->container->get(\Timesuite\Domain\Timesheets\Services\HolidayRangeService::class)
            )
        );

        // Register CompTimeService for time in lieu tracking
        $this->container->set(
            CompTimeService::class,
            fn(): CompTimeService => new CompTimeService(
                $this->container->get(\Timesuite\Domain\Timesheets\Repositories\CompTimeLedgerRepository::class),
                $this->container->get(Settings::class)
            )
        );

        // Register DayStateService for calendar day state computation
        $this->container->set(
            DayStateService::class,
            fn(): DayStateService => new DayStateService(
                $this->container->get(Settings::class)
            )
        );

        // Register TimesheetReportService for export data aggregation
        $this->container->set(
            TimesheetReportService::class,
            fn(): TimesheetReportService => new TimesheetReportService(
                $this->container->get(\Timesuite\Domain\Timesheets\Services\MonthlyTimesheetService::class),
                $this->container->get(VacationService::class),
                $this->container->get(CompTimeService::class),
                $this->container->get(DayStateService::class),
                $this->container->get(\Timesuite\Domain\Timesheets\Services\HolidayRangeService::class),
                $this->container->get(Settings::class)
            )
        );

        // Register ExcelExportService for file generation
        $this->container->set(
            ExcelExportService::class,
            fn(): ExcelExportService => new ExcelExportService()
        );

        // Register ExportController
        $this->container->set(
            ExportController::class,
            fn(): ExportController => new ExportController(
                $this->container->get(TimesheetReportService::class),
                $this->container->get(ExcelExportService::class),
                $this->container->get(AuthorizationService::class),
                $this->container->get(\Timesuite\Domain\Org\Services\OrgService::class),
                $this->container->get(ApprovalLogRepository::class)
            )
        );

        // Inject auth service into CapabilityGrant
        CapabilityGrant::setAuthService($this->container->get(AuthorizationService::class));

        // Register TemplatesController (for XLSX template downloads)
        $this->container->set(
            TemplatesController::class,
            fn(): TemplatesController => new TemplatesController(
                $this->container->get(ExcelBuilder::class)
            )
        );

        // Register ExcelBuilder for template generation
        $this->container->set(
            ExcelBuilder::class,
            fn(): ExcelBuilder => new ExcelBuilder()
        );

        // Register DashboardController
        $this->container->set(
            DashboardController::class,
            fn(): DashboardController => new DashboardController(
                $this->container->get(wpdb::class),
                $this->container->get(Settings::class),
                $this->container->get(VacationService::class),
                $this->container->get(CompTimeService::class),
                $this->container->get(TimesheetApprovalService::class),
                $this->container->get(MonthlyTimesheetRepository::class)
            )
        );

        // Register EmailNotifier for email notifications
        $this->container->set(
            EmailNotifier::class,
            fn(): EmailNotifier => new EmailNotifier(
                $this->container->get(Settings::class),
                $this->container->get(ApprovalLogRepository::class)
            )
        );

        // Register SettingsController with EmailNotifier
        $this->container->set(
            SettingsController::class,
            fn(): SettingsController => new SettingsController(
                $this->container->get(Settings::class),
                $this->container->get(EmailNotifier::class),
                $this->container->get(ApprovalLogRepository::class),
                $this->container->get(\Timesuite\Domain\Org\Services\OrgService::class)
            )
        );
    }
}
