<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Repositories;

use wpdb;
use const ARRAY_A;

class CompTimeLedgerRepository
{
    private string $table;

    public function __construct(private wpdb $wpdb)
    {
        $this->table = $this->wpdb->prefix . 'timesuite_comp_time_ledger';
    }

    /**
     * @param array<string, mixed> $data
     */
    public function insert(array $data): void
    {
        $sql = $this->wpdb->prepare(
            "
                INSERT INTO {$this->table}
                    (user_id, direction, minutes, source_type, source_key, work_date, expires_on, notes, created_at, created_by)
                VALUES (%d, %s, %d, %s, %s, %s, %s, %s, %s, %d)
            ",
            [
                (int) $data['user_id'],
                (string) $data['direction'],
                (int) $data['minutes'],
                (string) $data['source_type'],
                $data['source_key'] ?? null,
                $data['work_date'] ?? null,
                $data['expires_on'] ?? null,
                $data['notes'] ?? null,
                (string) $data['created_at'],
                isset($data['created_by']) ? (int) $data['created_by'] : null,
            ]
        );

        $this->wpdb->query($sql);
    }

    public function deleteBySource(int $userId, string $sourceType, string $sourceKey, ?string $direction = null): void
    {
        if ($direction) {
            $sql = $this->wpdb->prepare(
                "DELETE FROM {$this->table} WHERE user_id = %d AND source_type = %s AND source_key = %s AND direction = %s",
                [$userId, $sourceType, $sourceKey, $direction]
            );
        } else {
            $sql = $this->wpdb->prepare(
                "DELETE FROM {$this->table} WHERE user_id = %d AND source_type = %s AND source_key = %s",
                [$userId, $sourceType, $sourceKey]
            );
        }

        $this->wpdb->query($sql);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listByUser(int $userId): array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE user_id = %d ORDER BY created_at ASC, id ASC",
            $userId
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return $rows ?: [];
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findBySource(int $userId, string $sourceType, string $sourceKey, string $direction): ?array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE user_id = %d AND source_type = %s AND source_key = %s AND direction = %s LIMIT 1",
            [$userId, $sourceType, $sourceKey, $direction]
        );

        $row = $this->wpdb->get_row($sql, ARRAY_A);

        return $row ?: null;
    }

    public function deleteByUserId(int $userId): int
    {
        $sql = $this->wpdb->prepare(
            "DELETE FROM {$this->table} WHERE user_id = %d",
            $userId
        );

        $this->wpdb->query($sql);

        return (int) $this->wpdb->rows_affected;
    }
}
