<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Repositories;

use wpdb;
use const ARRAY_A;

class MonthlyTimesheetRepository
{
    private string $timesheetsTable;
    private string $entriesTable;
    private ?bool $hasScheduledHoursColumn = null;

    public function __construct(private wpdb $wpdb)
    {
        $this->timesheetsTable = $this->wpdb->prefix . 'timesuite_monthly_timesheets';
        $this->entriesTable    = $this->wpdb->prefix . 'timesuite_monthly_entries';
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getHeader(int $userId, int $year, int $month): ?array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->timesheetsTable} WHERE user_id = %d AND year = %d AND month = %d LIMIT 1",
            [$userId, $year, $month]
        );

        $row = $this->wpdb->get_row($sql, ARRAY_A);

        return $row ?: null;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getEntries(int $timesheetId): array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->entriesTable} WHERE timesheet_id = %d ORDER BY work_date ASC",
            $timesheetId
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return $rows ?: [];
    }

    /**
     * @param array<string, mixed> $data
     */
    public function upsertHeader(int $userId, int $year, int $month, array $data): int
    {
        $existing = $this->getHeader($userId, $year, $month);
        $now      = current_time('mysql', true);

        $fields = [
            'status' => (string) ($data['status'] ?? 'draft'),
            'updated_at' => (string) ($data['updated_at'] ?? $now),
            'updated_by' => $data['updated_by'] ?? null,
            'submitted_at' => $data['submitted_at'] ?? null,
            'submitted_by' => $data['submitted_by'] ?? null,
            'approved_at' => $data['approved_at'] ?? null,
            'approved_by' => $data['approved_by'] ?? null,
            'denied_at' => $data['denied_at'] ?? null,
            'denied_by' => $data['denied_by'] ?? null,
            'denied_comment' => $data['denied_comment'] ?? null,
        ];

        if ($existing) {
            $setClauses = [];
            $values = [];

            foreach ($fields as $column => $value) {
                if (null === $value) {
                    $setClauses[] = "{$column} = NULL";
                    continue;
                }

                $placeholder = is_int($value) ? '%d' : '%s';
                $setClauses[] = "{$column} = {$placeholder}";
                $values[] = $value;
            }

            $values[] = $userId;
            $values[] = $year;
            $values[] = $month;

            $sql = $this->wpdb->prepare(
                "UPDATE {$this->timesheetsTable} SET " . implode(', ', $setClauses) . ' WHERE user_id = %d AND year = %d AND month = %d',
                $values
            );

            $this->wpdb->query($sql);

            return (int) $existing['id'];
        }

        $fields['user_id'] = $userId;
        $fields['year'] = $year;
        $fields['month'] = $month;
        $fields['created_at'] = (string) ($data['created_at'] ?? $now);

        $columns = array_keys($fields);
        $placeholders = [];
        $values = [];

        foreach ($fields as $value) {
            if (null === $value) {
                $placeholders[] = 'NULL';
                continue;
            }

            $placeholders[] = is_int($value) ? '%d' : '%s';
            $values[] = $value;
        }

        $sql = $this->wpdb->prepare(
            "INSERT INTO {$this->timesheetsTable} (" . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')',
            $values
        );

        $this->wpdb->query($sql);

        return (int) $this->wpdb->insert_id;
    }

    /**
     * Inserts a header row ONLY if one doesn't already exist for this
     * user/year/month — never updates an existing row. Used by the legacy
     * backfill (P1.2, see docs/timesheet-status-investigation.md §11): a
     * backfill runs out-of-band with no request context that's already
     * committed to treating a specific legacy snapshot as canonical, so
     * unlike upsertHeader() (used by the lazy read-path materialization),
     * it must never overwrite a row that already exists — including one
     * that appeared between the caller's own candidate scan and this call.
     *
     * Deliberately plain `INSERT`, not `INSERT IGNORE`: IGNORE would also
     * silently swallow non-duplicate problems (truncation, an implicit
     * NOT NULL default substitution, etc.) and this method would then
     * mis-report them as "row already existed." The table's own
     * `UNIQUE KEY (user_id, year, month)` constraint is what actually
     * makes this race-safe (not any check-then-insert logic in PHP, which
     * would still have a TOCTOU gap) — a duplicate-key failure is detected
     * explicitly via the error message and treated as "already existed";
     * any other failure is a genuine problem and is re-thrown.
     *
     * @param array<string, mixed> $data
     *
     * @return int|null The new header's id, or null if a row already existed.
     *
     * @throws \RuntimeException on any non-duplicate-key insert failure.
     */
    public function insertHeaderIfAbsent(int $userId, int $year, int $month, array $data): ?int
    {
        $now = current_time('mysql', true);

        $fields = [
            'user_id' => $userId,
            'year' => $year,
            'month' => $month,
            'status' => (string) ($data['status'] ?? 'draft'),
            'updated_at' => (string) ($data['updated_at'] ?? $now),
            'updated_by' => $data['updated_by'] ?? null,
            'submitted_at' => $data['submitted_at'] ?? null,
            'submitted_by' => $data['submitted_by'] ?? null,
            'approved_at' => $data['approved_at'] ?? null,
            'approved_by' => $data['approved_by'] ?? null,
            'denied_at' => $data['denied_at'] ?? null,
            'denied_by' => $data['denied_by'] ?? null,
            'denied_comment' => $data['denied_comment'] ?? null,
            'created_at' => (string) ($data['created_at'] ?? $now),
        ];

        $columns = array_keys($fields);
        $placeholders = [];
        $values = [];

        foreach ($fields as $value) {
            if (null === $value) {
                $placeholders[] = 'NULL';
                continue;
            }

            $placeholders[] = is_int($value) ? '%d' : '%s';
            $values[] = $value;
        }

        $sql = $this->wpdb->prepare(
            "INSERT INTO {$this->timesheetsTable} (" . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')',
            $values
        );

        $result = $this->wpdb->query($sql);

        if (false === $result) {
            if ($this->isDuplicateKeyError((string) $this->wpdb->last_error)) {
                return null;
            }

            throw new \RuntimeException(sprintf(
                'Failed to insert monthly timesheet header for user %d, %04d-%02d: %s',
                $userId,
                $year,
                $month,
                (string) $this->wpdb->last_error
            ));
        }

        return (int) $this->wpdb->insert_id;
    }

    private function isDuplicateKeyError(string $error): bool
    {
        return '' !== $error && str_contains($error, 'Duplicate entry');
    }

    /**
     * Atomically materializes a legacy month: header + entries as a single
     * unit, via insertHeaderIfAbsent() (the race-safe, insert-only guard)
     * followed by upsertEntriesOrThrow() -- deliberately NOT the plain
     * upsertEntries(), which never checks its query results and would
     * silently continue past a failed entry write, defeating the rollback
     * below entirely. If entries fail to write AFTER the header insert
     * already succeeded, the whole operation is rolled back — without
     * this, the month would end up with a canonical header row but no
     * entries, which is invisible to both the backfill (the header's mere
     * existence removes it from findLegacyMonthCandidates()) and the lazy
     * read-path (a header row short-circuits before ever consulting legacy
     * meta again) — a silent, hard-to-repair partial state.
     *
     * @param array<string, mixed> $data
     * @param array<string, array<string, mixed>> $entries
     * @param array<string, array<string, mixed>> $approvals
     *
     * @return int|null The new header's id if materialized, or null if a
     *                   row already existed (nothing written).
     */
    public function materializeIfAbsent(
        int $userId,
        int $year,
        int $month,
        array $data,
        array $entries,
        array $approvals
    ): ?int {
        $this->wpdb->query('START TRANSACTION');

        try {
            $timesheetId = $this->insertHeaderIfAbsent($userId, $year, $month, $data);

            if (null === $timesheetId) {
                $this->wpdb->query('COMMIT');

                return null;
            }

            $this->upsertEntriesOrThrow($timesheetId, $userId, $entries, $approvals);

            $this->wpdb->query('COMMIT');

            return $timesheetId;
        } catch (\Throwable $e) {
            $this->wpdb->query('ROLLBACK');

            throw $e;
        }
    }

    /**
     * Finds candidate legacy-only months for the backfill (P1.2), keyset-
     * paginated by umeta_id so a large wp_usermeta table can be scanned in
     * bounded batches without OFFSET's degrading performance.
     *
     * The LIKE/SUBSTRING filtering here is deliberately loose (candidate-
     * finding only) — it mirrors HealthController::findLegacyOnlyMonths()'s
     * approach so the two agree on what counts as "legacy-only," but a
     * malformed meta_key (non-numeric year/month, out-of-range month) can
     * still pass through as a "candidate." Callers MUST strictly re-validate
     * each meta_key before writing anything — see
     * LegacyMonthBackfillService::parseLegacyMetaKey().
     *
     * @return array<int, array{umeta_id: int, user_id: int, meta_key: string}>
     */
    public function findLegacyMonthCandidates(int $afterUmetaId, int $limit): array
    {
        $metaTable = $this->wpdb->usermeta;

        $sql = $this->wpdb->prepare(
            "SELECT m.umeta_id, m.user_id, m.meta_key
             FROM {$metaTable} m
             LEFT JOIN {$this->timesheetsTable} mt
                ON mt.user_id = m.user_id
                AND mt.year = CAST(SUBSTRING(m.meta_key, 17, 4) AS UNSIGNED)
                AND mt.month = CAST(SUBSTRING(m.meta_key, 22, 2) AS UNSIGNED)
             WHERE m.meta_key LIKE 'timesuite\\_month\\_____\\_%%'
               AND m.umeta_id > %d
               AND mt.id IS NULL
             ORDER BY m.umeta_id ASC
             LIMIT %d",
            [$afterUmetaId, $limit]
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return $rows ?: [];
    }

    /**
     * @param array<string, array<string, mixed>> $entries
     * @param array<string, array<string, mixed>> $approvals
     */
    public function upsertEntries(int $timesheetId, int $userId, array $entries, array $approvals): void
    {
        if (empty($entries)) {
            return;
        }

        $now = current_time('mysql', true);
        $supportsScheduledHours = $this->hasScheduledHoursColumn();

        foreach ($entries as $date => $entry) {
            $sql = $this->buildEntryUpsertSql(
                $timesheetId,
                $userId,
                (string) $date,
                is_array($entry) ? $entry : [],
                is_array($approvals[$date] ?? null) ? $approvals[$date] : [],
                $now,
                $supportsScheduledHours
            );

            $this->wpdb->query($sql);
        }
    }

    /**
     * Same writes as upsertEntries(), but checks every query's result and
     * throws on the first failure instead of silently continuing. Used
     * only by materializeIfAbsent() (see docs/timesheet-status-investigation.md
     * §11.1): that method's whole point is to roll back the header insert
     * if entries fail, which only works if a failed entry write actually
     * throws — upsertEntries() itself is left with its existing (silently
     * tolerant) behavior because it also has three other, unrelated
     * callers (DashboardController, MonthlyTimesheetService,
     * TimesheetApprovalService) that were never designed or tested around
     * this method suddenly being able to throw, and auditing/changing
     * their behavior is out of scope for this backfill.
     *
     * @param array<string, array<string, mixed>> $entries
     * @param array<string, array<string, mixed>> $approvals
     *
     * @throws \RuntimeException on any entry-write failure.
     */
    private function upsertEntriesOrThrow(int $timesheetId, int $userId, array $entries, array $approvals): void
    {
        if (empty($entries)) {
            return;
        }

        $now = current_time('mysql', true);
        $supportsScheduledHours = $this->hasScheduledHoursColumn();

        foreach ($entries as $date => $entry) {
            $sql = $this->buildEntryUpsertSql(
                $timesheetId,
                $userId,
                (string) $date,
                is_array($entry) ? $entry : [],
                is_array($approvals[$date] ?? null) ? $approvals[$date] : [],
                $now,
                $supportsScheduledHours
            );

            $result = $this->wpdb->query($sql);

            if (false === $result) {
                throw new \RuntimeException(sprintf(
                    'Failed to insert monthly timesheet entry for timesheet %d, date %s: %s',
                    $timesheetId,
                    (string) $date,
                    (string) $this->wpdb->last_error
                ));
            }
        }
    }

    /**
     * @param array<string, mixed> $entry
     * @param array<string, mixed> $approval
     */
    private function buildEntryUpsertSql(
        int $timesheetId,
        int $userId,
        string $date,
        array $entry,
        array $approval,
        string $now,
        bool $supportsScheduledHours
    ): string {
        $fields = [
            'timesheet_id' => $timesheetId,
            'user_id' => $userId,
            'work_date' => $date,
            'type' => (string) ($entry['type'] ?? 'working_day'),
            'notes' => $entry['notes'] ?? null,
            'hours' => $entry['hours'] ?? null,
            'coverage_source' => $entry['coverage_source'] ?? null,
            'in_office' => ! empty($entry['in_office']) ? 1 : 0,
            'approval_status' => $approval['status'] ?? null,
            'approval_by' => $approval['by'] ?? null,
            'approval_at' => $approval['at'] ?? null,
            'approval_comment' => $approval['comment'] ?? null,
            'created_at' => $now,
            'updated_at' => $now,
        ];

        if ($supportsScheduledHours) {
            $fields['scheduled_hours'] = $entry['scheduled_hours'] ?? null;
        }

        $columns = array_keys($fields);
        $placeholders = [];
        $values = [];

        foreach ($fields as $value) {
            if (null === $value) {
                $placeholders[] = 'NULL';
                continue;
            }

            $placeholders[] = is_int($value) ? '%d' : '%s';
            $values[] = $value;
        }

        $updates = [
            'type = VALUES(type)',
            'notes = VALUES(notes)',
            'hours = VALUES(hours)',
            'coverage_source = VALUES(coverage_source)',
            'in_office = VALUES(in_office)',
            'approval_status = VALUES(approval_status)',
            'approval_by = VALUES(approval_by)',
            'approval_at = VALUES(approval_at)',
            'approval_comment = VALUES(approval_comment)',
            'updated_at = VALUES(updated_at)',
        ];

        if ($supportsScheduledHours) {
            array_splice($updates, 3, 0, ['scheduled_hours = VALUES(scheduled_hours)']);
        }

        return $this->wpdb->prepare(
            "INSERT INTO {$this->entriesTable} (" . implode(', ', $columns) . ')
            VALUES (' . implode(', ', $placeholders) . ')
            ON DUPLICATE KEY UPDATE ' . implode(', ', $updates),
            $values
        );
    }

    /**
     * Thin transaction-control wrappers so MonthlyTimesheetService can span
     * a single DB transaction across comp-time ledger writes (via
     * CompTimeService/CompTimeLedgerRepository, a different repository but
     * the same underlying wpdb connection) and its own header/entries
     * writes -- see MonthlyTimesheetService::finalizeSubmittedMonth() and
     * docs/p3.1-admin-rescue-actions-plan.md §1.1. Same pattern already
     * used internally by materializeIfAbsent() (P1.2).
     */
    public function beginTransaction(): void
    {
        $this->wpdb->query('START TRANSACTION');
    }

    public function commitTransaction(): void
    {
        $this->wpdb->query('COMMIT');
    }

    public function rollbackTransaction(): void
    {
        $this->wpdb->query('ROLLBACK');
    }

    public function deleteByUserId(int $userId): int
    {
        $total = 0;

        $sql = $this->wpdb->prepare(
            "DELETE FROM {$this->entriesTable} WHERE user_id = %d",
            $userId
        );
        $this->wpdb->query($sql);
        $total += (int) $this->wpdb->rows_affected;

        $sql = $this->wpdb->prepare(
            "DELETE FROM {$this->timesheetsTable} WHERE user_id = %d",
            $userId
        );
        $this->wpdb->query($sql);
        $total += (int) $this->wpdb->rows_affected;

        return $total;
    }

    private function hasScheduledHoursColumn(): bool
    {
        if ($this->hasScheduledHoursColumn !== null) {
            return $this->hasScheduledHoursColumn;
        }

        $column = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SHOW COLUMNS FROM {$this->entriesTable} LIKE %s",
                'scheduled_hours'
            )
        );

        $this->hasScheduledHoursColumn = is_string($column) && $column === 'scheduled_hours';

        return $this->hasScheduledHoursColumn;
    }
}
