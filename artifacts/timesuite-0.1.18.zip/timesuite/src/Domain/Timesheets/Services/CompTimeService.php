<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Services;

use Timesuite\Core\Settings;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Timesheets\Repositories\CompTimeLedgerRepository;

/**
 * Service for managing comp time (time in lieu) credits and debits.
 */
class CompTimeService
{
    private const SOURCE_MONTHLY = 'monthly';
    private const SOURCE_MANUAL = 'manual';
    private const DIRECTION_CREDIT = 'credit';
    private const DIRECTION_DEBIT = 'debit';

    public function __construct(
        private CompTimeLedgerRepository $ledgerRepository,
        private Settings $settings
    ) {
    }

    /**
     * @param array<int, array{date: string, minutes: int}> $debits
     */
    public function applyMonthlyDebits(
        int $userId,
        int $year,
        int $month,
        array $debits,
        int $actorId
    ): void {
        $sourceKey = sprintf('%04d-%02d', $year, $month);
        $rows = $this->ledgerRepository->listByUser($userId);

        $existingCredits = $this->filterEntries($rows, self::DIRECTION_CREDIT, null);
        $existingDebits = $this->filterEntries($rows, self::DIRECTION_DEBIT, $sourceKey);

        $pendingDebits = [];
        $now = current_time('mysql', true);

        foreach ($debits as $item) {
            if (($item['minutes'] ?? 0) <= 0) {
                continue;
            }

            $pendingDebits[] = [
                'minutes' => (int) $item['minutes'],
                'date'    => (string) $item['date'],
                'created_at' => $now,
            ];
        }

        $combinedDebits = array_merge($existingDebits, $pendingDebits);

        if ($this->allocateDebits($existingCredits, $combinedDebits) === null) {
            throw new ValidationException(__('Not enough comp time balance to cover the selected hours.', 'timesuite'));
        }

        $this->ledgerRepository->deleteBySource($userId, self::SOURCE_MONTHLY, $sourceKey, self::DIRECTION_DEBIT);

        foreach ($pendingDebits as $item) {
            $this->ledgerRepository->insert([
                'user_id'    => $userId,
                'direction'  => self::DIRECTION_DEBIT,
                'minutes'    => $item['minutes'],
                'source_type'=> self::SOURCE_MONTHLY,
                'source_key' => $sourceKey,
                'work_date'  => $item['date'],
                'expires_on' => null,
                'notes'      => 'Comp time used for partial day.',
                'created_at' => $now,
                'created_by' => $actorId,
            ]);
        }
    }

    /**
     * @param array<int, array{date: string, minutes: int}> $credits
     */
    public function applyMonthlyCredits(
        int $userId,
        int $year,
        int $month,
        array $credits,
        int $actorId
    ): void {
        $sourceKey = sprintf('%04d-%02d', $year, $month);
        $this->ledgerRepository->deleteBySource($userId, self::SOURCE_MONTHLY, $sourceKey, self::DIRECTION_CREDIT);

        if (empty($credits)) {
            return;
        }

        $expiryMonths = $this->getCompTimeExpiryMonthsForUser($userId);
        $expiresOn = $this->calculateExpiryDate($sourceKey, $expiryMonths);
        $now = current_time('mysql', true);

        foreach ($credits as $item) {
            if (($item['minutes'] ?? 0) <= 0) {
                continue;
            }

            $this->ledgerRepository->insert([
                'user_id'    => $userId,
                'direction'  => self::DIRECTION_CREDIT,
                'minutes'    => (int) $item['minutes'],
                'source_type'=> self::SOURCE_MONTHLY,
                'source_key' => $sourceKey,
                'work_date'  => (string) $item['date'],
                'expires_on' => $expiresOn,
                'notes'      => 'Overtime credit (monthly timesheet).',
                'created_at' => $now,
                'created_by' => $actorId,
            ]);
        }
    }

    public function clearMonthlyDebits(int $userId, int $year, int $month): void
    {
        $sourceKey = sprintf('%04d-%02d', $year, $month);
        $this->ledgerRepository->deleteBySource($userId, self::SOURCE_MONTHLY, $sourceKey, self::DIRECTION_DEBIT);
    }

    public function clearMonthlyCredits(int $userId, int $year, int $month): void
    {
        $sourceKey = sprintf('%04d-%02d', $year, $month);
        $this->ledgerRepository->deleteBySource($userId, self::SOURCE_MONTHLY, $sourceKey, self::DIRECTION_CREDIT);
    }

    /**
     * Read-only check used by the rescue diagnose endpoint (P3.1): does this
     * month have ANY monthly comp-time ledger rows (credit or debit)? Used
     * to detect a desync against the invariant "ledger rows exist iff the
     * month is submitted/approved/locked" -- see
     * docs/p3.1-admin-rescue-actions-plan.md §1.1.
     */
    public function hasMonthlyLedgerEntries(int $userId, int $year, int $month): bool
    {
        $sourceKey = sprintf('%04d-%02d', $year, $month);

        return $this->ledgerRepository->findBySource($userId, self::SOURCE_MONTHLY, $sourceKey, self::DIRECTION_CREDIT) !== null
            || $this->ledgerRepository->findBySource($userId, self::SOURCE_MONTHLY, $sourceKey, self::DIRECTION_DEBIT) !== null;
    }

    public function setAvailableMinutes(int $userId, int $targetMinutes, int $actorId): void
    {
        $targetMinutes = max(0, $targetMinutes);
        $asOfDate = (string) current_time('Y-m-d');
        $current = $this->getAvailableMinutes($userId, $asOfDate);
        $delta = $targetMinutes - $current;

        if (0 === $delta) {
            return;
        }

        $direction = $delta > 0 ? self::DIRECTION_CREDIT : self::DIRECTION_DEBIT;
        $minutes = abs($delta);
        $now = current_time('mysql', true);
        $monthKey = (string) current_time('Y-m');
        $expiryMonths = $this->getCompTimeExpiryMonthsForUser($userId);
        $expiresOn = $direction === self::DIRECTION_CREDIT
            ? $this->calculateExpiryDate($monthKey, $expiryMonths)
            : null;
        $sourceKey = sprintf('manual:%s', current_time('YmdHis'));

        $this->ledgerRepository->insert([
            'user_id'    => $userId,
            'direction'  => $direction,
            'minutes'    => $minutes,
            'source_type'=> self::SOURCE_MANUAL,
            'source_key' => $sourceKey,
            'work_date'  => $asOfDate,
            'expires_on' => $expiresOn,
            'notes'      => 'Manual comp time balance adjustment.',
            'created_at' => $now,
            'created_by' => $actorId,
        ]);
    }

    public function getAvailableMinutes(int $userId, string $asOfDate): int
    {
        $rows = $this->ledgerRepository->listByUser($userId);
        $credits = $this->filterEntries($rows, self::DIRECTION_CREDIT, null);
        $debits = $this->filterEntries($rows, self::DIRECTION_DEBIT, null);

        $remainingCredits = $this->allocateDebits($credits, $debits);

        if ($remainingCredits === null) {
            return 0;
        }

        $available = 0;

        foreach ($remainingCredits as $credit) {
            $expiresOn = $credit['expires_on'];

            if ($expiresOn !== null && $expiresOn < $asOfDate) {
                continue;
            }

            $available += $credit['remaining'];
        }

        return $available;
    }

    /**
     * Get available comp time minutes for multiple users.
     *
     * @param int[] $userIds
     * @return array<int, int> Map of user ID to available minutes
     */
    public function getBulkAvailableMinutes(array $userIds, string $asOfDate): array
    {
        $result = [];

        foreach ($userIds as $userId) {
            $result[(int) $userId] = $this->getAvailableMinutes((int) $userId, $asOfDate);
        }

        return $result;
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     *
     * @return array<int, array{minutes: int, date: string, created_at: string}>
     */
    private function filterEntries(array $rows, string $direction, ?string $excludeSourceKey): array
    {
        $items = [];

        foreach ($rows as $row) {
            if (($row['direction'] ?? '') !== $direction) {
                continue;
            }

            if ($excludeSourceKey !== null && ($row['source_type'] ?? '') === self::SOURCE_MONTHLY) {
                if (($row['source_key'] ?? '') === $excludeSourceKey) {
                    continue;
                }
            }

            $date = $row['work_date'] ?: (is_string($row['created_at']) ? substr($row['created_at'], 0, 10) : '');

            $items[] = [
                'minutes' => (int) ($row['minutes'] ?? 0),
                'date'    => $date,
                'created_at' => (string) ($row['created_at'] ?? ''),
                'expires_on' => $row['expires_on'] ?: null,
            ];
        }

        return $items;
    }

    /**
     * @param array<int, array{minutes: int, date: string, created_at: string, expires_on?: string|null}> $credits
     * @param array<int, array{minutes: int, date: string, created_at: string}> $debits
     *
     * @return array<int, array{remaining: int, expires_on: string|null}>|null
     */
    private function allocateDebits(array $credits, array $debits): ?array
    {
        $creditBuckets = [];

        foreach ($credits as $credit) {
            $expiresOn = $credit['expires_on'] ?? null;
            $creditBuckets[] = [
                'remaining' => (int) $credit['minutes'],
                'expires_on' => $expiresOn,
                'created_at' => $credit['created_at'],
            ];
        }

        usort(
            $creditBuckets,
            static function (array $a, array $b): int {
                $aExpiry = $a['expires_on'] ?? '9999-12-31';
                $bExpiry = $b['expires_on'] ?? '9999-12-31';

                if ($aExpiry === $bExpiry) {
                    return strcmp((string) $a['created_at'], (string) $b['created_at']);
                }

                return strcmp($aExpiry, $bExpiry);
            }
        );

        usort(
            $debits,
            static fn (array $a, array $b): int => strcmp($a['date'], $b['date'])
        );

        foreach ($debits as $debit) {
            $remaining = (int) $debit['minutes'];
            $debitDate = $debit['date'];

            foreach ($creditBuckets as &$credit) {
                if ($credit['remaining'] <= 0) {
                    continue;
                }

                $expiry = $credit['expires_on'];

                if ($expiry !== null && $expiry < $debitDate) {
                    continue;
                }

                $use = min($remaining, $credit['remaining']);
                $credit['remaining'] -= $use;
                $remaining -= $use;

                if (0 === $remaining) {
                    break;
                }
            }
            unset($credit);

            if ($remaining > 0) {
                return null;
            }
        }

        return $creditBuckets;
    }

    private function getCompTimeExpiryMonthsForUser(int $userId): int
    {
        $stored = get_user_meta($userId, 'timesuite_comp_time_expiry_months', true);

        if ('' === $stored || $stored === null) {
            return $this->settings->getCompTimeExpiryMonths();
        }

        return (int) $stored;
    }

    private function calculateExpiryDate(string $monthKey, int $expiryMonths): string
    {
        $start = \DateTimeImmutable::createFromFormat('Y-m-d', $monthKey . '-01');

        if (! $start) {
            return $monthKey . '-01';
        }

        $endOfMonth = $start->modify('last day of this month');

        if ($expiryMonths <= 0) {
            return $endOfMonth->format('Y-m-d');
        }

        $expires = $endOfMonth->modify('+' . $expiryMonths . ' months');

        return $expires->format('Y-m-d');
    }
}
