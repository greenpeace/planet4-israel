<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Services;

use Timesuite\Core\Settings;
use Timesuite\Core\Support\DateTimeHelper;
use Timesuite\Core\Support\MonthEndReminderSchedule;
use Timesuite\Core\Support\RuntimeEnvironment;
use Timesuite\Domain\Org\Services\OrgService;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Timesheets\Contracts\TimesheetApprovalServiceInterface;
use Timesuite\Domain\Timesheets\Contracts\TimesheetServiceInterface;
use Timesuite\Domain\Timesheets\EditabilityReason;
use Timesuite\Domain\Timesheets\Repositories\MonthlyTimesheetRepository;
use Timesuite\Services\Notifications\EmailNotifier;

/**
 * Main timesheet service handling CRUD operations.
 * Delegates approval workflow to TimesheetApprovalService.
 */
class MonthlyTimesheetService implements TimesheetServiceInterface, TimesheetApprovalServiceInterface
{
    private const META_PREFIX = 'timesuite_month_';
    private const USER_META_DAILY_HOURS_BY_DAY = 'timesuite_daily_hours_by_day';
    private const USER_META_HIRE_DATE = 'timesuite_hire_date';
    private const USER_META_EMPLOYMENT_END_DATE = 'timesuite_employment_end_date';
    private const LEGACY_PART_DAY_SOURCE_MAP = [
        'comp_time' => 'time_in_lieu',
        'pto' => 'half_day_off',
        'unpaid' => 'half_day_off',
    ];
    private const ALLOWED_DAY_TYPES = [
        'working_day',
        'half_working',
        'overtime',
        'time_in_lieu',
        'day_off',
        'sick_day',
        'holiday',
        'half_holiday',
        'not_employed',
    ];
    private const IN_OFFICE_ALLOWED_DAY_TYPES = [
        'working_day',
        'half_working',
        'overtime',
    ];
    private const LEGACY_TYPE_MAP = [
        'pto' => 'day_off',
        'sick' => 'sick_day',
        'illness' => 'sick_day',
        'vacation' => 'day_off',
        'annual_leave' => 'day_off',
        'unpaid_leave' => 'day_off',
        'travel' => 'working_day',
        'training' => 'working_day',
    ];
    // Per-stage "already nudged" markers, both holding a 'YYYY-MM' period.
    // Two keys rather than one richer value so the original key keeps its exact
    // meaning and format, leaving any pre-existing stored value valid.
    private const REMINDER_META_KEY = 'timesuite_last_reminder_period';
    private const FINAL_REMINDER_META_KEY = 'timesuite_last_final_reminder_period';

    private ?TimesheetApprovalService $approvalService = null;
    private ?DayStateService $dayStateService = null;

    public function __construct(
        private Settings $settings,
        private HolidayRangeService $holidayRangeService,
        private CompTimeService $compTimeService,
        private MonthlyTimesheetRepository $monthlyRepository,
        private ?EmailNotifier $emailNotifier = null,
        private ?OrgService $orgService = null
    ) {
    }

    /**
     * Set the DayStateService for enforcing day state rules.
     */
    public function setDayStateService(DayStateService $service): void
    {
        $this->dayStateService = $service;
    }

    /**
     * Get or create the day state service (lazy initialization).
     */
    private function getDayStateService(): DayStateService
    {
        if ($this->dayStateService === null) {
            $this->dayStateService = new DayStateService($this->settings);
        }

        return $this->dayStateService;
    }

    /**
     * Get or create the approval service instance (lazy initialization).
     */
    private function getApprovalService(): TimesheetApprovalService
    {
        if ($this->approvalService === null) {
            $this->approvalService = new TimesheetApprovalService(
                $this->settings,
                $this->holidayRangeService,
                $this->monthlyRepository,
                $this->emailNotifier
            );
        }

        return $this->approvalService;
    }

    /**
     * @return array<string, string>
     */
    public function getDayTypes(): array
    {
        return array_merge($this->getBuiltInDayTypes(), $this->getCustomLeaveTypeMap(false));
    }

    /**
     * @return array<string, string>
     */
    public function getSelectableDayTypes(): array
    {
        return array_merge($this->getBuiltInSelectableDayTypes(), $this->getCustomLeaveTypeMap(true));
    }

    /**
     * @return string[]
     */
    public function getCustomLeaveTypeKeys(): array
    {
        return array_keys($this->getCustomLeaveTypeMap(false));
    }

    /**
     * @return array<string, string>
     */
    public function getPartDaySources(): array
    {
        return array_merge($this->getBuiltInPartDaySources(), $this->getCustomLeaveTypeMap(false));
    }

    /**
     * @return array<string, string>
     */
    public function getSelectablePartDaySources(): array
    {
        return array_merge($this->getBuiltInPartDaySources(), $this->getCustomLeaveTypeMap(true));
    }

    /**
     * @return array<string, string>
     */
    private function getBuiltInPartDaySources(): array
    {
        return [
            'half_day_off'  => __('Half day off', 'timesuite'),
            'half_sick_day' => __('Half sick day', 'timesuite'),
            'time_in_lieu'  => __('Time in lieu', 'timesuite'),
        ];
    }

    public function isOfficeCheckboxEnabled(): bool
    {
        return $this->settings->isOfficeCheckboxEnabled();
    }

    /**
     * Get the configured daily hours from settings.
     *
     * This value is used for calculating total hours in timesheets.
     */
    public function getDailyHours(): float
    {
        return $this->settings->getDailyHours();
    }

    /**
     * @return array<string, mixed>
     */
    public function getMonth(int $userId, int $year, int $month): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $days           = $this->buildDaysList($year, $month);
        $stored         = $this->loadMonth($userId, $year, $month);
        $entries        = [];
        $workWeek       = $this->getWorkWeekForUser($userId);
        $holidayMap     = $this->getHolidayMapForMonth($year, $month);
        $approvals      = isset($stored['approvals']) && is_array($stored['approvals']) ? $stored['approvals'] : [];
        foreach ($days as $date => $info) {
            $defaultType = $this->defaultTypeForDate($userId, $date, $workWeek, $holidayMap);
            $isScheduledWorkDay = $defaultType === 'working_day';
            $storedOffice = $stored['entries'][$date]['in_office'] ?? null;
            $storedEntry = isset($stored['entries'][$date]) && is_array($stored['entries'][$date])
                ? $stored['entries'][$date]
                : [];
            $entryType = $this->normalizeDayType($storedEntry['type'] ?? $defaultType);
            if ($this->isOutsideEmploymentDates($userId, $date)) {
                $entryType = 'not_employed';
            }
            if (! isset($holidayMap[$date]) && in_array($entryType, ['holiday', 'half_holiday'], true)) {
                $entryType = $defaultType;
            }
            $needsApproval = $this->requiresApprovalForDate($date, $entryType, $workWeek, $holidayMap);
            $approvalStatus = $needsApproval ? $this->resolveApprovalStatus($approvals, $date) : null;
            $scheduledHours = $entryType === 'not_employed'
                ? 0.0
                : $this->resolveScheduledHoursForDate($userId, $date, $storedEntry);
            $entryHours = $storedEntry['hours'] ?? null;
            $coverageSource = $this->normalizeCoverageSource($storedEntry['coverage_source'] ?? null);
            if ($entryType === 'not_employed') {
                $entryHours = null;
                $coverageSource = null;
            }
            if (($entryType === 'half_working' || $entryType === 'half_holiday') && $entryHours === null) {
                $entryHours = $this->normalizeHalfDayHours($scheduledHours);
            }
            $entries[] = [
                'date'  => $date,
                'label' => $info['label'],
                'type'  => $entryType,
                'notes' => $storedEntry['notes'] ?? '',
                'hours' => $entryHours,
                'scheduled_hours' => $scheduledHours,
                'default_type' => $defaultType,
                'is_scheduled_work_day' => $isScheduledWorkDay,
                'coverage_source' => $coverageSource,
                'in_office' => $this->typeSupportsInOffice($entryType)
                    ? $this->normalizeInOffice($storedOffice)
                    : false,
                'approval_status' => $approvalStatus,
                'needs_approval' => $needsApproval,
            ];
        }

        return [
            'user_id'    => $userId,
            'year'       => $year,
            'month'      => $month,
            'days_count' => count($days),
            'entries'    => $entries,
            'status'     => $stored['status'] ?? 'draft',
            'updated_at' => $stored['updated_at'] ?? null,
            'submitted_at' => $stored['submitted_at'] ?? null,
            'approved_at' => $stored['approved_at'] ?? null,
            'denied_at' => $stored['denied_at'] ?? null,
            'denied_comment' => $stored['denied_comment'] ?? null,
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $entries
     */
    public function saveMonth(
        int $userId,
        int $year,
        int $month,
        array $entries,
        string $status = 'draft',
        ?int $actorId = null,
        bool $canOverrideRules = false
    ): array {
        [$year, $month] = $this->normalizeYearMonth($year, $month);

        $this->assertMonthEditable($year, $month, $canOverrideRules);

        $existing = $this->loadMonth($userId, $year, $month);

        $existingStatus = $existing['status'] ?? 'draft';
        $lockedStatuses = ['locked'];

        if (in_array($existingStatus, $lockedStatuses, true) && ! $canOverrideRules) {
            throw new ValidationException(__('This timesheet is locked and cannot be edited.', 'timesuite'));
        }

        // Submitted months are under review and cannot be edited directly.
        // Use the explicit undo-submit flow before manager decisions are made.
        if ('submitted' === $existingStatus && ! $canOverrideRules) {
            if ('submitted' === $status) {
                return $this->getMonth($userId, $year, $month);
            }

            throw new ValidationException(
                __('This timesheet is under review. Use Undo Submit before making changes.', 'timesuite')
            );
        }

        $skeleton   = $this->buildDaysList($year, $month);
        $normalized = [];
        $workWeek   = $this->getWorkWeekForUser($userId);
        $holidayMap = $this->getHolidayMapForMonth($year, $month);
        $officeEnabled = $this->settings->isOfficeCheckboxEnabled();

        foreach ($entries as $entry) {
            if (! is_array($entry)) {
                continue;
            }

            $date = isset($entry['date']) ? sanitize_text_field((string) $entry['date']) : null;

            if (! $date || ! isset($skeleton[$date])) {
                throw new ValidationException(
                    sprintf(__('Invalid date supplied: %s', 'timesuite'), (string) ($entry['date'] ?? ''))
                );
            }

            if ($this->isOutsideEmploymentDates($userId, $date)) {
                $normalized[$date] = [
                    'type'  => 'not_employed',
                    'notes' => '',
                    'hours' => null,
                    'scheduled_hours' => 0.0,
                    'coverage_source' => null,
                    'in_office' => false,
                ];
                continue;
            }

            $type = $this->normalizeDayType($entry['type'] ?? null, true);

            $this->assertTypeAllowedForDate($date, $type, $workWeek, $holidayMap);

            $notes = isset($entry['notes']) ? sanitize_textarea_field((string) $entry['notes']) : '';
            $existingEntry = isset($existing['entries'][$date]) && is_array($existing['entries'][$date])
                ? $existing['entries'][$date]
                : [];
            $scheduledHours = $this->resolveScheduledHoursForDate($userId, $date, $existingEntry);
            $hours = $this->normalizePartialHours($entry['hours'] ?? null);
            $coverageSource = $this->normalizeCoverageSource($entry['coverage_source'] ?? null);
            $storedOffice = $existing['entries'][$date]['in_office'] ?? null;
            $inOffice = $officeEnabled
                ? $this->normalizeInOffice($entry['in_office'] ?? null)
                : $this->normalizeInOffice($storedOffice);

            if (! $this->typeSupportsInOffice($type)) {
                $inOffice = false;
            }

            if ('half_working' === $type) {
                if ($coverageSource === null) {
                    throw new ValidationException(__('Please select a source for the remaining hours.', 'timesuite'));
                }
                $hours = $this->normalizeSplitWorkingHours($hours, $scheduledHours);
            } elseif ('half_holiday' === $type) {
                $hours = $this->normalizeHalfDayHours($scheduledHours);
                $coverageSource = null;
            } elseif ('time_in_lieu' === $type) {
                if (! $this->isWorkingDay($date, $workWeek, $holidayMap)) {
                    throw new ValidationException(__('Time in lieu can only be used on scheduled working days.', 'timesuite'));
                }

                $hours = null;
                $coverageSource = null;
            } elseif ('overtime' === $type) {
                if ($hours === null || $hours < 0.5 || $hours > 24) {
                    throw new ValidationException(__('Overtime hours must be between 0.5 and 24.', 'timesuite'));
                }

                $coverageSource = null;
            } else {
                $hours = null;
                $coverageSource = null;
            }

            $normalized[$date] = [
                'type'  => $type,
                'notes' => $this->truncateNotes($notes, 500),
                'hours' => $hours,
                'scheduled_hours' => $scheduledHours,
                'coverage_source' => $coverageSource,
                'in_office' => $inOffice,
            ];
        }

        foreach (array_keys($skeleton) as $date) {
            if (! isset($normalized[$date])) {
                $defaultType = $this->defaultTypeForDate($userId, $date, $workWeek, $holidayMap);
                $existingEntry = isset($existing['entries'][$date]) && is_array($existing['entries'][$date])
                    ? $existing['entries'][$date]
                    : [];
                $scheduledHours = $defaultType === 'not_employed'
                    ? 0.0
                    : $this->resolveScheduledHoursForDate($userId, $date, $existingEntry);
                $normalized[$date] = [
                    'type'  => $defaultType,
                    'notes' => '',
                    'hours' => null,
                    'scheduled_hours' => $scheduledHours,
                    'coverage_source' => null,
                    'in_office' => $this->typeSupportsInOffice($defaultType)
                        ? (
                            $officeEnabled
                                ? false
                                : $this->normalizeInOffice($existing['entries'][$date]['in_office'] ?? null)
                        )
                        : false,
                ];
            }
        }

        $approvals = isset($existing['approvals']) && is_array($existing['approvals']) ? $existing['approvals'] : [];

        foreach ($normalized as $date => $entry) {
            $previous = $existing['entries'][$date] ?? null;

            if (! $previous || ! $this->entryChanged($previous, $entry)) {
                continue;
            }

            $approvalStatus = $this->resolveApprovalStatus($approvals, $date);

            if ($approvalStatus !== null && ! $canOverrideRules) {
                throw new ValidationException(
                    __('This entry has already been approved or denied. Ask your manager to reset it.', 'timesuite')
                );
            }

            unset($approvals[$date]);
        }

        if ('submitted' === $status) {
            $this->finalizeSubmittedMonth($userId, $year, $month, $normalized, $approvals, $actorId ?: $userId);

            return $this->getMonth($userId, $year, $month);
        }

        // Draft save (including an override-save that returns an
        // already-submitted/approved/locked month back to draft).
        $now = current_time('mysql', true);

        if ($canOverrideRules) {
            $existingStatus = $existing['status'] ?? 'draft';

            if (in_array($existingStatus, ['submitted', 'approved', 'locked'], true)) {
                $this->compTimeService->clearMonthlyDebits($userId, $year, $month);
                $this->compTimeService->clearMonthlyCredits($userId, $year, $month);
            }
        }

        $data = [
            'entries'        => $normalized,
            'status'         => 'draft',
            'updated_at'     => $now,
            'updated_by'     => $actorId ?: $userId,
            'approvals'      => $approvals,
            'submitted_at'   => null,
            'submitted_by'   => null,
            'approved_at'    => null,
            'approved_by'    => null,
            'denied_at'      => null,
            'denied_by'      => null,
            'denied_comment' => null,
        ];

        $this->persistMonth($userId, $year, $month, $data);

        return $this->getMonth($userId, $year, $month);
    }

    /**
     * Finalizes a month into submitted-or-locked state from a given set of
     * (already normalized) entries: runs the auto-lock decision
     * (monthRequiresApproval), applies comp-time credits/debits (idempotent
     * -- see CompTimeService::applyMonthlyDebits()/applyMonthlyCredits()),
     * sets header timestamps, and persists.
     *
     * Shared by saveMonth() (the normal employee-submit path) and the P3.1
     * rescue methods (rescueSubmitOnBehalf(), rescueForceLock()) so there is
     * exactly one place that knows how a month becomes submitted/locked --
     * an earlier rescue-actions draft used a shallow status-only update
     * instead and would have desynced the comp-time ledger from the month
     * status. See docs/p3.1-admin-rescue-actions-plan.md §1.1.
     *
     * $forceLock=true skips the auto-lock decision and always results in
     * 'locked', used when an operator explicitly force-locks a month
     * regardless of whether any day still requires approval.
     *
     * @param array<string, array<string, mixed>> $normalizedEntries
     * @param array<string, array<string, mixed>> $approvals
     *
     * @return string The resulting status: 'submitted' or 'locked'.
     */
    private function finalizeSubmittedMonth(
        int $userId,
        int $year,
        int $month,
        array $normalizedEntries,
        array $approvals,
        int $actorId,
        bool $forceLock = false
    ): string {
        $workWeek   = $this->getWorkWeekForUser($userId);
        $holidayMap = $this->getHolidayMapForMonth($year, $month);
        $now        = current_time('mysql', true);

        $monthRequiresApproval = $this->monthRequiresApproval($normalizedEntries, $workWeek, $holidayMap);
        $newStatus = ($forceLock || ! $monthRequiresApproval) ? 'locked' : 'submitted';

        $data = [
            'entries'    => $normalizedEntries,
            'status'     => $newStatus,
            'updated_at' => $now,
            'updated_by' => $actorId,
            'approvals'  => $approvals,
        ];

        if ('submitted' === $newStatus) {
            $data['submitted_at'] = $now;
            $data['submitted_by'] = $actorId;
            $data['approved_at'] = null;
            $data['approved_by'] = null;
            $data['denied_at'] = null;
            $data['denied_by'] = null;
            $data['denied_comment'] = null;
        } else { // locked
            $data['submitted_at'] = $now;
            $data['submitted_by'] = $actorId;
            $data['approved_at'] = $now;
            $data['approved_by'] = $actorId;
            $data['denied_at'] = null;
            $data['denied_by'] = null;
            $data['denied_comment'] = null;
        }

        // Credits BEFORE debits, deliberately: applyMonthlyDebits() reads
        // ALL of the user's credit rows (not scoped to this month) to check
        // available balance, so a month with BOTH an overtime day (credit)
        // AND a time-in-lieu day (debit) needs its own new credit already
        // written before the debit balance check runs, or a legitimate,
        // fully-self-funded submission would be wrongly rejected. (Verified
        // by tests/Unit/MonthlyTimesheetServiceTest.php::
        // testSubmittingMonthAppliesCompTimeCreditsBeforeDebits -- swapping
        // this order breaks that test.) Because credits can't throw but
        // debits can (insufficient balance), that ordering alone leaves a
        // partial-write risk: if debits throws, the credits from this same
        // call already landed in the ledger while the header status never
        // changes. Wrapping the whole sequence in a transaction closes that
        // gap without touching the ordering. See
        // docs/p3.1-admin-rescue-actions-plan.md §1.1 correction.
        $this->monthlyRepository->beginTransaction();

        try {
            $this->applyCompTimeCredits($userId, $year, $month, $normalizedEntries, $actorId);
            $this->applyCompTimeDebits($userId, $year, $month, $normalizedEntries, $actorId);
            $this->persistMonth($userId, $year, $month, $data);

            $this->monthlyRepository->commitTransaction();
        } catch (\Throwable $e) {
            $this->monthlyRepository->rollbackTransaction();

            throw $e;
        }

        if ('submitted' === $newStatus) {
            $this->sendSubmissionNotification($userId, $year, $month);
        }

        return $newStatus;
    }

    /**
     * @return array{status:string, submitted_at:?string, approved_at:?string, denied_at:?string, denied_comment:?string, updated_at:?string}
     */
    public function getMonthMeta(int $userId, int $year, int $month): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $stored = $this->loadMonthMeta($userId, $year, $month);

        return [
            'status' => $stored['status'] ?? 'draft',
            'submitted_at' => $stored['submitted_at'] ?? null,
            'approved_at' => $stored['approved_at'] ?? null,
            'denied_at' => $stored['denied_at'] ?? null,
            'denied_comment' => $stored['denied_comment'] ?? null,
            'updated_at' => $stored['updated_at'] ?? null,
        ];
    }

    /**
     * Update the overall status of a timesheet month.
     * Delegates to TimesheetApprovalService.
     *
     * @return array<string, mixed>
     */
    public function updateMonthStatus(
        int $userId,
        int $year,
        int $month,
        string $status,
        ?int $actorId = null,
        ?string $comment = null
    ): array {
        return $this->getApprovalService()->updateMonthStatus($userId, $year, $month, $status, $actorId, $comment);
    }

    /**
     * Update approval status for a single day.
     * Delegates to TimesheetApprovalService.
     *
     * @return array<string, mixed>
     */
    public function updateDayApproval(
        int $userId,
        int $year,
        int $month,
        string $date,
        string $status,
        int $actorId,
        ?string $comment = null
    ): array {
        return $this->getApprovalService()->updateDayApproval($userId, $year, $month, $date, $status, $actorId, $comment);
    }

    /**
     * Reset approval status for a single day.
     *
     * @return array<string, mixed>
     */
    public function resetDayApproval(
        int $userId,
        int $year,
        int $month,
        string $date,
        int $actorId
    ): array {
        return $this->getApprovalService()->resetDayApproval($userId, $year, $month, $date, $actorId);
    }

    /**
     * Approve all days requiring approval.
     * Delegates to TimesheetApprovalService.
     *
     * @return array<string, mixed>
     */
    public function approveAllDays(int $userId, int $year, int $month, int $actorId): array
    {
        return $this->getApprovalService()->approveAllDays($userId, $year, $month, $actorId);
    }

    /**
     * Deny all days requiring approval.
     * Delegates to TimesheetApprovalService.
     *
     * @return array<string, mixed>
     */
    public function denyAllDays(int $userId, int $year, int $month, int $actorId, ?string $comment = null): array
    {
        return $this->getApprovalService()->denyAllDays($userId, $year, $month, $actorId, $comment);
    }

    /**
     * Reset all day approvals.
     * Delegates to TimesheetApprovalService.
     *
     * @return array<string, mixed>
     */
    public function resetAllApprovals(int $userId, int $year, int $month, int $actorId): array
    {
        return $this->getApprovalService()->resetAllApprovals($userId, $year, $month, $actorId);
    }

    /**
     * Finalize manager review once all approval-required days were reviewed.
     *
     * @return array<string, mixed>
     */
    public function finalizeReview(
        int $userId,
        int $year,
        int $month,
        int $actorId,
        ?string $comment = null
    ): array {
        return $this->getApprovalService()->finalizeReview($userId, $year, $month, $actorId, $comment);
    }

    /**
     * Return whether the month can be reverted from submitted to draft without manager intervention.
     */
    public function canUndoSubmit(int $userId, int $year, int $month): bool
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $stored = $this->loadMonth($userId, $year, $month);

        if (($stored['status'] ?? 'draft') !== 'submitted') {
            return false;
        }

        $approvals = isset($stored['approvals']) && is_array($stored['approvals']) ? $stored['approvals'] : [];

        foreach ($approvals as $approval) {
            if (! is_array($approval)) {
                continue;
            }

            $status = strtolower((string) ($approval['status'] ?? ''));
            if (in_array($status, ['approved', 'denied'], true)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Reopen a locked month back to draft and clear prior review decisions.
     *
     * @return array<string, mixed>
     */
    public function reopenLockedMonth(int $userId, int $year, int $month, int $actorId): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $stored = $this->loadMonth($userId, $year, $month);

        if (($stored['status'] ?? 'draft') !== 'locked') {
            throw new ValidationException(__('Only locked timesheets can be reopened.', 'timesuite'));
        }

        return $this->reopenMonthToDraft($userId, $year, $month, $actorId);
    }

    /**
     * Rescue (P3.1): return a month to draft and clear prior review
     * decisions + comp-time, regardless of its current status. Unlike
     * reopenLockedMonth(), this has no 'locked'-only guard -- the caller
     * (RescueController) is responsible for whatever precondition it wants
     * to enforce for its own surface. reopenLockedMonth() delegates here
     * after its own guard passes, so there is one place that knows how to
     * reset a month to draft.
     *
     * @return array<string, mixed>
     */
    public function reopenMonthToDraft(int $userId, int $year, int $month, int $actorId): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $stored = $this->loadMonth($userId, $year, $month);

        $now = current_time('mysql', true);
        $stored['status'] = 'draft';
        $stored['approvals'] = [];
        $stored['updated_at'] = $now;
        $stored['updated_by'] = $actorId;
        $stored['submitted_at'] = null;
        $stored['submitted_by'] = null;
        $stored['approved_at'] = null;
        $stored['approved_by'] = null;
        $stored['denied_at'] = null;
        $stored['denied_by'] = null;
        $stored['denied_comment'] = null;

        $this->compTimeService->clearMonthlyDebits($userId, $year, $month);
        $this->compTimeService->clearMonthlyCredits($userId, $year, $month);

        $this->persistMonth($userId, $year, $month, $stored);

        return $this->getMonth($userId, $year, $month);
    }

    /**
     * Rescue (P3.1): submit an employee's already-entered month on their
     * behalf, exactly as if they had clicked Submit -- including the
     * auto-lock decision and comp-time credits/debits, via
     * finalizeSubmittedMonth(). Operates on the currently stored entries;
     * never alters day data. Any stale day-approvals (e.g. left over from a
     * prior denial) are cleared, matching a fresh submit.
     *
     * Precondition (only from draft/denied) is enforced by the caller.
     * finalizeSubmittedMonth()'s comp-time apply can throw ValidationException
     * (e.g. an unfunded time-in-lieu day) -- this propagates to the caller.
     *
     * @return array{timesheet: array<string, mixed>, to: string}
     */
    public function rescueSubmitOnBehalf(int $userId, int $year, int $month, int $actorId): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $stored  = $this->loadMonth($userId, $year, $month);
        $entries = isset($stored['entries']) && is_array($stored['entries']) ? $stored['entries'] : [];

        $to = $this->finalizeSubmittedMonth($userId, $year, $month, $entries, [], $actorId);

        return ['timesheet' => $this->getMonth($userId, $year, $month), 'to' => $to];
    }

    /**
     * Rescue (P3.1): force a month to 'locked' regardless of whether any day
     * still requires approval, via finalizeSubmittedMonth(forceLock:true) --
     * this applies comp-time (idempotent) so the ledger stays consistent
     * with the "submitted-or-later => comp-time applied" invariant even
     * when locking straight from draft. Existing day approvals are
     * preserved (locking should not erase a manager's prior decisions).
     *
     * Precondition (not already locked) is enforced by the caller.
     *
     * @return array{timesheet: array<string, mixed>}
     */
    public function rescueForceLock(int $userId, int $year, int $month, int $actorId): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $stored     = $this->loadMonth($userId, $year, $month);
        $entries    = isset($stored['entries']) && is_array($stored['entries']) ? $stored['entries'] : [];
        $approvals  = isset($stored['approvals']) && is_array($stored['approvals']) ? $stored['approvals'] : [];

        $this->finalizeSubmittedMonth($userId, $year, $month, $entries, $approvals, $actorId, forceLock: true);

        return ['timesheet' => $this->getMonth($userId, $year, $month)];
    }

    /**
     * Rescue (P3.1): re-derive whether a *submitted* month should have
     * auto-locked. Repairs a month stuck 'submitted' when none of its days
     * actually require approval -- the auto-lock in saveMonth()/
     * finalizeSubmittedMonth() never ran for it (legacy month, aborted
     * save, a prior shallow status flip, etc.). Reuses the real
     * monthRequiresApproval() decision, and routes the actual transition
     * through rescueForceLock() so the comp-time path is identical to a
     * normal auto-lock (even though comp-time was already applied at
     * submit time, so the re-apply here is an idempotent no-op).
     *
     * Only ever transitions submitted -> locked; never downgrades.
     *
     * @return array{timesheet: array<string, mixed>, changed: bool, from: string, to: string}
     */
    public function recalculateMonthStatus(int $userId, int $year, int $month, int $actorId): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);
        $stored = $this->loadMonth($userId, $year, $month);
        $from   = (string) ($stored['status'] ?? 'draft');

        if ('submitted' !== $from) {
            return [
                'timesheet' => $this->getMonth($userId, $year, $month),
                'changed'   => false,
                'from'      => $from,
                'to'        => $from,
            ];
        }

        $entries  = isset($stored['entries']) && is_array($stored['entries']) ? $stored['entries'] : [];
        $requires = $this->monthRequiresApproval(
            $entries,
            $this->getWorkWeekForUser($userId),
            $this->getHolidayMapForMonth($year, $month)
        );

        if ($requires) {
            return [
                'timesheet' => $this->getMonth($userId, $year, $month),
                'changed'   => false,
                'from'      => 'submitted',
                'to'        => 'submitted',
            ];
        }

        $this->rescueForceLock($userId, $year, $month, $actorId);

        return [
            'timesheet' => $this->getMonth($userId, $year, $month),
            'changed'   => true,
            'from'      => 'submitted',
            'to'        => 'locked',
        ];
    }

    /**
     * Read-only diagnostic aggregator for the rescue tool (P3.1). Deliberately
     * does NOT call loadMonth()/getMonth() -- both persist (materialize) a
     * legacy-only month into the canonical table as a side effect of reading
     * it via persistMonth(). This method replicates that resolution using
     * only read-only primitives (getHeader/getEntries/loadLegacyMonth) so an
     * operator can diagnose a month without writing anything.
     *
     * @return array<string, mixed>
     */
    public function diagnoseMonth(int $userId, int $year, int $month): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);

        $header  = $this->monthlyRepository->getHeader($userId, $year, $month);
        $legacyRaw = get_user_meta($userId, $this->metaKey($year, $month), true);

        $canonicalExists = null !== $header;
        $legacyExists    = is_array($legacyRaw);
        $materializedFromLegacy = ! $canonicalExists && $legacyExists;

        // Deliberately NOT loadMonth() -- that method persists (materializes)
        // a legacy-only month as a side effect of reading it. Replicate its
        // resolution here using only the read-only primitives so diagnosing
        // a month never writes anything.
        if ($canonicalExists) {
            $entryRows = $this->monthlyRepository->getEntries((int) $header['id']);
            $stored = $this->hydrateMonth($header, $entryRows);
        } else {
            $stored = $this->loadLegacyMonth($userId, $year, $month) ?? [
                'entries' => [],
                'approvals' => [],
                'status' => 'draft',
            ];
        }

        $status  = (string) ($stored['status'] ?? 'draft');
        $entries = isset($stored['entries']) && is_array($stored['entries']) ? $stored['entries'] : [];

        $requiresApproval = $this->monthRequiresApproval(
            $entries,
            $this->getWorkWeekForUser($userId),
            $this->getHolidayMapForMonth($year, $month)
        );
        $shouldHaveAutoLocked = 'submitted' === $status && ! $requiresApproval;

        // "Expected" is NOT just "the month is submitted/approved/locked" --
        // a normal month with zero overtime/time-in-lieu entries produces
        // zero ledger rows even when submitted (buildCompTimeCredits()/
        // buildCompTimeDebits() both return an empty array, and
        // CompTimeService's apply methods are no-ops for an empty input).
        // Treating "status implies comp-time" as the rule would flag every
        // ordinary submitted month with no comp-time usage as a false
        // "inconsistent" -- see docs/p3.1-admin-rescue-actions-plan.md §1.1
        // correction. Expected is instead: the month is submitted-or-later
        // AND its entries actually generate at least one credit or debit.
        $monthWouldGenerateCompTime = ! empty($this->buildCompTimeCredits($entries))
            || ! empty($this->buildCompTimeDebits($entries));
        $comptimeExpected  = in_array($status, ['submitted', 'approved', 'locked'], true)
            && $monthWouldGenerateCompTime;
        $comptimeApplied   = $this->compTimeService->hasMonthlyLedgerEntries($userId, $year, $month);
        $comptimeConsistent = $comptimeApplied === $comptimeExpected;

        $legacyStatus = $legacyExists ? (string) ($legacyRaw['status'] ?? 'draft') : null;
        $crossLayerMismatch = $canonicalExists && $legacyExists
            && null !== $legacyStatus && $legacyStatus !== $status;

        return [
            'canonical_row_exists'     => $canonicalExists,
            'legacy_meta_exists'       => $legacyExists,
            'materialized_from_legacy' => $materializedFromLegacy,
            'status'                   => $status,
            'requires_approval'        => $requiresApproval,
            'should_have_auto_locked'  => $shouldHaveAutoLocked,
            'comptime_applied'         => $comptimeApplied,
            'comptime_expected'        => $comptimeExpected,
            'comptime_consistent'      => $comptimeConsistent,
            'cross_layer_mismatch'     => $crossLayerMismatch,
        ];
    }

    /**
     * @return array{editable: bool, reason: string|null, reason_code: string}
     */
    public function getEditability(int $year, int $month, bool $canOverrideRules = false): array
    {
        [$year, $month] = $this->normalizeYearMonth($year, $month);

        if ($canOverrideRules) {
            return ['editable' => true, 'reason' => null, 'reason_code' => EditabilityReason::OVERRIDE_ACTIVE];
        }

        $currentYear  = (int) current_time('Y');
        $currentMonth = (int) current_time('n');
        $currentDay   = (int) current_time('j');
        $cutoff       = $this->normalizeCutoffDay($this->settings->getPeriodCutoffDay());

        if ($year === $currentYear && $month === $currentMonth) {
            return ['editable' => true, 'reason' => null, 'reason_code' => EditabilityReason::CURRENT_MONTH_OPEN];
        }

        [$prevYear, $prevMonth] = $this->previousMonth($currentYear, $currentMonth);

        if ($year === $prevYear && $month === $prevMonth) {
            if (! $this->settings->isBackdatingAllowed()) {
                return [
                    'editable' => false,
                    'reason'   => __('Backdating is disabled for previous months.', 'timesuite'),
                    'reason_code' => EditabilityReason::BACKDATING_DISABLED,
                ];
            }

            if ($currentDay > $cutoff) {
                return [
                    'editable' => false,
                    'reason'   => sprintf(
                        __('Previous months lock after day %d of the current month.', 'timesuite'),
                        $cutoff
                    ),
                    'reason_code' => EditabilityReason::PERIOD_CUTOFF_PASSED,
                ];
            }

            return [
                'editable' => true,
                'reason' => null,
                'reason_code' => EditabilityReason::PREVIOUS_MONTH_BEFORE_CUTOFF,
            ];
        }

        return [
            'editable' => false,
            'reason'   => __('Only the current or previous month can be edited.', 'timesuite'),
            'reason_code' => EditabilityReason::OUTSIDE_EDITABLE_WINDOW,
        ];
    }

    /**
     * @return array<string, array{label: string}>
     */
    private function buildDaysList(int $year, int $month): array
    {
        $daysInMonth = $this->daysInMonth($year, $month);
        $list        = [];

        for ($day = 1; $day <= $daysInMonth; ++$day) {
            $date  = sprintf('%04d-%02d-%02d', $year, $month, $day);
            $label = wp_date('D, M j', strtotime($date . ' UTC'));
            $list[$date] = ['label' => $label];
        }

        return $list;
    }

    /**
     * @return array<string, string> Map of Y-m-d => holiday type.
     */
    private function getHolidayMapForMonth(int $year, int $month): array
    {
        $daysInMonth = $this->daysInMonth($year, $month);
        $startDate = sprintf('%04d-%02d-01', $year, $month);
        $endDate = sprintf('%04d-%02d-%02d', $year, $month, $daysInMonth);

        return $this->holidayRangeService->getHolidayMapForRange($startDate, $endDate);
    }

    /**
     * @param array<string, string> $holidayMap
     */
    private function defaultTypeForDate(int $userId, string $date, array $workWeek, array $holidayMap): string
    {
        if ($this->isOutsideEmploymentDates($userId, $date)) {
            return 'not_employed';
        }

        if (! $this->isWorkingDay($date, $workWeek, $holidayMap)) {
            if (isset($holidayMap[$date])) {
                return $holidayMap[$date] === 'half_holiday' ? 'half_holiday' : 'holiday';
            }

            return 'day_off';
        }

        return 'working_day';
    }

    /**
     * @param array<string, string> $holidayMap
     */
    private function assertTypeAllowedForDate(string $date, string $type, array $workWeek, array $holidayMap): void
    {
        if (isset($holidayMap[$date])) {
            $defaultType = $holidayMap[$date] === 'half_holiday' ? 'half_holiday' : 'holiday';

            if (in_array($type, [$defaultType, 'overtime'], true)) {
                return;
            }

            throw new ValidationException(__('Only the holiday default or overtime can be selected on holidays.', 'timesuite'));
        }

        if (! $this->isWorkingDay($date, $workWeek, $holidayMap)) {
            if (in_array($type, ['day_off', 'overtime'], true)) {
                return;
            }

            throw new ValidationException(__('Only non-working day or overtime can be selected on non-working days.', 'timesuite'));
        }

        if ($type === 'holiday' || $type === 'half_holiday') {
            throw new ValidationException(__('Holiday types can only be used on holiday dates.', 'timesuite'));
        }
    }

    private function isDefaultHolidayType(string $date, string $type, array $holidayMap): bool
    {
        if (! isset($holidayMap[$date])) {
            return false;
        }

        $defaultType = $holidayMap[$date] === 'half_holiday' ? 'half_holiday' : 'holiday';

        return $type === $defaultType;
    }

    private function isDefaultNonWorkingType(string $date, string $type, array $workWeek, array $holidayMap): bool
    {
        if (isset($holidayMap[$date])) {
            return false;
        }

        if ($type !== 'day_off') {
            return false;
        }

        return ! $this->isWorkingDay($date, $workWeek, $holidayMap);
    }

    private function isApprovalFreeType(string $type): bool
    {
        return in_array($type, ['working_day', 'holiday', 'half_holiday', 'not_employed'], true);
    }

    private function requiresApprovalForDate(string $date, string $type, array $workWeek, array $holidayMap): bool
    {
        if ($this->isDefaultHolidayType($date, $type, $holidayMap)) {
            return false;
        }

        if ($this->isDefaultNonWorkingType($date, $type, $workWeek, $holidayMap)) {
            return false;
        }

        if (isset($holidayMap[$date])) {
            return true;
        }

        if ($this->isApprovalFreeType($type)) {
            return false;
        }

        return true;
    }


    private function metaKey(int $year, int $month): string
    {
        return self::META_PREFIX . sprintf('%04d_%02d', $year, $month);
    }

    /**
     * @return array{0:int,1:int}
     */
    private function normalizeYearMonth(int $year, int $month): array
    {
        if ($year < 2000 || $year > 2100) {
            throw new ValidationException(__('Year out of supported range.', 'timesuite'));
        }

        if ($month < 1 || $month > 12) {
            throw new ValidationException(__('Month must be between 1 and 12.', 'timesuite'));
        }

        return [$year, $month];
    }
    private function assertMonthEditable(int $year, int $month, bool $canOverrideRules): void
    {
        $status = $this->getEditability($year, $month, $canOverrideRules);

        if (! $status['editable']) {
            throw new ValidationException($status['reason'] ?? __('Timesheet is locked.', 'timesuite'));
        }
    }

    private function normalizeCutoffDay(int $cutoff): int
    {
        return max(1, min(31, $cutoff));
    }

    private function normalizeDayType(mixed $value, bool $strict = false): string
    {
        $type = is_string($value) ? sanitize_key($value) : '';

        if ($type === '') {
            return 'working_day';
        }

        if (isset(self::LEGACY_TYPE_MAP[$type])) {
            $type = self::LEGACY_TYPE_MAP[$type];
        }

        if (! array_key_exists($type, $this->getDayTypes())) {
            if ($strict) {
                throw new ValidationException(
                    sprintf(__('Invalid day type: %s', 'timesuite'), (string) $value)
                );
            }

            return 'working_day';
        }

        return $type;
    }

    /**
     * @return array<string, string>
     */
    private function getBuiltInDayTypes(): array
    {
        return [
            'working_day'  => __('Working day', 'timesuite'),
            'half_working' => __('Half working day', 'timesuite'),
            'overtime'     => __('Overtime', 'timesuite'),
            'time_in_lieu' => __('Time in lieu', 'timesuite'),
            'day_off'      => __('Day off', 'timesuite'),
            'sick_day'     => __('Sick day', 'timesuite'),
            'holiday'      => __('Holiday', 'timesuite'),
            'half_holiday' => __('Half-day holiday', 'timesuite'),
            'not_employed' => __('Not employed', 'timesuite'),
        ];
    }

    /**
     * @return array<string, string>
     */
    private function getBuiltInSelectableDayTypes(): array
    {
        $types = $this->getBuiltInDayTypes();
        unset($types['not_employed']);

        return $types;
    }

    /**
     * @return array<string, string>
     */
    private function getCustomLeaveTypeMap(bool $activeOnly): array
    {
        $types = [];

        foreach ($this->settings->getCustomLeaveTypes() as $item) {
            $key = isset($item['key']) ? sanitize_key((string) $item['key']) : '';
            $label = isset($item['label']) ? sanitize_text_field((string) $item['label']) : '';
            $isActive = ! array_key_exists('active', $item) || (bool) $item['active'];

            if ($key === '' || $label === '') {
                continue;
            }

            if ($activeOnly && ! $isActive) {
                continue;
            }

            $types[$key] = $label;
        }

        return $types;
    }

    private function normalizeCoverageSource(mixed $value): ?string
    {
        if (! is_string($value) || '' === trim($value)) {
            return null;
        }

        $value = sanitize_key($value);

        if (isset(self::LEGACY_PART_DAY_SOURCE_MAP[$value])) {
            $value = self::LEGACY_PART_DAY_SOURCE_MAP[$value];
        }

        if (! array_key_exists($value, $this->getPartDaySources())) {
            return null;
        }

        return $value;
    }

    private function normalizePartialHours(mixed $value): ?float
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_int($value)) {
            return (float) $value;
        }

        if (is_float($value)) {
            $rounded = round($value * 2) / 2;

            if (abs($rounded - $value) > 0.001) {
                return null;
            }

            return $rounded;
        }

        if (is_string($value)) {
            $value = trim($value);

            if ('' === $value) {
                return null;
            }

            if (preg_match('/^\d+(?:\.\d+)?$/', $value) === 1) {
                $floatValue = (float) $value;
                $rounded = round($floatValue * 2) / 2;

                if (abs($rounded - $floatValue) > 0.001) {
                    return null;
                }

                return $rounded;
            }
        }

        return null;
    }

    private function normalizeHalfDayHours(float $dailyHours): float
    {
        return round($dailyHours / 2, 2);
    }

    private function normalizeSplitWorkingHours(?float $hours, float $scheduledHours): float
    {
        if ($hours === null) {
            return $this->normalizeHalfDayHours($scheduledHours);
        }

        if ($hours < 0.5 || $hours >= $scheduledHours) {
            throw new ValidationException(
                __('Worked hours for a half day must be at least 0.5 and less than the scheduled hours.', 'timesuite')
            );
        }

        return round($hours, 2);
    }

    /**
     * @param array<string, array<string, mixed>> $entries
     * @param array<string, string> $holidayMap
     */
    private function monthRequiresApproval(array $entries, array $workWeek, array $holidayMap): bool
    {
        foreach ($entries as $date => $entry) {
            $type = isset($entry['type']) ? (string) $entry['type'] : '';

            if ($this->requiresApprovalForDate((string) $date, $type, $workWeek, $holidayMap)) {
                return true;
            }
        }

        return false;
    }

    private function normalizeInOffice(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return (int) $value === 1;
        }

        if (is_string($value)) {
            $normalized = strtolower(trim($value));

            return in_array($normalized, ['1', 'true', 'yes', 'on'], true);
        }

        return false;
    }

    private function typeSupportsInOffice(string $type): bool
    {
        return in_array($type, self::IN_OFFICE_ALLOWED_DAY_TYPES, true);
    }

    /**
     * @param array<string, array<string, mixed>> $entries
     */
    private function applyCompTimeDebits(int $userId, int $year, int $month, array $entries, int $actorId): void
    {
        $this->compTimeService->applyMonthlyDebits($userId, $year, $month, $this->buildCompTimeDebits($entries), $actorId);
    }

    /**
     * @param array<string, array<string, mixed>> $entries
     */
    private function applyCompTimeCredits(int $userId, int $year, int $month, array $entries, int $actorId): void
    {
        $this->compTimeService->applyMonthlyCredits($userId, $year, $month, $this->buildCompTimeCredits($entries), $actorId);
    }

    /**
     * Which entries in $entries would generate a comp-time debit --
     * extracted so diagnoseMonth() (P3.1) can determine whether a month's
     * entries actually call for comp-time rows, read-only, using the exact
     * same rule applyCompTimeDebits() writes with (rather than a
     * status-only guess that would false-positive on a perfectly normal
     * submitted/locked month with no time-in-lieu usage at all). See
     * docs/p3.1-admin-rescue-actions-plan.md §1.1 correction.
     *
     * @param array<string, array<string, mixed>> $entries
     *
     * @return array<int, array{date: string, minutes: int}>
     */
    private function buildCompTimeDebits(array $entries): array
    {
        $debits = [];

        foreach ($entries as $date => $entry) {
            $scheduledHours = isset($entry['scheduled_hours']) ? (float) $entry['scheduled_hours'] : 0.0;
            $type = (string) ($entry['type'] ?? '');
            $coverageSource = (string) ($entry['coverage_source'] ?? '');

            if ($type === 'time_in_lieu') {
                $missing = max(0, $scheduledHours);
            } elseif ($type === 'half_working' && $coverageSource === 'time_in_lieu') {
                $hoursWorked = isset($entry['hours']) ? (float) $entry['hours'] : 0.0;
                $missing = max(0, $scheduledHours - $hoursWorked);
            } else {
                continue;
            }

            if ($missing <= 0) {
                continue;
            }

            $debits[] = [
                'date' => (string) $date,
                'minutes' => (int) round($missing * 60),
            ];
        }

        return $debits;
    }

    /**
     * Which entries in $entries would generate a comp-time credit -- see
     * buildCompTimeDebits() doc-comment for why this exists as a read-only
     * extraction.
     *
     * @param array<string, array<string, mixed>> $entries
     *
     * @return array<int, array{date: string, minutes: int}>
     */
    private function buildCompTimeCredits(array $entries): array
    {
        $credits = [];

        foreach ($entries as $date => $entry) {
            if (($entry['type'] ?? '') !== 'overtime') {
                continue;
            }

            $hours = isset($entry['hours']) ? (float) $entry['hours'] : 0.0;
            if ($hours <= 0) {
                continue;
            }

            $credits[] = [
                'date' => (string) $date,
                'minutes' => (int) round($hours * 60),
            ];
        }

        return $credits;
    }

    /**
     * @return string[]
     */
    private function getWorkWeekForUser(int $userId): array
    {
        $stored = get_user_meta($userId, 'timesuite_work_week', true);
        $stored = Settings::normalizeWorkWeekDays($stored);

        if (! empty($stored)) {
            return $stored;
        }

        return Settings::normalizeWorkWeekDays($this->settings->getWorkWeek());
    }

    private function resolveScheduledHoursForDate(int $userId, string $date, array $storedEntry = []): float
    {
        if (isset($storedEntry['scheduled_hours']) && is_numeric($storedEntry['scheduled_hours'])) {
            $stored = round((float) $storedEntry['scheduled_hours'], 2);

            if ($stored > 0) {
                return $stored;
            }
        }

        return $this->getDailyHoursForUserDate($userId, $date);
    }

    private function getDailyHoursForUserDate(int $userId, string $date): float
    {
        $dayCode = gmdate('D', strtotime($date . ' UTC'));
        $default = round($this->settings->getDailyHours(), 2);
        $stored = get_user_meta($userId, self::USER_META_DAILY_HOURS_BY_DAY, true);

        if (! is_array($stored)) {
            return $default;
        }

        $hours = $stored[$dayCode] ?? null;

        if (! is_numeric($hours)) {
            return $default;
        }

        $resolved = round((float) $hours, 2);

        if ($resolved < 1 || $resolved > 24) {
            return $default;
        }

        return $resolved;
    }

    /**
     * @return array{0:int,1:int}
     */
    private function previousMonth(int $year, int $month): array
    {
        if ($month === 1) {
            return [$year - 1, 12];
        }

        return [$year, $month - 1];
    }

    private function daysInMonth(int $year, int $month): int
    {
        $date = new \DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month), new \DateTimeZone('UTC'));

        return (int) $date->format('t');
    }

    /**
     * @return array<string, mixed>
     */
    private function loadMonth(int $userId, int $year, int $month): array
    {
        $header = $this->monthlyRepository->getHeader($userId, $year, $month);

        if ($header) {
            $entries = $this->monthlyRepository->getEntries((int) $header['id']);

            return $this->hydrateMonth($header, $entries);
        }

        $legacy = $this->loadLegacyMonth($userId, $year, $month);

        if ($legacy) {
            $this->persistMonth($userId, $year, $month, $legacy);

            return $legacy;
        }

        return [
            'entries' => [],
            'approvals' => [],
            'status'  => 'draft',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function loadMonthMeta(int $userId, int $year, int $month): array
    {
        $header = $this->monthlyRepository->getHeader($userId, $year, $month);

        if ($header) {
            return $this->normalizeHeader($header);
        }

        $legacy = $this->loadLegacyMonth($userId, $year, $month);

        if ($legacy) {
            return $this->normalizeHeader($legacy);
        }

        return [];
    }

    /**
     * @return array<string, mixed>|null
     */
    private function loadLegacyMonth(int $userId, int $year, int $month): ?array
    {
        $data = get_user_meta($userId, $this->metaKey($year, $month), true);

        if (! is_array($data)) {
            return null;
        }

        if (! isset($data['entries']) || ! is_array($data['entries'])) {
            $data['entries'] = [];
        }

        if (! isset($data['approvals']) || ! is_array($data['approvals'])) {
            $data['approvals'] = [];
        }

        return $data;
    }

    /**
     * @param array<string, mixed> $data
     */
    private function persistMonth(int $userId, int $year, int $month, array $data): void
    {
        $header = $this->normalizeHeader($data);
        $entries = isset($data['entries']) && is_array($data['entries']) ? $data['entries'] : [];
        $approvals = isset($data['approvals']) && is_array($data['approvals']) ? $data['approvals'] : [];

        $timesheetId = $this->monthlyRepository->upsertHeader($userId, $year, $month, $header);
        $this->monthlyRepository->upsertEntries($timesheetId, $userId, $entries, $approvals);
    }

    /**
     * @param array<string, mixed> $header
     * @param array<int, array<string, mixed>> $entryRows
     *
     * @return array<string, mixed>
     */
    private function hydrateMonth(array $header, array $entryRows): array
    {
        $data = $this->normalizeHeader($header);
        $entries = [];
        $approvals = [];

        foreach ($entryRows as $row) {
            $date = (string) ($row['work_date'] ?? '');

            if ('' === $date) {
                continue;
            }

            $hours = $row['hours'] ?? null;
            $entries[$date] = [
                'type' => (string) ($row['type'] ?? 'working_day'),
                'notes' => (string) ($row['notes'] ?? ''),
                'hours' => $hours === null ? null : (float) $hours,
                'scheduled_hours' => isset($row['scheduled_hours']) && $row['scheduled_hours'] !== null
                    ? (float) $row['scheduled_hours']
                    : null,
                'coverage_source' => $row['coverage_source'] ?? null,
                'in_office' => ! empty($row['in_office']),
            ];

            if (! empty($row['approval_status'])) {
                $approvals[$date] = [
                    'status' => (string) $row['approval_status'],
                    'by' => isset($row['approval_by']) ? (int) $row['approval_by'] : null,
                    'at' => $row['approval_at'] ?? null,
                    'comment' => $row['approval_comment'] ?? null,
                ];
            }
        }

        $data['entries'] = $entries;
        $data['approvals'] = $approvals;

        if (! isset($data['status'])) {
            $data['status'] = 'draft';
        }

        return $data;
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    private function normalizeHeader(array $data): array
    {
        $keys = [
            'status',
            'updated_at',
            'updated_by',
            'submitted_at',
            'submitted_by',
            'approved_at',
            'approved_by',
            'denied_at',
            'denied_by',
            'denied_comment',
            'created_at',
        ];

        $normalized = [];

        foreach ($keys as $key) {
            if (array_key_exists($key, $data)) {
                $normalized[$key] = $data[$key];
            }
        }

        return $normalized;
    }

    private function resolveApprovalStatus(array $approvals, string $date): ?string
    {
        if (! isset($approvals[$date]) || ! is_array($approvals[$date])) {
            return null;
        }

        $status = $approvals[$date]['status'] ?? null;

        if (! is_string($status)) {
            return null;
        }

        $status = strtolower($status);

        if (! in_array($status, ['approved', 'denied'], true)) {
            return null;
        }

        return $status;
    }

    private function isWorkingDay(string $date, array $workWeek, array $holidayMap): bool
    {
        if (isset($holidayMap[$date])) {
            return false;
        }

        $dayCode = gmdate('D', strtotime($date . ' UTC'));

        return in_array($dayCode, $workWeek, true);
    }

    private function isOutsideEmploymentDates(int $userId, string $date): bool
    {
        $startDate = $this->getEmploymentStartDate($userId);
        $endDate = $this->getEmploymentEndDate($userId);

        return ($startDate !== null && $date < $startDate)
            || ($endDate !== null && $date > $endDate);
    }

    private function getEmploymentStartDate(int $userId): ?string
    {
        $stored = get_user_meta($userId, self::USER_META_HIRE_DATE, true);

        if (! is_string($stored) || trim($stored) === '') {
            return null;
        }

        $date = trim($stored);
        $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d', $date, new \DateTimeZone('UTC'));

        if (! $parsed instanceof \DateTimeImmutable || $parsed->format('Y-m-d') !== $date) {
            return null;
        }

        return $date;
    }

    private function getEmploymentEndDate(int $userId): ?string
    {
        $stored = get_user_meta($userId, self::USER_META_EMPLOYMENT_END_DATE, true);

        if (! is_string($stored) || trim($stored) === '') {
            return null;
        }

        $date = trim($stored);
        $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d', $date, new \DateTimeZone('UTC'));

        if (! $parsed instanceof \DateTimeImmutable || $parsed->format('Y-m-d') !== $date) {
            return null;
        }

        return $date;
    }

    /**
     * @param array<string, mixed> $previous
     * @param array<string, mixed> $current
     */
    private function entryChanged(array $previous, array $current): bool
    {
        $fields = ['type', 'notes', 'hours', 'scheduled_hours', 'coverage_source', 'in_office'];

        foreach ($fields as $field) {
            if (($previous[$field] ?? null) !== ($current[$field] ?? null)) {
                return true;
            }
        }

        return false;
    }

    private function truncateNotes(string $value, int $limit): string
    {
        if ($limit <= 0) {
            return '';
        }

        if (function_exists('mb_substr')) {
            return (string) mb_substr($value, 0, $limit);
        }

        return substr($value, 0, $limit);
    }

    /**
     * Send submission notification to the user's manager.
     */
    private function sendSubmissionNotification(int $userId, int $year, int $month): void
    {
        if (! $this->emailNotifier || ! $this->orgService) {
            return;
        }

        if (! $this->settings->shouldNotifyOnSubmit()) {
            return;
        }

        $mapping = $this->orgService->getMappingForUser($userId);
        $managerId = $mapping['manager_id'] ?? null;

        if (! $managerId) {
            return; // No manager assigned
        }

        try {
            $this->emailNotifier->notifySubmission($userId, $managerId, $year, $month);
        } catch (\Throwable $e) {
            // Log but don't fail the operation
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Timesuite: Failed to send submission notification: ' . $e->getMessage());
            }
        }
    }

    /**
     * Nudge employees who have not submitted, as the month closes.
     *
     * Fires on the second-to-last and last day of the month; see
     * {@see MonthEndReminderSchedule} for why this is month-end rather than
     * cutoff-driven.
     *
     * @param \DateTimeImmutable|null $now Injectable "today", for tests. The
     *        absence of this seam is why the previous schedule's date maths
     *        went unverified; production passes nothing and uses the clock.
     *
     * @return array{sent: int, eligible: int, skipped: int}
     */
    public function sendDeadlineReminders(?\DateTimeImmutable $now = null): array
    {
        if (! $this->emailNotifier || ! $this->orgService) {
            return ['sent' => 0, 'eligible' => 0, 'skipped' => 0];
        }

        if (! $this->settings->areNotificationsEnabled()) {
            return ['sent' => 0, 'eligible' => 0, 'skipped' => 0];
        }

        if (! RuntimeEnvironment::allowsAutomatedReminderEmails()) {
            return ['sent' => 0, 'eligible' => 0, 'skipped' => 0];
        }

        $today = $now ?? DateTimeHelper::fromSettings()->now();
        $schedule = MonthEndReminderSchedule::resolveFor(
            (int) $today->format('Y'),
            (int) $today->format('n'),
            (int) $today->format('j')
        );

        if (null === $schedule) {
            return ['sent' => 0, 'eligible' => 0, 'skipped' => 0];
        }

        $year = $schedule['year'];
        $month = $schedule['month'];
        $stage = $schedule['stage'];
        $mappings = $this->orgService->getMappings();
        $sent = 0;
        $eligible = 0;
        $skipped = 0;

        foreach ($mappings as $mapping) {
            if (empty($mapping['active'])) {
                continue;
            }

            $userId = (int) ($mapping['user_id'] ?? 0);

            if ($userId <= 0) {
                continue;
            }

            $eligible++;

            if ($this->hasReminderSent($userId, $year, $month, $stage)) {
                $skipped++;
                continue;
            }

            $header = $this->monthlyRepository->getHeader($userId, $year, $month);
            $status = $header['status'] ?? 'not_started';

            // Anyone who has already submitted is done -- this is the
            // "for those who haven't submitted" part of the second nudge.
            if (in_array($status, ['submitted', 'approved', 'locked'], true)) {
                continue;
            }

            if ($this->emailNotifier->notifyDeadlineReminder($userId, $year, $month, $stage)) {
                $this->markReminderSent($userId, $year, $month, $stage);
                $sent++;
            }
        }

        return [
            'sent' => $sent,
            'eligible' => $eligible,
            'skipped' => $skipped,
        ];
    }

    private function hasReminderSent(int $userId, int $year, int $month, string $stage): bool
    {
        $period = sprintf('%04d-%02d', $year, $month);
        $stored = get_user_meta($userId, $this->reminderMetaKey($stage), true);

        return is_string($stored) && $stored === $period;
    }

    private function markReminderSent(int $userId, int $year, int $month, string $stage): void
    {
        update_user_meta(
            $userId,
            $this->reminderMetaKey($stage),
            sprintf('%04d-%02d', $year, $month)
        );
    }

    /**
     * Each stage records its own period, so the final nudge still reaches
     * someone who already got the first one, while neither ever repeats.
     */
    private function reminderMetaKey(string $stage): string
    {
        return MonthEndReminderSchedule::STAGE_FINAL === $stage
            ? self::FINAL_REMINDER_META_KEY
            : self::REMINDER_META_KEY;
    }

}
