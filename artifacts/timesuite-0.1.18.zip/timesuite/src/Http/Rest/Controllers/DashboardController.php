<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Core\Settings;
use Timesuite\Core\Support\DateTimeHelper;
use Timesuite\Domain\Timesheets\Repositories\MonthlyTimesheetRepository;
use Timesuite\Domain\Timesheets\Services\CompTimeService;
use Timesuite\Domain\Timesheets\Services\TimesheetApprovalService;
use Timesuite\Domain\Timesheets\Services\VacationService;
use Timesuite\Http\Rest\AbstractRestController;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use wpdb;

/**
 * Dashboard controller providing overview data for the main dashboard screen.
 */
class DashboardController extends AbstractRestController
{
    private const HR_OVERVIEW_BUCKETS = ['not_submitted', 'ready', 'waiting_manager'];
    private const HR_OVERVIEW_PER_PAGE = 20;

    public function __construct(
        private wpdb $wpdb,
        private Settings $settings,
        private VacationService $vacationService,
        private CompTimeService $compTimeService,
        private TimesheetApprovalService $approvalService,
        private MonthlyTimesheetRepository $monthlyRepository
    ) {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/dashboard',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getOverview'],
                'permission_callback' => function () {
                    return $this->checkPermission('timesuite.timesheet.view_own');
                },
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/dashboard/deadlines',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getDeadlines'],
                'permission_callback' => function () {
                    return $this->checkPermission('timesuite.timesheet.view_own');
                },
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/dashboard/hr-overview',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getHrOverview'],
                'permission_callback' => function () {
                    return $this->checkHrOverviewPermission();
                },
            ]
        );
    }

    /**
     * Get dashboard overview for the current user.
     */
    public function getOverview(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $userId = get_current_user_id();
        $dt     = DateTimeHelper::fromSettings();
        $year   = $dt->currentYear();
        $month  = $dt->currentMonth();

        // Get user's timesheet status
        $myTimesheet = $this->getUserTimesheetStatus($userId, $year, $month);

        // Get pending approvals if user is a manager
        $pendingApprovals = [];
        $readyToFinalizeCount = 0;
        $isManager        = current_user_can('timesuite.timesheet.approve_team');

        if ($isManager) {
            $pendingApprovals = $this->getPendingApprovals($userId);
            $readyToFinalizeCount = $this->getReadyToFinalizeCount($userId, $year, $month);
        }

        // Get recent activity
        $recentActivity = $this->getRecentActivity($userId, $isManager);

        // Calculate deadlines
        $deadlines = $this->calculateDeadlines($dt);

        // Get vacation and sick day stats for the current year
        $stats = $this->vacationService->getStats($userId, $year);

        // Get comp time (time in lieu) balance
        $compTimeMinutes = $this->compTimeService->getAvailableMinutes($userId, gmdate('Y-m-d'));
        $compTimeHours = round($compTimeMinutes / 60, 1);
        $dailyHours = $this->settings->getDailyHours();

        return new WP_REST_Response([
            'user'              => [
                'id'         => $userId,
                'name'       => wp_get_current_user()->display_name,
                'is_manager' => $isManager,
                'is_hr'      => current_user_can('timesuite.period.lock'),
            ],
            'current_period'    => [
                'year'  => $year,
                'month' => $month,
                'label' => wp_date('F Y'),
            ],
            'my_timesheet'      => $myTimesheet,
            'vacation_stats'    => [
                'contract_days'  => $stats['vacation_contract'],
                'days_used'      => $stats['vacation_used'],
                'days_remaining' => $stats['vacation_remaining'],
            ],
            'sick_stats'        => [
                'contract_days'  => $stats['sick_contract'],
                'days_used'      => $stats['sick_used'],
                'days_remaining' => $stats['sick_remaining'],
            ],
            'comp_time_stats'   => [
                'balance_minutes' => $compTimeMinutes,
                'balance_hours'   => $compTimeHours,
                'daily_hours'     => $dailyHours,
            ],
            'pending_approvals' => $pendingApprovals,
            'ready_to_finalize_count' => $readyToFinalizeCount,
            'recent_activity'   => $recentActivity,
            'deadlines'         => $deadlines,
        ], 200);
    }

    /**
     * Get upcoming deadlines.
     */
    public function getDeadlines(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $dt        = DateTimeHelper::fromSettings();
        $deadlines = $this->calculateDeadlines($dt);

        return new WP_REST_Response(['deadlines' => $deadlines], 200);
    }

    /**
     * Get HR overview for monthly compliance.
     */
    public function getHrOverview(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $period = $request->get_param('period');
        $period = is_string($period) ? strtolower($period) : 'current';

        if (! in_array($period, ['current', 'last'], true)) {
            return $this->validationError(__('Invalid period supplied.', 'timesuite'));
        }

        $bucket = $request->get_param('bucket');
        $bucket = is_string($bucket) ? strtolower($bucket) : 'not_submitted';

        if (! in_array($bucket, self::HR_OVERVIEW_BUCKETS, true)) {
            $bucket = 'not_submitted';
        }

        $page = (int) $request->get_param('page');
        $page = $page > 0 ? $page : 1;

        $dt    = DateTimeHelper::fromSettings();
        $year  = $dt->currentYear();
        $month = $dt->currentMonth();

        if ($period === 'last') {
            [$year, $month] = $dt->previousMonth($year, $month);
        }

        $periodStart = $dt->firstOfMonth($year, $month);
        $periodEnd   = $dt->lastOfMonth($year, $month);
        $periodDate  = $dt->createFromYearMonth($year, $month);
        $periodLabel = wp_date('F Y', $periodDate->getTimestamp(), $periodDate->getTimezone());

        $employees = $this->fetchActiveEmployeesForPeriod($year, $month);
        $pendingCounts = $this->calculatePendingApprovals(
            $employees,
            $periodStart,
            $periodEnd,
            $year,
            $month
        );

        $counts = [
            'not_submitted' => 0,
            'ready' => 0,
            'waiting_manager' => 0,
        ];
        $rows = [];

        foreach ($employees as $employee) {
            $userId = (int) $employee['user_id'];
            $status = isset($employee['timesheet_status']) && is_string($employee['timesheet_status'])
                ? $employee['timesheet_status']
                : null;
            $pending = $pendingCounts[$userId] ?? 0;
            $denied = $status === 'denied';
            $bucketValue = 'not_submitted';

            if ($status === null || $status === '' || in_array($status, ['draft', 'denied'], true)) {
                $bucketValue = 'not_submitted';
            } elseif ($status === 'submitted') {
                $bucketValue = 'waiting_manager';
            } elseif (in_array($status, ['approved', 'locked'], true)) {
                $bucketValue = 'ready';
            }

            $counts[$bucketValue] = ($counts[$bucketValue] ?? 0) + 1;

            $rows[] = [
                'user_id' => $userId,
                'name' => $employee['display_name'] ?: $employee['user_email'],
                'email' => $employee['user_email'],
                'manager_name' => $employee['manager_name'] ?: null,
                'status' => $bucketValue,
                'denied' => $denied,
                'pending_requests' => $pending,
                'updated_at' => $employee['timesheet_updated_at'] ?? null,
            ];
        }

        $filtered = array_values(
            array_filter(
                $rows,
                static fn(array $row): bool => $row['status'] === $bucket
            )
        );
        $total = count($filtered);
        $offset = ($page - 1) * self::HR_OVERVIEW_PER_PAGE;
        $paged = array_slice($filtered, $offset, self::HR_OVERVIEW_PER_PAGE);
        $hasMore = ($offset + self::HR_OVERVIEW_PER_PAGE) < $total;

        return new WP_REST_Response(
            [
                'period' => [
                    'year' => $year,
                    'month' => $month,
                    'label' => $periodLabel,
                    'key' => $period,
                ],
                'counts' => $counts,
                'bucket' => $bucket,
                'page' => $page,
                'per_page' => self::HR_OVERVIEW_PER_PAGE,
                'total' => $total,
                'has_more' => $hasMore,
                'employees' => $paged,
            ],
            200
        );
    }

    /**
     * Get user's timesheet status for a given month.
     *
     * IMPORTANT — legacy-data safety: months that predate the
     * wp_timesuite_monthly_timesheets table only exist as WordPress
     * user-meta ('timesuite_month_YYYY_MM') until something reads them
     * once through the legacy-aware fallback (which materializes them into
     * the new table). This method used to read only the new table via raw
     * SQL, so a legacy-only month showed here as 'not_started' even though
     * the employee's own My Timesheet page (which does have the fallback)
     * correctly showed it as submitted/locked — this was the concrete
     * mechanism behind "employee says they submitted, HR Dashboard still
     * shows not submitted". See docs/timesheet-status-investigation.md.
     *
     * @return array{status: string, working_days: int, submitted_at: string|null, can_edit: bool}
     */
    private function getUserTimesheetStatus(int $userId, int $year, int $month): array
    {
        $table = $this->wpdb->prefix . 'timesuite_monthly_timesheets';

        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT status, submitted_at FROM {$table} WHERE user_id = %d AND year = %d AND month = %d",
                [$userId, $year, $month]
            ),
            ARRAY_A
        );

        if ($row) {
            $status      = $row['status'] ?? 'not_started';
            $submittedAt = $row['submitted_at'] ?? null;

            // Count entries
            $entriesTable = $this->wpdb->prefix . 'timesuite_monthly_entries';
            $workingDays  = (int) $this->wpdb->get_var(
                $this->wpdb->prepare(
                    "SELECT COUNT(*) FROM {$entriesTable} me
                     JOIN {$table} mt ON me.timesheet_id = mt.id
                     WHERE mt.user_id = %d AND mt.year = %d AND mt.month = %d AND me.type = 'working_day'",
                    [$userId, $year, $month]
                )
            );

            return [
                'status'       => $status,
                'working_days' => $workingDays,
                'submitted_at' => $submittedAt,
                'can_edit'     => in_array($status, ['not_started', 'draft', 'denied'], true),
            ];
        }

        $legacy = $this->resolveLegacyMonthStatus($userId, $year, $month);

        if ($legacy) {
            return [
                'status'       => $legacy['status'],
                'working_days' => $legacy['working_days'],
                'submitted_at' => $legacy['submitted_at'],
                'can_edit'     => in_array($legacy['status'], ['not_started', 'draft', 'denied'], true),
            ];
        }

        return [
            'status'       => 'not_started',
            'working_days' => 0,
            'submitted_at' => null,
            'can_edit'     => true,
        ];
    }

    /**
     * Read a month from legacy 'timesuite_month_YYYY_MM' user-meta and
     * materialize it into the new table so every future reader (this one
     * included) sees it directly without needing this fallback again.
     *
     * Returns null when there is no legacy data either (a genuinely
     * never-touched month).
     *
     * @return array{status: string, working_days: int, submitted_at: string|null, updated_at: string|null}|null
     */
    private function resolveLegacyMonthStatus(int $userId, int $year, int $month): ?array
    {
        $metaKey = sprintf('timesuite_month_%04d_%02d', $year, $month);
        $legacy  = get_user_meta($userId, $metaKey, true);

        if (! is_array($legacy) || empty($legacy)) {
            return null;
        }

        $status    = is_string($legacy['status'] ?? null) ? $legacy['status'] : 'draft';
        $entries   = isset($legacy['entries']) && is_array($legacy['entries']) ? $legacy['entries'] : [];
        $approvals = isset($legacy['approvals']) && is_array($legacy['approvals']) ? $legacy['approvals'] : [];

        // Materialize into the canonical table (same upsert primitives every
        // other legacy-fallback path in the plugin already uses).
        $header = array_intersect_key($legacy, array_flip([
            'status', 'updated_at', 'updated_by', 'submitted_at', 'submitted_by',
            'approved_at', 'approved_by', 'denied_at', 'denied_by', 'denied_comment', 'created_at',
        ]));
        $timesheetId = $this->monthlyRepository->upsertHeader($userId, $year, $month, $header);
        $this->monthlyRepository->upsertEntries($timesheetId, $userId, $entries, $approvals);

        $workingDays = 0;
        foreach ($entries as $entry) {
            if (is_array($entry) && ($entry['type'] ?? null) === 'working_day') {
                $workingDays++;
            }
        }

        return [
            'status'       => $status,
            'working_days' => $workingDays,
            'submitted_at' => is_string($legacy['submitted_at'] ?? null) ? $legacy['submitted_at'] : null,
            'updated_at'   => is_string($legacy['updated_at'] ?? null) ? $legacy['updated_at'] : null,
        ];
    }

    /**
     * Ensure the current user has HR-level access for the overview.
     */
    private function checkHrOverviewPermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to access this resource.', 'timesuite'),
                ['status' => 401]
            );
        }

        if (
            current_user_can('timesuite.settings.manage')
            || current_user_can('timesuite.period.lock')
            || current_user_can('timesuite.org.edit')
        ) {
            return true;
        }

        return new WP_Error(
            'timesuite_forbidden',
            __('You do not have permission to perform this action.', 'timesuite'),
            ['status' => 403]
        );
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function fetchActiveEmployeesForPeriod(int $year, int $month): array
    {
        $orgTable       = $this->wpdb->prefix . 'timesuite_users_org';
        $timesheetTable = $this->wpdb->prefix . 'timesuite_monthly_timesheets';
        $usersTable     = $this->wpdb->users;
        $metaTable      = $this->wpdb->usermeta;

        $sql = $this->wpdb->prepare(
            "SELECT u.ID AS user_id,
                    u.display_name,
                    u.user_email,
                    manager.display_name AS manager_name,
                    mt.id AS timesheet_id,
                    mt.status AS timesheet_status,
                    mt.updated_at AS timesheet_updated_at
             FROM {$orgTable} o
             JOIN {$usersTable} u ON u.ID = o.user_id
             LEFT JOIN {$usersTable} manager ON manager.ID = o.org_unit_id
             LEFT JOIN {$metaTable} removed ON removed.user_id = u.ID AND removed.meta_key = 'timesuite_removed'
             LEFT JOIN {$timesheetTable} mt ON mt.user_id = o.user_id AND mt.year = %d AND mt.month = %d
             WHERE o.removed_at IS NULL
               AND (removed.meta_value IS NULL OR removed.meta_value <> '1')
             ORDER BY COALESCE(NULLIF(u.display_name, ''), u.user_email) ASC, u.user_email ASC",
            $year,
            $month
        );

        $employees = $this->wpdb->get_results($sql, ARRAY_A) ?? [];

        return $this->overlayLegacyStatusesForMissingRows($employees, $year, $month);
    }

    /**
     * For employees with no row in the new table (timesheet_id === null),
     * fall back to legacy 'timesuite_month_YYYY_MM' user-meta and
     * materialize any hit into the new table — same fallback every other
     * reader in the plugin uses. Without this, any employee whose month
     * lives only in legacy storage shows as "Not submitted" here forever,
     * while their own My Timesheet page (which does have the fallback)
     * correctly shows submitted/locked. This is the concrete mechanism
     * behind the reported "employee submitted, HR Dashboard disagrees"
     * symptom. See docs/timesheet-status-investigation.md.
     *
     * Bulk-primes the WordPress user-meta cache for the affected users in
     * ONE query, so this doesn't turn into an N+1 lookup on a dashboard
     * listing hundreds of employees.
     *
     * @param array<int, array<string, mixed>> $employees
     *
     * @return array<int, array<string, mixed>>
     */
    private function overlayLegacyStatusesForMissingRows(array $employees, int $year, int $month): array
    {
        $missingUserIds = [];

        foreach ($employees as $employee) {
            if (($employee['timesheet_id'] ?? null) === null) {
                $missingUserIds[] = (int) $employee['user_id'];
            }
        }

        if (empty($missingUserIds)) {
            return $employees;
        }

        if (function_exists('update_meta_cache')) {
            update_meta_cache('user', array_values(array_unique($missingUserIds)));
        }

        foreach ($employees as &$employee) {
            if (($employee['timesheet_id'] ?? null) !== null) {
                continue;
            }

            $legacy = $this->resolveLegacyMonthStatus((int) $employee['user_id'], $year, $month);

            if ($legacy) {
                $employee['timesheet_status']     = $legacy['status'];
                $employee['timesheet_updated_at'] = $legacy['updated_at'];
            }
        }
        unset($employee);

        return $employees;
    }

    /**
     * @param array<int, array<string, mixed>> $employees
     *
     * @return array<int, int>
     */
    private function calculatePendingApprovals(
        array $employees,
        string $periodStart,
        string $periodEnd,
        int $year,
        int $month
    ): array {
        $userIds = [];

        foreach ($employees as $employee) {
            $status = isset($employee['timesheet_status']) && is_string($employee['timesheet_status'])
                ? $employee['timesheet_status']
                : null;

            if ($status && $status === 'submitted') {
                $userIds[] = (int) $employee['user_id'];
            }
        }

        return $this->calculatePendingApprovalsForUsers($userIds, $periodStart, $periodEnd, $year, $month);
    }

    /**
     * @param array<int, int> $userIds
     *
     * @return array<int, int>
     */
    private function calculatePendingApprovalsForUsers(
        array $userIds,
        string $periodStart,
        string $periodEnd,
        int $year,
        int $month
    ): array {
        $userIds = array_values(
            array_filter(
                array_map('intval', array_unique($userIds)),
                static fn(int $userId): bool => $userId > 0
            )
        );

        if (empty($userIds)) {
            return [];
        }

        $holidayMap = $this->approvalService->getHolidayMapForMonth($year, $month);
        $workWeeks = [];

        foreach ($userIds as $userId) {
            $workWeeks[$userId] = $this->approvalService->getWorkWeekForUser($userId);
        }

        $entriesTable = $this->wpdb->prefix . 'timesuite_monthly_entries';
        $placeholders = implode(',', array_fill(0, count($userIds), '%d'));
        $params = array_merge($userIds, [$periodStart, $periodEnd]);

        $sql = $this->wpdb->prepare(
            "SELECT user_id, work_date, type, approval_status
             FROM {$entriesTable}
             WHERE user_id IN ({$placeholders})
               AND work_date BETWEEN %s AND %s",
            $params
        );

        $entries = $this->wpdb->get_results($sql, ARRAY_A) ?? [];
        $pendingCounts = [];

        foreach ($entries as $entry) {
            if (! empty($entry['approval_status'])) {
                continue;
            }

            $userId = (int) ($entry['user_id'] ?? 0);
            $date = isset($entry['work_date']) ? (string) $entry['work_date'] : '';

            if (! $userId || $date === '') {
                continue;
            }

            $type = isset($entry['type']) ? (string) $entry['type'] : '';
            $workWeek = $workWeeks[$userId] ?? $this->approvalService->getWorkWeekForUser($userId);

            if ($this->approvalService->requiresApprovalForDate($date, $type, $workWeek, $holidayMap)) {
                $pendingCounts[$userId] = ($pendingCounts[$userId] ?? 0) + 1;
            }
        }

        return $pendingCounts;
    }

    private function getReadyToFinalizeCount(int $managerId, int $year, int $month): int
    {
        $timesheetTable = $this->wpdb->prefix . 'timesuite_monthly_timesheets';
        $orgTable       = $this->wpdb->prefix . 'timesuite_users_org';
        $dt             = DateTimeHelper::fromSettings();
        $periodStart    = $dt->firstOfMonth($year, $month);
        $periodEnd      = $dt->lastOfMonth($year, $month);

        $submittedRows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT mt.user_id
                 FROM {$timesheetTable} mt
                 JOIN {$orgTable} o ON o.user_id = mt.user_id AND o.removed_at IS NULL
                 WHERE mt.status = 'submitted'
                   AND mt.year = %d
                   AND mt.month = %d
                   AND o.org_unit_id = %d",
                [$year, $month, $managerId]
            ),
            ARRAY_A
        ) ?? [];

        if (empty($submittedRows)) {
            return 0;
        }

        $userIds = array_map(
            static fn(array $row): int => (int) ($row['user_id'] ?? 0),
            $submittedRows
        );

        $pendingCounts = $this->calculatePendingApprovalsForUsers($userIds, $periodStart, $periodEnd, $year, $month);
        $readyCount = 0;

        foreach ($userIds as $userId) {
            if (($pendingCounts[$userId] ?? 0) === 0) {
                $readyCount++;
            }
        }

        return $readyCount;
    }

    /**
     * Get pending approvals for a manager.
     *
     * @return array<int, array{user_id: int, name: string, year: int, month: int, submitted_at: string}>
     */
    private function getPendingApprovals(int $managerId): array
    {
        $timesheetTable = $this->wpdb->prefix . 'timesuite_monthly_timesheets';
        $orgTable       = $this->wpdb->prefix . 'timesuite_users_org';
        $usersTable     = $this->wpdb->users;

        // Get active org records (removed_at IS NULL indicates current active assignment)
        $sql = $this->wpdb->prepare(
            "SELECT mt.user_id, mt.year, mt.month, mt.submitted_at, u.display_name, u.user_email
             FROM {$timesheetTable} mt
             JOIN {$orgTable} o ON o.user_id = mt.user_id AND o.removed_at IS NULL
             JOIN {$usersTable} u ON u.ID = mt.user_id
             WHERE mt.status = 'submitted'
               AND o.org_unit_id = %d
             ORDER BY mt.submitted_at DESC
             LIMIT 10",
            $managerId
        );

        $results = $this->wpdb->get_results($sql, ARRAY_A) ?? [];

        return array_map(function (array $row): array {
            return [
                'user_id'      => (int) $row['user_id'],
                'name'         => $row['display_name'] ?: $row['user_email'],
                'year'         => (int) $row['year'],
                'month'        => (int) $row['month'],
                'submitted_at' => $row['submitted_at'],
            ];
        }, $results);
    }

    /**
     * Get recent activity for the user.
     *
     * @return array<int, array{action: string, message: string, created_at: string}>
     */
    private function getRecentActivity(int $userId, bool $isManager): array
    {
        $logTable = $this->wpdb->prefix . 'timesuite_approvals_log';

        // For managers, show actions they performed
        // For employees, show actions on their timesheets
        if ($isManager) {
            $sql = $this->wpdb->prepare(
                "SELECT action, entity_type, comment, created_at
                 FROM {$logTable}
                 WHERE actor_id = %d
                 ORDER BY created_at DESC
                 LIMIT 5",
                $userId
            );
        } else {
            $sql = $this->wpdb->prepare(
                "SELECT action, entity_type, comment, created_at
                 FROM {$logTable}
                 WHERE entity_id = %d OR actor_id = %d
                 ORDER BY created_at DESC
                 LIMIT 5",
                [$userId, $userId]
            );
        }

        $results = $this->wpdb->get_results($sql, ARRAY_A) ?? [];

        return array_map(function (array $row): array {
            return [
                'action'     => $row['action'],
                'type'       => $row['entity_type'],
                'message'    => $this->formatActivityMessage($row['action'], $row['entity_type'], $row['comment']),
                'created_at' => $row['created_at'],
            ];
        }, $results);
    }

    /**
     * Format an activity message for display.
     */
    private function formatActivityMessage(string $action, string $entityType, ?string $comment): string
    {
        $messages = [
            'submit'  => __('Timesheet submitted', 'timesuite'),
            'approve' => __('Timesheet approved', 'timesuite'),
            'deny'    => $comment ? sprintf(__('Timesheet denied: %s', 'timesuite'), $comment) : __('Timesheet denied', 'timesuite'),
            'lock'    => __('Period locked', 'timesuite'),
            'month_locked' => __('Month locked', 'timesuite'),
            'month_reopened' => __('Month reopened', 'timesuite'),
            'undo_submit' => __('Submission undone', 'timesuite'),
            'request_created' => __('Re-edit requested', 'timesuite'),
            'request_approved' => __('Re-edit approved', 'timesuite'),
            'request_denied' => __('Re-edit denied', 'timesuite'),
            'reset'   => __('Timesheet reset to draft', 'timesuite'),
            'import'  => __('Data imported', 'timesuite'),
            'export'  => __('Data exported', 'timesuite'),
            'update'  => __('Settings updated', 'timesuite'),
        ];

        return $messages[$action] ?? ucfirst($action);
    }

    /**
     * Calculate upcoming deadlines.
     *
     * @return array<int, array{type: string, label: string, date: string, days_until: int, urgent: bool}>
     */
    private function calculateDeadlines(DateTimeHelper $dt): array
    {
        $deadlines  = [];
        $cutoffDay  = $this->settings->getPeriodCutoffDay();
        $year       = $dt->currentYear();
        $month      = $dt->currentMonth();

        // The deadline for the current month's timesheet is on cutoff day of the next month
        if ($month === 12) {
            $deadlineYear  = $year + 1;
            $deadlineMonth = 1;
        } else {
            $deadlineYear  = $year;
            $deadlineMonth = $month + 1;
        }

        // Ensure cutoff day doesn't exceed month length
        $daysInDeadlineMonth = (int) gmdate('t', strtotime("{$deadlineYear}-{$deadlineMonth}-01"));
        $effectiveCutoffDay  = min($cutoffDay, $daysInDeadlineMonth);

        $nextDeadlineDate = sprintf('%04d-%02d-%02d', $deadlineYear, $deadlineMonth, $effectiveCutoffDay);
        $daysUntil        = (int) ceil((strtotime($nextDeadlineDate) - time()) / 86400);

        if ($daysUntil > 0 && $daysUntil <= 45) {
            $deadlines[] = [
                'type'       => 'submission',
                'label'      => sprintf(
                    /* translators: %s: month name */
                    __('Submit %s timesheet', 'timesuite'),
                    wp_date('F', strtotime("{$year}-{$month}-01"))
                ),
                'date'       => $nextDeadlineDate,
                'days_until' => $daysUntil,
                'urgent'     => $daysUntil <= 3,
            ];
        }

        return $deadlines;
    }
}
