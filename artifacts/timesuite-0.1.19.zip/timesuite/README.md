# Timesuite WordPress Plugin

Timesuite provides employee time tracking, approvals, payroll exports, and org-management tools inside WordPress. It ships with a modern React/Vite interface plus REST APIs for automation.

## Requirements

- PHP 8.1+
- WordPress 6.0+
- Composer 2.x
- Node.js 18+ / npm 9+

## Installation & Setup

1. Install dependencies:
   ```bash
   composer install
   npm install
   ```
2. Build the frontend bundle (outputs to `assets/`):
   ```bash
   npm run build
   ```
   During local development you can enable the Vite dev server by setting in `wp-config.php`:
   ```php
   define('TIMESUITE_VITE_DEV', true);
   define('TIMESUITE_VITE_DEV_SERVER', 'http://localhost:5173');
   ```
   and running `npm run dev`.
3. Activate the plugin from the WordPress admin (Plugins → Timesuite).

## Development Workflow

- **CI (PHP)**: `composer ci` (runs PHPCS + PHPUnit)
- **CI (frontend)**: `npm run ci` (typecheck + vitest)
- **Lint** PHP: `composer lint` (PHPCS)
- **Security scan** (WordPress coding standard): `composer scan`
- **PHPUnit tests** (unit + integration): `composer test`
- **Frontend dev server**: `npm run dev`
- **Build assets**: `npm run build` (cleans `assets/` each build)

Enable WordPress debugging during development (`WP_DEBUG`, `WP_DEBUG_LOG`) to capture activation/runtime errors.

## First-Time Setup (Bootstrap Mode)

When you first install Timesuite or move it to a new WordPress installation, **Bootstrap Mode** automatically activates if no Timesuite administrators exist yet.

### How Bootstrap Mode Works

1. **No Tech Admin = Bootstrap Mode**: If there are no Timesuite technical administrators assigned, the plugin enters Bootstrap Mode
2. **WordPress Admins Get Temporary Access**: During Bootstrap Mode, any WordPress administrator can access Timesuite
3. **Setup First Admin**: The setup screen allows you to select which WordPress administrator should become the first Timesuite administrator
4. **Automatic Lock Down**: Once the first admin is assigned, Bootstrap Mode exits and normal security restrictions apply

### Security Features

- ✅ Only WordPress administrators (`manage_options` capability) can access Bootstrap Mode
- ✅ Bootstrap Mode automatically exits once a tech admin exists
- ✅ All actions are logged in the audit trail
- ✅ Can be disabled via filter: `add_filter('timesuite_bootstrap_mode_enabled', '__return_false');`

This ensures you can always set up Timesuite even when moving between environments, without security vulnerabilities.

## Capabilities & Roles

Timesuite relies on custom capabilities. Assign them to roles/users with standard WP tooling:

- `timesuite.timesheet.*` – employee create/edit/import/submit
- `timesuite.timesheet.view_team`, `timesuite.timesheet.approve_team` – manager queue
- `timesuite.period.lock`, `timesuite.export.run` – HR locking/export
- `timesuite.org.manage` – HR org chart management
- `timesuite.settings.manage` – admin settings page

## REST API Overview

| Endpoint | Method | Description | Capability |
| --- | --- | --- | --- |
| `/timesuite/v1/timesheet/entries` | GET | List employee entries | `timesuite.timesheet.view_own` |
| `/timesuite/v1/timesheet/entry` | POST | Create/update draft entry | create/edit own |
| `/timesuite/v1/timesheet/entry/{id}` | DELETE | Delete draft entry | `timesuite.timesheet.edit_own` |
| `/timesuite/v1/timesheet/import` | POST | Upload XLSX import | `timesuite.timesheet.bulk_import_own` |
| `/timesuite/v1/timesheet/period/submit` | POST | Submit a period | `timesuite.timesheet.submit_own` |
| `/timesuite/v1/manager/approvals` | GET | Manager queue | `timesuite.timesheet.view_team` |
| `/timesuite/v1/period/{id}/approve|deny|lock` | POST | Period workflow | manager/HR caps |
| `/timesuite/v1/export` | GET | Payroll export CSV/XLSX | `timesuite.export.run` |
| `/timesuite/v1/org` | GET/POST | Org mapping CRUD | `timesuite.org.manage` |
| `/timesuite/v1/org/import` | POST | Org CSV dry-run/apply | `timesuite.org.manage` |
| `/timesuite/v1/templates/timesheet.xlsx` | GET | Employee XLSX template | logged-in |

All mutating calls require the WordPress REST nonce (`X-WP-Nonce`) which the frontend localizes via `timesuiteSettings`.

A Postman collection lives in `docs/Timesuite.postman_collection.json` covering these endpoints with sample payloads.

## Frontend Bundle

The React app (Vite) lives in `src/Frontend/app` with three core screens: Employee timesheet grid, Manager approvals queue, and HR periods dashboard. Assets enqueue automatically on Timesuite admin screens (or anywhere you hook `timesuite_enqueue_frontend`).

## Testing Strategy

- **Unit**: domain services & utility classes (PHPUnit)
- **Integration**: REST controllers, import/export flows, migrations
- **Frontend**: Vitest + React Testing Library (run `npm run test:run`)

Run `composer test` before committing to ensure the suite passes.

## Security Notes

- Every REST endpoint enforces `current_user_can()` and REST nonce checks on mutations.
- SQL access always uses `$wpdb->prepare`.
- Imports validate MIME/size and log actions to `timesuite_approvals_log`.
- Use `composer scan` / `composer lint` regularly to keep coding standards.

## Internationalization (i18n)

The plugin is translation-ready with all user-facing strings wrapped in `__()` functions.

**Generate translation template:**
```bash
composer make-pot
```
This requires [WP-CLI](https://wp-cli.org/) with the `i18n` command and outputs to `languages/timesuite.pot`.

## Credits

Timesuite was conceived, architected, and fully implemented by **Niv Reznik**.

Developed for **Greenpeace Israel**.

**Author & Maintainer:**  
Niv Reznik  
nreznik@greenpeace.org | niv704@gmail.com
If `composer` is not in your PATH (common on Windows), you can run Composer via:
```bash
php composer.phar make-pot
```

**Translators**: Place `.po` and `.mo` files in the `languages/` directory following the pattern `timesuite-{locale}.po` (e.g., `timesuite-de_DE.po`).

## Support & Troubleshooting

- Enable `WP_DEBUG_LOG` to inspect runtime errors (see `wp-content/debug.log`).
- Ensure `npm run build` has been executed when deploying to production.
- If a Timesuite admin page is blank, check for the **manifest missing** admin notice and rebuild assets.
- For Vite dev server issues, confirm Node 18+ and the constants in `wp-config.php`.

Happy time tracking!
