# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | :white_check_mark: |

## Reporting a Vulnerability

We take security seriously. If you discover a security vulnerability in Timesuite, please report it responsibly.

### How to Report

**Do NOT create a public GitHub issue for security vulnerabilities.**

Instead, please send an email to: **security@example.com** (replace with your actual security contact)

Include the following information:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Any suggested fixes (optional)

### What to Expect

1. **Acknowledgment**: We will acknowledge receipt of your report within 48 hours.
2. **Assessment**: We will investigate and assess the severity within 7 days.
3. **Resolution**: We aim to release a fix within 30 days for critical/high severity issues.
4. **Disclosure**: We will coordinate with you on public disclosure timing.

### Safe Harbor

We consider security research conducted in good faith to be authorized. We will not pursue legal action against researchers who:

- Make a good faith effort to avoid privacy violations and disruptions
- Do not exploit vulnerabilities beyond what is necessary to demonstrate the issue
- Report vulnerabilities promptly
- Allow reasonable time for remediation before disclosure

## Security Best Practices

When deploying Timesuite:

### WordPress Configuration

```php
// Recommended wp-config.php settings
define('DISALLOW_FILE_EDIT', true);
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', false);
define('WP_DEBUG_DISPLAY', false);
```

### File Permissions

- Plugin directory: `755`
- PHP files: `644`
- `wp-config.php`: `440` or `400`

### Database

- Use a dedicated database user with minimal required permissions
- Enable SSL for database connections in production

### Network

- Use HTTPS (TLS 1.2+) exclusively
- Consider IP allowlisting for admin areas if feasible
- Use a Web Application Firewall (WAF)

## Security Features

Timesuite includes the following security measures:

### Authentication & Authorization

- WordPress capability-based access control
- Granular permissions for different user roles
- REST API endpoints protected with `current_user_can()` checks

### CSRF Protection

- WordPress nonce verification on all state-changing operations
- REST API nonce (`X-WP-Nonce` header) required for mutations

### Input Validation

- All user inputs are sanitized using WordPress sanitization functions
- File uploads validated for MIME type and size
- Parameterized queries (`$wpdb->prepare()`) for all database operations

### Rate Limiting

- Configurable rate limits on sensitive endpoints
- Per-user and per-IP tracking
- Stricter limits on imports and bulk operations

### Audit Logging

- All approval/denial actions are logged
- Settings changes are tracked
- Export operations are recorded
- Configurable log retention

### Data Protection

- Minimal PII collection
- Timezone-aware date handling
- Optimistic locking to prevent data corruption

## Known Limitations

- Rate limiting uses WordPress transients; consider object caching for high-traffic sites
- Audit logs are stored in the WordPress database; consider external logging for compliance-critical deployments

## Updates

We recommend:
- Keeping Timesuite updated to the latest version
- Monitoring the changelog for security-related updates
- Subscribing to WordPress security announcements

---

Thank you for helping keep Timesuite secure!

