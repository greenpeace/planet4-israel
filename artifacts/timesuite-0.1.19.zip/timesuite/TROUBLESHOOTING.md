# Timesuite Troubleshooting Guide

This guide covers common issues and their solutions. For security issues, see [SECURITY.md](SECURITY.md).

## Quick Diagnostics

1. **Check System Status**: Navigate to Timesuite → System Status in the WordPress admin
2. **View Audit Log**: Timesuite → Audit Log shows recent activity
3. **Health Endpoint**: Visit `/wp-json/timesuite/v1/health` for API status

---

## Installation Issues

### "Build Required" Screen Appears

**Symptoms**: The plugin shows instructions to run `npm run build` instead of the normal UI.

**Cause**: Frontend assets haven't been compiled.

**Solution**:
```bash
cd wp-content/plugins/timesuite
npm install
npm run build
```

For Local by Flywheel users: Use the "Site Shell" to run these commands.

### "Cannot Find Module" Errors During Build

**Symptoms**: `npm run build` fails with module not found errors.

**Cause**: Dependencies not installed or corrupted.

**Solution**:
```bash
rm -rf node_modules
rm package-lock.json
npm install
npm run build
```

### Database Tables Not Created

**Symptoms**: Errors about missing tables, or empty screens.

**Cause**: Activation hook didn't run, or migration failed.

**Solution**:
1. Deactivate the plugin
2. Reactivate the plugin
3. Check System Status page for table status

If tables still missing:
```sql
-- Check if tables exist
SHOW TABLES LIKE 'wp_timesuite_%';
```

---

## Authentication & Permissions

### "You Do Not Have Access" Error

**Symptoms**: User sees "You do not have access to this Timesuite area."

**Causes**:
- User doesn't have the required capability
- User's role wasn't updated after plugin activation

**Solution**:
1. Verify user's role includes Timesuite capabilities
2. For custom roles, manually add capabilities:
   - `timesuite.timesheet.view_own`
   - `timesuite.timesheet.submit_own`
   - etc.

### Session Expired / Unauthorized Errors

**Symptoms**: Frequent "session expired" messages or 401 errors.

**Causes**:
- WordPress session expired
- Nonce validation failed
- Caching plugin serving stale nonces

**Solution**:
1. Refresh the page and log in again
2. If using a caching plugin, exclude `/wp-admin/` and REST API endpoints
3. Check if the issue persists in incognito mode

---

## Timesheet Issues

### Cannot Edit Submitted Timesheet

**Symptoms**: Timesheet is read-only after submission.

**Expected Behavior**: Submitted timesheets are locked until approved/denied.

**Solution**:
- Manager must deny the timesheet for employee to re-edit
- Or, manager can reset the timesheet to draft status

### Timesheet Shows Wrong Month/Days

**Symptoms**: Calendar shows dates from wrong month or wrong number of days.

**Causes**:
- Timezone mismatch between server and configured timezone
- Browser timezone different from organization timezone

**Solution**:
1. Set explicit timezone in Policy Settings → Data Retention section
2. Verify server timezone matches expected timezone

### "Unsaved Changes" Warning Won't Go Away

**Symptoms**: Warning appears even after saving.

**Cause**: Save failed silently or data didn't sync.

**Solution**:
1. Check browser console for errors
2. Try saving again
3. Refresh the page (after saving)

---

## Manager/Approval Issues

### No Team Members Showing

**Symptoms**: Manager View shows empty list.

**Causes**:
- No employees assigned to this manager in Org Directory
- Filter hiding results

**Solution**:
1. Go to Org Directory
2. Verify employees have this manager assigned
3. Clear any search filters in Manager View

### Bulk Approve Fails Partway

**Symptoms**: Some timesheets approved, others not.

**Causes**:
- Rate limiting kicked in
- One timesheet had a validation error
- Network timeout

**Solution**:
1. Refresh and check which timesheets were approved
2. Approve remaining individually
3. Check Audit Log for error details

---

## Import/Export Issues

### CSV Import Fails

**Symptoms**: Import shows errors or partial import.

**Common Causes**:
- Wrong column names
- Invalid email addresses
- Special characters in names
- Wrong file encoding

**Solution**:
1. Download the template from Org Import page
2. Ensure columns match exactly: `email`, `manager_email`, `department`, `cost_center`, `is_manager`, `active`
3. Save as UTF-8 CSV
4. Use preview mode first (`dry_run=1`)

### Export Times Out

**Symptoms**: Large exports fail or browser shows timeout.

**Cause**: Too much data for single request.

**Solution**:
1. Export smaller date ranges
2. Filter by department
3. For very large exports, use CLI:
   ```bash
   wp timesuite export --format=csv --year=2024 --output=export.csv
   ```

---

## Performance Issues

### Slow Page Load

**Symptoms**: Pages take >5 seconds to load.

**Causes**:
- Missing database indexes
- Large number of users/entries
- Slow database queries

**Solution**:
1. Check System Status for database health
2. Ensure migrations have run (indexes are added)
3. If using Query Monitor, check slow queries

### Memory Errors During Export

**Symptoms**: "Allowed memory size exhausted" errors.

**Cause**: Export trying to load too much data at once.

**Solution**:
1. Export smaller date ranges
2. Increase PHP memory limit in `wp-config.php`:
   ```php
   define('WP_MEMORY_LIMIT', '256M');
   ```

---

## API/Integration Issues

### REST API Returns 403

**Symptoms**: API calls fail with "Forbidden" error.

**Causes**:
- User lacks capability
- Nonce missing or invalid
- Rate limit exceeded

**Solution**:
1. Check user capabilities
2. Include nonce in request header: `X-WP-Nonce`
3. Wait and retry if rate limited

### Webhook/Integration Not Firing

**Symptoms**: External system not receiving events.

**Cause**: Hook not registered or action not triggering.

**Solution**:
1. Verify hook is registered:
   ```php
   add_action('timesuite_timesheet_approved', 'your_function', 10, 4);
   ```
2. Check Audit Log for the action
3. Test hook manually:
   ```php
   do_action('timesuite_timesheet_approved', $userId, $year, $month, $approverId);
   ```

---

## Environment-Specific Issues

### Works Locally, Fails on Production

**Common Causes**:
- Different PHP version
- Missing PHP extensions
- Stricter permissions
- Caching differences

**Checklist**:
1. PHP 8.1+ on both environments
2. `zip` extension for XLSX exports
3. Write permissions on `wp-content/uploads/`
4. Flush cache after deployment

### Dev Mode Features in Production

**Symptoms**: Debug output visible to users.

**Cause**: `TIMESUITE_VITE_DEV` still defined.

**Solution**:
Remove or set to false in `wp-config.php`:
```php
define('TIMESUITE_VITE_DEV', false);
```

---

## Getting Help

If your issue isn't covered here:

1. **Check Audit Log** for error patterns
2. **Enable Debug Mode** temporarily:
   ```php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   ```
3. **Review error log** at `wp-content/debug.log`
4. **Report issues** following [SECURITY.md](SECURITY.md) for security issues, or open a GitHub issue for bugs

### Useful Debug Information

When reporting issues, include:
- WordPress version
- PHP version
- Timesuite version (from System Status)
- Browser and version
- Steps to reproduce
- Any error messages (screenshot or text)

