# Bootstrap Mode Documentation

## Overview

Bootstrap Mode is a secure onboarding feature that solves the "cold start" problem when deploying Timesuite to a new WordPress installation or moving it between environments. It allows WordPress administrators to set up the first Timesuite administrator without requiring pre-configured access.

## The Problem It Solves

When moving Timesuite to a new WordPress installation:
- No Timesuite users are configured yet
- Super admin emails list is empty
- Normal access control blocks everyone (including WP admins)
- **Result**: You're locked out and can't configure the plugin

## The Solution

Bootstrap Mode provides a secure, automatic pathway for initial setup:

1. **Automatic Detection**: The plugin detects when no Timesuite technical administrators exist
2. **Temporary Access**: WordPress administrators get temporary access to Timesuite during bootstrap
3. **Guided Setup**: A setup screen guides the admin through assigning the first tech admin
4. **Automatic Lock Down**: Once configured, bootstrap mode exits and normal security applies

## Security Design

### Access Requirements

Bootstrap Mode access is restricted by **multiple layers**:

1. **WordPress Administrator Only**: User must have `manage_options` capability
2. **No Tech Admin Exists**: Bootstrap mode only activates when database has zero tech admins
3. **Read-Only Initially**: Until setup is complete, access is limited
4. **Audit Logging**: All bootstrap actions are logged for accountability

### Security Properties

✅ **No Backdoor**: Bootstrap mode completely disables once first admin is set  
✅ **Privilege Required**: Only existing WP admins can access (no anonymous users)  
✅ **Audit Trail**: Bootstrap setup is logged with both actor and target user  
✅ **Filter Override**: Can be disabled entirely via WordPress filter  
✅ **Cache Invalidation**: Bootstrap status is cached but invalidates immediately on setup  

## Technical Implementation

### Backend (PHP)

#### 1. TimesuiteAccess Class

```php
// Priority 8 - runs before normal capability checks
add_filter('user_has_cap', [self::class, 'maybeGrantBootstrapAccess'], 8, 4);
```

**Logic Flow:**
1. Check if `isBootstrapMode()` (cached check for tech admin existence)
2. Verify user has WordPress `manage_options` capability
3. Only handle `timesuite.*` capability requests
4. Grant tech_admin-level capabilities temporarily

#### 2. Bootstrap Detection

```php
public static function isBootstrapMode(): bool
{
    // Cached check
    if (self::$bootstrapMode !== null) {
        return self::$bootstrapMode;
    }

    // Check filter (can disable feature)
    $enabled = apply_filters('timesuite_bootstrap_mode_enabled', true);
    
    if (!$enabled) {
        return false;
    }

    // Bootstrap mode = no tech admin exists
    return !self::hasTechAdmin();
}
```

#### 3. Cache Invalidation

When a tech admin is assigned:
- User meta update triggers `maybeClearUserCache()`
- If role is `tech_admin`, calls `clearBootstrapCache()`
- Next capability check will re-evaluate bootstrap status
- Bootstrap mode exits automatically

### REST API

#### GET `/timesuite/v1/bootstrap/status`

Returns current bootstrap mode status.

**Permission**: Any logged-in user (returns limited info for non-admins)

**Response:**
```json
{
  "bootstrap_mode": true,
  "can_setup": true,
  "has_tech_admin": false,
  "current_user": {
    "id": 1,
    "email": "admin@example.com",
    "is_wp_admin": true
  },
  "available_admins": [
    {
      "id": 1,
      "name": "Admin User",
      "email": "admin@example.com",
      "is_current": true
    }
  ]
}
```

#### POST `/timesuite/v1/bootstrap/setup`

Sets up the first Timesuite technical administrator.

**Permission**: WordPress administrators only (`manage_options`)

**Request Body:**
```json
{
  "user_id": 1
}
```

**Response:**
```json
{
  "success": true,
  "message": "Successfully set up admin@example.com as the first Timesuite administrator.",
  "user": {
    "id": 1,
    "name": "Admin User",
    "email": "admin@example.com"
  }
}
```

**Actions Performed:**
1. Validates bootstrap mode is still active
2. Verifies user exists
3. Assigns `timesuite_access_role` = `tech_admin` user meta
4. Logs action to `timesuite_approvals_log`
5. Clears bootstrap cache (exits bootstrap mode)

### Frontend (React/TypeScript)

#### App Bootstrap Check

On mount, the App component:
1. Calls `/bootstrap/status` endpoint
2. If `bootstrap_mode: true` and `can_setup: true` → show `<BootstrapSetup />`
3. Otherwise, proceed with normal access control

#### BootstrapSetup Component

**Features:**
- Lists all WordPress administrators
- Auto-selects current user by default
- Submit button assigns selected user as tech admin
- Success message → auto-reload after 2 seconds
- Error handling with user-friendly messages

**UX Flow:**
```
Loading... 
  ↓
Bootstrap Setup Screen
  ↓
Select Admin → Click "Set Up Administrator"
  ↓
Success Message (2s)
  ↓
Page Reload → Bootstrap Mode Off → Normal Access
```

## Usage Examples

### Normal First-Time Setup

1. Install Timesuite plugin
2. Activate plugin (no users configured yet)
3. WordPress admin visits Timesuite menu
4. **Bootstrap screen appears automatically**
5. Admin selects themselves or another admin
6. Clicks "Set Up Administrator"
7. Page reloads → Full Timesuite access granted

### Moving Between Environments

```bash
# Export from Production
wp db export production.sql

# Import to Staging
wp db import production.sql

# Visit Timesuite → Bootstrap screen appears
# Select staging admin → Set up → Done!
```

### Disabling Bootstrap Mode

If you want to disable bootstrap mode entirely (e.g., for security hardening in production):

```php
// In wp-config.php or functions.php
add_filter('timesuite_bootstrap_mode_enabled', '__return_false');
```

**Note**: Only disable if you have another way to assign the first admin (e.g., direct database access or WP-CLI).

### WP-CLI Alternative

You can also set up the first admin via WP-CLI without using bootstrap mode:

```bash
# Set user ID 1 as tech admin
wp user meta update 1 timesuite_access_role tech_admin
```

## Audit Logging

Bootstrap actions are logged to the audit trail:

**Action**: `bootstrap_setup`  
**Actor**: WordPress admin who performed the setup  
**Target**: User who was assigned tech admin role  
**Comment**: Full description with both users' emails  

Example log entry:
```
Bootstrap setup: John Admin (john@example.com) assigned Jane Smith (jane@example.com) as first tech admin
```

## Testing Bootstrap Mode

### Manual Testing

1. **Fresh Install Test:**
   - Install plugin on clean WordPress
   - Visit Timesuite as admin
   - Verify bootstrap screen appears

2. **Lock Down Test:**
   - Complete bootstrap setup
   - Reload page
   - Verify normal security (no bootstrap screen)

3. **Non-Admin Test:**
   - Log out
   - Log in as non-admin user
   - Visit Timesuite
   - Verify "No Access" screen (not bootstrap)

4. **Re-trigger Bootstrap:**
   - Delete tech admin user meta: `DELETE FROM wp_usermeta WHERE meta_key = 'timesuite_access_role' AND meta_value = 'tech_admin'`
   - Visit Timesuite as admin
   - Verify bootstrap screen appears again

### Database State

**Bootstrap Mode ON** (no tech admins):
```sql
SELECT COUNT(*) FROM wp_usermeta 
WHERE meta_key = 'timesuite_access_role' 
AND meta_value = 'tech_admin';
-- Returns: 0
```

**Bootstrap Mode OFF** (tech admin exists):
```sql
SELECT user_id FROM wp_usermeta 
WHERE meta_key = 'timesuite_access_role' 
AND meta_value = 'tech_admin';
-- Returns: 1 (or more)
```

## Troubleshooting

### "Bootstrap mode is not active" error when trying to set up

**Cause**: A tech admin already exists (someone set one up while you were on the page)

**Solution**: Reload the page. If bootstrap was legitimately needed, ensure no tech admins exist in the database.

### Bootstrap screen doesn't appear

**Possible causes:**
1. A tech admin already exists → Check database
2. You're not a WordPress administrator → Log in as admin
3. Bootstrap mode is disabled via filter → Check `wp-config.php` or theme functions

### Can't exit bootstrap mode

**Cause**: User meta not being set correctly

**Solution**: 
```bash
# Manually set tech admin via WP-CLI
wp user meta update <USER_ID> timesuite_access_role tech_admin

# Or via database
INSERT INTO wp_usermeta (user_id, meta_key, meta_value) 
VALUES (1, 'timesuite_access_role', 'tech_admin');
```

## Performance Considerations

### Caching Strategy

Bootstrap mode status is cached in static properties:
- `$bootstrapMode` - Cached boolean (null = not checked yet)
- Cache lifetime: Single request (request-level cache)
- Invalidation: Explicit via `clearBootstrapCache()`

### Database Queries

Bootstrap check queries:
1. Check user meta for `timesuite_access_role = tech_admin`
2. Check legacy WordPress roles for `timesuite_tech_admin`

Both queries are indexed and fast. Total: 2 queries, cached after first check.

## Security Considerations

### Attack Vectors & Mitigations

| Attack Vector | Mitigation |
|---------------|------------|
| Unauthorized access to bootstrap | Requires WP `manage_options` capability |
| Bootstrap mode stays active | Auto-exits on first tech admin assignment |
| Privilege escalation | Only grants Timesuite caps (not WP caps) |
| Race condition (multiple setups) | Database constraint + cache invalidation |
| Audit log tampering | Standard WP database protections apply |

### Security Best Practices

1. **Complete Setup Immediately**: Don't leave bootstrap mode active
2. **Audit Regular Reviews**: Check logs for unexpected bootstrap usage
3. **Limit WP Admins**: Fewer admins = smaller attack surface
4. **Filter in Production**: Consider disabling bootstrap in production if not needed

## Future Enhancements

Potential improvements for future versions:

- [ ] Time-limited bootstrap window (e.g., 24 hours after plugin activation)
- [ ] Email notification when bootstrap mode activates
- [ ] Multi-step wizard for initial configuration (policies, work week, etc.)
- [ ] Option to import settings from JSON during bootstrap
- [ ] Bootstrap mode banner in WordPress admin for awareness

## Summary

Bootstrap Mode provides a **secure, user-friendly onboarding experience** that:
- ✅ Prevents lockout scenarios
- ✅ Maintains security boundaries
- ✅ Logs all actions for accountability
- ✅ Automatically locks down after setup
- ✅ Works seamlessly with existing WordPress permissions

It's designed to be **safe by default** while solving a real deployment problem.
