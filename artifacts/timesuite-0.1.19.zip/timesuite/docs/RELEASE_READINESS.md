# Timesuite Release Readiness (Production)

Use this checklist before deploying Timesuite to a real site.

## Breaking Changes In This Release

- The legacy per-entry timesheet REST API has been retired:
  - `timesuite/v1/timesheet`
- The legacy period approval/export REST API has been retired:
  - `timesuite/v1/periods`
- Any external integrations, scripts, Postman collections, or automation still calling those endpoints must be updated before deployment.
- The active supported workflow is now the monthly timesheet + monthly approval flow only.

## 1) Scope and Change Freeze

- Confirm release scope includes:
  - Locked-month flow.
  - Ask to Re-edit (employee request + manager decision).
  - Manager Submit Review flow (top + bottom buttons).
  - HR/dashboard/audit visibility for re-edit events.
  - Schedule-aware month calculations (`scheduled_hours`).
  - Standardized leave-hour accounting (vacation + sick).
- Freeze non-related feature changes during deployment window.
- Define rollback owner and go/no-go decision owner.

## 2) Environment Prerequisites

- WordPress and PHP versions satisfy plugin requirements.
- `vendor/` dependencies are present on target server.
- Frontend bundle built and deployed (`assets/` is updated from latest source).
- Outbound mail is configured (manager notifications for submissions/re-edit requests).
- WP-Cron/cron is running for scheduled tasks.
- Persistent cache/CDN invalidation plan is ready.

## 3) Database and Migrations (Critical)

- Backup DB before deployment.
- Ensure migration autoload is up to date on the artifact:
  - Run `composer dump-autoload -o` in build/deploy pipeline.
- Run plugin migrations after deploy:
  - `wp timesuite migrate`
- Verify required tables exist (especially re-edit):
  - `wp_timesuite_reedit_requests`
  - `wp_timesuite_monthly_timesheets`
  - `wp_timesuite_monthly_entries`
  - `wp_timesuite_approvals_log`
- Verify health endpoint/system status reports migrations as healthy.

## 4) Permissions and Org Mapping

- Validate role capabilities for:
  - `employee`, `manager`, `hr`, `tech_admin`.
- Confirm org mapping is correct (employee reports to correct manager).
- Confirm manager can only approve/reopen direct reports.

## 5) Functional Smoke QA (Required)

Run this minimum matrix in production/staging with real role accounts.

### Employee

- Submit month with no approval-required entries -> month auto-locks.
- Submit month with approval-required entry (e.g., Sick day) -> moves to in-review.
- When locked:
  - Day-type dropdowns are read-only.
  - Ask to Re-edit is visible.
- Ask to Re-edit modal:
  - Text input keeps focus while typing.
  - Validation error appears inside modal under input (min length).
  - Request creates pending state and disables duplicate requests.

### Manager

- Sees pending re-edit queue for direct reports.
- Can view employee reason.
- Deny requires manager reason and keeps month locked.
- Approve reopens month to draft and clears prior review decisions.
- For day approvals:
  - Approve/Disapprove per day works.
  - Submit Review exists top and bottom.
  - If any denied days, final submit requires reason for requested changes.

### HR / Dashboard / Audit

- Dashboard reflects updated status transitions.
- Audit log contains:
  - `request_created`
  - `request_denied`
  - `request_approved`
  - `month_reopened`
  - `month_locked`
- Event actor/time metadata are correct.

## 6) Payroll and Leave Integrity

- Confirm leave calculations use latest finalized month state only.
- Validate no double-counting after reopen/relock cycles.
- Verify denied sick day does not count unless month is finalized with approved state.
- Treat `leave_standard_day_hours` as a payroll unit and do not change it mid-rollout.
- Run leave-hour backfill in dry-run first:
  - `php scripts/backfill-leave-hours.php --year=YYYY`
- Run leave-hour reconciliation and require a clean result before go-live:
  - `php scripts/reconcile-leave-balances.php --year=YYYY`
- After dry-run review, run committed backfill:
  - `php scripts/backfill-leave-hours.php --year=YYYY --commit`
- Re-run reconciliation after commit:
  - `php scripts/reconcile-leave-balances.php --year=YYYY`
- Verify part-time users deduct against their scheduled hours, not company default hours.
- Verify display parity remains in days after backfill (no visible balance jumps).

## 7) Reopen / Relock Regression

- Run the re-edit lifecycle E2E on staging with seeded employee + manager accounts:
  - `WP_BASE_URL="..." EMPLOYEE_USER="..." EMPLOYEE_PASS="..." MANAGER_USER="..." MANAGER_PASS="..." npm run test:e2e -- --project=chromium --grep "request -> deny -> approve -> reopen -> resubmit"`
- Confirm latest locked version remains the only one counted for leave usage.
- Confirm reopening an old month does not recompute historical `scheduled_hours` from the employee's current schedule.
- Confirm relocking after edits updates only the latest version and does not stack old leave usage.

## 8) Performance and Reliability

- Verify API latency for:
  - month load/save/submit
  - manager queue load
  - approve/deny/re-edit endpoints
- Confirm endpoints are idempotent against retries/double-click.
- Confirm one pending re-edit request per month is enforced.

## 9) Security and Compliance

- Verify REST permissions on all new endpoints:
  - employee create request
  - manager list/approve/deny
- Confirm server-side authorization is the source of truth (no client-side bypass).
- Confirm audit entries are immutable and attributable.

## 10) Export / Payroll Parity

- Export a pilot employee report and HR summary after backfill.
- Compare these fields to the payroll salary summary for the same month:
  - Vacation used this period
  - Vacation used YTD
  - Vacation remaining
  - Sick used this period
  - Sick used YTD
  - Sick remaining
- Use at least:
  - one full-time employee
  - one part-time employee with custom daily hours
  - one reopened/relocked month
- If payroll uses hours internally, confirm the Timesuite day display equals:
  - `standardized_hours / leave_standard_day_hours`

## 11) Deployment Steps (Recommended Order)

1. Put site in maintenance mode (if required).
2. Deploy plugin code and built frontend assets.
3. Run `composer dump-autoload -o` on deployed code if build pipeline does not package optimized autoload.
4. Run `wp timesuite migrate`.
5. Run `php scripts/backfill-leave-hours.php --year=YYYY` (dry-run) and review the output.
6. Run `php scripts/reconcile-leave-balances.php --year=YYYY` and require a clean result.
7. Run `php scripts/backfill-leave-hours.php --year=YYYY --commit`.
8. Re-run `php scripts/reconcile-leave-balances.php --year=YYYY`.
9. Run smoke QA matrix above.
10. Run the re-edit lifecycle E2E on staging or a production-safe pilot tenant.
11. Validate export/payroll parity on the pilot users.
12. Clear object/page cache + CDN cache.
13. Remove maintenance mode for pilot users only, if your platform supports a controlled pilot.
14. Expand to full rollout only after pilot parity is confirmed.
15. Monitor logs and support channel for 24-48 hours.

## 12) Rollback Plan

- Keep previous plugin artifact available.
- If rollback needed:
  - Revert plugin artifact.
  - Clear caches.
  - Re-run smoke tests on key paths.
- Do not remove the new hour-based leave meta on rollback; preserve it for forward-fix analysis.
- Do not drop newly created tables during rollback; keep data for forward fix.

## 13) Post-Release Monitoring

- Monitor:
  - HTTP 5xx on `timesuite/v1/*` endpoints
  - DB errors (missing table/index)
  - failed notification emails
- Timesuite now emits `do_action('timesuite_alert', $type, $context)` for:
  - `rest_5xx` on `timesuite/v1/*`
  - `db_table_missing` when a Timesuite table is missing at runtime
- Hook this action in `mu-plugins` or your observability integration to forward alerts to Slack/PagerDuty/Sentry.
- Watch for user-reported blockers:
  - cannot submit
  - cannot request re-edit
  - manager cannot see queue
  - incorrect lock/read-only state
- Watch for payroll-facing issues:
  - unexpected leave balance changes after rollout
  - part-time users losing too many or too few leave days
  - export totals not matching salary-summary review

## 14) Operational Notes

- Keep WP-CLI command `wp timesuite migrate` in runbook.
- Keep these scripts in the deployment runbook:
  - `php scripts/backfill-leave-hours.php --year=YYYY`
  - `php scripts/reconcile-leave-balances.php --year=YYYY`
- Keep a seeded test trio in non-prod:
  - employee, manager, hr
- Keep a seeded part-time employee in non-prod with custom daily hours.
- Record exact deployed plugin version + migration version for incident tracing.
