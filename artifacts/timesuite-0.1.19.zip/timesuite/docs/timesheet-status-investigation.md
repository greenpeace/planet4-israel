# Timesuite — Timesheet Status: Investigation, Fixes Shipped, and Remaining Plan

Status: **Phase 1, Phase 2, a second-review correction round, P1.2 (legacy-month backfill), and
P3.1 (admin rescue actions) all shipped and tested.** Phase 1 = root cause + the most severe
related bugs (§3). Phase 2 = the cutoff-aware default-period feature, structured editability
reason codes, fuller submit messaging, a data-integrity checker, and authorization-path
unification (§9). §10 documents a second independent review of Phase 2 that caught one real
regression (SuperAccess bypass) plus two hygiene issues, all now fixed. §11 is the one-time
backfill migration for legacy-only months (P1.2), with a §11.1/§11.2 two-round review that caught
a real atomicity gap and a real error-detection gap. §12 is the HR/Tech-Admin-only rescue-action
panel (P3.1) — see `docs/p3.1-admin-rescue-actions-plan.md` for the full build spec, revised
before implementation after a review caught a comp-time (Time-in-Lieu) desync risk in the
original draft. Remaining backlog (P3.2) is in §7.
Context: production issue on Greenpeace Israel. Reference case — Marina Doktorova
(`mdoktoro@greenpeace.org`, WP user ID **92**), month **June 2026**.

This document combines two independent code reviews plus a full implementation pass — including
one **production-blocking DI wiring bug that a second independent review caught before deploy**
(§3.5). Every item marked **SHIPPED** below was implemented, covered by a new automated test,
and verified two ways: (a) the test fails against the pre-fix code and passes against the fix,
and (b) the full PHP (`composer test`) and frontend (`npx vitest run`, `npx tsc --noEmit`) suites
pass clean with **zero new failures** beyond 3 pre-existing, unrelated, date-window-dependent
test failures that predate this work (see "Known pre-existing issue" at the bottom). §3.5 is
also a reminder that "tests pass" only covers what the tests actually exercise — worth reading
even though it isn't a status-storage bug.

---

## 1. The problem, in one paragraph

Timesheet **status** is stored in two places — the new table `wp_timesuite_monthly_timesheets`
and legacy per-user WordPress user-meta (`timesuite_month_YYYY_MM`). Different code paths
handled the fallback between these two layers inconsistently: some had it, some didn't. The
worst instance was on the **write path** — approval-workflow actions had no fallback at all,
so touching a legacy-only month could silently overwrite real submission history with an empty
draft. The HR Dashboard also had no fallback, so it showed "Not submitted" for genuinely
submitted legacy-only months. This document fixes the read AND write inconsistencies, adds a
frontend safeguard against masking failed loads as "nothing submitted," and adds audit logging
for submit attempts.

## 2. Reported symptoms → cause → fix status
| # | Symptom | Root cause | Status |
|---|---------|-----------|--------|
| 1 | "Submitted" employees still show **Not submitted** in HR Dashboard | HR Dashboard read `mt.status` via direct SQL with no legacy fallback | **SHIPPED** — §3.2 |
| 2 | My Timesheet shows **Locked**, Manager View shows **DRAFT** (same user/month) | Multiple: legacy/new-table split (§3.2), plus the write-path corruption bug (§3.1) could have already flipped the canonical row to draft before this fix | **SHIPPED** (mechanism fixed; Marina's specific historical row still needs a one-time check — see §5) |
| 3 | Employee/manager both stuck, no available action | Downstream of #2 — once the canonical row disagreed with what a client displayed, neither side had a consistent state to act on | **Mitigated by §3.1–3.3**; a dedicated admin repair tool (§7, P3.1) is still recommended as a safety net for any future edge case |

---

## 3. SHIPPED this session

### 3.1 — CRITICAL, previously undiscovered: approval-workflow writes had no legacy fallback (data-loss bug)
**File:** `src/Domain/Timesheets/Services/TimesheetApprovalService.php`

`TimesheetApprovalService` had its own private `loadMonth()`/`persistMonth()`, structurally
identical to `MonthlyTimesheetService`'s **except** it was missing the legacy-user-meta
fallback branch. Every public write method in this class — `updateMonthStatus` (used by
undo-submit, and by admin/HR status changes), `updateDayApproval`, `resetDayApproval`,
`approveAllDays`, `denyAllDays`, `resetAllApprovals`, `finalizeReview` — went through this
loader.

**Impact:** if any of these actions was the *first* thing to touch a month that existed only
in legacy storage, it saw "no data," treated the month as a brand-new empty draft, and then
**persisted that empty draft** — permanently overwriting the real (possibly submitted/locked)
history. Once a new-table row exists, the legacy fallback is never consulted again for that
user/month, so this was not a display glitch — it was **irreversible data loss** through an
otherwise completely unrelated action (an HR undo, a manager reset, etc.).

**Fix:** added the same legacy-fallback branch (`loadLegacyMonth()`) that
`MonthlyTimesheetService` already had, so both services now behave identically. (A full
consolidation into one shared repository method was attempted first and reverted — see
"Architecture note" below — this fix is a small, targeted patch instead.)

**Test:** `tests/Unit/TimesheetApprovalServiceLegacyFallbackTest.php` — seeds a legacy-only
"submitted" month, calls `updateMonthStatus(..., 'draft', ...)` (the undo-submit path), and
asserts the legacy entry is read and re-persisted rather than silently discarded. **Verified
to fail against the pre-fix code** (`Failed asserting that an array contains 1`) and pass
against the fix.

### 3.2 — HR Dashboard had no legacy fallback (the direct cause of symptom #1)
**File:** `src/Http/Rest/Controllers/DashboardController.php`

Both `getUserTimesheetStatus()` (the personal "my status" widget) and
`fetchActiveEmployeesForPeriod()` (the bulk HR-overview employee list, feeding `getHrOverview`'s
not_submitted/waiting_manager/ready buckets) read `mt.status` via raw SQL only.

**Fix:**
- `getUserTimesheetStatus()`: on a missing row, falls back to legacy user-meta via the new
  `resolveLegacyMonthStatus()` helper, which also materializes the legacy data into the new
  table (same self-healing pattern used elsewhere in the plugin).
- `fetchActiveEmployeesForPeriod()`: after the SQL query, a new `overlayLegacyStatusesForMissingRows()`
  pass finds employees with `timesheet_id === null`, bulk-primes WordPress's user-meta cache
  with `update_meta_cache('user', ...)` (avoids N+1 on a dashboard listing hundreds of
  employees), and overlays the resolved legacy status so downstream bucketing sees the real
  status.
- Constructor now takes `MonthlyTimesheetRepository` (autowired by the DI container in
  production; existing test updated to pass a mock).

**Tests:**
- `tests/Integration/Http/Rest/DashboardControllerHrOverviewLegacyFallbackTest.php` — seeds a
  legacy-only "submitted" month for user 92, asserts `getHrOverview()` buckets it as
  `waiting_manager` (1) and **not** `not_submitted` (0). **Verified to fail against the pre-fix
  code with the exact reported symptom text**: *"Legacy-only submitted month was incorrectly
  bucketed as not_submitted."*
- Existing `tests/Integration/Http/Rest/DashboardControllerTest.php` updated for the new
  constructor param; still passes unmodified otherwise.

### 3.3 — Manager View silently rendered failed loads as "nothing submitted"
**File:** `src/Frontend/app/components/ManagerView.tsx`

`status` defaulted to `useState('draft')`, `entries` to `[]`. On a failed fetch, the `catch`
block set a generic error banner but left `status`/`entries` untouched — rendering pixel-for-
pixel identical to "this employee has a fresh, untouched, not-submitted month" (a legitimate
draft renders `status-chip status-draft` + "0 pending" + "0 reviewed" — exactly what a failure
looked like too).

**Fix:** added a dedicated `loadError` state. On failure: the status chip is replaced with a
distinct "Unable to load" chip, the approvals toolbar is hidden entirely, and the main content
area shows an explicit "Unable to load this employee/month" message instead of an empty table.
Also added a general "This month has not been submitted yet" notice for plain draft months with
no approval-required entries (previously only months *with* approval-required entries got an
explanatory notice via the pre-existing `showDraftApprovalNotice`; a plain all-regular-days
draft showed a bare, unexplained status chip).

**Tests:** two new cases in `src/Frontend/app/components/__tests__/ManagerView.test.tsx`:
- Failed fetch shows "Unable to load" and **not** a draft chip or "0 pending"/"0 reviewed".
- A plain draft month (no approval-required entries) shows the new "not submitted yet" notice.

Both **verified to fail against the pre-fix component** and pass against the fix. Full existing
suite (7 prior tests) and `npx tsc --noEmit` both still pass clean.

### 3.4 — No audit trail for submit attempts
**File:** `src/Http/Rest/Controllers/MonthlyTimesheetController.php`

Undo-submit, approve, deny, and re-edit actions were already logged via the existing generic
`ApprovalLogRepository::log()`. The actual **"Submit Month" action was not logged at all** —
exactly the information that was missing when investigating whether Marina's submit actually
persisted.

**Fix:** `saveMonth()` now logs, for submit attempts only (not every draft autosave, to avoid
flooding the log):
- `submit` on success, with `previous_status`, `new_status`, `requires_manager_review`
  (distinguishes a plain submit from an auto-lock), `year`, `month`, `source`
  (`my_timesheet` vs `manager_view`).
- `submit_failed` on a validation error, with `previous_status` and the error message.

No schema change — this uses the existing `log(action, entryId, actorId, context)` method,
which JSON-encodes `context` into the existing `comment` column. A single query on
`(entity_id, action)` now reconstructs a month's full submit history.

**Test:** `tests/Integration/Http/Rest/MonthlyTimesheetControllerSubmitAuditLogTest.php` — three
cases (successful submit logs correctly, failed submit logs correctly, plain draft save logs
nothing). **Verified 2 of 3 fail against the pre-fix code** (no log call existed at all).

**Test-fixture fix (incidental):** `tests/bootstrap.php`'s `get_user_by()` stub only supported
`'email'` field lookups; extended it to also support `'id'` (matching real WordPress's
signature), since this controller had zero prior test coverage and needed it. One pre-existing
test (`OrgServiceTest::testCircularManagerConflictExplainsTheContradiction`) incidentally relied
on `'id'` lookups always failing to exercise a fallback-label code path; updated it to use
non-registered user IDs so it still exercises that path deliberately instead of by accident.

### 3.5 — Caught by review, before deploy: a production-fatal DI registration mismatch
**File:** `src/Core/Plugin.php`

§3.2's `DashboardController` constructor change (added `MonthlyTimesheetRepository` as a 6th
parameter) was correct in isolation, and every test in this document passed with it — but
`Plugin::registerContainerDefaults()` registers `DashboardController` via a **hand-written
factory closure** (`fn(): DashboardController => new DashboardController($wpdb, $settings,
$vacation, $compTime, $approvalService)`), not the container's generic reflection-based
autowiring. That closure still passed only 5 arguments. This is the one place in the plugin
where adding a constructor parameter does **not** "just work" automatically.

**Why the test suite didn't catch it:** every test for `DashboardController` (existing and new)
constructs it directly — `new DashboardController(...)` — which exercises the *class*, but never
the *real registration path* production actually uses
(`$this->container->get(DashboardController::class)`). This is exactly why a second reviewer
(an independent AI pass on this same diff) flagged it before deploy: they read `Plugin.php`
directly rather than trusting that "tests pass" implied the DI wiring was correct.

**Confirmed exact impact by temporarily reverting the fix and re-running the new smoke test:**
```
ArgumentCountError: Too few arguments to function
Timesuite\Http\Rest\Controllers\DashboardController::__construct(), 5 passed in
.../Plugin.php on line 472 and exactly 6 expected
```
This is a fatal error on every single page load in production, once deployed — `boot()`
unconditionally resolves and registers every controller including this one.

**Fix:** added `$this->container->get(MonthlyTimesheetRepository::class)` as the 6th argument
in the factory closure, plus the missing `use` import. Verified the container's `autowire()`
correctly resolves `MonthlyTimesheetRepository` (it only needs `wpdb`, already registered).

**Test added:** `tests/Smoke/PluginContainerRegistrationTest.php` — resolves **every controller
class that `Plugin::boot()` actually resolves through the container** (12 total: all REST
controllers registered there), the same way production does, via a real `new Plugin(new
Container())`. This guards the whole class of bug — any future constructor change to any of
these 12 classes that isn't reflected in a hand-written factory override will now fail this
smoke test immediately, rather than only failing silently until the plugin actually boots in
production. **Verified to reproduce the exact `ArgumentCountError` above** when the `Plugin.php`
fix is reverted, and to pass with it applied.

**Lesson for this document itself:** "all tests pass" is only as strong as what the tests
actually exercise. §3.2 was fully covered by tests that construct the class directly, which
gave a false sense of completeness — none of them exercised the DI registration path where the
bug actually lived. The new smoke test closes that specific gap for all 12 boot-resolved
controllers going forward.

### Architecture note: why the write-path fix (§3.1) is a small patch, not a full consolidation
The first attempt at §3.1 extracted the shared load/persist logic into
`MonthlyTimesheetRepository` so both services would call one implementation. This was reverted:
the existing test suite mocks `MonthlyTimesheetRepository` wholesale via
`$this->createMock(MonthlyTimesheetRepository::class)` and asserts on its granular methods
(`getHeader`, `getEntries`, `upsertHeader`, `upsertEntries`); moving the "smart" legacy-fallback
logic into a new repository method those tests don't know to mock made it silently no-op under
test (PHPUnit mocks return `null`/defaults for unconfigured methods), breaking 9 previously
passing tests. The shipped fix instead duplicates the small (~15-line) legacy-read branch
locally in `TimesheetApprovalService`, with an explicit comment cross-referencing the twin copy
in `MonthlyTimesheetService` so a future change to one prompts checking the other. A true
shared-class extraction remains a good idea but needs a coordinated test-suite update
(introducing a new injectable collaborator + updating both services' test factories) — worth
doing as its own dedicated, reviewed change, not bundled into an urgent data-loss fix.

---

## 4. Verified facts (for anyone continuing this work)
- `wp_timesuite_monthly_timesheets` has `UNIQUE KEY (user_id, year, month)` → at most one row
  per user/month. A `locked`-vs-`draft` split for the same user/month is either a stale client,
  or (before §3.1/§3.2) the legacy/new-table divergence — never two rows.
- Legacy meta is **read-only** in code — nothing writes a `timesuite_month_*` key anymore
  (confirmed by grep). Once a month is backfilled/materialized, it can't drift back to legacy.
- **No backfill migration exists** for months that predate the new table. §3.1/§3.2 make the
  *read* paths self-healing (they materialize on first read), but a month that is never opened
  through any of these paths stays legacy-only indefinitely. See §7, P1.2 for the still-open
  backfill-migration recommendation.
- The backend already partially separates status from editability (`read_only`,
  `read_only_reason`, `editable` fields on `getMonth`'s response) — the gap is structured reason
  codes and a frontend that stops reusing the word "Locked" for both concepts. See §7, P2.1.
- `TimesheetGrid.tsx` (My Timesheet, the employee-facing equivalent of `ManagerView.tsx`)
  already re-fetches after submit and correctly surfaces errors without falsely claiming
  success — it did **not** have the §3.3 class of bug.
- `listApprovals` showing only `submitted` months is intentional, not a bug — a `locked` month
  already has the "Ask to Re-edit" escape hatch. (An earlier draft of this doc incorrectly
  called this the root cause of symptom #3; that framing is withdrawn.)

---

## 5. Marina — what to check now
The *mechanism* that could produce her symptom is now fixed going forward. Her **existing**
June 2026 row may already have been affected before this fix shipped. Recommended one-time,
read-only check on production:
```sql
SELECT id, status, submitted_at, submitted_by, approved_at, approved_by,
       updated_at, updated_by, created_at
FROM wp_timesuite_monthly_timesheets
WHERE user_id = 92 AND year = 2026 AND month = 6;

SELECT * FROM wp_timesuite_approvals_log
WHERE entity_id = 92 ORDER BY created_at DESC LIMIT 50;

SELECT meta_key, meta_value FROM wp_usermeta
WHERE user_id = 92 AND meta_key LIKE 'timesuite_month_2026%';
```
- If the new-table row says `draft` but legacy meta says `submitted`/`locked` → confirms she was
  hit by §3.1 before the fix; the legacy data is still intact and recoverable (nothing was
  deleted, just shadowed) — a manual correction of the new-table row from the legacy values is
  safe now that the write path won't re-corrupt it.
- If `approvals_log` shows an `undo_submit`/`reset`/similar action from someone other than
  Marina around the time she says she submitted, that's the actual trigger event.
- Now that §3.4 ships, any *future* submit issue will show up directly in this log with
  `previous_status`/`new_status`/`error` — no more guessing.

---

## 6. Verification summary (for review)
Phase 1 (§3), at the time it shipped:
```
composer test    → 110 tests, 0 new failures (3 pre-existing, unrelated — see below)
composer lint     → PHP syntax OK (122 files)
npx vitest run    → 55 tests, all passing (10 files)
npx tsc --noEmit  → clean
```
Phase 2 (§9), current state:
```
composer test    → 140 tests, 0 new failures (same 3 pre-existing, unrelated — see below)
composer lint     → PHP syntax OK (128 files)
npx vitest run    → 74 tests, all passing (12 files)
npx tsc --noEmit  → clean
```
Every new/changed behavior above has a regression test that was confirmed to **fail against the
pre-fix code** before the fix was applied, not just "written and green" — this rules out
tautological tests that pass regardless of whether the fix works. This includes §3.5's DI-wiring
smoke test, which reproduces the exact fatal `ArgumentCountError` production would have hit.

**Known pre-existing issue (not touched by this work):** 3 tests in
`tests/Unit/MonthlyTimesheetServiceTest.php` fail with *"Only the current or previous month can
be edited"* — these appear to hardcode a month relative to a fixture date that has since become
outside the "current or previous month" editability window as real time has passed. This is a
pre-existing test-fixture staleness issue, unrelated to the status-storage bugs in this
document; flagged here rather than silently left unexplained.

---

## 7. Remaining backlog (not shipped — still recommended)

P2.1, P2.2, P3.3, and P3.4 (originally listed here) all **shipped in Phase 2 — see §9.**
P1.2 **shipped — see §11.** P3.1 **shipped — see §12.** What's left:

### P3.2 — Central state-transition guard
Define allowed transitions in one place (`draft→submitted`, `draft→locked` when no approval
required, `submitted→locked` after approval, `submitted→draft` only via undo before any
decision, `locked→draft` only via approved re-edit or admin reopen) and route every write
through it, rejecting anything else with a clear error. Prevention of *future* invalid states,
not a fix for existing data — sequence after P1.2.

---

## 8. Findings & decisions log
- Confirmed the read-path split (HR Dashboard vs. `getMonth`) as the mechanism for symptom #1.
- **Discovered mid-implementation, not in either original review:** the write-path version of
  the same bug in `TimesheetApprovalService`, which is strictly more severe (data loss, not just
  a stale read) — this became the top-priority fix (§3.1).
- Corrected two over-broad claims from earlier drafts: the directory does NOT expose the whole
  org to any logged-in user (it's properly scoped via `resolveVisibleUserIds`); the approvals
  filter (`listApprovals`) is not itself a bug (locked months have the re-edit escape hatch).
- Shipped and tested: §3.1 (write-path fallback), §3.2 (HR Dashboard fallback, both personal and
  bulk), §3.3 (Manager View failure/notice states), §3.4 (submit audit logging).
- Attempted and reverted a full repository-level consolidation for §3.1 after it broke 9 tests
  by silently no-op'ing under the existing wholesale-repository-mock testing pattern; shipped a
  smaller, equally effective, test-verified patch instead.
- **Caught by a second, independent review before deploy:** §3.2's `DashboardController`
  constructor change was correct but left `Plugin.php`'s hand-written DI factory under-supplied
  (5 args passed, 6 required) — a fatal `ArgumentCountError` on every production page load,
  invisible to every test in this document because none of them exercised the real
  `$container->get(DashboardController::class)` registration path. Fixed in §3.5, plus a new
  smoke test (`PluginContainerRegistrationTest`) that resolves all 12 boot-time controllers
  through a real container, so this class of bug is now caught automatically for all of them,
  not just this one instance.
- Remaining backlog re-prioritized in §7, all still relevant and none blocking on Marina's
  specific historical-data check (§5), which is the only item still needing production DB access.
- **Phase 2 (§9) added, shipping P2.1, P2.2, P3.3, P3.4, plus a new feature (cutoff-aware
  default period) that was not in the original backlog** — requested directly in response to a
  separate, real complaint: users confused about which month they're viewing when submitting or
  approving.

---

## 9. Phase 2 — shipped this round

### 9.1 — New feature: cutoff-aware default period
**Files:** `src/Core/Settings.php`, `src/Core/Support/DefaultPeriodResolver.php` (new),
`src/Frontend/enqueue.php`, `src/Frontend/app/lib/api.ts`,
`src/Frontend/app/components/TimesheetGrid.tsx`, `ManagerView.tsx`, `HrMonthOverview.tsx`,
`src/Frontend/app/components/PolicySettings.tsx`.

**Problem:** employees, managers, and HR all default to viewing the *current* calendar month.
Right after the month rolls over (days 1–7, given the existing "Period cutoff day" setting),
most real activity is still catching up on the *previous* month — but every screen opens on the
new, mostly-empty one, which is exactly the "which month am I on?" confusion reported.

**Fix — new independent toggle**, "Default to previous month before cutoff," added under the
existing "Period cutoff day" field in Policy Settings, **off by default**. When on: until the
configured cutoff day of the new month, My Timesheet, Manager View, and HR Month Overview all
open on the *previous* month by default (deep-linked/explicit month selections still take
priority — this only changes what loads with no other signal). One canonical server-side
computation (`DefaultPeriodResolver::resolve()`, localized into the page JS once) feeds all
three surfaces, rather than three separate client-side date computations that could drift out
of sync with each other or with the server's own cutoff logic.

**Decisions made per your instructions:**
- **Not gated** on the existing "Allow previous-month edits" (backdating) toggle — a fully
  independent setting, per your explicit call ("dont gate it, its extra compiixity and risk").
  A site can have this default-view behavior on with backdating off (previous month is shown,
  but is still read-only past its own edit window) — that's a valid, intentional combination,
  not a bug.
- Server computes once, client trusts it (my recommendation, which you accepted) — avoids three
  independent client-side "what month is it, and is today past the cutoff" computations that
  could each get timezone/off-by-one handling slightly differently.

**Tests:**
- `tests/Unit/Core/Support/DefaultPeriodResolverTest.php` (5 cases): toggle off → current month;
  toggle on + before cutoff → previous month (including January → prior December rollover);
  toggle on + after cutoff → current month; cutoff day clamped to a sane 1–31 range.
- `src/Frontend/app/lib/__tests__/api.test.ts` (4 cases) for `getDefaultPeriod()`'s parsing and
  defensive validation (rejects a malformed month).
- `TimesheetGrid.test.tsx`, `ManagerView.test.tsx`, `HrMonthOverview.test.tsx` (new file) —
  each confirms the component opens on the resolved default period when no explicit month is
  requested, and that an explicit/deep-linked month always wins over the default.
- `PolicySettings.test.tsx` — new toggle renders, saves, and reveals the cutoff-day field
  independently of the backdating toggle (both-off, either-on, both-on all show the field).

### 9.2 — P2.1: Structured editability reason codes
**Files:** `src/Domain/Timesheets/EditabilityReason.php` (new), `MonthlyTimesheetService.php`,
`MonthlyTimesheetController.php`, `Contracts/TimesheetServiceInterface.php`.

Added a stable `reason_code` (e.g. `CURRENT_MONTH_OPEN`, `PREVIOUS_MONTH_BEFORE_CUTOFF`,
`PERIOD_CUTOFF_PASSED`, `SUBMITTED_UNDER_REVIEW`, `MONTH_LOCKED`, `MONTH_LOCKED_REEDIT_PENDING`,
`MONTH_LOCKED_REEDIT_DENIED`, `DENIED`, `VIEWING_ANOTHER_USER`) alongside the existing freetext
`read_only_reason`, returned as `read_only_reason_code` in `getMonth()`'s response. This lets any
future frontend work (or the integrity checker, or admin tooling) branch on a stable code instead
of string-matching translated, human-facing text — the freetext reason can still change wording
without breaking anything that depends on *why* a month is read-only.

**Test:** `tests/Unit/MonthlyTimesheetServiceEditabilityReasonCodeTest.php` (6 cases, one with an
explicit skip guard for the structurally-untestable day-1-of-month edge case rather than a flaky
date-dependent assertion).

### 9.3 — P2.2: Fuller submit-result messaging
**File:** `src/Frontend/app/components/TimesheetGrid.tsx`.

Added a distinct "Submitted successfully — no approval was needed, so the month is now locked"
message when a submit auto-locks (vs. the plain "Submitted for review" message), and a
"Last submitted at [timestamp]" line parsed explicitly as UTC from the server's MySQL datetime.

**Bug found and fixed along the way (not previously known):** `handleSubmit()` set the success
message *before* `await loadTimesheet()` — but `loadTimesheet()`'s first synchronous statement is
`setMessage(null)`, which (under React's batching) silently discarded the success message before
it ever rendered. This affected **every** submit, not just the new auto-lock case. Fixed by
reordering to set the message after the reload resolves; verified the fix against a reverted
(pre-fix) version to confirm the message really was being lost.

**Tests:** new cases in `TimesheetGrid.test.tsx` covering plain-submit message, auto-lock
message, and the "last submitted at" display; one specifically written to fail against the
pre-fix message-ordering bug.

### 9.4 — P3.3: Data-integrity checker in System Status
**Files:** `src/Http/Rest/Controllers/HealthController.php`,
`src/Frontend/app/components/SystemStatus.tsx`.

New `checkTimesheetIntegrity()`, following the existing `detailedCheck()` `$checks` array
pattern, covering: duplicate active org mappings, duplicate active emails, org mappings pointing
at missing users/managers, legacy-only months (see P1.2 above), cross-layer status mismatches
(legacy meta vs. canonical table disagree), and — when circular manager assignments are
disallowed by settings — circular manager chains (reusing `OrgService::getCircularManagerConflict()`
rather than a new implementation). Each finding includes user id, email, month/year, severity,
and a suggested action. `SystemStatus.tsx` renders these under a new "Data Integrity Issues"
section, hidden entirely when there are none.

**Test:** `tests/Unit/Http/Rest/HealthControllerTimesheetIntegrityTest.php` (6 cases) — calls the
private `checkTimesheetIntegrity()` directly via reflection rather than the public
`detailedCheck()` endpoint, deliberately avoiding two unrelated pre-existing test-infrastructure
gaps (`detailedCheck()`'s other checks depend on `TIMESUITE_PLUGIN_PATH` and
`wp_next_scheduled()`, neither ever stubbed because no prior test exercised that endpoint) —
fixing those was out of scope for this change. Plus 2 new cases in `SystemStatus.test.tsx` for
the rendering.

### 9.5 — P3.4: Unified the two "is this my report?" authorization paths
**File:** `src/Http/Rest/Controllers/MonthlyTimesheetController.php`.

`canView()`, `canEdit()`, and `hasHrPowers()` had their own local, inline authorization logic,
separate from `AuthorizationService` (already the canonical mechanism used elsewhere, per its own
class docblock: *"Controllers should NEVER implement their own authorization logic"*). Replaced
all three with delegation to `AuthorizationService::canViewTimesheetFor()`,
`canEditTimesheetFor()`, and `hasOrgManagementPowers()`. `canSubmit()` was left as-is — no
`AuthorizationService` equivalent exists for submit-specific checks, and inventing one wasn't
part of the requested scope.

**Verified equivalence, not just "it compiles":** traced through both the old and new logic for
every branch (self-view, HR viewing anyone, manager viewing a direct report vs. a non-report,
plain employee viewing a colleague, self-edit, HR attempting to edit someone else). The
manager/direct-report check in both old and new code bottoms out in the same
`OrgService::managerCanAccessUser()` call — confirmed by reading both call chains, not assumed.

**Real gap found and closed:** `AuthorizationService` — despite being the plugin's stated "single
source of truth" for permissions — had **zero direct test coverage** anywhere in the suite.
Added `tests/Unit/Core/Access/AuthorizationServiceTest.php` (12 cases covering
`canViewTimesheetFor`, `canEditTimesheetFor`, and `hasOrgManagementPowers` across employee/
manager/HR/tech_admin/no-role scenarios). This also surfaced a real static-cache-leak hazard:
`AuthorizationService` caches roles/capabilities in `private static` properties for
request-lifetime performance, which persist across PHPUnit test methods in the same process
unless explicitly cleared — the new test's `setUp()` now calls the existing
`AuthorizationService::clearAllCaches()` to avoid order-dependent false passes/failures (verified
by running the suite with `--order-by=random`).

**Immediate follow-up caught before it shipped broken:** the pre-existing
`MonthlyTimesheetControllerSubmitAuditLogTest.php` (§3.4/§9.2's audit-log test) still constructed
`MonthlyTimesheetController` with the old `OrgService` constructor argument; updated its
`controller()` test factory to mock `AuthorizationService` instead, matching the real
(now-changed) constructor signature. Confirmed passing after the update.

**Not done:** did not add a dedicated frontend-facing regression test asserting the *old and new
authorization outcomes are identical for every possible role/relationship combination* beyond the
branches listed above (e.g. every legacy-role-inference edge case) — the traced-through-code
verification plus the new direct unit tests were judged sufficient given this is an internal
refactor with no behavior change intended, not a new feature.

---

## 10. Second-review correction round (post-Phase 2)

A second independent AI review of the Phase 2 diff raised three findings. Each was verified
against the actual code (not taken on trust) before fixing.

### 10.1 — CONFIRMED, real regression: SuperAccess was bypassed by the P3.4 refactor
**File:** `src/Core/Access/AuthorizationService.php`

**The claim:** `MonthlyTimesheetController`'s new `canView()`/`canEdit()`/`hasHrPowers()`
(§9.5) call `AuthorizationService`, whose `userHasCapability()` only reads the Timesuite role
system (`timesuite_access_role` user meta, or legacy WP-role inference) — it never checks
SuperAccess (`src/Core/SuperAccess.php`), the break-glass override that grants a configured list
of emails every `timesuite.*` capability via a `user_has_cap` WordPress filter. The frontend
(`enqueue.php`'s `get_current_user_timesuite_caps()`) already special-cases SuperAccess and
returns *all* capabilities for such a user — so a SuperAccess user with no (or a low) Timesuite
role assigned would see full UI access but get rejected by the REST endpoint.

**Verified true.** Traced `userHasCapability()` → `getCapabilitiesForUser()` →
`getRoleForUser()` → confirmed none of that chain, nor `hasOrgManagementPowers()`,
`canViewTimesheetFor()`, or `canEditTimesheetFor()`, ever consult `SuperAccess`. Confirmed the
frontend really does short-circuit to "all capabilities" for SuperAccess users
(`enqueue.php:337-339`). This gap already existed in `AuthorizationService` before this session
(it's also used by `ExportController`, `DirectoryController`, and `TimesheetApprovalController`)
— but before §9.5, `MonthlyTimesheetController`'s own inline checks used `current_user_can()`
directly, which *does* honor SuperAccess (via the same WordPress filter) — so §9.5 turned a
working case into a broken one for this specific controller, while also leaving the pre-existing
gap in the other three controllers unfixed.

**Fix:** centralized in `AuthorizationService::userHasCapability()` itself (not a controller-level
special case, per the review's explicit recommendation) — it now returns `true` immediately for
any `timesuite.*` capability when the acting user is a SuperAccess user, mirroring exactly what
`SuperAccess::grantCapabilities()` already does for `current_user_can()`. Because every scoped
check (`hasOrgManagementPowers`, `canApproveTimesheets`, `canViewTeamTimesheets`,
`canViewTimesheetFor`, `canEditTimesheetFor`, `canApproveTimesheetFor`) is built on
`userHasCapability()`, this one change fixes the gap everywhere at once — including in
`ExportController` and `DirectoryController`, not just the controller this session touched.

**Test:** `tests/Unit/Core/Access/AuthorizationServiceTest.php` — added 5 new cases (a SuperAccess
user with **no Timesuite role assigned at all** can view/edit their own timesheet, view any
employee's timesheet without a manager relationship, and has org-management powers; plus a
sanity check that a non-SuperAccess user with no role still gets nothing). **Verified to fail
against the pre-fix code** (`git stash` on just `AuthorizationService.php`): all 4 SuperAccess
assertions failed with "Failed asserting that false is true," confirming they weren't
tautological.

**Test-infrastructure gap found along the way:** writing this test required a `WP_User` class
stub usable via `get_user_by('id', ...)` (the existing fake user registry only ever stored plain
`stdClass` objects, and `SuperAccess::isSuperUser()`/`AuthorizationService::canManageRoles()`
both strictly type-hint `WP_User`, which PHP enforces even for object instanceof checks). Added a
shared `WP_User` stub directly to `tests/bootstrap.php` (previously this stub only existed
duplicated inside `CapabilitiesTest.php`, invisible to any test file run in isolation) — confirmed
`CapabilitiesTest.php` still passes unchanged with the shared version (it exercises
`add_role()`/`remove_role()`, which the shared stub now also implements).

### 10.2 — CONFIRMED: line-ending corruption in `ManagerView.test.tsx`, minor mixed endings in `DashboardController.php`
The project's `.editorconfig` mandates `end_of_line = lf` for all files. `ManagerView.test.tsx`
was already non-compliant before this session (81 of 297 lines were CRLF), but edits made across
this session made it drastically worse — 411 of 412 lines were CRLF by the end of Phase 2.
Normalized the whole file to LF (`git diff --check` now clean). `DashboardController.php`'s
CRLF ratio was roughly unchanged by this session's edits (pre-existing, mixed, not newly
introduced) — left the bulk of the file as-is to avoid an unrelated whole-file diff, but fixed
the two lines `git diff --check` actually flagged as touched-and-broken (a stray bare `\r` on an
otherwise-LF blank line, and a doubled trailing newline at EOF). Re-ran the full frontend suite
after the `ManagerView.test.tsx` rewrite — all 11 of its tests still pass, `tsc --noEmit` clean.

### 10.3 — CONFIRMED: duplicate PHPDoc block
**File:** `src/Domain/Timesheets/Services/MonthlyTimesheetService.php`

§9.2's `reason_code` addition left the **old** `@return` docblock for `getEditability()` in
place directly above the **new** one instead of replacing it — two consecutive docblocks, only
the second (correct) one taking effect. Removed the stale one.

### Verification after this round
```
composer test    → 145 tests, 0 new failures (same 3 pre-existing, unrelated — see §6)
composer lint    → PHP syntax OK (128 files)
npm run ci (tsc --noEmit + vitest run) → clean; 74 tests passing (12 files)
git diff --check → clean (was previously flagging real issues in 2 files)
```

---

## 11. P1.2 — Legacy-month backfill (shipped)

**Files:** `src/Domain/Timesheets/Repositories/MonthlyTimesheetRepository.php` (new
`insertHeaderIfAbsent()`, `materializeIfAbsent()`, `findLegacyMonthCandidates()`),
`src/Domain/Timesheets/Services/LegacyMonthBackfillService.php` (new), `src/Core/Plugin.php`
(new `wp timesuite backfill-legacy-months` CLI command).

Even with §3.1/§3.2's self-healing lazy reads, a month nobody has ever opened stays legacy-only
indefinitely. This closes that permanently: a dedicated, idempotent, batched backfill that
materializes every legacy `timesuite_month_YYYY_MM` entry with no corresponding row in
`wp_timesuite_monthly_timesheets`.

**CLI-first by design, not an automatic upgrade step.** A full `wp_usermeta` scan is too heavy
and unobservable to run implicitly on plugin boot or version upgrade (unlike the schema
migrations in `MigrationsRunner`, which are cheap `dbDelta` calls). `wp timesuite
backfill-legacy-months [--dry-run] [--batch-size=N]` is the operator-driven entry point,
matching the existing `wp timesuite migrate` command's registration pattern. Recommended
workflow: run `--dry-run` against a production DB clone, compare its `materialized` count to
§9.4's integrity-checker `legacy_only_month` count (they should agree), run for real, then
re-check the integrity checker reports zero.

**Safety properties (all directly requested, all enforced and tested):**

- **Insert-only, never upsert, and atomic across header + entries.**
  `MonthlyTimesheetRepository::materializeIfAbsent()` wraps `insertHeaderIfAbsent()` (insert-only,
  race-safe via the table's `UNIQUE KEY (user_id, year, month)`) and `upsertEntries()` in a single
  `START TRANSACTION` / `COMMIT` / `ROLLBACK` — see §11.1 for why this atomicity was added after
  the first review round, and why a genuine (non-duplicate-key) insert failure is now thrown
  rather than silently treated as "already existed."
- **Strict meta-key validation before any write.** The candidate scan
  (`findLegacyMonthCandidates()`) intentionally reuses the same loose `LIKE`/`SUBSTRING` filter
  as §9.4's `findLegacyOnlyMonths()` (so the two agree on what counts as a "candidate"), which
  means a malformed key (non-numeric year/month, or an out-of-range month like `_13`) can still
  pass through as a candidate. `LegacyMonthBackfillService::parseLegacyMetaKey()` is the actual
  gate: an exact `^timesuite_month_(\d{4})_(\d{2})$` match with month 1–12, applied before any
  legacy data is even read, let alone written. Anything else is `skipped_invalid`.
- **Dry-run is truly read-only.** In dry-run mode the service never calls
  `materializeIfAbsent()` at all — it reports what the scan found and would attempt, nothing more.
- **Legacy user-meta is never deleted.** The backfill only writes to the new table; the
  `timesuite_month_*` meta stays in place as the recoverable source of truth, unchanged from
  before this session's other fixes.
- **One bad row can't sink the batch.** Each candidate is processed independently inside a
  try/catch; a thrown exception is recorded in `failed[]` with the user/month/error and the run
  continues. Malformed legacy meta (present in `wp_usermeta` but not an array by read time) is
  handled the same way — counted as `skipped_existing`, not fatal.
- **Batched via keyset pagination on `umeta_id`**, not `OFFSET` (which degrades on a large
  `wp_usermeta` table) — resumable in principle, though a re-run naturally starts the scan over
  from the beginning since `run()` doesn't currently persist a cursor between invocations; that's
  fine because materializing an already-materialized month is always a cheap no-op skip, never a
  correctness issue.

**Why the existing lazy read-paths (§3.1/§3.2) were NOT switched to this new primitive:**
`MonthlyTimesheetService`/`TimesheetApprovalService`'s `loadMonth()` → `persistMonth()` →
`upsertHeader()` chain still uses the update-capable primitive. This was a deliberate choice, not
an oversight: those call sites already committed to returning a specific legacy-derived snapshot
to an in-flight HTTP request by the time they write it, so a same-request race with another
lazy-load of the *same never-before-touched month* is self-consistent (both derive from the same
legacy source and would produce equivalent data) — whereas the backfill runs out-of-band via CLI
with no request depending on a specific return value, so it has no reason to reconcile with a
"winning" row and can simply treat "already exists" as terminal. Switching the hot lazy-load path
to insert-only would additionally require handling "someone else already created this row"
by re-fetching and returning *that* row instead of the stale legacy snapshot already in hand —
a real, separate change to code every "first view of an untouched month" request goes through,
independent of this backfill. Bundling it here would widen this change's blast radius for no
immediate benefit, following the same small-and-documented-over-broad-and-risky precedent already
established in §3.1's "Architecture note."

**Tests:**
- `tests/Unit/Domain/Timesheets/Repositories/MonthlyTimesheetRepositoryInsertIfAbsentTest.php`
  (8 cases, after §11.1) — inserts and returns the new id when no row exists; returns `null`
  without writing on a duplicate-key error; a *non*-duplicate insert failure is thrown, not
  silently treated as "already existed" — **verified to fail** against a version that mapped
  every failure to `null`; confirms the SQL is plain `INSERT` (not `INSERT IGNORE` or
  `ON DUPLICATE KEY UPDATE`); `findLegacyMonthCandidates()` produces the expected
  keyset-paginated query shape; `materializeIfAbsent()` commits header+entries together on
  success, commits without writing entries when the header already exists, and **rolls back
  instead of leaving a canonical header behind when entries fail after a successful header
  insert** — verified to fail against a non-transactional version of the method.
- `tests/Unit/Domain/Timesheets/Services/LegacyMonthBackfillServiceTest.php` (9 cases) —
  materializes a valid candidate with entries; does not overwrite a row that already exists at
  write time; **re-running after a materialized run is a no-op**, not an overwrite (idempotency);
  an out-of-range month (`_13`) and a non-numeric year/month are both rejected before any write
  is attempted — **verified to fail** when the month-range check was temporarily removed;
  malformed legacy meta for one candidate doesn't abort processing the rest of the batch; a
  thrown exception during materialization (e.g. `materializeIfAbsent()` re-throwing after its own
  rollback) is recorded in `failed[]`, not fatal; dry-run performs zero writes; multi-page
  batching aggregates counts correctly across pages.
- Confirmed `$container->get(LegacyMonthBackfillService::class)` resolves via the container's
  generic reflection-based autowiring (both constructor dependencies — `wpdb`,
  `MonthlyTimesheetRepository` — are already autowirable) with **no hand-written factory closure
  to fall out of sync** — deliberately avoiding the exact class of bug §3.5 found and fixed.

**Verification:**
```
composer test    → 162 tests, 0 new failures (same 3 pre-existing, unrelated)
composer lint    → PHP syntax OK (131 files)
npm run ci       → unaffected (no frontend changes); 74 tests passing
git diff --check → clean
```

**Not done / deliberately out of scope:** no in-dashboard "run backfill" button — that's P3.1
territory, and the CLI plus the §9.4 integrity-checker count is the intended operator workflow
for now. No persisted resume-cursor between separate CLI invocations (a re-run rescans from the
start, which is correctness-neutral, only a minor efficiency cost). No change to the lazy
read-path's own materialization primitive (see rationale above).

### 11.1 — Second-review correction round (post-P1.2)

A second independent review of the initial P1.2 diff raised two findings before approving it.
Both verified against the actual code and fixed.

**CONFIRMED, real gap: header and entries were not atomic.** The original `materializeOne()`
called `insertHeaderIfAbsent()` then `upsertEntries()` as two separate, unguarded steps. If
entries failed to write *after* the header insert had already succeeded, the month would end up
with a canonical header row but zero entries — and that state is effectively permanent and
silent: `findLegacyMonthCandidates()`'s `mt.id IS NULL` filter would no longer find the month (a
header row now exists), and the lazy read-path (`loadMonth()`) short-circuits on `getHeader()`
returning non-null, never falling back to legacy meta again. **Fix:** added
`MonthlyTimesheetRepository::materializeIfAbsent()`, wrapping the header insert and entries write
in one `START TRANSACTION`/`COMMIT`/`ROLLBACK` — an entries failure now rolls back the header
insert too, so the month remains a legitimate legacy-only candidate for the next run instead of a
silently-broken canonical row. `LegacyMonthBackfillService::materializeOne()` now calls this one
atomic method instead of the two separate ones.

**CONFIRMED, real gap: `INSERT IGNORE` was too broad.** It correctly suppressed duplicate-key
races, but MySQL's `IGNORE` modifier also downgrades *other* insert errors (data truncation,
implicit NOT NULL default substitution, etc.) into warnings — meaning a genuine problem could
have been silently miscounted as `skipped_existing` rather than surfaced as `failed`. **Fix:**
`insertHeaderIfAbsent()` now uses a plain `INSERT`, checks `$wpdb->query()`'s return value, and
inspects `$wpdb->last_error` for MySQL's actual duplicate-key error text (`"Duplicate entry"`) —
only that specific case becomes `null`/`skipped_existing`; any other failure is thrown as a
`\RuntimeException`, which the service correctly records in `failed[]`.

**Test-infrastructure change:** `tests/bootstrap.php`'s fake `wpdb` previously always returned
`true` from `query()`; added `queueQueryResult(bool)`/`queueLastError(string)` (same queue
pattern as the existing `queueRowsAffected`/`queueInsertId`) so tests can simulate a failed query
with a specific MySQL error message — purely additive, no existing test's behavior changed since
the new queues default to empty (unchanged `query()` behavior) unless a test explicitly opts in.

**Verified both fixes with fail-before/pass-after:** temporarily reverted `materializeIfAbsent()`
to the non-transactional two-call version — the new rollback test failed exactly as expected
(`Failed asserting that an array contains 'START TRANSACTION'`). Temporarily reverted the
duplicate-detection logic to treat every failure as `null` — the new non-duplicate-error test
failed exactly as expected (`Failed asserting that exception of type "RuntimeException" is
thrown`). Both reverts were then restored and the full suite re-confirmed clean.

### 11.2 — Third-review pass: the rollback still didn't trigger on a real entry-write failure

**CONFIRMED, real gap.** §11.1's rollback test used a partial mock (`onlyMethods(['upsertEntries'])`)
that overrode `upsertEntries()` to throw — proving `materializeIfAbsent()`'s try/catch+rollback
*shape* was correct, but not that the real, production `upsertEntries()` method ever actually
throws. It doesn't: it calls `$this->wpdb->query($sql)` per entry and never checks the result or
`$wpdb->last_error` — a genuine per-entry insert failure (data truncation, a bad connection
mid-loop, etc.) would silently continue, `materializeIfAbsent()` would then `COMMIT`, and the
exact partial-state bug §11.1 was meant to close (canonical header, missing/incomplete entries)
would still happen, just via a different trigger.

**Fix:** rather than making the shared, public `upsertEntries()` throw (it has three other,
unrelated callers — `DashboardController`, `MonthlyTimesheetService::persistMonth()`,
`TimesheetApprovalService::persistMonth()` — none of which were designed or tested around this
method suddenly being able to throw, and auditing/changing their behavior was judged out of scope
for this backfill), the per-entry SQL construction was extracted into a private
`buildEntryUpsertSql()` helper shared by both. `upsertEntries()` keeps its existing (silently
tolerant) behavior unchanged for its other callers. A new private `upsertEntriesOrThrow()` uses
the same SQL builder but checks every `$wpdb->query()` result and throws a `\RuntimeException` on
the first failure. `materializeIfAbsent()` now calls `upsertEntriesOrThrow()`, not `upsertEntries()`.

**Test:** rewrote `MonthlyTimesheetRepositoryInsertIfAbsentTest::testEntriesFailureAfterHeaderInsertRollsBackInsteadOfLeavingTheHeaderBehind`
to drop the partial mock entirely and instead configure the fake `wpdb` to return `false` with a
genuine (non-duplicate-key) error message specifically on the entries `INSERT` query, while the
preceding `START TRANSACTION` and header `INSERT` both succeed — this exercises the real
`upsertEntriesOrThrow()` write path, not a mocked collaborator. Asserts `ROLLBACK` was issued and
`COMMIT` was not. **Verified to fail against the pre-fix code**: temporarily reverted
`materializeIfAbsent()` to call `upsertEntries()` again — the test failed with `Expected the
entries failure to propagate` (no exception was thrown, exactly reproducing the reported bug),
then the fix was restored and the full suite (162 tests, same 3 pre-existing failures),
`composer lint`, and `git diff --check` were all re-confirmed clean.

---

## 12. P3.1 — Admin rescue actions (shipped)

**Build spec:** `docs/p3.1-admin-rescue-actions-plan.md` (researched, written, then revised once
by a review before implementation — see that doc's "Rev 2" note and the ⚠️ box in its §1: the
original draft would have desynced the comp-time ledger, caught before any code was written).

**Files:**
- `src/Domain/Timesheets/Services/CompTimeService.php` — new `hasMonthlyLedgerEntries()` (read-only
  diagnose helper).
- `src/Domain/Timesheets/Services/MonthlyTimesheetService.php` — extracted `finalizeSubmittedMonth()`
  from `saveMonth()`'s submit tail (pure refactor); new `rescueSubmitOnBehalf()`, `rescueForceLock()`,
  `reopenMonthToDraft()` (with `reopenLockedMonth()` now delegating to it after its own guard),
  `recalculateMonthStatus()`, `diagnoseMonth()`.
- `src/Domain/Timesheets/Repositories/ReeditRequestRepository.php` — new `cancelPending()`.
- `src/Http/Rest/Controllers/RescueController.php` (new) — 7 routes (`diagnose` + 6 actions),
  `checkRescuePermission()`.
- `src/Core/Plugin.php` — `RescueController` registered in `boot()`, autowired (no hand-written
  factory — see §3.5 for why that matters).
- `src/Http/Admin/Menu.php`, `src/Http/Admin/Pages/DashboardPage.php` — new "Admin Rescue" submenu
  + `currentUserCanSeeRescue()` + `renderRescue()`.
- Frontend: `src/Frontend/app/components/AdminRescue.tsx` (new), `pages/RescuePage.tsx` (new),
  `lib/routes.ts`, `lib/types/index.ts` (`Screen` union), `lib/copy.ts` (`rescue` block +
  `audit.actionLabels` entries), `styles.css`, plus a "Fix in Admin Rescue" deep-link added to
  `SystemStatus.tsx`'s Data Integrity Issues section (closing the loop with §9.4's checker).

**Access (§0 of the plan):** every route is gated by `AuthorizationService::hasOrgManagementPowers()`
— held by both HR and Tech-Admin (and, per §10.1, SuperAccess), and correctly excludes a plain
Manager. Deliberately **not** gated on `timesuite.system.view` (Tech-Admin-only, would have
excluded HR) and **not** scoped to a manager relationship (rescue is an org-wide tool, unlike
Manager View).

**The comp-time correction (why this wasn't a thin `updateMonthStatus()` wrapper):** the plugin
maintains an invariant — monthly comp-time (Time-in-Lieu) ledger rows exist iff a month is
submitted/approved/locked, cleared on return to draft. `updateMonthStatus()` only flips the header
status and never touches that ledger. A pre-implementation review caught that the original draft
of this spec would have desynced the ledger for any month with `overtime`/`time_in_lieu` entries.
Fixed by giving every status-changing rescue action a dedicated method
(`rescueSubmitOnBehalf`/`rescueForceLock`/`reopenMonthToDraft`/`recalculateMonthStatus`) built on
`finalizeSubmittedMonth()` (extracted from `saveMonth()`, so there's one place that knows how a
month becomes submitted/locked) — none of them call `updateMonthStatus()`. Also surfaced that
`applyMonthlyDebits()` can legitimately throw `ValidationException` on an unfunded time-in-lieu
day; the controller and frontend both handle this as a plain error, not a crash.

**Read-only `diagnose` endpoint:** added after review (not in the original plan) because loading
the plain `/monthly-timesheets` response isn't enough context to decide which rescue action is
right. `GET .../rescue/diagnose` reports canonical-vs-legacy state, whether a submitted month
should have auto-locked, comp-time consistency, and a pending re-edit request — without writing
anything (deliberately does not call `loadMonth()`/`getMonth()`, both of which materialize a
legacy-only month as a side effect of reading it; replicates that resolution using only read-only
primitives). Drives a `recommended_action` the frontend highlights.

**The six actions:**
1. **Submit on behalf** (draft/denied → submitted or auto-locked) — `rescueSubmitOnBehalf()`.
2. **Force-lock** (anything but locked → locked) — `rescueForceLock()`, applies comp-time even
   when locking straight from a draft with unapproved entries, preserves existing day approvals.
3. **Reopen to draft** (submitted/denied → draft) — `reopenMonthToDraft()`.
4. **Unlock** (locked → draft) — reuses the existing `reopenLockedMonth()` as-is (its own guard,
   now delegating internally to `reopenMonthToDraft()`).
5. **Recalculate status** (stuck submitted with no approval-required days → locked) — reuses the
   real `monthRequiresApproval()`, routes the actual transition through `rescueForceLock()` so the
   comp-time path is identical to a normal auto-lock.
6. **Clear stale re-edit request** (pending → cancelled, not approved/denied) — `cancelPending()`.

Every write action is audit-logged via the existing `ApprovalLogRepository::log()` with a
`rescue_*` action prefix and `source: 'rescue'` context (no schema change). `recalculate` and
`clear_reedit_request` only log when something actually changed, not on a no-op.

**Tests:**
- `tests/Unit/Domain/Timesheets/Services/CompTimeServiceHasMonthlyLedgerEntriesTest.php` (4 cases).
- `tests/Unit/MonthlyTimesheetServiceRescueTest.php` (17 cases) — the crux of this suite is
  comp-time side effects, not just status transitions: force-locking a draft month with an
  overtime entry applies credits, reopening a submitted month clears them, both **verified to
  fail** when temporarily reverted to naive `updateMonthStatus()`-based implementations (exactly
  reproducing the bug the review caught); an unfunded-time-in-lieu `ValidationException`
  propagates from both `rescueSubmitOnBehalf`/`rescueForceLock`; `diagnoseMonth()` never calls a
  repository write method.
- `tests/Unit/Domain/Timesheets/Repositories/ReeditRequestRepositoryCancelPendingTest.php` (4 cases).
- `tests/Integration/Http/Rest/RescueControllerTest.php` (19 cases) — the access gate (a plain
  Manager gets 403, `hasOrgManagementPowers` gets in), every action's happy path + audit log +
  precondition rejection, `diagnose` never triggers a write, no per-target scoping.
- `tests/Smoke/PluginContainerRegistrationTest.php` — `RescueController` added, confirms it
  autowires with no hand-written factory to fall out of sync.
- `src/Frontend/app/components/__tests__/AdminRescue.test.tsx` (8 cases) — picker, diagnosis
  load/display, per-action enable/disable by precondition, recommended-action highlight, the full
  confirm → post → success → reload flow, cancel-leaves-nothing-called, and a server error
  surfacing as a plain message.
- `src/Frontend/app/components/__tests__/SystemStatus.test.tsx` (+2 cases) — the deep-link
  renders for a user+month-scoped finding and is absent for an org-wide one.

**Verification:**
```
composer test    → 212 tests, 0 new failures (same 3 pre-existing, unrelated); order-independent
composer lint    → PHP syntax OK (136 files)
npm run ci       → tsc --noEmit clean; 85 tests passing (13 files)
git diff --check → clean
```

**Not done / deliberately out of scope (per the plan's §6):** P3.2's general state-transition
guard (each rescue action validates its own precondition inline instead); bulk rescue (single
target only, by design — a footgun for a manual repair tool); editing day-entry data (status/
workflow only); hard deletes (rescue transitions status and cancels a pending request, never
destroys data).

### 12.1 — Second-review correction round (post-P3.1 implementation)

A second independent review of the shipped P3.1 code raised three findings. Verified against the
actual code and fixed.

**CONFIRMED, real gap: `diagnoseMonth()` false-flagged normal months as comp-time-inconsistent.**
`comptime_expected` was computed as "the month is submitted/approved/locked," full stop — but a
perfectly ordinary submitted month with no `overtime`/`time_in_lieu` entries produces **zero**
ledger rows (`buildCompTimeCredits()`/`buildCompTimeDebits()` both return an empty array for such
a month, and `CompTimeService`'s apply methods are no-ops on an empty input). Every normal
submitted month with no comp-time usage would have been flagged `comptime_consistent: false`,
recommending an unnecessary `recalculate`. **Fix:** extracted the entry-scanning logic from
`applyCompTimeCredits()`/`applyCompTimeDebits()` into read-only `buildCompTimeCredits()`/
`buildCompTimeDebits()` helpers (pure refactor, same logic, no behavior change to the write
paths), and `comptime_expected` now requires both the status check **and** that the month's
entries would actually generate a credit or debit.

**CONFIRMED, real gap: submit/force-lock wasn't atomic around comp-time writes.** Credits were
applied, then debits (which can throw `ValidationException` on an unfunded time-in-lieu day —
`CompTimeService.php:60-62`), then the header persisted. A debit failure left the credit rows
already committed while the header status never changed — exactly the kind of comp-time/status
desync this whole feature exists to fix. **The first attempted fix (swap the write order to
debits-before-credits) was wrong and caught by a pre-existing test**:
`applyMonthlyDebits()` reads *all* of a user's credit rows (not scoped to the current month) to
check available balance, so a month with both an overtime day (credit) and a time-in-lieu day
(debit) needs its *own* new credit already written before the debit check runs — reordering broke
`testSubmittingMonthAppliesCompTimeCreditsBeforeDebits` immediately. **Actual fix:** kept the
credits-then-debits order and wrapped the whole credits+debits+persist sequence in a transaction
(new `MonthlyTimesheetRepository::beginTransaction()`/`commitTransaction()`/`rollbackTransaction()`
thin wrappers, same pattern as §11.1's `materializeIfAbsent()`) — a debit failure now rolls back
the already-written credits and never touches the header, a clean no-op instead of a partial
write.

**CONFIRMED, real gap: a `cross_layer_mismatch` was diagnosable but not actionable.**
`diagnoseMonth()` already computed `cross_layer_mismatch`, but `recommendAction()` never
referenced it, silently falling through to `null` ("nothing to fix") even when the canonical and
legacy status disagree. None of the six rescue actions touch entry data (by design — see the
plan's §6), so there is no safe one-click fix for this case. **Fix:** `cross_layer_mismatch` now
recommends a new `manual_review` outcome, checked *first* (ahead of every other heuristic, since a
mismatch means the canonical entries those heuristics reason about may themselves be untrustworthy).
The frontend renders this as a distinct notice pointing to §5's manual-check guidance instead of
trying to map it to a clickable action button — `manual_review` deliberately isn't in the action
button list, so nothing gets mis-highlighted as "recommended."

**Tests:** `tests/Unit/MonthlyTimesheetServiceRescueTest.php` — replaced the one test that had
encoded the old, wrong `comptime_expected` behavior with two new cases (a working-day-only
submitted month is correctly `comptime_consistent: true`; an overtime day with no matching ledger
row is correctly flagged `false`), plus a new orchestration test proving a debit failure calls
`beginTransaction`/`rollbackTransaction` and never `commitTransaction`, and leaves the header
status unchanged. `tests/Unit/Domain/Timesheets/Repositories/MonthlyTimesheetRepositoryInsertIfAbsentTest.php`
gained a test for the raw SQL the new transaction wrappers issue.
`tests/Integration/Http/Rest/RescueControllerTest.php` gained a test proving `manual_review` wins
over `recalculate` when both would otherwise apply. `src/Frontend/app/components/__tests__/AdminRescue.test.tsx`
gained a test for the manual-review notice. **All three fixes verified fail-before/pass-after**:
temporarily reverted `comptime_expected` to the status-only version (new tests failed exactly as
expected); temporarily removed the transaction wrap (the new orchestration test failed exactly as
expected); both reverts restored and the full suite re-confirmed clean.

**Verification after this round:**
```
composer test    → 212 tests, 0 new failures (same 3 pre-existing, unrelated); order-independent
composer lint    → PHP syntax OK (136 files)
npm run ci       → tsc --noEmit clean; 85 tests passing (13 files)
git diff --check → clean
```
