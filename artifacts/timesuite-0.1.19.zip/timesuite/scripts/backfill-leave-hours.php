#!/usr/bin/env php
<?php

declare(strict_types=1);

use Timesuite\Core\Settings;
use Timesuite\Domain\Timesheets\Repositories\HolidayRangeRepository;
use Timesuite\Domain\Timesheets\Services\HolidayRangeService;
use Timesuite\Domain\Timesheets\Services\VacationService;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This script must be run from the command line.\n");
    exit(1);
}

requireWordPress();
requirePluginAutoload();

/** @var wpdb $wpdb */
global $wpdb;

$options = parseArgs($argv);
$year = $options['year'] ?? (int) gmdate('Y');
$commit = $options['commit'] ?? false;
$userIds = resolveUserIds($wpdb, $options['user'] ?? null);

$settings = Settings::load();
$holidayService = new HolidayRangeService(new HolidayRangeRepository($wpdb), $settings);
$vacationService = new VacationService($wpdb, $settings, $holidayService);

$counts = [
    'users_scanned' => 0,
    'users_updated' => 0,
    'vacation_contract_hours' => 0,
    'sick_contract_hours' => 0,
    'vacation_adjustment_hours' => 0,
    'sick_adjustment_hours' => 0,
];

$mismatches = [];

echo "Timesuite leave-hours backfill\n";
echo "=============================\n";
echo 'Mode: ' . ($commit ? 'COMMIT' : 'DRY RUN') . "\n";
echo "Year: {$year}\n";
echo 'Users: ' . count($userIds) . "\n\n";

foreach ($userIds as $userId) {
    $counts['users_scanned']++;
    $hours = $vacationService->getHoursStats($userId, $year);
    $before = $vacationService->getStats($userId, $year);
    $updates = [];

    if (! hasNumericUserMeta($userId, 'timesuite_vacation_contract_hours')) {
        $updates['timesuite_vacation_contract_hours'] = $hours['vacation_contract_hours'];
        $counts['vacation_contract_hours']++;
    }

    if (! hasNumericUserMeta($userId, 'timesuite_sick_contract_hours')) {
        $updates['timesuite_sick_contract_hours'] = $hours['sick_contract_hours'];
        $counts['sick_contract_hours']++;
    }

    if (
        ! hasNumericUserMeta($userId, 'timesuite_vacation_balance_adjustment_hours')
        && abs((float) $hours['vacation_adjustment_hours']) >= 0.005
    ) {
        $updates['timesuite_vacation_balance_adjustment_hours'] = $hours['vacation_adjustment_hours'];
        $counts['vacation_adjustment_hours']++;
    }

    if (
        ! hasNumericUserMeta($userId, 'timesuite_sick_balance_adjustment_hours')
        && abs((float) $hours['sick_adjustment_hours']) >= 0.005
    ) {
        $updates['timesuite_sick_balance_adjustment_hours'] = $hours['sick_adjustment_hours'];
        $counts['sick_adjustment_hours']++;
    }

    if (empty($updates)) {
        continue;
    }

    $counts['users_updated']++;
    printf(
        "User %d: %s\n",
        $userId,
        implode(
            ', ',
            array_map(
                static fn(string $key, mixed $value): string => $key . '=' . formatNumber((float) $value),
                array_keys($updates),
                array_values($updates)
            )
        )
    );

    if ($commit) {
        foreach ($updates as $metaKey => $value) {
            update_user_meta($userId, $metaKey, $value);
        }

        $after = $vacationService->getStats($userId, $year);
        if (
            (float) $before['vacation_remaining'] !== (float) $after['vacation_remaining']
            || (float) $before['sick_remaining'] !== (float) $after['sick_remaining']
            || (float) $before['vacation_used'] !== (float) $after['vacation_used']
            || (float) $before['sick_used'] !== (float) $after['sick_used']
        ) {
            $mismatches[] = sprintf(
                'User %d changed display stats after backfill (vacation %s -> %s, sick %s -> %s)',
                $userId,
                formatNumber((float) $before['vacation_remaining']),
                formatNumber((float) $after['vacation_remaining']),
                formatNumber((float) $before['sick_remaining']),
                formatNumber((float) $after['sick_remaining'])
            );
        }
    }
}

echo "\nSummary\n";
echo "-------\n";
foreach ($counts as $label => $value) {
    echo str_replace('_', ' ', $label) . ': ' . $value . "\n";
}

if (! empty($mismatches)) {
    echo "\nMismatches detected\n";
    echo "-------------------\n";
    foreach ($mismatches as $mismatch) {
        echo '- ' . $mismatch . "\n";
    }

    exit(1);
}

echo "\nNo display-balance mismatches detected.\n";
exit(0);

/**
 * @return array{commit?: bool, year?: int, user?: string}
 */
function parseArgs(array $argv): array
{
    $parsed = [];

    foreach (array_slice($argv, 1) as $arg) {
        if ($arg === '--commit') {
            $parsed['commit'] = true;
            continue;
        }

        if (str_starts_with($arg, '--year=')) {
            $parsed['year'] = (int) substr($arg, 7);
            continue;
        }

        if (str_starts_with($arg, '--user=')) {
            $parsed['user'] = substr($arg, 7);
        }
    }

    return $parsed;
}

function requireWordPress(): void
{
    $candidates = [
        dirname(__DIR__, 4) . '/wp-load.php',
        dirname(__DIR__, 5) . '/wp-load.php',
        dirname(__DIR__, 6) . '/wp-load.php',
    ];

    foreach ($candidates as $candidate) {
        if (is_readable($candidate)) {
            require_once $candidate;
            return;
        }
    }

    fwrite(STDERR, "Could not locate wp-load.php.\n");
    exit(1);
}

function requirePluginAutoload(): void
{
    $autoload = dirname(__DIR__) . '/vendor/autoload.php';

    if (is_readable($autoload)) {
        require_once $autoload;
    }
}

/**
 * @return int[]
 */
function resolveUserIds(wpdb $wpdb, ?string $rawUserIds): array
{
    if (is_string($rawUserIds) && trim($rawUserIds) !== '') {
        $userIds = array_values(
            array_filter(
                array_map('intval', array_map('trim', explode(',', $rawUserIds))),
                static fn(int $userId): bool => $userId > 0
            )
        );

        if (! empty($userIds)) {
            return $userIds;
        }
    }

    $rows = $wpdb->get_col("SELECT ID FROM {$wpdb->users} ORDER BY ID ASC");

    return array_map('intval', $rows ?? []);
}

function hasNumericUserMeta(int $userId, string $metaKey): bool
{
    $value = get_user_meta($userId, $metaKey, true);

    return $value !== '' && $value !== null && is_numeric($value);
}

function formatNumber(float $value): string
{
    $rounded = round($value, 2);

    if (abs($rounded - round($rounded)) < 0.001) {
        return (string) (int) round($rounded);
    }

    return rtrim(rtrim(number_format($rounded, 2, '.', ''), '0'), '.');
}
