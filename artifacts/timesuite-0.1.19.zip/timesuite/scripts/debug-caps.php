<?php
/**
 * Debug script to check capability flow
 */

// Load WordPress
require_once dirname(__DIR__, 4) . '/wp-load.php';

if (!current_user_can('manage_options')) {
    wp_die('Must be admin');
}

header('Content-Type: text/html; charset=utf-8');

$user = wp_get_current_user();
$meta_key = 'timesuite_access_role';
$role = get_user_meta($user->ID, $meta_key, true);

echo "<h1>Timesuite Capability Debug</h1>";

echo "<h2>1. User Info</h2>";
echo "<pre>";
echo "User ID: " . $user->ID . "\n";
echo "Email: " . $user->user_email . "\n";
echo "Timesuite Role (from meta): " . ($role ?: '(not set)') . "\n";
echo "</pre>";

echo "<h2>2. Raw User Meta Check</h2>";
global $wpdb;
$meta_check = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key = %s",
    $user->ID,
    $meta_key
));
echo "<pre>";
print_r($meta_check);
echo "</pre>";

echo "<h2>3. Capability Checks (current_user_can)</h2>";
$test_caps = [
    'timesuite.timesheet.view_own',
    'timesuite.settings.manage',
    'timesuite.org.view',
    'timesuite.system.view',
];

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Capability</th><th>current_user_can()</th></tr>";
foreach ($test_caps as $cap) {
    $has = current_user_can($cap) ? '✅ YES' : '❌ NO';
    echo "<tr><td>{$cap}</td><td>{$has}</td></tr>";
}
echo "</table>";

echo "<h2>4. TimesuiteAccess Class Check</h2>";
if (class_exists('Timesuite\Core\TimesuiteAccess')) {
    $class = 'Timesuite\Core\TimesuiteAccess';
    echo "<pre>";
    echo "Class exists: YES\n";
    echo "getEffectiveRoleForUserId({$user->ID}): " . $class::getEffectiveRoleForUserId($user->ID) . "\n";
    echo "hasTechAdmin(): " . ($class::hasTechAdmin() ? 'YES' : 'NO') . "\n";
    echo "</pre>";
} else {
    echo "<p style='color:red'>TimesuiteAccess class NOT LOADED!</p>";
}

echo "<h2>5. Filter Registration Check</h2>";
global $wp_filter;
echo "<pre>";
if (isset($wp_filter['user_has_cap'])) {
    echo "user_has_cap filter has " . count($wp_filter['user_has_cap']->callbacks) . " priority levels\n\n";
    foreach ($wp_filter['user_has_cap']->callbacks as $priority => $callbacks) {
        foreach ($callbacks as $id => $callback) {
            if (strpos($id, 'Timesuite') !== false || strpos($id, 'timesuite') !== false) {
                echo "Priority {$priority}: {$id}\n";
            }
        }
    }
} else {
    echo "user_has_cap filter not found!\n";
}
echo "</pre>";

echo "<h2>6. Quick Fix</h2>";
echo "<p>If capabilities aren't working, the filter may not be registered. Try reactivating the plugin.</p>";
echo "<p><a href='" . admin_url('plugins.php') . "'>Go to Plugins page</a></p>";
