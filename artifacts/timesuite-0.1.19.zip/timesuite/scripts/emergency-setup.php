<?php
/**
 * Timesuite Emergency Setup Script
 * 
 * Run this script once to grant yourself Timesuite admin access.
 * 
 * Usage: Visit this URL in your browser while logged into WordPress as admin:
 * /wp-content/plugins/timesuite/scripts/emergency-setup.php
 * 
 * DELETE THIS FILE AFTER USE!
 * 
 * NOTE: This script intentionally uses direct meta access for emergency purposes.
 * In normal operation, all role changes go through RoleAssignmentService.
 */

// Load WordPress
$wp_load_paths = [
    dirname(__DIR__, 4) . '/wp-load.php',           // Local by Flywheel (public folder)
    dirname(__DIR__, 5) . '/wp-load.php',           // Standard WP structure
    dirname(__DIR__, 6) . '/wp-load.php',           // Some hosts
];

$wp_loaded = false;
foreach ($wp_load_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $wp_loaded = true;
        break;
    }
}

if (!$wp_loaded) {
    die('Could not find wp-load.php. Please run this from WordPress admin or adjust the path.');
}

// Security: Only allow WordPress administrators
if (!current_user_can('manage_options')) {
    wp_die('Access denied. You must be logged in as a WordPress administrator.', 'Access Denied', ['response' => 403]);
}

// Get current user
$current_user = wp_get_current_user();

// Use the same meta key as the new access system
// This matches Timesuite\Core\Access\AuthorizationService::META_KEY
$meta_key = 'timesuite_access_role';
$role_value = 'tech_admin'; // Matches Timesuite\Core\Access\Role::TECH_ADMIN

/**
 * Log emergency access action.
 * 
 * Attempts to use the audit system if available, falls back to error_log.
 */
function timesuite_emergency_log(string $action, int $userId, string $details): void {
    global $wpdb;
    
    // Try to log to audit table if it exists
    $table = $wpdb->prefix . 'timesuite_approvals_log';
    
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") === $table) {
        $wpdb->insert($table, [
            'action' => $action,
            'actor_id' => get_current_user_id(),
            'target_user_id' => $userId,
            'details' => $details,
            'created_at' => current_time('mysql', true),
        ]);
    }
    
    // Also log to error_log for traceability
    // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
    error_log(sprintf('[Timesuite Emergency] %s: %s', $action, $details));
}

// HTML output
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Timesuite Emergency Setup</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f0f0f1;
        }
        .card {
            background: white;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        h1 { color: #1d2327; margin-top: 0; }
        h2 { color: #1d2327; margin-top: 0; font-size: 1.2em; }
        .success { background: #d4edda; border-color: #c3e6cb; color: #155724; padding: 12px; border-radius: 4px; }
        .warning { background: #fff3cd; border-color: #ffeeba; color: #856404; padding: 12px; border-radius: 4px; }
        .info { background: #d1ecf1; border-color: #bee5eb; color: #0c5460; padding: 12px; border-radius: 4px; margin-bottom: 16px; }
        .error { background: #f8d7da; border-color: #f5c6cb; color: #721c24; padding: 12px; border-radius: 4px; }
        table { width: 100%; border-collapse: collapse; margin: 16px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f6f7f7; }
        code { background: #f0f0f1; padding: 2px 6px; border-radius: 3px; }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #2271b1;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }
        .btn:hover { background: #135e96; }
        .btn-danger { background: #d63638; }
        .btn-danger:hover { background: #b32d2e; }
        .btn-success { background: #00a32a; }
        .btn-success:hover { background: #008a20; }
    </style>
</head>
<body>
    <div class="card">
        <h1>🔧 Timesuite Emergency Setup</h1>
        <p>This script helps you regain access to Timesuite after moving to a new environment.</p>
    </div>

    <?php
    // Check current state
    global $wpdb;
    
    // Get all existing Timesuite users
    $existing_admins = $wpdb->get_results($wpdb->prepare(
        "SELECT u.ID, u.user_email, u.display_name, um.meta_value as timesuite_role
         FROM {$wpdb->users} u
         JOIN {$wpdb->usermeta} um ON u.ID = um.user_id
         WHERE um.meta_key = %s",
        $meta_key
    ));
    
    // Check if current user already has access
    $current_user_role = get_user_meta($current_user->ID, $meta_key, true);
    
    // Handle form submission
    $action_taken = false;
    $action_message = '';
    
    if (isset($_POST['action']) && wp_verify_nonce($_POST['_wpnonce'], 'timesuite_emergency_setup')) {
        if ($_POST['action'] === 'grant_access') {
            update_user_meta($current_user->ID, $meta_key, $role_value);
            $action_taken = true;
            $action_message = "✅ Success! You ({$current_user->user_email}) are now a Timesuite tech_admin.";
            $current_user_role = $role_value;
            
            // Log this emergency action
            timesuite_emergency_log(
                'emergency_role_grant',
                $current_user->ID,
                sprintf(
                    'Emergency setup: %s granted themselves tech_admin role',
                    $current_user->user_email
                )
            );
            
            // Clear any caches (if classes are available)
            if (class_exists('\\Timesuite\\Core\\Access\\AuthorizationService')) {
                \Timesuite\Core\Access\AuthorizationService::clearAllCaches();
            }
            if (class_exists('\\Timesuite\\Core\\Access\\BootstrapService')) {
                \Timesuite\Core\Access\BootstrapService::clearCache();
            }
            
            // Refresh existing admins list
            $existing_admins = $wpdb->get_results($wpdb->prepare(
                "SELECT u.ID, u.user_email, u.display_name, um.meta_value as timesuite_role
                 FROM {$wpdb->users} u
                 JOIN {$wpdb->usermeta} um ON u.ID = um.user_id
                 WHERE um.meta_key = %s",
                $meta_key
            ));
        } elseif ($_POST['action'] === 'clear_all') {
            $wpdb->delete($wpdb->usermeta, ['meta_key' => $meta_key]);
            $action_taken = true;
            $action_message = "✅ All Timesuite role assignments have been cleared. Bootstrap mode will now activate.";
            $existing_admins = [];
            $current_user_role = '';
            
            // Log this emergency action
            timesuite_emergency_log(
                'emergency_role_clear',
                0,
                sprintf(
                    'Emergency setup: %s cleared ALL Timesuite role assignments',
                    $current_user->user_email
                )
            );
            
            // Clear caches
            if (class_exists('\\Timesuite\\Core\\Access\\AuthorizationService')) {
                \Timesuite\Core\Access\AuthorizationService::clearAllCaches();
            }
            if (class_exists('\\Timesuite\\Core\\Access\\BootstrapService')) {
                \Timesuite\Core\Access\BootstrapService::clearCache();
            }
        }
    }
    
    if ($action_taken): ?>
        <div class="card">
            <div class="success"><?php echo esc_html($action_message); ?></div>
            <p style="margin-top: 16px;">
                <a href="<?php echo admin_url('admin.php?page=timesuite'); ?>" class="btn btn-success">
                    → Go to Timesuite
                </a>
            </p>
        </div>
    <?php endif; ?>

    <div class="card">
        <h2>📊 Current Status</h2>
        
        <div class="info">
            <strong>You are logged in as:</strong><br>
            <?php echo esc_html($current_user->display_name); ?> (<?php echo esc_html($current_user->user_email); ?>)<br>
            <strong>Your Timesuite role:</strong> <?php echo $current_user_role ? esc_html($current_user_role) : '<em>None (no access)</em>'; ?>
        </div>
        
        <h3>Existing Timesuite Users</h3>
        <?php if (empty($existing_admins)): ?>
            <div class="warning">
                <strong>No Timesuite users found.</strong><br>
                Bootstrap mode should be active - any WordPress admin can set up the first user.
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Timesuite Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($existing_admins as $admin): ?>
                        <tr>
                            <td><?php echo esc_html($admin->ID); ?></td>
                            <td><?php echo esc_html($admin->display_name); ?></td>
                            <td><?php echo esc_html($admin->user_email); ?></td>
                            <td><code><?php echo esc_html($admin->timesuite_role); ?></code></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p><em>These users have Timesuite access. If you moved from another environment, these user IDs may not match actual users on this site.</em></p>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>🚀 Actions</h2>
        
        <form method="post" style="margin-bottom: 16px;">
            <?php wp_nonce_field('timesuite_emergency_setup'); ?>
            <input type="hidden" name="action" value="grant_access">
            <p><strong>Option 1: Grant yourself admin access</strong></p>
            <p>This will make you (<?php echo esc_html($current_user->user_email); ?>) a Timesuite tech_admin.</p>
            <button type="submit" class="btn btn-success">
                ✓ Make me a Timesuite Admin
            </button>
        </form>
        
        <hr style="margin: 24px 0;">
        
        <form method="post">
            <?php wp_nonce_field('timesuite_emergency_setup'); ?>
            <input type="hidden" name="action" value="clear_all">
            <p><strong>Option 2: Clear all Timesuite roles</strong></p>
            <p>This removes ALL Timesuite role assignments, triggering bootstrap mode. Use this if you want a fresh start.</p>
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure? This will remove ALL Timesuite role assignments.');">
                ⚠ Clear All Roles (Fresh Start)
            </button>
        </form>
    </div>

    <div class="card">
        <h2>⚠️ Important: Delete This File!</h2>
        <div class="warning">
            <strong>After you've regained access, delete this file for security:</strong><br>
            <code><?php echo esc_html(__FILE__); ?></code>
        </div>
    </div>
</body>
</html>
