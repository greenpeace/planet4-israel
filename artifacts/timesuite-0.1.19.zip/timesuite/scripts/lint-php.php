<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$paths = [
    $root . '/src',
    $root . '/scripts',
    $root . '/tests',
];
$files = [
    $root . '/timesuite.php',
    $root . '/uninstall.php',
];

foreach ($paths as $path) {
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iterator as $file) {
        if ($file->isFile() && strtolower($file->getExtension()) === 'php') {
            $files[] = $file->getPathname();
        }
    }
}

$failed = false;

foreach ($files as $file) {
    $command = escapeshellarg(PHP_BINARY) . ' -l ' . escapeshellarg($file);
    exec($command, $output, $exitCode);

    if ($exitCode !== 0) {
        $failed = true;
        fwrite(STDERR, implode(PHP_EOL, $output) . PHP_EOL);
    }

    $output = [];
}

if ($failed) {
    exit(1);
}

echo sprintf("PHP syntax OK (%d files)%s", count($files), PHP_EOL);
