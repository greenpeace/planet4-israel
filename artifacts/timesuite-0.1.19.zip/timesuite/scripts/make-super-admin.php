<?php
/**
 * One-time script to add current user as Timesuite Super Admin
 */

require_once dirname(__DIR__, 4) . '/wp-load.php';

if (!current_user_can('manage_options')) {
    wp_die('Must be WordPress admin');
}

$user = wp_get_current_user();
$email = strtolower($user->user_email);

// Get current settings
$settings = get_option('timesuite_settings', []);
if (!is_array($settings)) {
    $settings = [];
}

// Add email to super users list
$superEmails = $settings['super_user_emails'] ?? [];
if (!is_array($superEmails)) {
    $superEmails = [];
}

if (!in_array($email, $superEmails)) {
    $superEmails[] = $email;
    $settings['super_user_emails'] = $superEmails;
    update_option('timesuite_settings', $settings);
    echo "<h1>✅ Done!</h1>";
    echo "<p>Added <strong>{$email}</strong> as Timesuite Super Admin.</p>";
} else {
    echo "<h1>Already a Super Admin</h1>";
    echo "<p><strong>{$email}</strong> is already in the super user list.</p>";
}

echo "<p><a href='" . admin_url('admin.php?page=timesuite') . "'>Go to Timesuite →</a></p>";
echo "<p style='color: #666; margin-top: 30px;'><em>Delete this script after use: scripts/make-super-admin.php</em></p>";
