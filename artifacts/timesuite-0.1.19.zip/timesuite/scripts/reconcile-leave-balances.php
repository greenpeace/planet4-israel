#!/usr/bin/env php
<?php

declare(strict_types=1);

use Timesuite\Core\Settings;
use Timesuite\Domain\Timesheets\Repositories\HolidayRangeRepository;
use Timesuite\Domain\Timesheets\Services\HolidayRangeService;
use Timesuite\Domain\Timesheets\Services\VacationService;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This script must be run from the command line.\n");
    exit(1);
}

requireWordPress();
requirePluginAutoload();

/** @var wpdb $wpdb */
global $wpdb;

$options = parseArgs($argv);
$year = $options['year'] ?? (int) gmdate('Y');
$userIds = resolveUserIds($wpdb, $options['user'] ?? null);

$settings = Settings::load();
$holidayService = new HolidayRangeService(new HolidayRangeRepository($wpdb), $settings);
$vacationService = new VacationService($wpdb, $settings, $holidayService);

$issues = [];
$rowsChecked = 0;

echo "Timesuite leave-balance reconciliation\n";
echo "=====================================\n";
echo "Year: {$year}\n";
echo 'Users: ' . count($userIds) . "\n\n";

foreach ($userIds as $userId) {
    $rowsChecked++;
    $display = $vacationService->getStats($userId, $year);
    $hours = $vacationService->getHoursStats($userId, $year);
    $standard = (float) $hours['standard_day_hours'];

    $vacationExpectedDays = round($hours['vacation_remaining_hours'] / $standard, 1);
    $sickExpectedDays = round($hours['sick_remaining_hours'] / $standard, 1);
    $vacationUsedDays = round($hours['vacation_used_hours'] / $standard, 1);
    $sickUsedDays = round($hours['sick_used_hours'] / $standard, 1);

    $userIssues = [];

    if (! hasNumericUserMeta($userId, 'timesuite_vacation_contract_hours')) {
        $userIssues[] = 'missing vacation_contract_hours';
    }

    if (! hasNumericUserMeta($userId, 'timesuite_sick_contract_hours')) {
        $userIssues[] = 'missing sick_contract_hours';
    }

    if (
        hasNumericUserMeta($userId, 'timesuite_vacation_balance_adjustment')
        && ! hasNumericUserMeta($userId, 'timesuite_vacation_balance_adjustment_hours')
    ) {
        $userIssues[] = 'legacy vacation adjustment still not backfilled';
    }

    if (
        hasNumericUserMeta($userId, 'timesuite_sick_balance_adjustment')
        && ! hasNumericUserMeta($userId, 'timesuite_sick_balance_adjustment_hours')
    ) {
        $userIssues[] = 'legacy sick adjustment still not backfilled';
    }

    if (round((float) $display['vacation_remaining'], 1) !== $vacationExpectedDays) {
        $userIssues[] = sprintf(
            'vacation remaining mismatch (%s displayed vs %s expected)',
            formatNumber((float) $display['vacation_remaining']),
            formatNumber($vacationExpectedDays)
        );
    }

    if (round((float) $display['sick_remaining'], 1) !== $sickExpectedDays) {
        $userIssues[] = sprintf(
            'sick remaining mismatch (%s displayed vs %s expected)',
            formatNumber((float) $display['sick_remaining']),
            formatNumber($sickExpectedDays)
        );
    }

    if (round((float) $display['vacation_used'], 1) !== $vacationUsedDays) {
        $userIssues[] = sprintf(
            'vacation used mismatch (%s displayed vs %s expected)',
            formatNumber((float) $display['vacation_used']),
            formatNumber($vacationUsedDays)
        );
    }

    if (round((float) $display['sick_used'], 1) !== $sickUsedDays) {
        $userIssues[] = sprintf(
            'sick used mismatch (%s displayed vs %s expected)',
            formatNumber((float) $display['sick_used']),
            formatNumber($sickUsedDays)
        );
    }

    if ((float) $hours['vacation_remaining_hours'] < -0.01) {
        $userIssues[] = 'negative vacation remaining hours';
    }

    if ((float) $hours['sick_remaining_hours'] < -0.01) {
        $userIssues[] = 'negative sick remaining hours';
    }

    if (! empty($userIssues)) {
        $issues[] = [
            'user_id' => $userId,
            'issues' => $userIssues,
        ];
    }
}

echo "Checked users: {$rowsChecked}\n";
echo 'Users with issues: ' . count($issues) . "\n";

if (empty($issues)) {
    echo "\nReconciliation clean.\n";
    exit(0);
}

echo "\nIssues\n";
echo "------\n";
foreach ($issues as $issue) {
    echo 'User ' . $issue['user_id'] . ': ' . implode('; ', $issue['issues']) . "\n";
}

exit(1);

/**
 * @return array{year?: int, user?: string}
 */
function parseArgs(array $argv): array
{
    $parsed = [];

    foreach (array_slice($argv, 1) as $arg) {
        if (str_starts_with($arg, '--year=')) {
            $parsed['year'] = (int) substr($arg, 7);
            continue;
        }

        if (str_starts_with($arg, '--user=')) {
            $parsed['user'] = substr($arg, 7);
        }
    }

    return $parsed;
}

function requireWordPress(): void
{
    $candidates = [
        dirname(__DIR__, 4) . '/wp-load.php',
        dirname(__DIR__, 5) . '/wp-load.php',
        dirname(__DIR__, 6) . '/wp-load.php',
    ];

    foreach ($candidates as $candidate) {
        if (is_readable($candidate)) {
            require_once $candidate;
            return;
        }
    }

    fwrite(STDERR, "Could not locate wp-load.php.\n");
    exit(1);
}

function requirePluginAutoload(): void
{
    $autoload = dirname(__DIR__) . '/vendor/autoload.php';

    if (is_readable($autoload)) {
        require_once $autoload;
    }
}

/**
 * @return int[]
 */
function resolveUserIds(wpdb $wpdb, ?string $rawUserIds): array
{
    if (is_string($rawUserIds) && trim($rawUserIds) !== '') {
        $userIds = array_values(
            array_filter(
                array_map('intval', array_map('trim', explode(',', $rawUserIds))),
                static fn(int $userId): bool => $userId > 0
            )
        );

        if (! empty($userIds)) {
            return $userIds;
        }
    }

    $rows = $wpdb->get_col("SELECT ID FROM {$wpdb->users} ORDER BY ID ASC");

    return array_map('intval', $rows ?? []);
}

function hasNumericUserMeta(int $userId, string $metaKey): bool
{
    $value = get_user_meta($userId, $metaKey, true);

    return $value !== '' && $value !== null && is_numeric($value);
}

function formatNumber(float $value): string
{
    $rounded = round($value, 2);

    if (abs($rounded - round($rounded)) < 0.001) {
        return (string) (int) round($rounded);
    }

    return rtrim(rtrim(number_format($rounded, 2, '.', ''), '0'), '.');
}
