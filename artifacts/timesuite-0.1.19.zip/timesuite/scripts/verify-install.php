#!/usr/bin/env php
<?php
/**
 * Timesuite Installation Verification Script
 *
 * Verifies that all dependencies are correctly installed and
 * the environment is properly configured.
 *
 * Usage:
 *   php scripts/verify-install.php
 *
 * Exit codes:
 *   0 - All checks passed
 *   1 - One or more checks failed
 */

declare(strict_types=1);

$errors = [];
$warnings = [];

echo "Timesuite Installation Verification\n";
echo "====================================\n\n";

// 1. PHP Version
echo "Checking PHP version... ";
$phpVersion = PHP_VERSION;
if (version_compare($phpVersion, '8.1.0', '<')) {
    $errors[] = "PHP 8.1+ required, found {$phpVersion}";
    echo "FAIL\n";
} else {
    echo "OK ({$phpVersion})\n";
}

// 2. Required PHP Extensions
echo "Checking PHP extensions... ";
$requiredExtensions = ['mbstring', 'json'];
$optionalExtensions = ['zip' => 'Required for XLSX exports'];
$missingRequired = [];
$missingOptional = [];

foreach ($requiredExtensions as $ext) {
    if (!extension_loaded($ext)) {
        $missingRequired[] = $ext;
    }
}

foreach ($optionalExtensions as $ext => $reason) {
    if (!extension_loaded($ext)) {
        $missingOptional[$ext] = $reason;
    }
}

if (!empty($missingRequired)) {
    $errors[] = "Missing required extensions: " . implode(', ', $missingRequired);
    echo "FAIL\n";
} else {
    echo "OK\n";
}

if (!empty($missingOptional)) {
    foreach ($missingOptional as $ext => $reason) {
        $warnings[] = "Optional extension '{$ext}' not loaded: {$reason}";
    }
}

// 3. Composer Dependencies
echo "Checking Composer dependencies... ";
$composerLock = __DIR__ . '/../composer.lock';
$vendorAutoload = __DIR__ . '/../vendor/autoload.php';

if (!file_exists($composerLock)) {
    $errors[] = "composer.lock not found - run 'composer install'";
    echo "FAIL\n";
} elseif (!file_exists($vendorAutoload)) {
    $errors[] = "vendor/autoload.php not found - run 'composer install'";
    echo "FAIL\n";
} else {
    echo "OK\n";
}

// 4. NPM Dependencies
echo "Checking NPM dependencies... ";
$packageLock = __DIR__ . '/../package-lock.json';
$nodeModules = __DIR__ . '/../node_modules';

if (!file_exists($packageLock)) {
    $errors[] = "package-lock.json not found - run 'npm install'";
    echo "FAIL\n";
} elseif (!is_dir($nodeModules)) {
    $errors[] = "node_modules not found - run 'npm install'";
    echo "FAIL\n";
} else {
    echo "OK\n";
}

// 5. Built Assets
echo "Checking built assets... ";
$manifestPaths = [
    __DIR__ . '/../assets/.vite/manifest.json',
    __DIR__ . '/../assets/manifest.json',
];
$manifestFound = false;

foreach ($manifestPaths as $path) {
    if (file_exists($path)) {
        $manifestFound = true;
        break;
    }
}

if (!$manifestFound) {
    $warnings[] = "Frontend assets not built - run 'npm run build'";
    echo "WARNING\n";
} else {
    echo "OK\n";
}

// 6. File Permissions
echo "Checking file permissions... ";
$pluginDir = dirname(__DIR__);
if (!is_readable($pluginDir)) {
    $errors[] = "Plugin directory is not readable";
    echo "FAIL\n";
} else {
    echo "OK\n";
}

// 7. WordPress Environment (if running within WP)
if (defined('ABSPATH')) {
    echo "Checking WordPress environment... ";
    
    if (!function_exists('get_bloginfo')) {
        $warnings[] = "WordPress functions not available";
        echo "WARNING\n";
    } else {
        $wpVersion = get_bloginfo('version');
        if (version_compare($wpVersion, '6.0', '<')) {
            $warnings[] = "WordPress 6.0+ recommended, found {$wpVersion}";
            echo "WARNING\n";
        } else {
            echo "OK ({$wpVersion})\n";
        }
    }
}

// 8. Cross-platform path check
echo "Checking path handling... ";
$testPath = __DIR__ . '/../src/Core/Plugin.php';
if (!file_exists($testPath)) {
    $errors[] = "Path resolution failed - check directory separator";
    echo "FAIL\n";
} else {
    echo "OK\n";
}

// Summary
echo "\n";
echo "====================================\n";

if (!empty($warnings)) {
    echo "\nWarnings:\n";
    foreach ($warnings as $warning) {
        echo "  ⚠ {$warning}\n";
    }
}

if (!empty($errors)) {
    echo "\nErrors:\n";
    foreach ($errors as $error) {
        echo "  ✕ {$error}\n";
    }
    echo "\n";
    echo "Installation verification FAILED\n";
    exit(1);
}

echo "\n";
echo "All checks passed! ✓\n";
exit(0);

