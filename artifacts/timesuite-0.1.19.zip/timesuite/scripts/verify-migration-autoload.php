<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$migrationsDir = $root . '/src/Core/DB/Migrations';
$classmapFile = $root . '/vendor/composer/autoload_classmap.php';

if (! is_dir($migrationsDir)) {
    fwrite(STDERR, "Migrations directory not found: {$migrationsDir}\n");
    exit(1);
}

if (! is_readable($classmapFile)) {
    fwrite(STDERR, "Composer classmap is missing: {$classmapFile}\n");
    fwrite(STDERR, "Run composer install or composer dump-autoload -o first.\n");
    exit(1);
}

/** @var array<string, string> $classMap */
$classMap = require $classmapFile;
$migrationFiles = glob($migrationsDir . '/*.php') ?: [];
$errors = [];

$expectedClasses = [];

foreach ($migrationFiles as $file) {
    $base = basename($file);
    $classSuffix = pathinfo($base, PATHINFO_FILENAME);

    if (preg_match('/^\d{4}_\d{2}_\d{2}_\d{6}_(.+)$/', $classSuffix, $matches) === 1) {
        $classSuffix = $matches[1];
    }

    $className = 'Timesuite\\Core\\DB\\Migrations\\' . $classSuffix;
    $expectedClasses[$className] = $file;

    if (! isset($classMap[$className])) {
        $errors[] = "Missing classmap entry for {$className}";
        continue;
    }

    $mappedPath = str_replace('\\', '/', (string) $classMap[$className]);
    $expectedPath = str_replace('\\', '/', (string) $file);

    if (! str_ends_with($mappedPath, '/src/Core/DB/Migrations/' . $base)) {
        $errors[] = "Classmap path mismatch for {$className}: {$mappedPath}";
    }

    if (! is_readable($mappedPath) && ! is_readable($expectedPath)) {
        $errors[] = "Mapped migration file is not readable for {$className}";
    }
}

foreach ($classMap as $className => $mappedPath) {
    if (! str_starts_with($className, 'Timesuite\\Core\\DB\\Migrations\\')) {
        continue;
    }

    if (! isset($expectedClasses[$className])) {
        $errors[] = "Stale migration classmap entry: {$className}";
    }
}

if (! empty($errors)) {
    fwrite(STDERR, "Migration autoload verification failed:\n");

    foreach ($errors as $error) {
        fwrite(STDERR, " - {$error}\n");
    }

    fwrite(STDERR, "Fix by running: composer dump-autoload -o\n");
    exit(1);
}

fwrite(STDOUT, sprintf("Migration autoload OK (%d classes)\n", count($expectedClasses)));
