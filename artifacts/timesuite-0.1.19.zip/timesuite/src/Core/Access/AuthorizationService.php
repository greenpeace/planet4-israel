<?php

declare(strict_types=1);

namespace Timesuite\Core\Access;

use Timesuite\Domain\Org\Services\OrgService;

/**
 * Centralized authorization service.
 *
 * ALL permission checks should go through this service.
 * Controllers should NEVER implement their own authorization logic.
 *
 * This is the single source of truth for "who can do what."
 */
class AuthorizationService
{
    public const META_KEY = 'timesuite_access_role';

    /**
     * @var array<int, string> Cached roles by user ID.
     */
    private static array $roleCache = [];

    /**
     * @var array<int, array<string, bool>> Cached capabilities by user ID.
     */
    private static array $capsCache = [];

    public function __construct(
        private ?OrgService $orgService = null
    ) {
    }

    // =========================================================================
    // Role Queries
    // =========================================================================

    /**
     * Get the effective Timesuite role for a user.
     *
     * This is the ONLY method that should be used to determine a user's role.
     */
    public function getRoleForUser(int $userId): string
    {
        if ($userId <= 0) {
            return Role::NONE;
        }

        if (isset(self::$roleCache[$userId])) {
            return self::$roleCache[$userId];
        }

        // Primary: check user meta (the source of truth)
        $stored = get_user_meta($userId, self::META_KEY, true);

        if (is_string($stored) && '' !== $stored) {
            $role = Role::normalize($stored);
            self::$roleCache[$userId] = $role;

            return $role;
        }

        // Fallback: legacy WP role inference (migration path only)
        $role = $this->inferFromLegacyRoles($userId);
        self::$roleCache[$userId] = $role;

        return $role;
    }

    /**
     * Get the capabilities for a user based on their role.
     *
     * @return array<string, bool>
     */
    public function getCapabilitiesForUser(int $userId): array
    {
        if ($userId <= 0) {
            return [];
        }

        if (isset(self::$capsCache[$userId])) {
            return self::$capsCache[$userId];
        }

        $role = $this->getRoleForUser($userId);
        $caps = Role::capabilities($role);
        self::$capsCache[$userId] = $caps;

        return $caps;
    }

    /**
     * Check if a user has a specific Timesuite capability.
     *
     * SuperAccess users get every `timesuite.*` capability, mirroring
     * SuperAccess::grantCapabilities()'s effect on current_user_can() — this
     * is the one place that check needs to live so every method built on
     * userHasCapability() (hasOrgManagementPowers, canViewTimesheetFor,
     * canEditTimesheetFor, ...) honors it automatically instead of each
     * caller needing its own SuperAccess special-case.
     */
    public function userHasCapability(int $userId, string $capability): bool
    {
        if (str_starts_with($capability, 'timesuite.') && $this->isSuperAccessUser($userId)) {
            return true;
        }

        $caps = $this->getCapabilitiesForUser($userId);

        return isset($caps[$capability]) && $caps[$capability] === true;
    }

    private function isSuperAccessUser(int $userId): bool
    {
        if ($userId <= 0) {
            return false;
        }

        $user = get_user_by('id', $userId);

        return $user instanceof \WP_User && \Timesuite\Core\SuperAccess::isSuperUser($user);
    }

    // =========================================================================
    // Role Checks (Convenience Methods)
    // =========================================================================

    /**
     * Check if a user is a Technical Admin.
     */
    public function isTechAdmin(int $userId): bool
    {
        return $this->getRoleForUser($userId) === Role::TECH_ADMIN;
    }

    /**
     * Check if a user is HR.
     */
    public function isHR(int $userId): bool
    {
        return $this->getRoleForUser($userId) === Role::HR;
    }

    /**
     * Check if a user is a Manager.
     */
    public function isManager(int $userId): bool
    {
        return $this->getRoleForUser($userId) === Role::MANAGER;
    }

    /**
     * Check if a user is an Employee (or higher).
     */
    public function isEmployee(int $userId): bool
    {
        return $this->getRoleForUser($userId) !== Role::NONE;
    }

    /**
     * Check if a user has "HR-level powers" (can manage org, lock periods, etc.)
     *
     * This replaces the duplicated hasHrPowers() methods across controllers.
     */
    public function hasOrgManagementPowers(int $userId): bool
    {
        return $this->userHasCapability($userId, 'timesuite.settings.manage')
            || $this->userHasCapability($userId, 'timesuite.period.lock')
            || $this->userHasCapability($userId, 'timesuite.org.edit');
    }

    /**
     * Check if a user can approve timesheets (manager or higher).
     */
    public function canApproveTimesheets(int $userId): bool
    {
        return $this->userHasCapability($userId, 'timesuite.timesheet.approve_team')
            || $this->hasOrgManagementPowers($userId);
    }

    /**
     * Check if a user can view team timesheets.
     */
    public function canViewTeamTimesheets(int $userId): bool
    {
        return $this->userHasCapability($userId, 'timesuite.timesheet.view_team')
            || $this->userHasCapability($userId, 'timesuite.timesheet.approve_team')
            || $this->hasOrgManagementPowers($userId);
    }

    /**
     * Check if a user can manage Timesuite access roles.
     */
    public function canManageRoles(int $userId): bool
    {
        if ($userId <= 0) {
            return false;
        }

        $user = get_user_by('id', $userId);
        if ($user instanceof \WP_User && \Timesuite\Core\SuperAccess::isSuperUser($user)) {
            return true;
        }

        return user_can($userId, 'timesuite.roles.manage');
    }

    // =========================================================================
    // Scoped Access Checks
    // =========================================================================

    /**
     * Check if a user can view another user's timesheet.
     */
    public function canViewTimesheetFor(int $actorId, int $targetUserId): bool
    {
        // Own timesheet
        if ($actorId === $targetUserId) {
            return $this->userHasCapability($actorId, 'timesuite.timesheet.view_own');
        }

        // HR powers = can view all
        if ($this->hasOrgManagementPowers($actorId)) {
            return true;
        }

        // Manager can view direct reports
        if ($this->userHasCapability($actorId, 'timesuite.timesheet.approve_team')) {
            return $this->isDirectReport($actorId, $targetUserId);
        }

        return false;
    }

    /**
     * Check if a user can edit another user's timesheet.
     */
    public function canEditTimesheetFor(int $actorId, int $targetUserId): bool
    {
        // Can only edit own timesheet (unless HR with override)
        if ($actorId !== $targetUserId) {
            return false;
        }

        return $this->userHasCapability($actorId, 'timesuite.timesheet.edit_own');
    }

    /**
     * Check if a user can approve another user's timesheet.
     */
    public function canApproveTimesheetFor(int $actorId, int $targetUserId): bool
    {
        if ($actorId === $targetUserId) {
            if (! $this->hasOrgManagementPowers($actorId)
                && ! $this->userHasCapability($actorId, 'timesuite.timesheet.approve_team')
            ) {
                return false;
            }

            return $this->isDirectReport($actorId, $targetUserId);
        }

        // HR powers = can approve all
        if ($this->hasOrgManagementPowers($actorId)) {
            return true;
        }

        // Manager can approve direct reports
        if ($this->userHasCapability($actorId, 'timesuite.timesheet.approve_team')) {
            return $this->isDirectReport($actorId, $targetUserId);
        }

        return false;
    }

    /**
     * Check if target user is a direct report of the actor.
     */
    private function isDirectReport(int $managerId, int $targetUserId): bool
    {
        if ($this->orgService === null) {
            return false;
        }

        return $this->orgService->managerCanAccessUser($managerId, $targetUserId);
    }

    // =========================================================================
    // Legacy Migration Support
    // =========================================================================

    /**
     * Infer role from legacy WP Timesuite roles.
     *
     * This is ONLY used as a fallback when meta is not set.
     * New installations should never hit this path.
     */
    private function inferFromLegacyRoles(int $userId): string
    {
        $user = get_user_by('id', $userId);

        if (! $user) {
            return Role::NONE;
        }

        $roles = is_array($user->roles) ? $user->roles : [];

        if (in_array('timesuite_tech_admin', $roles, true)) {
            return Role::TECH_ADMIN;
        }

        if (in_array('timesuite_hr', $roles, true)) {
            return Role::HR;
        }

        if (in_array('timesuite_manager', $roles, true)) {
            return Role::MANAGER;
        }

        if (in_array('timesuite_employee', $roles, true)) {
            return Role::EMPLOYEE;
        }

        return Role::NONE;
    }

    // =========================================================================
    // Cache Management
    // =========================================================================

    /**
     * Clear cached data for a specific user.
     */
    public static function clearCacheForUser(int $userId): void
    {
        unset(self::$roleCache[$userId], self::$capsCache[$userId]);
    }

    /**
     * Clear all cached data.
     */
    public static function clearAllCaches(): void
    {
        self::$roleCache = [];
        self::$capsCache = [];
    }
}
