<?php

declare(strict_types=1);

namespace Timesuite\Core\Access;

/**
 * Bootstrap mode service.
 *
 * Handles first-time setup when no tech_admin exists.
 *
 * This uses a "Bootstrap Gate" approach:
 * - When bootstrap mode is active, ONLY bootstrap-specific endpoints are allowed
 * - No global capability filtering (which caused memory issues)
 * - WP admins can access bootstrap UI and setup endpoint
 * - Once a tech_admin is set, bootstrap mode exits permanently
 */
class BootstrapService
{
    /**
     * @var bool|null Cached bootstrap mode status.
     */
    private static ?bool $bootstrapMode = null;

    /**
     * Check if bootstrap mode is active (no tech_admin exists).
     *
     * This is a fast, cached check suitable for use in hot paths.
     */
    public static function isBootstrapMode(): bool
    {
        if (self::$bootstrapMode !== null) {
            return self::$bootstrapMode;
        }

        // Can be disabled via constant
        if (defined('TIMESUITE_DISABLE_BOOTSTRAP') && TIMESUITE_DISABLE_BOOTSTRAP) {
            self::$bootstrapMode = false;

            return false;
        }

        // Bootstrap mode = no tech admin exists
        self::$bootstrapMode = ! self::hasTechAdmin();

        return self::$bootstrapMode;
    }

    /**
     * Check if any VALID tech_admin exists in the system.
     *
     * This validates that:
     * 1. The meta value is exactly 'tech_admin' (not corrupted)
     * 2. The user actually exists in WordPress
     *
     * This prevents bootstrap mode from being blocked by orphaned/corrupted meta.
     */
    public static function hasTechAdmin(): bool
    {
        global $wpdb;

        // Check for users with internal Timesuite role = tech_admin
        // AND verify the user actually exists (JOIN with users table)
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) 
                 FROM {$wpdb->usermeta} um
                 INNER JOIN {$wpdb->users} u ON um.user_id = u.ID
                 WHERE um.meta_key = %s AND um.meta_value = %s",
                AuthorizationService::META_KEY,
                Role::TECH_ADMIN
            )
        );

        if ((int) $count > 0) {
            return true;
        }

        // Also check for legacy WP role (backwards compatibility)
        // Again, verify user exists
        $legacyCount = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) 
                 FROM {$wpdb->usermeta} um
                 INNER JOIN {$wpdb->users} u ON um.user_id = u.ID
                 WHERE um.meta_key = %s 
                 AND um.meta_value LIKE %s",
                $wpdb->prefix . 'capabilities',
                '%timesuite_tech_admin%'
            )
        );

        return (int) $legacyCount > 0;
    }

    /**
     * Get list of valid tech admins (for diagnostics/health checks).
     *
     * @return array<int, array{user_id: int, email: string, name: string, source: string}>
     */
    public static function getTechAdmins(): array
    {
        global $wpdb;

        $admins = [];

        // Check meta-based tech admins
        $metaAdmins = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT u.ID, u.user_email, u.display_name
                 FROM {$wpdb->usermeta} um
                 INNER JOIN {$wpdb->users} u ON um.user_id = u.ID
                 WHERE um.meta_key = %s AND um.meta_value = %s",
                AuthorizationService::META_KEY,
                Role::TECH_ADMIN
            )
        );

        foreach ($metaAdmins as $admin) {
            $admins[] = [
                'user_id' => (int) $admin->ID,
                'email' => $admin->user_email,
                'name' => $admin->display_name ?: $admin->user_email,
                'source' => 'meta',
            ];
        }

        // Check legacy WP role tech admins (not already in list)
        $existingIds = array_column($admins, 'user_id');

        $legacyAdmins = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT u.ID, u.user_email, u.display_name
                 FROM {$wpdb->usermeta} um
                 INNER JOIN {$wpdb->users} u ON um.user_id = u.ID
                 WHERE um.meta_key = %s 
                 AND um.meta_value LIKE %s",
                $wpdb->prefix . 'capabilities',
                '%timesuite_tech_admin%'
            )
        );

        foreach ($legacyAdmins as $admin) {
            if (in_array((int) $admin->ID, $existingIds, true)) {
                continue;
            }

            $admins[] = [
                'user_id' => (int) $admin->ID,
                'email' => $admin->user_email,
                'name' => $admin->display_name ?: $admin->user_email,
                'source' => 'legacy_wp_role',
            ];
        }

        return $admins;
    }

    /**
     * Find and report orphaned/corrupted Timesuite role meta.
     *
     * Returns entries where:
     * - User doesn't exist (orphaned)
     * - Meta value is not a valid role (corrupted)
     *
     * @return array{orphaned: array, corrupted: array}
     */
    public static function findInvalidRoleMeta(): array
    {
        global $wpdb;

        $validRoles = Role::ALL;

        // Find orphaned meta (user doesn't exist)
        $orphaned = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT um.umeta_id, um.user_id, um.meta_value
                 FROM {$wpdb->usermeta} um
                 LEFT JOIN {$wpdb->users} u ON um.user_id = u.ID
                 WHERE um.meta_key = %s AND u.ID IS NULL",
                AuthorizationService::META_KEY
            ),
            ARRAY_A
        );

        // Find corrupted meta (invalid role value)
        $allMeta = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT um.umeta_id, um.user_id, um.meta_value, u.user_email
                 FROM {$wpdb->usermeta} um
                 INNER JOIN {$wpdb->users} u ON um.user_id = u.ID
                 WHERE um.meta_key = %s",
                AuthorizationService::META_KEY
            ),
            ARRAY_A
        );

        $corrupted = [];
        foreach ($allMeta as $meta) {
            if (! in_array($meta['meta_value'], $validRoles, true)) {
                $corrupted[] = $meta;
            }
        }

        return [
            'orphaned' => $orphaned ?: [],
            'corrupted' => $corrupted,
        ];
    }

    /**
     * Clean up orphaned and corrupted role meta.
     *
     * @return array{orphaned_deleted: int, corrupted_deleted: int}
     */
    public static function cleanupInvalidRoleMeta(): array
    {
        global $wpdb;

        $invalid = self::findInvalidRoleMeta();

        $orphanedDeleted = 0;
        $corruptedDeleted = 0;

        // Delete orphaned entries
        foreach ($invalid['orphaned'] as $entry) {
            $deleted = $wpdb->delete(
                $wpdb->usermeta,
                ['umeta_id' => $entry['umeta_id']],
                ['%d']
            );

            if ($deleted) {
                $orphanedDeleted++;
            }
        }

        // Delete corrupted entries
        foreach ($invalid['corrupted'] as $entry) {
            $deleted = $wpdb->delete(
                $wpdb->usermeta,
                ['umeta_id' => $entry['umeta_id']],
                ['%d']
            );

            if ($deleted) {
                $corruptedDeleted++;
            }
        }

        // Clear caches
        self::clearCache();
        AuthorizationService::clearAllCaches();

        return [
            'orphaned_deleted' => $orphanedDeleted,
            'corrupted_deleted' => $corruptedDeleted,
        ];
    }

    /**
     * Check if a user can access bootstrap setup.
     *
     * Requirements:
     * 1. Bootstrap mode must be active
     * 2. User must be a WordPress administrator (manage_options)
     */
    public static function canAccessBootstrap(int $userId): bool
    {
        if (! self::isBootstrapMode()) {
            return false;
        }

        if ($userId <= 0) {
            return false;
        }

        // Must be WP admin
        return user_can($userId, 'manage_options');
    }

    /**
     * Check if a specific route is a bootstrap route.
     *
     * Bootstrap routes are the ONLY Timesuite routes allowed during bootstrap mode
     * for users who don't have normal Timesuite access.
     */
    public static function isBootstrapRoute(string $route): bool
    {
        $bootstrapRoutes = [
            '/timesuite/v1/bootstrap/status',
            '/timesuite/v1/bootstrap/setup',
        ];

        foreach ($bootstrapRoutes as $allowed) {
            if (str_contains($route, $allowed)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Clear the bootstrap mode cache.
     *
     * Call this after assigning a tech_admin.
     */
    public static function clearCache(): void
    {
        self::$bootstrapMode = null;
    }

    /**
     * Get list of WordPress administrators for bootstrap selection.
     *
     * @return array<int, array{id: int, name: string, email: string, is_current: bool}>
     */
    public static function getAvailableAdmins(): array
    {
        $admins = get_users([
            'role' => 'administrator',
            'fields' => ['ID', 'display_name', 'user_email'],
        ]);

        $currentUserId = get_current_user_id();
        $result = [];

        foreach ($admins as $admin) {
            $result[] = [
                'id' => (int) $admin->ID,
                'name' => $admin->display_name ?: $admin->user_email,
                'email' => $admin->user_email,
                'is_current' => (int) $admin->ID === $currentUserId,
            ];
        }

        // Sort current user first
        usort($result, static fn ($a, $b) => $b['is_current'] <=> $a['is_current']);

        return $result;
    }

    /**
     * Get bootstrap status for API response.
     *
     * @return array<string, mixed>
     */
    public static function getStatus(): array
    {
        $currentUserId = get_current_user_id();
        $isBootstrap = self::isBootstrapMode();
        $canSetup = self::canAccessBootstrap($currentUserId);

        $response = [
            'bootstrap_mode' => $isBootstrap,
            'can_setup' => $canSetup,
            'has_tech_admin' => self::hasTechAdmin(),
            'current_user' => [
                'id' => $currentUserId,
                'email' => wp_get_current_user()->user_email ?? '',
                'is_wp_admin' => current_user_can('manage_options'),
            ],
        ];

        // Only include admin list if in bootstrap and user can setup
        if ($isBootstrap && $canSetup) {
            $response['available_admins'] = self::getAvailableAdmins();
        }

        return $response;
    }
}
