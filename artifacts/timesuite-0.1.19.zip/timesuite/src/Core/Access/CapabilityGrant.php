<?php

declare(strict_types=1);

namespace Timesuite\Core\Access;

use WP_User;

/**
 * Capability grant filter.
 *
 * This hooks into WordPress's user_has_cap filter to grant Timesuite capabilities
 * based on the user's Timesuite role (stored in user meta).
 *
 * Priority 9 - runs after most plugins but before SuperAccess.
 */
class CapabilityGrant
{
    private static ?AuthorizationService $authService = null;

    /**
     * Register the capability grant filter.
     */
    public static function register(): void
    {
        add_filter('user_has_cap', [self::class, 'grantTimesuiteCaps'], 9, 4);

        // Clear caches when user meta changes
        add_action('updated_user_meta', [self::class, 'maybeClearCache'], 10, 4);
        add_action('added_user_meta', [self::class, 'maybeClearCache'], 10, 4);
        add_action('deleted_user_meta', [self::class, 'maybeClearCache'], 10, 4);
    }

    /**
     * Set the authorization service (for DI).
     */
    public static function setAuthService(AuthorizationService $service): void
    {
        self::$authService = $service;
    }

    /**
     * Get or create the authorization service.
     */
    private static function getAuthService(): AuthorizationService
    {
        if (self::$authService === null) {
            self::$authService = new AuthorizationService();
        }

        return self::$authService;
    }

    /**
     * Grant Timesuite capabilities based on user's Timesuite role.
     *
     * @param array<string, bool> $allCaps All capabilities the user has.
     * @param string[]            $caps    Capabilities being checked.
     * @param array<int, mixed>   $args    Additional arguments.
     * @param WP_User             $user    The user being checked.
     *
     * @return array<string, bool>
     */
    public static function grantTimesuiteCaps(array $allCaps, array $caps, array $args, WP_User $user): array
    {
        // Only handle Timesuite capabilities
        $needsTimesuiteCap = false;

        foreach ($caps as $cap) {
            if (is_string($cap) && str_starts_with($cap, 'timesuite.')) {
                $needsTimesuiteCap = true;
                break;
            }
        }

        if (! $needsTimesuiteCap) {
            return $allCaps;
        }

        $userId = (int) $user->ID;

        if ($userId <= 0) {
            return $allCaps;
        }

        // Timesuite capabilities come only from the Timesuite role meta.
        // WordPress Administrator status must not override the internal role.
        $authService = self::getAuthService();
        $userCaps = $authService->getCapabilitiesForUser($userId);

        // Grant the requested capabilities if the user has them
        foreach ($caps as $cap) {
            if (! is_string($cap) || ! str_starts_with($cap, 'timesuite.')) {
                continue;
            }

            if (isset($userCaps[$cap]) && $userCaps[$cap] === true) {
                $allCaps[$cap] = true;
            }
        }

        return $allCaps;
    }

    /**
     * Clear caches when relevant user meta changes.
     *
     * @param int|int[] $metaId    Meta ID (or array of meta IDs for deleted_user_meta).
     * @param int    $userId    User ID.
     * @param string $metaKey   Meta key.
     * @param mixed  $metaValue Meta value.
     */
    public static function maybeClearCache(int|array $metaId, int $userId, string $metaKey, mixed $metaValue): void
    {
        if ($metaKey !== AuthorizationService::META_KEY) {
            return;
        }

        AuthorizationService::clearCacheForUser($userId);

        // Clear bootstrap cache if a tech admin was added/removed
        // Normalize the value to string for safe comparison
        $normalizedValue = is_string($metaValue) ? Role::normalize($metaValue) : '';
        if ($normalizedValue === Role::TECH_ADMIN) {
            BootstrapService::clearCache();
        }
    }
}
