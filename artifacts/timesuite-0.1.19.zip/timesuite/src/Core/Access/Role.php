<?php

declare(strict_types=1);

namespace Timesuite\Core\Access;

/**
 * Enum-like class for Timesuite roles.
 *
 * This is the single source of truth for role definitions.
 */
final class Role
{
    public const NONE = 'none';
    public const EMPLOYEE = 'employee';
    public const MANAGER = 'manager';
    public const HR = 'hr';
    public const TECH_ADMIN = 'tech_admin';

    /**
     * All valid roles in order of privilege (lowest to highest).
     */
    public const ALL = [
        self::NONE,
        self::EMPLOYEE,
        self::MANAGER,
        self::HR,
        self::TECH_ADMIN,
    ];

    /**
     * Human-readable labels for each role.
     *
     * @return array<string, string>
     */
    public static function labels(): array
    {
        return [
            self::NONE => __('None (no access)', 'timesuite'),
            self::EMPLOYEE => __('Employee', 'timesuite'),
            self::MANAGER => __('Manager', 'timesuite'),
            self::HR => __('HR', 'timesuite'),
            self::TECH_ADMIN => __('Technical Admin', 'timesuite'),
        ];
    }

    /**
     * Check if a string is a valid role.
     */
    public static function isValid(string $role): bool
    {
        return in_array($role, self::ALL, true);
    }

    /**
     * Normalize a role string (lowercase, trim, validate).
     * Returns NONE if invalid.
     */
    public static function normalize(string $role): string
    {
        $normalized = strtolower(trim($role));

        return self::isValid($normalized) ? $normalized : self::NONE;
    }

    /**
     * Get the access level rank for a role (higher = more access).
     */
    public static function rank(string $role): int
    {
        $normalized = self::normalize($role);
        $index = array_search($normalized, self::ALL, true);

        return $index === false ? 0 : (int) $index;
    }

    /**
     * Check if a role is lower than another role.
     */
    public static function isLowerThan(string $role, string $otherRole): bool
    {
        return self::rank($role) < self::rank($otherRole);
    }

    /**
     * Get capabilities for a given role.
     *
     * @return array<string, bool>
     */
    public static function capabilities(string $role): array
    {
        $employee = [
            'timesuite.timesheet.create' => true,
            'timesuite.timesheet.edit_own' => true,
            'timesuite.timesheet.submit_own' => true,
            'timesuite.timesheet.view_own' => true,
            'timesuite.timesheet.bulk_import_own' => true,
        ];

        $managerExtra = [
            'timesuite.timesheet.view_team' => true,
            'timesuite.timesheet.approve_team' => true,
            'timesuite.timesheet.comment_team' => true,
        ];

        $hrExtra = [
            'timesuite.timesheet.view_team' => true,
            'timesuite.timesheet.approve_team' => true,
            'timesuite.timesheet.comment_team' => true,
            'timesuite.timesheet.view_all' => true,
            'timesuite.period.lock' => true,
            'timesuite.export.run' => true,
            'timesuite.roles.manage' => true,
            'timesuite.org.view' => true,
            'timesuite.org.edit' => true,
            'timesuite.settings.manage' => true,
            'timesuite.settings.view' => true,
            'timesuite.audit.view' => true,
        ];

        $techAdminExtra = [
            'timesuite.settings.manage' => true,
            'timesuite.settings.view' => true,
            'timesuite.org.view' => true,
            'timesuite.org.edit' => true,
            'timesuite.org.import' => true,
            'timesuite.org.delete' => true,
            'timesuite.export.run' => true,
            'timesuite.export.sensitive' => true,
            'timesuite.roles.manage' => true,
            'timesuite.period.lock' => true,
            'timesuite.audit.view' => true,
            'timesuite.system.view' => true,
        ];

        return match ($role) {
            self::EMPLOYEE => $employee,
            self::MANAGER => array_merge($employee, $managerExtra),
            self::HR => array_merge($employee, $hrExtra),
            self::TECH_ADMIN => array_merge($employee, $techAdminExtra),
            default => [],
        };
    }
}
