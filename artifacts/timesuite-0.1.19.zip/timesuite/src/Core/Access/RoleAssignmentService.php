<?php

declare(strict_types=1);

namespace Timesuite\Core\Access;

use Timesuite\Domain\Shared\Exceptions\ForbiddenException;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use WP_User;

/**
 * Centralized role assignment service.
 *
 * ALL role changes MUST go through this service. No exceptions.
 *
 * This ensures:
 * - Validation (allowed roles only)
 * - Authorization (who can assign what)
 * - Auditing (always)
 * - Cache invalidation
 * - Consistent side effects
 */
class RoleAssignmentService
{
    public function __construct(
        private AuthorizationService $authService,
        private ?ApprovalLogRepository $logRepo = null
    ) {
    }

    /**
     * Assign a role to a user.
     *
     * @param int         $targetUserId  The user to assign the role to.
     * @param string      $newRole       The role to assign.
     * @param int         $actorId       The user performing the action (0 for system).
     * @param string|null $context       Optional context for audit log.
     * @param bool        $skipAuthCheck Skip authorization check (for bootstrap/migration).
     *
     * @throws ValidationException If role is invalid.
     * @throws ForbiddenException If actor cannot assign roles.
     */
    public function assignRole(
        int $targetUserId,
        string $newRole,
        int $actorId = 0,
        ?string $context = null,
        bool $skipAuthCheck = false
    ): bool {
        // Validate role
        $normalizedRole = Role::normalize($newRole);

        if ($newRole !== '' && ! Role::isValid($normalizedRole)) {
            throw new ValidationException(
                sprintf(__('Invalid role: %s', 'timesuite'), $newRole)
            );
        }

        // Validate target user exists
        $targetUser = get_user_by('id', $targetUserId);

        if (! $targetUser instanceof WP_User) {
            throw new ValidationException(__('User not found.', 'timesuite'));
        }

        // Authorization check
        if (! $skipAuthCheck && $actorId > 0) {
            $this->assertCanAssignRole($actorId, $targetUserId, $normalizedRole);
        }

        // Get previous role for audit
        $previousRole = $this->authService->getRoleForUser($targetUserId);

        // Skip if no change
        if ($previousRole === $normalizedRole) {
            return true;
        }

        // Perform the assignment
        if ($normalizedRole === Role::NONE) {
            $success = delete_user_meta($targetUserId, AuthorizationService::META_KEY);
        } else {
            $success = (bool) update_user_meta($targetUserId, AuthorizationService::META_KEY, $normalizedRole);
        }

        if (! $success) {
            return false;
        }

        // Clear caches
        AuthorizationService::clearCacheForUser($targetUserId);
        BootstrapService::clearCache();

        // Audit log
        $this->logRoleChange($targetUserId, $previousRole, $normalizedRole, $actorId, $context);

        // Fire action for other systems to hook into
        do_action('timesuite_role_assigned', $targetUserId, $normalizedRole, $previousRole, $actorId);

        return true;
    }

    /**
     * Remove a user's Timesuite access (set role to NONE).
     */
    public function removeRole(int $targetUserId, int $actorId = 0, ?string $context = null): bool
    {
        return $this->assignRole($targetUserId, Role::NONE, $actorId, $context);
    }

    /**
     * Bulk assign roles (for imports).
     *
     * @param array<int, string> $assignments Array of userId => role.
     * @param int                $actorId     The user performing the action.
     * @param string|null        $context     Optional context for audit log.
     *
     * @return array{success: int, failed: int, errors: array<int, string>}
     */
    public function bulkAssign(array $assignments, int $actorId, ?string $context = null): array
    {
        $results = [
            'success' => 0,
            'failed' => 0,
            'errors' => [],
        ];

        foreach ($assignments as $userId => $role) {
            try {
                $this->assignRole((int) $userId, $role, $actorId, $context);
                $results['success']++;
            } catch (\Throwable $e) {
                $results['failed']++;
                $results['errors'][$userId] = $e->getMessage();
            }
        }

        return $results;
    }

    /**
     * Check if an actor can assign a specific role to a target user.
     *
     * @throws ForbiddenException If actor cannot assign the role.
     */
    private function assertCanAssignRole(int $actorId, int $targetUserId, string $newRole): void
    {
        // Check if actor can manage roles at all
        if (! $this->authService->canManageRoles($actorId)) {
            throw new ForbiddenException(
                __('You do not have permission to manage Timesuite roles.', 'timesuite')
            );
        }

        // Prevent lowering your own access level.
        if ($actorId === $targetUserId) {
            $currentRole = $this->authService->getRoleForUser($actorId);

            if (Role::isLowerThan($newRole, $currentRole)) {
                throw new ForbiddenException(
                    __('You cannot lower your own access level.', 'timesuite')
                );
            }
        }

        // Prevent removing your own Tech Admin role (safety)
        if ($actorId === $targetUserId) {
            $currentRole = $this->authService->getRoleForUser($actorId);

            if ($currentRole === Role::TECH_ADMIN && $newRole !== Role::TECH_ADMIN) {
                // Check if there's another tech admin
                if (! $this->hasOtherTechAdmin($actorId)) {
                    throw new ForbiddenException(
                        __('Cannot remove your own Tech Admin role when you are the only one.', 'timesuite')
                    );
                }
            }
        }
    }

    /**
     * Check if there's another tech admin besides the given user.
     */
    private function hasOtherTechAdmin(int $excludeUserId): bool
    {
        global $wpdb;

        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->usermeta} 
                 WHERE meta_key = %s AND meta_value = %s AND user_id != %d",
                AuthorizationService::META_KEY,
                Role::TECH_ADMIN,
                $excludeUserId
            )
        );

        return (int) $count > 0;
    }

    /**
     * Log role change to audit trail.
     */
    private function logRoleChange(
        int $targetUserId,
        string $previousRole,
        string $newRole,
        int $actorId,
        ?string $context
    ): void {
        if ($this->logRepo === null) {
            return;
        }

        $targetUser = get_user_by('id', $targetUserId);
        $targetEmail = $targetUser ? $targetUser->user_email : "User #{$targetUserId}";

        $actorEmail = 'system';
        if ($actorId > 0) {
            $actor = get_user_by('id', $actorId);
            $actorEmail = $actor ? $actor->user_email : "User #{$actorId}";
        }

        $roleLabels = Role::labels();
        $fromLabel = $roleLabels[$previousRole] ?? $previousRole;
        $toLabel = $roleLabels[$newRole] ?? $newRole;

        $details = sprintf(
            'Role changed for %s: %s → %s',
            $targetEmail,
            $fromLabel,
            $toLabel
        );

        if ($context) {
            $details .= " ({$context})";
        }

        $this->logRepo->logAction(
            'role_change',
            $actorId,
            $targetUserId,
            0,
            0,
            $details
        );
    }

    /**
     * Migrate a user from legacy WP role to meta-based role.
     *
     * This should be called during plugin upgrade.
     */
    public function migrateFromLegacyRole(int $userId): bool
    {
        // Check if already migrated
        $existingMeta = get_user_meta($userId, AuthorizationService::META_KEY, true);

        if (is_string($existingMeta) && '' !== $existingMeta) {
            return true; // Already has meta, skip
        }

        // Infer role from legacy WP roles
        $user = get_user_by('id', (string) $userId);

        if (! $user instanceof WP_User) {
            return false;
        }

        $roles = is_array($user->roles) ? $user->roles : [];
        $inferredRole = Role::NONE;

        if (in_array('timesuite_tech_admin', $roles, true)) {
            $inferredRole = Role::TECH_ADMIN;
        } elseif (in_array('timesuite_hr', $roles, true)) {
            $inferredRole = Role::HR;
        } elseif (in_array('timesuite_manager', $roles, true)) {
            $inferredRole = Role::MANAGER;
        } elseif (in_array('timesuite_employee', $roles, true)) {
            $inferredRole = Role::EMPLOYEE;
        }

        if ($inferredRole === Role::NONE) {
            return true; // Nothing to migrate
        }

        // Set the meta (skip auth check, this is migration), then detach legacy WP roles.
        $migrated = $this->assignRole($userId, $inferredRole, 0, 'legacy_migration', true);

        if ($migrated) {
            $this->removeLegacyWpRoles($user);
        }

        return $migrated;
    }

    /**
     * Migrate all users with legacy WP roles.
     *
     * @return array{migrated: int, skipped: int}
     */
    public function migrateAllLegacyRoles(): array
    {
        global $wpdb;

        $results = ['migrated' => 0, 'skipped' => 0];

        // Find users with legacy timesuite_* WP roles
        $legacyRoles = ['timesuite_employee', 'timesuite_manager', 'timesuite_hr', 'timesuite_tech_admin'];

        foreach ($legacyRoles as $legacyRole) {
            $users = get_users([
                'role' => $legacyRole,
                'fields' => ['ID'],
            ]);

            foreach ($users as $userResult) {
                $userId = $this->getUserIdFromQueryResult($userResult);
                $user = get_user_by('id', (string) $userId);

                if (! $user instanceof WP_User) {
                    $results['skipped']++;
                    continue;
                }

                // Check if already has meta
                $existingMeta = get_user_meta($userId, AuthorizationService::META_KEY, true);

                if (is_string($existingMeta) && '' !== $existingMeta) {
                    $this->removeLegacyWpRoles($user);
                    $results['skipped']++;
                    continue;
                }

                if ($this->migrateFromLegacyRole($userId)) {
                    $results['migrated']++;
                }
            }
        }

        return $results;
    }

    private function removeLegacyWpRoles(WP_User $user): void
    {
        $legacyRoles = ['timesuite_employee', 'timesuite_manager', 'timesuite_hr', 'timesuite_tech_admin'];

        foreach ($legacyRoles as $legacyRole) {
            if (in_array($legacyRole, $user->roles ?? [], true)) {
                $user->remove_role($legacyRole);
            }
        }

        if (empty($user->roles) && function_exists('get_role') && get_role('subscriber')) {
            $user->add_role('subscriber');
        }
    }

    private function getUserIdFromQueryResult(mixed $userResult): int
    {
        if (is_object($userResult) && isset($userResult->ID)) {
            return (int) $userResult->ID;
        }

        if (is_array($userResult) && isset($userResult['ID'])) {
            return (int) $userResult['ID'];
        }

        return (int) $userResult;
    }
}
