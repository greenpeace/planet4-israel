<?php

declare(strict_types=1);

namespace Timesuite\Core;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Core\Access\Role;
use WP_Role;
use WP_User;

class Capabilities
{
    private const ROLE_EMPLOYEE = 'timesuite_employee';
    private const ROLE_MANAGER = 'timesuite_manager';
    private const ROLE_HR = 'timesuite_hr';
    private const ROLE_TECH_ADMIN = 'timesuite_tech_admin';
    private const LEGACY_ROLE_MAP = [
        'employee' => Role::EMPLOYEE,
        'manager'  => Role::MANAGER,
        'hr'       => Role::HR,
    ];
    private const TIMESUITE_WP_ROLE_MAP = [
        self::ROLE_EMPLOYEE   => Role::EMPLOYEE,
        self::ROLE_MANAGER    => Role::MANAGER,
        self::ROLE_HR         => Role::HR,
        self::ROLE_TECH_ADMIN => Role::TECH_ADMIN,
    ];

    // Capability constants (for reuse + clarity)
    private const CAP_TIMESHEET_CREATE = 'timesuite.timesheet.create';
    private const CAP_TIMESHEET_EDIT_OWN = 'timesuite.timesheet.edit_own';
    private const CAP_TIMESHEET_SUBMIT_OWN = 'timesuite.timesheet.submit_own';
    private const CAP_TIMESHEET_VIEW_OWN = 'timesuite.timesheet.view_own';
    private const CAP_TIMESHEET_BULK_IMPORT_OWN = 'timesuite.timesheet.bulk_import_own';
    private const CAP_TIMESHEET_VIEW_TEAM = 'timesuite.timesheet.view_team';
    private const CAP_TIMESHEET_APPROVE_TEAM = 'timesuite.timesheet.approve_team';
    private const CAP_TIMESHEET_COMMENT_TEAM = 'timesuite.timesheet.comment_team';
    private const CAP_TIMESHEET_VIEW_ALL = 'timesuite.timesheet.view_all';
    private const CAP_PERIOD_LOCK = 'timesuite.period.lock';
    private const CAP_EXPORT_RUN = 'timesuite.export.run';
    private const CAP_EXPORT_SENSITIVE = 'timesuite.export.sensitive';
    private const CAP_ROLES_MANAGE = 'timesuite.roles.manage';
    private const CAP_ORG_VIEW = 'timesuite.org.view';
    private const CAP_ORG_EDIT = 'timesuite.org.edit';
    private const CAP_ORG_IMPORT = 'timesuite.org.import';
    private const CAP_ORG_DELETE = 'timesuite.org.delete';
    private const CAP_SETTINGS_VIEW = 'timesuite.settings.view';
    private const CAP_SETTINGS_MANAGE = 'timesuite.settings.manage';
    private const CAP_AUDIT_VIEW = 'timesuite.audit.view';
    private const CAP_SYSTEM_VIEW = 'timesuite.system.view';

    // Legacy capability used in older builds.
    private const CAP_ORG_MANAGE_LEGACY = 'timesuite.org.manage';

    private const EMPLOYEE_CAPABILITIES = [
        self::CAP_TIMESHEET_CREATE,
        self::CAP_TIMESHEET_EDIT_OWN,
        self::CAP_TIMESHEET_SUBMIT_OWN,
        self::CAP_TIMESHEET_VIEW_OWN,
        self::CAP_TIMESHEET_BULK_IMPORT_OWN,
    ];

    private const MANAGER_EXTRA_CAPABILITIES = [
        self::CAP_TIMESHEET_VIEW_TEAM,
        self::CAP_TIMESHEET_APPROVE_TEAM,
        self::CAP_TIMESHEET_COMMENT_TEAM,
    ];

    private const HR_CAPABILITIES = [
        self::CAP_TIMESHEET_VIEW_TEAM,
        self::CAP_TIMESHEET_APPROVE_TEAM,
        self::CAP_TIMESHEET_COMMENT_TEAM,
        self::CAP_TIMESHEET_VIEW_ALL,
        self::CAP_PERIOD_LOCK,
        self::CAP_EXPORT_RUN,
        self::CAP_ROLES_MANAGE,
        self::CAP_ORG_VIEW,
        self::CAP_ORG_EDIT,
        self::CAP_SETTINGS_MANAGE,
        self::CAP_SETTINGS_VIEW,
        self::CAP_AUDIT_VIEW,
    ];

    private const ADMIN_CAPABILITIES = [
        self::CAP_SETTINGS_MANAGE,
        self::CAP_SETTINGS_VIEW,
        self::CAP_ORG_VIEW,
        self::CAP_ORG_EDIT,
        self::CAP_ORG_IMPORT,
        self::CAP_ORG_DELETE,
        self::CAP_EXPORT_RUN,
        self::CAP_EXPORT_SENSITIVE, // Export with PII
        self::CAP_PERIOD_LOCK,
        self::CAP_AUDIT_VIEW,
        self::CAP_SYSTEM_VIEW,
    ];

    private const TECH_ADMIN_CAPABILITIES = self::ADMIN_CAPABILITIES;

    /**
     * All capabilities for reference/documentation.
     */
    public const ALL_CAPABILITIES = [
        // Employee caps
        self::CAP_TIMESHEET_CREATE,
        self::CAP_TIMESHEET_EDIT_OWN,
        self::CAP_TIMESHEET_SUBMIT_OWN,
        self::CAP_TIMESHEET_VIEW_OWN,
        self::CAP_TIMESHEET_BULK_IMPORT_OWN,
        // Manager caps
        self::CAP_TIMESHEET_VIEW_TEAM,
        self::CAP_TIMESHEET_APPROVE_TEAM,
        self::CAP_TIMESHEET_COMMENT_TEAM,
        // HR caps
        self::CAP_TIMESHEET_VIEW_ALL,
        self::CAP_PERIOD_LOCK,
        self::CAP_EXPORT_RUN,
            self::CAP_EXPORT_SENSITIVE,
            self::CAP_ROLES_MANAGE,
            self::CAP_ORG_VIEW,
        self::CAP_ORG_EDIT,
        self::CAP_ORG_IMPORT,
        self::CAP_ORG_DELETE,
        // Admin caps
        self::CAP_SETTINGS_VIEW,
        self::CAP_SETTINGS_MANAGE,
        self::CAP_AUDIT_VIEW,
        self::CAP_SYSTEM_VIEW,
        // Legacy caps
        self::CAP_ORG_MANAGE_LEGACY,
    ];

    public function registerRolesAndCaps(): void
    {
        $this->removeAdministratorCaps();
        $this->migrateRegisteredTimesuiteRoles();
        $this->migrateLegacyRoles();
    }

    public function ensureRoles(): void
    {
        $this->removeAdministratorCaps();

        foreach (array_keys(self::TIMESUITE_WP_ROLE_MAP) as $slug) {
            if (get_role($slug)) {
                $this->registerRolesAndCaps();

                return;
            }
        }

        foreach (self::LEGACY_ROLE_MAP as $legacySlug => $newSlug) {
            $role = get_role($legacySlug);

            if ($role instanceof WP_Role && $this->roleHasTimesuiteCaps($role)) {
                $this->registerRolesAndCaps();

                return;
            }
        }
    }

    public function removeRolesAndCaps(): void
    {
        $roles = array_keys(self::TIMESUITE_WP_ROLE_MAP);

        $this->migrateUsersToInternalRolesAndFallback($roles, 'subscriber');

        foreach ($roles as $slug) {
            remove_role($slug);
        }

        foreach (self::LEGACY_ROLE_MAP as $legacySlug => $newSlug) {
            $role = get_role($legacySlug);

            if ($role instanceof WP_Role && $this->roleHasTimesuiteCaps($role)) {
                $this->migrateUsersToFallbackRole([$legacySlug], 'subscriber');
                remove_role($legacySlug);
            }
        }

        $adminRole = get_role('administrator');

        if (! $adminRole) {
            return;
        }

        $this->removeAdministratorCaps();
    }

    private function removeAdministratorCaps(): void
    {
        $adminRole = get_role('administrator');

        if (! $adminRole) {
            return;
        }

        foreach (self::ADMIN_CAPABILITIES as $capability) {
            $adminRole->remove_cap($capability);
        }
    }

    /**
     * @param string[] $caps
     *
     * @return array<string, bool>
     */
    private function formatCaps(array $caps): array
    {
        $map = [];

        foreach ($caps as $capability) {
            $map[$capability] = true;
        }

        return $map;
    }

    /**
     * @return array<string, array{label: string, caps: array<string, bool>}>
     */
    private function getRolesConfig(): array
    {
        return [
            self::ROLE_EMPLOYEE => [
                'label' => __('Timesuite Employee', 'timesuite'),
                'caps'  => $this->formatCaps(self::EMPLOYEE_CAPABILITIES),
            ],
            self::ROLE_MANAGER  => [
                'label' => __('Timesuite Manager', 'timesuite'),
                'caps'  => $this->formatCaps(
                    array_merge(self::EMPLOYEE_CAPABILITIES, self::MANAGER_EXTRA_CAPABILITIES)
                ),
            ],
            self::ROLE_HR       => [
                'label' => __('Timesuite HR', 'timesuite'),
                // HR users are still employees; include base employee abilities so they can access the plugin UI.
                'caps'  => $this->formatCaps(array_merge(self::EMPLOYEE_CAPABILITIES, self::HR_CAPABILITIES)),
            ],
            self::ROLE_TECH_ADMIN => [
                'label' => __('Timesuite Technical Admin', 'timesuite'),
                // Technical admins need access to Timesuite UI even if they don't use timesheets daily.
                // Include base employee view capability (and other harmless employee caps) to ensure the menu renders.
                'caps'  => $this->formatCaps(array_merge(self::EMPLOYEE_CAPABILITIES, self::TECH_ADMIN_CAPABILITIES)),
            ],
        ];
    }

    private function migrateRegisteredTimesuiteRoles(): void
    {
        foreach (self::TIMESUITE_WP_ROLE_MAP as $roleSlug => $internalRole) {
            $this->migrateUsersFromRole($roleSlug, $internalRole, 'subscriber');
            remove_role($roleSlug);
        }
    }

    private function migrateLegacyRoles(): void
    {
        foreach (self::LEGACY_ROLE_MAP as $legacySlug => $internalRole) {
            $role = get_role($legacySlug);

            if (! $role instanceof WP_Role) {
                continue;
            }

            if (! $this->roleHasTimesuiteCaps($role)) {
                continue;
            }

            $this->migrateUsersFromRole($legacySlug, $internalRole);
            remove_role($legacySlug);
        }
    }

    private function migrateUsersFromRole(string $fromRole, string $internalRole, ?string $fallbackRole = null): void
    {
        $users = get_users([
            'role' => $fromRole,
            'fields' => ['ID'],
        ]);

        foreach ($users as $userResult) {
            $userId = $this->getUserIdFromQueryResult($userResult);
            $user = $this->getUserById($userId);

            if (! $user instanceof WP_User) {
                continue;
            }

            $this->assignInternalRoleIfMissing($userId, $internalRole);
            $user->remove_role($fromRole);

            if ($fallbackRole !== null && empty($user->roles) && get_role($fallbackRole)) {
                $user->add_role($fallbackRole);
            }
        }
    }

    /**
     * @param string[] $roles
     */
    private function migrateUsersToFallbackRole(array $roles, string $fallbackRole): void
    {
        if (! get_role($fallbackRole)) {
            return;
        }

        foreach ($roles as $role) {
            $users = get_users([
                'role' => $role,
                'fields' => ['ID'],
            ]);

            foreach ($users as $userId) {
                $user = $this->getUserById((int) $userId);

                if (! $user instanceof WP_User) {
                    continue;
                }

                $user->remove_role($role);

                if (empty($user->roles)) {
                    $user->add_role($fallbackRole);
                }
            }
        }
    }

    /**
     * @param string[] $roles
     */
    private function migrateUsersToInternalRolesAndFallback(array $roles, string $fallbackRole): void
    {
        if (! get_role($fallbackRole)) {
            return;
        }

        foreach ($roles as $role) {
            $users = get_users([
                'role' => $role,
                'fields' => ['ID'],
            ]);

            foreach ($users as $userResult) {
                $userId = $this->getUserIdFromQueryResult($userResult);
                $user = $this->getUserById($userId);

                if (! $user instanceof WP_User) {
                    continue;
                }

                $internalRole = self::TIMESUITE_WP_ROLE_MAP[$role] ?? Role::NONE;

                if ($internalRole !== Role::NONE) {
                    $this->assignInternalRoleIfMissing($userId, $internalRole);
                }

                $user->remove_role($role);

                if (empty($user->roles)) {
                    $user->add_role($fallbackRole);
                }
            }
        }
    }

    private function assignInternalRoleIfMissing(int $userId, string $internalRole): void
    {
        if (! function_exists('get_user_meta') || ! function_exists('update_user_meta')) {
            return;
        }

        $existingRole = get_user_meta($userId, AuthorizationService::META_KEY, true);

        if (is_string($existingRole) && '' !== trim($existingRole)) {
            return;
        }

        update_user_meta($userId, AuthorizationService::META_KEY, $internalRole);
    }

    private function getUserIdFromQueryResult(mixed $userResult): int
    {
        if (is_object($userResult) && isset($userResult->ID)) {
            return (int) $userResult->ID;
        }

        if (is_array($userResult) && isset($userResult['ID'])) {
            return (int) $userResult['ID'];
        }

        return (int) $userResult;
    }

    private function getUserById(int $userId): ?WP_User
    {
        if (function_exists('get_userdata')) {
            $user = get_userdata($userId);

            if ($user instanceof WP_User) {
                return $user;
            }
        }

        $user = get_user_by('id', (string) $userId);

        return $user instanceof WP_User ? $user : null;
    }

    private function roleHasTimesuiteCaps(WP_Role $role): bool
    {
        foreach ($role->capabilities as $capability => $granted) {
            if ($granted && strpos((string) $capability, 'timesuite.') === 0) {
                return true;
            }
        }

        return false;
    }
}
