<?php

declare(strict_types=1);

namespace Timesuite\Core;

require_once __DIR__ . '/Support/PsrContainer.php';

use Psr\Container\ContainerInterface;
use ReflectionClass;
use ReflectionNamedType;
use Timesuite\Core\Exceptions\ContainerException;
use Timesuite\Core\Exceptions\NotFoundException;

/**
 * PSR-11 compliant dependency injection container.
 */
class Container implements ContainerInterface
{
    /**
     * @var array<string, mixed>
     */
    private array $entries = [];

    public function set(string $id, mixed $value): void
    {
        $this->entries[$id] = $value;
    }

    /**
     * {@inheritdoc}
     */
    public function has($id): bool
    {
        if (array_key_exists($id, $this->entries)) {
            return true;
        }

        return class_exists($id);
    }

    /**
     * {@inheritdoc}
     *
     * @template T
     *
     * @param class-string<T>|string $id
     *
     * @return T|mixed
     *
     * @throws NotFoundException  If the entry is not found.
     * @throws ContainerException If the entry cannot be resolved.
     */
    public function get($id)
    {
        if (array_key_exists($id, $this->entries)) {
            return $this->resolve($id);
        }

        if (class_exists($id)) {
            $instance = $this->autowire($id);
            $this->entries[$id] = $instance;

            return $instance;
        }

        throw new NotFoundException(
            sprintf('No entry was found for identifier "%s".', $id)
        );
    }

    private function resolve(string $id): mixed
    {
        $entry = $this->entries[$id];

        if (is_callable($entry)) {
            $entry = $entry($this);
            $this->entries[$id] = $entry;
        }

        return $entry;
    }

    private function autowire(string $id): mixed
    {
        try {
            $reflection = new ReflectionClass($id);
        } catch (\ReflectionException $e) {
            throw new ContainerException(
                sprintf('Cannot reflect class "%s": %s', $id, $e->getMessage()),
                0,
                $e
            );
        }

        if (! $reflection->isInstantiable()) {
            throw new ContainerException(
                sprintf('Cannot instantiate "%s".', $id)
            );
        }

        $constructor = $reflection->getConstructor();

        if (! $constructor) {
            return new $id();
        }

        $args = [];

        foreach ($constructor->getParameters() as $param) {
            $type = $param->getType();

            if ($type instanceof ReflectionNamedType && ! $type->isBuiltin()) {
                try {
                    $args[] = $this->get($type->getName());
                    continue;
                } catch (NotFoundException $e) {
                    if (! $param->isOptional()) {
                        throw new ContainerException(
                            sprintf(
                                'Unable to resolve parameter "$%s" of type "%s" for "%s".',
                                $param->getName(),
                                $type->getName(),
                                $id
                            ),
                            0,
                            $e
                        );
                    }
                    $args[] = $param->getDefaultValue();
                    continue;
                }
            }

            if ($param->isDefaultValueAvailable()) {
                $args[] = $param->getDefaultValue();
                continue;
            }

            if ($type && $type->allowsNull()) {
                $args[] = null;
                continue;
            }

            throw new ContainerException(
                sprintf('Unable to resolve parameter "$%s" for "%s".', $param->getName(), $id)
            );
        }

        return $reflection->newInstanceArgs($args);
    }
}
