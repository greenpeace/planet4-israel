<?php

declare(strict_types=1);

namespace Timesuite\Core\DB;

use wpdb;

abstract class Migration
{
    abstract public function getVersion(): string;

    abstract public function up(wpdb $wpdb): void;

    public function maybeName(): string
    {
        return static::class;
    }

    protected function getDefaultCollation(): string
    {
        return 'DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci';
    }
}
