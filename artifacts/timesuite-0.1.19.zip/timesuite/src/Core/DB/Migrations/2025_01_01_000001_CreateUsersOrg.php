<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class CreateUsersOrg extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_01_000001';
    }

    public function up(wpdb $wpdb): void
    {
        $tableName = $wpdb->prefix . 'timesuite_users_org';
        $collation = $wpdb->get_charset_collate() ?: $this->getDefaultCollation();

        $sql = "CREATE TABLE {$tableName} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            org_unit_id bigint(20) unsigned NOT NULL,
            role_slug varchar(50) NOT NULL,
            assigned_at datetime NOT NULL,
            removed_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_org_unit (user_id, org_unit_id),
            KEY org_role (org_unit_id, role_slug)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($sql);
    }
}
