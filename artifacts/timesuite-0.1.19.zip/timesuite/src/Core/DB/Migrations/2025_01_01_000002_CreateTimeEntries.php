<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class CreateTimeEntries extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_01_000002';
    }

    public function up(wpdb $wpdb): void
    {
        $tableName = $wpdb->prefix . 'timesuite_time_entries';
        $collation = $wpdb->get_charset_collate() ?: $this->getDefaultCollation();

        $sql = "CREATE TABLE {$tableName} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            period_id bigint(20) unsigned DEFAULT NULL,
            work_date date NOT NULL,
            start_time time DEFAULT NULL,
            end_time time DEFAULT NULL,
            duration_minutes int(10) unsigned NOT NULL DEFAULT 0,
            break_minutes int(10) unsigned NOT NULL DEFAULT 0,
            task_code varchar(100) NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'draft',
            notes text,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_work_date (user_id, work_date),
            KEY period_id (period_id),
            KEY status_work_date (status, work_date)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($sql);
    }
}
