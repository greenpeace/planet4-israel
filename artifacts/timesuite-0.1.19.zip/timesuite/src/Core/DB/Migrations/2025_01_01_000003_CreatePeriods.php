<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class CreatePeriods extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_01_000003';
    }

    public function up(wpdb $wpdb): void
    {
        $tableName = $wpdb->prefix . 'timesuite_periods';
        $collation = $wpdb->get_charset_collate() ?: $this->getDefaultCollation();

        $sql = "CREATE TABLE {$tableName} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            period_start date NOT NULL,
            period_end date NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'draft',
            locked tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY user_period_range (user_id, period_start, period_end),
            KEY status_period_start (status, period_start),
            KEY user_period (user_id, status)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($sql);
    }
}
