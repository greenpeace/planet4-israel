<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class CreateApprovalsLog extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_01_000004';
    }

    public function up(wpdb $wpdb): void
    {
        $tableName = $wpdb->prefix . 'timesuite_approvals_log';
        $collation = $wpdb->get_charset_collate() ?: $this->getDefaultCollation();

        $sql = "CREATE TABLE {$tableName} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            entry_id bigint(20) unsigned NOT NULL,
            period_id bigint(20) unsigned NOT NULL,
            actor_id bigint(20) unsigned NOT NULL,
            entity_type varchar(40) NOT NULL DEFAULT 'entry',
            entity_id bigint(20) unsigned NOT NULL DEFAULT 0,
            action varchar(40) NOT NULL,
            comment text,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY log_entry (entry_id),
            KEY log_period (period_id),
            KEY log_actor_action (actor_id, action)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($sql);
    }
}
