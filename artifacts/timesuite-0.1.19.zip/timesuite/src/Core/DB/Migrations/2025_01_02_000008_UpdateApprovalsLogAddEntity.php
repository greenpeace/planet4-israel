<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class UpdateApprovalsLogAddEntity extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_02_000008';
    }

    public function up(wpdb $wpdb): void
    {
        // Columns were added in the base CreateApprovalsLog migration; keep this
        // migration for version tracking but avoid duplicate ALTER statements.
    }
}
