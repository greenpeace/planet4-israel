<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class UpdateTimeEntriesAllowNullPeriod extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_03_000010';
    }

    public function up(wpdb $wpdb): void
    {
        $tableName = $wpdb->prefix . 'timesuite_time_entries';
        $pattern = function_exists('esc_like') ? esc_like($tableName) : $tableName;
        $exists = $wpdb->get_var(
            $wpdb->prepare('SHOW TABLES LIKE %s', $pattern)
        );

        if ($exists !== $tableName) {
            return;
        }

        $wpdb->query(
            "ALTER TABLE {$tableName} MODIFY period_id bigint(20) unsigned DEFAULT NULL"
        );
        $wpdb->query(
            "UPDATE {$tableName} SET period_id = NULL WHERE period_id = 0"
        );
    }
}
