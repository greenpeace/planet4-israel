<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class CreateMonthlyTimesheets extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_04_000011';
    }

    public function up(wpdb $wpdb): void
    {
        $timesheetsTable = $wpdb->prefix . 'timesuite_monthly_timesheets';
        $entriesTable    = $wpdb->prefix . 'timesuite_monthly_entries';
        $collation       = $wpdb->get_charset_collate() ?: $this->getDefaultCollation();

        $timesheetsSql = "CREATE TABLE {$timesheetsTable} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            year smallint unsigned NOT NULL,
            month tinyint unsigned NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'draft',
            updated_at datetime NOT NULL,
            updated_by bigint(20) unsigned DEFAULT NULL,
            submitted_at datetime DEFAULT NULL,
            submitted_by bigint(20) unsigned DEFAULT NULL,
            approved_at datetime DEFAULT NULL,
            approved_by bigint(20) unsigned DEFAULT NULL,
            denied_at datetime DEFAULT NULL,
            denied_by bigint(20) unsigned DEFAULT NULL,
            denied_comment text,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY user_month (user_id, year, month),
            KEY status_month (status, year, month),
            KEY user_status (user_id, status)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($timesheetsSql);

        $entriesSql = "CREATE TABLE {$entriesTable} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            timesheet_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            work_date date NOT NULL,
            type varchar(20) NOT NULL DEFAULT 'working_day',
            notes text,
            hours decimal(4,2) DEFAULT NULL,
            coverage_source varchar(20) DEFAULT NULL,
            in_office tinyint(1) NOT NULL DEFAULT 0,
            approval_status varchar(20) DEFAULT NULL,
            approval_by bigint(20) unsigned DEFAULT NULL,
            approval_at datetime DEFAULT NULL,
            approval_comment text,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY timesheet_day (timesheet_id, work_date),
            KEY user_date (user_id, work_date),
            KEY approval_status (approval_status)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($entriesSql);
    }
}
