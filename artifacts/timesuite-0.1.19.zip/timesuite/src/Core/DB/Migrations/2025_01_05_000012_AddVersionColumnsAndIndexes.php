<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

/**
 * Adds version columns for optimistic locking and additional indexes for performance.
 */
class AddVersionColumnsAndIndexes extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_05_000012';
    }

    public function up(wpdb $wpdb): void
    {
        $monthlyTimesheets = $wpdb->prefix . 'timesuite_monthly_timesheets';
        $monthlyEntries    = $wpdb->prefix . 'timesuite_monthly_entries';
        $periods           = $wpdb->prefix . 'timesuite_periods';
        $usersOrg          = $wpdb->prefix . 'timesuite_users_org';
        $approvalsLog      = $wpdb->prefix . 'timesuite_approvals_log';

        // Add version column to monthly_timesheets for optimistic locking
        $this->addColumnIfNotExists($wpdb, $monthlyTimesheets, 'version', 'INT UNSIGNED NOT NULL DEFAULT 1');

        // Add version column to monthly_entries for optimistic locking
        $this->addColumnIfNotExists($wpdb, $monthlyEntries, 'version', 'INT UNSIGNED NOT NULL DEFAULT 1');

        // Add version column to periods for optimistic locking
        $this->addColumnIfNotExists($wpdb, $periods, 'version', 'INT UNSIGNED NOT NULL DEFAULT 1');

        // Add version column to users_org for optimistic locking
        $this->addColumnIfNotExists($wpdb, $usersOrg, 'version', 'INT UNSIGNED NOT NULL DEFAULT 1');

        // Add indexes for hot query paths

        // Index on approvals_log for retention cleanup queries
        $this->addIndexIfNotExists($wpdb, $approvalsLog, 'idx_created_at', '(created_at)');

        // Index on monthly_entries for user lookups
        $this->addIndexIfNotExists($wpdb, $monthlyEntries, 'idx_user_type', '(user_id, type)');

        // Index on users_org for manager lookups
        $this->addIndexIfNotExists($wpdb, $usersOrg, 'idx_manager_id', '(manager_id)');

        // Index on users_org for active users
        $this->addIndexIfNotExists($wpdb, $usersOrg, 'idx_active', '(active)');
    }

    private function addColumnIfNotExists(wpdb $wpdb, string $table, string $column, string $definition): void
    {
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
                DB_NAME,
                $table,
                $column
            )
        );

        if ((int) $exists === 0) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
        }
    }

    private function addIndexIfNotExists(wpdb $wpdb, string $table, string $indexName, string $columns): void
    {
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = %s",
                DB_NAME,
                $table,
                $indexName
            )
        );

        if ((int) $exists === 0) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE {$table} ADD INDEX {$indexName} {$columns}");
        }
    }
}

