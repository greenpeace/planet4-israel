<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class CreateReeditRequests extends Migration
{
    public function getVersion(): string
    {
        return '2026_02_26_000013';
    }

    public function up(wpdb $wpdb): void
    {
        $table = $wpdb->prefix . 'timesuite_reedit_requests';
        $collation = $wpdb->get_charset_collate() ?: $this->getDefaultCollation();

        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            year smallint unsigned NOT NULL,
            month tinyint unsigned NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            employee_reason text NOT NULL,
            manager_reason text DEFAULT NULL,
            requested_at datetime NOT NULL,
            decided_at datetime DEFAULT NULL,
            requested_by bigint(20) unsigned NOT NULL,
            decided_by bigint(20) unsigned DEFAULT NULL,
            pending_unique tinyint(1) unsigned DEFAULT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY user_period (user_id, year, month),
            KEY status_period (status, year, month),
            KEY requested_at (requested_at),
            UNIQUE KEY uniq_pending_per_month (user_id, year, month, pending_unique)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($sql);
    }
}
