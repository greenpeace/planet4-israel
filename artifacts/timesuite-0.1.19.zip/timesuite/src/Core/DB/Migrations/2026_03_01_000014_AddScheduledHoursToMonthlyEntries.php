<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class AddScheduledHoursToMonthlyEntries extends Migration
{
    public function getVersion(): string
    {
        return '2026_03_01_000014';
    }

    public function up(wpdb $wpdb): void
    {
        $table = $wpdb->prefix . 'timesuite_monthly_entries';
        $collation = $wpdb->get_charset_collate() ?: $this->getDefaultCollation();

        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            timesheet_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            work_date date NOT NULL,
            type varchar(20) NOT NULL DEFAULT 'working_day',
            notes text,
            hours decimal(4,2) DEFAULT NULL,
            scheduled_hours decimal(5,2) DEFAULT NULL,
            coverage_source varchar(20) DEFAULT NULL,
            in_office tinyint(1) NOT NULL DEFAULT 0,
            approval_status varchar(20) DEFAULT NULL,
            approval_by bigint(20) unsigned DEFAULT NULL,
            approval_at datetime DEFAULT NULL,
            approval_comment text,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY timesheet_day (timesheet_id, work_date),
            KEY user_date (user_id, work_date),
            KEY approval_status (approval_status)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($sql);
    }
}
