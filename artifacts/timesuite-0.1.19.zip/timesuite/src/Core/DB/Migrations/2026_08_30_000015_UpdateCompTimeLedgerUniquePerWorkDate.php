<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

/**
 * Replaces the comp-time ledger's month-level uniqueness rule with a
 * date-level one.
 *
 * The original key was:
 *
 *     UNIQUE KEY user_source (user_id, source_type, source_key, direction)
 *
 * Monthly credits and debits use one row per work date but share a single
 * source_key ('YYYY-MM'), source_type ('monthly') and direction, so every row
 * after the first in a month collided on that key and was rejected. Because
 * CompTimeLedgerRepository::insert() did not check the result of
 * wpdb::query(), the rejection was silent: an employee with 9h of overtime on
 * one date and 4.5h on another kept only the 9h credit, and the balance simply
 * looked smaller than it should. Adding work_date to the key is what makes one
 * row per date legal.
 *
 * Widening a unique key can only ever permit more rows, never fewer, so no
 * existing row can be invalidated by this change and no data is rewritten.
 * Verified against all three writers:
 *   - monthly credits: one row per overtime date   -> distinct work_date
 *   - monthly debits:  one row per time-in-lieu date -> distinct work_date
 *   - manual adjustments: source_key already carries a timestamp, so their
 *     uniqueness never depended on the columns being changed here.
 *
 * dbDelta() is deliberately NOT used. dbDelta only adds missing indexes; it
 * does not drop an index that has been removed from the CREATE TABLE
 * statement, so leaving the old key to dbDelta would leave the bug in place on
 * every existing install while appearing to succeed. The old key is dropped
 * and the new one created explicitly, each guarded by an information_schema
 * lookup so the migration can be run repeatedly without error.
 */
class UpdateCompTimeLedgerUniquePerWorkDate extends Migration
{
    private const OLD_INDEX = 'user_source';
    private const NEW_INDEX = 'user_source_date';

    public function getVersion(): string
    {
        return '2026_08_30_000015';
    }

    public function up(wpdb $wpdb): void
    {
        $table = $wpdb->prefix . 'timesuite_comp_time_ledger';

        if (! $this->tableExists($wpdb, $table)) {
            // Fresh installs get the correct key straight from
            // CreateCompTimeLedger; there is nothing to migrate.
            return;
        }

        // Order matters: create the wider key first so the rows stay protected
        // by *some* uniqueness rule for the whole migration. Dropping first
        // would leave a window in which duplicates could be inserted.
        if (! $this->indexExists($wpdb, $table, self::NEW_INDEX)) {
            $this->execute(
                $wpdb,
                "ALTER TABLE {$table} ADD UNIQUE KEY " . self::NEW_INDEX
                    . ' (user_id, source_type, source_key, direction, work_date)'
            );
        }

        if ($this->indexExists($wpdb, $table, self::OLD_INDEX)) {
            $this->execute($wpdb, "ALTER TABLE {$table} DROP INDEX " . self::OLD_INDEX);
        }
    }

    private function tableExists(wpdb $wpdb, string $table): bool
    {
        $found = $wpdb->get_var(
            $wpdb->prepare('SHOW TABLES LIKE %s', $table)
        );

        return is_string($found) && '' !== $found;
    }

    private function indexExists(wpdb $wpdb, string $table, string $indexName): bool
    {
        $count = $wpdb->get_var(
            $wpdb->prepare(
                'SELECT COUNT(*) FROM information_schema.STATISTICS'
                    . ' WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND INDEX_NAME = %s',
                $table,
                $indexName
            )
        );

        return (int) $count > 0;
    }

    /**
     * A failed ALTER here must not be mistaken for success: the whole point of
     * the migration is that silently-skipped writes are what caused the bug.
     */
    private function execute(wpdb $wpdb, string $sql): void
    {
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $result = $wpdb->query($sql);

        if (false === $result) {
            $error = property_exists($wpdb, 'last_error') ? (string) $wpdb->last_error : '';

            throw new \RuntimeException(
                'Timesuite migration ' . $this->getVersion() . ' failed: ' . $sql
                    . ('' !== $error ? ' -- ' . $error : '')
            );
        }
    }
}
