<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use wpdb;

class CreateHolidayRanges extends Migration
{
    public function getVersion(): string
    {
        return '2025_01_06_000013';
    }

    public function up(wpdb $wpdb): void
    {
        $table = $wpdb->prefix . 'timesuite_holiday_ranges';
        $collation = $wpdb->get_charset_collate() ?: $this->getDefaultCollation();

        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            start_date date NOT NULL,
            end_date date NOT NULL,
            type varchar(20) NOT NULL DEFAULT 'holiday',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY date_range (start_date, end_date),
            KEY end_date (end_date)
        ) ENGINE=InnoDB {$collation};";

        dbDelta($sql);

        $this->migrateLegacyHolidays($wpdb, $table);
    }

    private function migrateLegacyHolidays(wpdb $wpdb, string $table): void
    {
        $settings = get_option('timesuite_settings', []);
        $holidays = [];

        if (is_array($settings) && isset($settings['holidays'])) {
            $holidays = is_array($settings['holidays'])
                ? $settings['holidays']
                : (is_string($settings['holidays']) ? preg_split('/[\r\n,]+/', $settings['holidays']) : []);
        }

        if (empty($holidays)) {
            return;
        }

        $valid = [];

        foreach ($holidays as $item) {
            if (! is_string($item)) {
                continue;
            }

            $item = sanitize_text_field($item);

            if ($item === '') {
                continue;
            }

            $date = \DateTime::createFromFormat('Y-m-d', $item);

            if (! $date || $date->format('Y-m-d') !== $item) {
                continue;
            }

            $valid[] = $item;
        }

        $valid = array_values(array_unique($valid));

        if (empty($valid)) {
            return;
        }

        $now = current_time('mysql', true);

        foreach ($valid as $date) {
            $existing = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$table} WHERE start_date = %s AND end_date = %s AND type = %s LIMIT 1",
                    $date,
                    $date,
                    'holiday'
                )
            );

            if ($existing) {
                continue;
            }

            $wpdb->insert(
                $table,
                [
                    'start_date' => $date,
                    'end_date' => $date,
                    'type' => 'holiday',
                    'created_at' => $now,
                ],
                ['%s', '%s', '%s', '%s']
            );
        }

        if (is_array($settings)) {
            $settings['holidays'] = [];
            update_option('timesuite_settings', $settings);
        }
    }
}
