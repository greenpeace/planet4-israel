<?php

declare(strict_types=1);

namespace Timesuite\Core\DB;

use Timesuite\Core\DB\Migrations\CreateApprovalsLog;
use Timesuite\Core\DB\Migrations\CreatePeriods;
use Timesuite\Core\DB\Migrations\CreateTimeEntries;
use Timesuite\Core\DB\Migrations\CreateUsersOrg;
use Timesuite\Core\DB\Migrations\UpdatePeriodsAddUserColumn;
use Timesuite\Core\DB\Migrations\AddBreakMinutesToTimeEntries;
use Timesuite\Core\DB\Migrations\UpdateApprovalsLogAddEntity;
use Timesuite\Core\DB\Migrations\CreateCompTimeLedger;
use Timesuite\Core\DB\Migrations\UpdateTimeEntriesAllowNullPeriod;
use Timesuite\Core\DB\Migrations\CreateMonthlyTimesheets;
use Timesuite\Core\DB\Migrations\CreateHolidayRanges;
use Timesuite\Core\DB\Migrations\CreateReeditRequests;
use Timesuite\Core\DB\Migrations\AddScheduledHoursToMonthlyEntries;
use Timesuite\Core\DB\Migrations\UpdateCompTimeLedgerUniquePerWorkDate;
use wpdb;

class MigrationsRunner
{
    private const OPTION_NAME = 'timesuite_migrations_version';

    /**
     * @var class-string<Migration>[]
     */
    private const MIGRATIONS = [
        CreateUsersOrg::class,
        CreateTimeEntries::class,
        CreatePeriods::class,
        CreateApprovalsLog::class,
        UpdatePeriodsAddUserColumn::class,
        AddBreakMinutesToTimeEntries::class,
        UpdateApprovalsLogAddEntity::class,
        CreateCompTimeLedger::class,
        UpdateTimeEntriesAllowNullPeriod::class,
        CreateMonthlyTimesheets::class,
        CreateHolidayRanges::class,
        CreateReeditRequests::class,
        AddScheduledHoursToMonthlyEntries::class,
        UpdateCompTimeLedgerUniquePerWorkDate::class,
    ];

    public function __construct(private wpdb $wpdb)
    {
    }

    public function runAll(): void
    {
        $currentVersion = (string) get_option(self::OPTION_NAME, '');
        $migrations = $this->getMigrations();
        $latestVersion = '';

        foreach ($migrations as $migration) {
            $latestVersion = $migration->getVersion();

            if ('' !== $currentVersion && version_compare($currentVersion, $latestVersion, '>=')) {
                continue;
            }

            $this->executeMigration($migration);
            update_option(self::OPTION_NAME, $latestVersion);
            $currentVersion = $latestVersion;
        }

        // Ensure version is recorded even if no migrations ran
        // (tables may exist from manual setup or previous untracked runs)
        if ('' === $currentVersion && '' !== $latestVersion) {
            update_option(self::OPTION_NAME, $latestVersion);
        }
    }

    /**
     * @return Migration[]
     */
    private function getMigrations(): array
    {
        $instances = [];

        foreach (self::MIGRATIONS as $className) {
            $instances[] = new $className();
        }

        usort(
            $instances,
            static function (Migration $a, Migration $b): int {
                return strcmp($a->getVersion(), $b->getVersion());
            }
        );

        return $instances;
    }

    private function executeMigration(Migration $migration): void
    {
        if (! function_exists('dbDelta')) {
            if (defined('ABSPATH')) {
                $upgradeFile = ABSPATH . 'wp-admin/includes/upgrade.php';

                if (is_readable($upgradeFile)) {
                    require_once $upgradeFile;
                }
            }
        }

        $migration->up($this->wpdb);
    }
}
