<?php

declare(strict_types=1);

namespace Timesuite\Core\Exceptions;

use Exception;
use Psr\Container\ContainerExceptionInterface;

/**
 * Exception thrown when a container error occurs.
 */
class ContainerException extends Exception implements ContainerExceptionInterface
{
}

