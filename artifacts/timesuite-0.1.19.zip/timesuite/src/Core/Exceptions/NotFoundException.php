<?php

declare(strict_types=1);

namespace Timesuite\Core\Exceptions;

use Exception;
use Psr\Container\NotFoundExceptionInterface;

/**
 * Exception thrown when an entry is not found in the container.
 */
class NotFoundException extends Exception implements NotFoundExceptionInterface
{
}

