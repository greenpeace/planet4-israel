<?php

declare(strict_types=1);

namespace Timesuite\Core\Monitoring;

/**
 * Scoped diagnostics logger for Timesuite-only operational debugging.
 */
class DiagnosticsService
{
    private const ENABLED_OPTION = 'timesuite_diagnostics_enabled';
    private const EXPIRES_AT_OPTION = 'timesuite_diagnostics_expires_at';
    private const LOG_OPTION = 'timesuite_diagnostics_log';
    private const MAX_ENTRIES = 500;
    private const RECENT_ENTRIES = 20;
    private const DEFAULT_DURATION_HOURS = 24;

    /**
     * @var callable|null
     */
    private $previousErrorHandler = null;

    public function register(): void
    {
        add_action('timesuite_alert', [$this, 'recordAlert'], 10, 2);
        $this->previousErrorHandler = set_error_handler([$this, 'handlePhpError']);
        add_action('shutdown', [$this, 'captureFatalError']);
    }

    public function enable(int $durationHours = self::DEFAULT_DURATION_HOURS): array
    {
        $durationHours = max(1, min(168, $durationHours));

        update_option(self::ENABLED_OPTION, true);
        update_option(self::EXPIRES_AT_OPTION, time() + ($durationHours * 3600));

        $this->record('info', 'diagnostics', 'Diagnostics mode enabled.', [
            'duration_hours' => $durationHours,
        ]);

        return $this->status();
    }

    public function disable(): array
    {
        $this->record('info', 'diagnostics', 'Diagnostics mode disabled.');

        update_option(self::ENABLED_OPTION, false);
        update_option(self::EXPIRES_AT_OPTION, 0);

        return $this->status();
    }

    public function clear(): array
    {
        update_option(self::LOG_OPTION, []);

        return $this->status();
    }

    /**
     * @return array<string, mixed>
     */
    public function status(): array
    {
        $enabled = $this->isEnabled();
        $expiresAt = $this->getExpiresAt();
        $entries = $this->getEntries();

        return [
            'enabled' => $enabled,
            'expires_at' => $enabled && $expiresAt > 0 ? gmdate('c', $expiresAt) : null,
            'entries_count' => count($entries),
            'recent_entries' => array_slice(array_reverse($entries), 0, self::RECENT_ENTRIES),
            'max_entries' => self::MAX_ENTRIES,
            'privacy_note' => __(
                'Diagnostics are scoped to Timesuite and redact emails, tokens, passwords, secrets, and authorization values.',
                'timesuite'
            ),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function export(): array
    {
        return [
            'generated_at' => gmdate('c'),
            'status' => $this->status(),
            'entries' => $this->getEntries(),
        ];
    }

    public function isEnabled(): bool
    {
        $enabled = (bool) get_option(self::ENABLED_OPTION, false);

        if (! $enabled) {
            return false;
        }

        $expiresAt = $this->getExpiresAt();

        if ($expiresAt > 0 && $expiresAt <= time()) {
            update_option(self::ENABLED_OPTION, false);
            update_option(self::EXPIRES_AT_OPTION, 0);

            return false;
        }

        return true;
    }

    /**
     * @param array<string, mixed> $context
     */
    public function record(string $level, string $area, string $message, array $context = []): void
    {
        if (! $this->isEnabled()) {
            return;
        }

        $entries = $this->getEntries();
        $entries[] = [
            'time' => gmdate('c'),
            'level' => $this->normalizeLevel($level),
            'area' => sanitize_key($area) ?: 'general',
            'message' => $this->redactString($message),
            'context' => $this->redactContext($context),
        ];

        if (count($entries) > self::MAX_ENTRIES) {
            $entries = array_slice($entries, -self::MAX_ENTRIES);
        }

        update_option(self::LOG_OPTION, $entries);
    }

    /**
     * @param array<string, mixed> $context
     */
    public function recordAlert(string $type, array $context = []): void
    {
        $level = in_array($type, ['rest_5xx', 'db_table_missing'], true) ? 'error' : 'warning';

        $this->record($level, 'alert', sprintf('Timesuite alert: %s', $type), [
            'type' => $type,
            'context' => $context,
        ]);
    }

    public function handlePhpError(int $severity, string $message, string $file = '', int $line = 0): bool
    {
        if (! $this->isEnabled()) {
            return $this->delegatePreviousErrorHandler($severity, $message, $file, $line);
        }

        if ((error_reporting() & $severity) === 0) {
            return $this->delegatePreviousErrorHandler($severity, $message, $file, $line);
        }

        if (! $this->isTimesuitePath($file)) {
            return $this->delegatePreviousErrorHandler($severity, $message, $file, $line);
        }

        $this->record($this->phpErrorLevel($severity), 'php', $message, [
            'severity' => $severity,
            'file' => $this->relativePluginPath($file),
            'line' => $line,
        ]);

        return $this->delegatePreviousErrorHandler($severity, $message, $file, $line);
    }

    public function captureFatalError(): void
    {
        if (! $this->isEnabled()) {
            return;
        }

        $error = error_get_last();

        if (! is_array($error)) {
            return;
        }

        $type = (int) ($error['type'] ?? 0);
        $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR];

        if (! in_array($type, $fatalTypes, true)) {
            return;
        }

        $file = (string) ($error['file'] ?? '');

        if (! $this->isTimesuitePath($file)) {
            return;
        }

        $this->record('error', 'php', (string) ($error['message'] ?? 'Fatal PHP error.'), [
            'severity' => $type,
            'file' => $this->relativePluginPath($file),
            'line' => (int) ($error['line'] ?? 0),
            'fatal' => true,
        ]);
    }

    private function getExpiresAt(): int
    {
        return (int) get_option(self::EXPIRES_AT_OPTION, 0);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function getEntries(): array
    {
        $entries = get_option(self::LOG_OPTION, []);

        return is_array($entries) ? $entries : [];
    }

    private function normalizeLevel(string $level): string
    {
        $level = strtolower($level);

        return in_array($level, ['debug', 'info', 'warning', 'error'], true) ? $level : 'info';
    }

    private function phpErrorLevel(int $severity): string
    {
        return match ($severity) {
            E_WARNING, E_USER_WARNING, E_CORE_WARNING, E_COMPILE_WARNING => 'warning',
            E_NOTICE, E_USER_NOTICE, E_DEPRECATED, E_USER_DEPRECATED, E_STRICT => 'info',
            default => 'error',
        };
    }

    private function isTimesuitePath(string $file): bool
    {
        if ($file === '') {
            return false;
        }

        $normalizedFile = $this->normalizePath($file);
        $pluginPath = defined('TIMESUITE_PLUGIN_PATH') ? $this->normalizePath((string) TIMESUITE_PLUGIN_PATH) : '';

        if ($pluginPath !== '' && str_starts_with($normalizedFile, rtrim($pluginPath, '/') . '/')) {
            return true;
        }

        return str_contains($normalizedFile, '/plugins/timesuite/');
    }

    private function relativePluginPath(string $file): string
    {
        $normalizedFile = $this->normalizePath($file);
        $pluginPath = defined('TIMESUITE_PLUGIN_PATH') ? $this->normalizePath((string) TIMESUITE_PLUGIN_PATH) : '';

        if ($pluginPath !== '' && str_starts_with($normalizedFile, rtrim($pluginPath, '/') . '/')) {
            return ltrim(substr($normalizedFile, strlen(rtrim($pluginPath, '/'))), '/');
        }

        return basename($file);
    }

    private function normalizePath(string $path): string
    {
        return str_replace('\\', '/', $path);
    }

    private function delegatePreviousErrorHandler(int $severity, string $message, string $file, int $line): bool
    {
        if (! is_callable($this->previousErrorHandler)) {
            return false;
        }

        return (bool) call_user_func($this->previousErrorHandler, $severity, $message, $file, $line);
    }

    /**
     * @param array<string, mixed> $context
     *
     * @return array<string, mixed>
     */
    private function redactContext(array $context): array
    {
        $redacted = [];

        foreach ($context as $key => $value) {
            $normalizedKey = strtolower((string) $key);

            if (preg_match('/(password|passwd|secret|token|authorization|api[_-]?key|email|phone)/', $normalizedKey)) {
                $redacted[$key] = '[redacted]';
                continue;
            }

            if (is_array($value)) {
                $redacted[$key] = $this->redactContext($value);
            } elseif (is_string($value)) {
                $redacted[$key] = $this->redactString($value);
            } elseif (is_scalar($value) || null === $value) {
                $redacted[$key] = $value;
            } else {
                $redacted[$key] = '[unsupported]';
            }
        }

        return $redacted;
    }

    private function redactString(string $value): string
    {
        $value = preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', '[redacted-email]', $value) ?? $value;
        $value = preg_replace('/(password|passwd|secret|token|authorization|api[_-]?key)(\\s*[=:]\\s*)[^\\s,&]+/i', '$1$2[redacted]', $value) ?? $value;

        if (strlen($value) > 500) {
            $value = substr($value, 0, 500) . '...';
        }

        return $value;
    }
}
