<?php

declare(strict_types=1);

namespace Timesuite\Core\Monitoring;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Emits lightweight operational alerts for critical production failures.
 */
class ProductionAlertMonitor
{
    private const TIMESUITE_ROUTE_PREFIX = '/timesuite/v1/';

    public function register(): void
    {
        add_filter('rest_post_dispatch', [$this, 'captureRestFailures'], 20, 3);
        add_action('shutdown', [$this, 'captureDatabaseErrors']);
    }

    /**
     * @param mixed $response
     * @param mixed $server
     * @return mixed
     */
    public function captureRestFailures($response, $server, WP_REST_Request $request)
    {
        $route = (string) $request->get_route();

        if (! str_starts_with($route, self::TIMESUITE_ROUTE_PREFIX)) {
            return $response;
        }

        $status = $this->resolveStatusCode($response);

        if ($status !== null && $status >= 500) {
            $this->emitAlert(
                'rest_5xx',
                [
                    'status' => $status,
                    'route' => $route,
                    'method' => method_exists($request, 'get_method') ? (string) $request->get_method() : null,
                    'time' => gmdate('c'),
                ]
            );
        }

        return $response;
    }

    public function captureDatabaseErrors(): void
    {
        global $wpdb;

        if (! ($wpdb instanceof \wpdb)) {
            return;
        }

        $error = trim((string) ($wpdb->last_error ?? ''));

        if ($error === '') {
            return;
        }

        $query = (string) ($wpdb->last_query ?? '');
        $missingTable = stripos($error, "doesn't exist") !== false
            || stripos($error, 'does not exist') !== false;

        if (! $missingTable) {
            return;
        }

        if (stripos($error, 'timesuite_') === false && stripos($query, 'timesuite_') === false) {
            return;
        }

        $this->emitAlert(
            'db_table_missing',
            [
                'error' => $error,
                'query' => $query,
                'time' => gmdate('c'),
            ]
        );
    }

    /**
     * @param mixed $response
     */
    private function resolveStatusCode($response): ?int
    {
        if ($response instanceof WP_REST_Response) {
            return $response->get_status();
        }

        if ($response instanceof WP_Error) {
            $data = $response->get_error_data();

            if (is_array($data) && isset($data['status'])) {
                return (int) $data['status'];
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $context
     */
    private function emitAlert(string $type, array $context): void
    {
        if (function_exists('do_action')) {
            do_action('timesuite_alert', $type, $context);
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            $json = function_exists('wp_json_encode')
                ? wp_json_encode($context)
                : json_encode($context);

            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            error_log(sprintf('Timesuite alert [%s]: %s', $type, (string) $json));
        }
    }
}
