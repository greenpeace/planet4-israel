<?php

declare(strict_types=1);

namespace Timesuite\Core;

class Settings
{
    private const OPTION_NAME = 'timesuite_settings';
    private const CUSTOM_LEAVE_KEY_PREFIX = 'cl_';
    private const CUSTOM_LEAVE_KEY_MAX_LENGTH = 20;
    private const BUILT_IN_DAY_TYPE_KEYS = [
        'working_day',
        'half_working',
        'overtime',
        'day_off',
        'sick_day',
        'holiday',
        'half_holiday',
    ];

    private const DEFAULTS = [
        'super_user_emails'          => [],
        'work_week'                  => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu'],
        'period_cutoff_day'          => 1,
        'daily_hours'                => 9,
        'leave_standard_day_hours'   => 9,
        'backdating_allowed'         => false,
        'default_previous_month_before_cutoff' => false,
        'comp_time_expiry_months'    => 2,
        'holidays'                   => [],
        'office_checkbox_enabled'    => false,
        'allow_circular_manager_assignments' => false,
        'timezone'                   => '', // Empty = use WordPress timezone
        'audit_retention_days'       => 365, // Days to keep audit logs (0 = forever)
        'export_version'             => 'v1', // Export schema version
        // Overtime settings
        'overtime_enabled'           => false,
        'overtime_daily_threshold'   => 0, // 0 = disabled
        'overtime_weekly_threshold'  => 0, // 0 = disabled
        // Data retention
        'timesheet_retention_months' => 36, // 3 years default
        // Email notifications
        'notifications_enabled'      => false,
        'notify_on_submit'           => true,
        'notify_on_approve'          => true,
        'notify_on_deny'             => true,
        'email_from_name'            => '', // Empty = use site name
        'email_from_address'         => '', // Empty = use admin email
        // Vacation / Annual Leave settings
        'default_vacation_days'      => 18, // Default annual vacation days per contract
        'default_sick_days'          => 10, // Default annual sick days per contract
        'time_off_reset_enabled'     => false, // Legacy combined carryover toggle
        'time_off_reset_vacation_enabled' => false,
        'time_off_reset_sick_enabled' => false,
        'time_off_reset_vacation_days' => 0, // Default paid time off carryover cap
        'time_off_reset_sick_days'   => 0, // Default sick carryover cap
        'custom_leave_types'         => [],
    ];

    // Days start from Sunday (standard calendar order)
    public const WORK_WEEK_OPTIONS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    private const WORK_WEEK_ALIASES = [
        'sun' => 'Sun',
        'sunday' => 'Sun',
        'mon' => 'Mon',
        'monday' => 'Mon',
        'tue' => 'Tue',
        'tues' => 'Tue',
        'tuesday' => 'Tue',
        'wed' => 'Wed',
        'wednesday' => 'Wed',
        'thu' => 'Thu',
        'thur' => 'Thu',
        'thurs' => 'Thu',
        'thursday' => 'Thu',
        'fri' => 'Fri',
        'friday' => 'Fri',
        'sat' => 'Sat',
        'saturday' => 'Sat',
    ];

    /**
     * @var array<string, mixed>
     */
    private array $data;

    public function __construct(?array $data = null)
    {
        $this->data = $this->normalize($data ?? []);
    }

    public static function load(): self
    {
        $stored = get_option(self::OPTION_NAME, []);

        return new self(is_array($stored) ? $stored : []);
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return $this->data;
    }

    public function getSuperUserEmails(): array
    {
        return $this->data['super_user_emails'];
    }

    /**
     * Get SuperAccess emails with validation status.
     *
     * Returns each email with whether a WordPress user exists for it.
     * This helps admins identify misconfigured SuperAccess entries.
     *
     * @return array<int, array{email: string, valid: bool, user_id: int|null, user_name: string|null}>
     */
    public function getSuperUserEmailsWithValidation(): array
    {
        $emails = $this->getSuperUserEmails();
        $result = [];

        foreach ($emails as $email) {
            $user = get_user_by('email', $email);

            $result[] = [
                'email' => $email,
                'valid' => $user instanceof \WP_User,
                'user_id' => $user ? (int) $user->ID : null,
                'user_name' => $user ? ($user->display_name ?: $user->user_login) : null,
            ];
        }

        return $result;
    }

    /**
     * Check if any SuperAccess emails are invalid (no WP user exists).
     *
     * @return array{valid: bool, invalid_emails: string[], warning: string|null}
     */
    public function validateSuperUserEmails(): array
    {
        $validation = $this->getSuperUserEmailsWithValidation();
        $invalidEmails = [];

        foreach ($validation as $entry) {
            if (! $entry['valid']) {
                $invalidEmails[] = $entry['email'];
            }
        }

        $valid = empty($invalidEmails);
        $warning = null;

        if (! $valid) {
            $warning = sprintf(
                /* translators: %s: comma separated list of invalid emails */
                __('The following SuperAccess emails do not match any WordPress user: %s. These users will NOT be able to use SuperAccess.', 'timesuite'),
                implode(', ', $invalidEmails)
            );
        }

        return [
            'valid' => $valid,
            'invalid_emails' => $invalidEmails,
            'warning' => $warning,
        ];
    }

    public function getWorkWeek(): array
    {
        return $this->data['work_week'];
    }

    public static function normalizeWorkWeekDays(mixed $value): array
    {
        $values = is_string($value)
            ? preg_split('/[\s,;|]+/', $value, -1, PREG_SPLIT_NO_EMPTY)
            : (is_array($value) ? $value : []);

        $days = [];

        foreach ($values as $item) {
            $normalized = self::normalizeWorkWeekDay($item);

            if ($normalized !== null) {
                $days[] = $normalized;
            }
        }

        return array_values(array_unique($days));
    }

    public function getPeriodCutoffDay(): int
    {
        return (int) $this->data['period_cutoff_day'];
    }

    public function getDailyHours(): float
    {
        return (float) $this->data['daily_hours'];
    }

    public function getLeaveStandardDayHours(): float
    {
        return (float) $this->data['leave_standard_day_hours'];
    }

    public function isBackdatingAllowed(): bool
    {
        return (bool) $this->data['backdating_allowed'];
    }

    /**
     * Whether the app should default employees, managers, and HR onto the
     * previous month (instead of the current month) while today is still
     * on/before the period cutoff day. This only changes what month each
     * screen opens on by default — it does not affect editability, and is
     * independent of isBackdatingAllowed() (deliberately not gated on it,
     * to keep the two toggles simple and independent).
     */
    public function isDefaultPreviousMonthBeforeCutoff(): bool
    {
        return (bool) $this->data['default_previous_month_before_cutoff'];
    }

    public function getCompTimeExpiryMonths(): int
    {
        return (int) $this->data['comp_time_expiry_months'];
    }

    public function getHolidays(): array
    {
        return $this->data['holidays'];
    }

    public function isOfficeCheckboxEnabled(): bool
    {
        return (bool) $this->data['office_checkbox_enabled'];
    }

    public function allowCircularManagerAssignments(): bool
    {
        return (bool) $this->data['allow_circular_manager_assignments'];
    }

    public function getTimezone(): string
    {
        return $this->data['timezone'];
    }

    public function getAuditRetentionDays(): int
    {
        return (int) $this->data['audit_retention_days'];
    }

    public function getExportVersion(): string
    {
        return $this->data['export_version'];
    }

    public function isOvertimeEnabled(): bool
    {
        return (bool) $this->data['overtime_enabled'];
    }

    public function getOvertimeDailyThreshold(): float
    {
        return (float) $this->data['overtime_daily_threshold'];
    }

    public function getOvertimeWeeklyThreshold(): float
    {
        return (float) $this->data['overtime_weekly_threshold'];
    }

    public function getTimesheetRetentionMonths(): int
    {
        return (int) $this->data['timesheet_retention_months'];
    }

    public function areNotificationsEnabled(): bool
    {
        return (bool) $this->data['notifications_enabled'];
    }

    public function shouldNotifyOnSubmit(): bool
    {
        return $this->areNotificationsEnabled() && (bool) $this->data['notify_on_submit'];
    }

    public function shouldNotifyOnApprove(): bool
    {
        return $this->areNotificationsEnabled() && (bool) $this->data['notify_on_approve'];
    }

    public function shouldNotifyOnDeny(): bool
    {
        return $this->areNotificationsEnabled() && (bool) $this->data['notify_on_deny'];
    }

    public function getEmailFromName(): string
    {
        $name = $this->data['email_from_name'] ?? '';

        return '' !== $name ? $name : get_bloginfo('name');
    }

    public function getEmailFromAddress(): string
    {
        $email = $this->data['email_from_address'] ?? '';

        return '' !== $email && is_email($email) ? $email : get_option('admin_email');
    }

    public function getDefaultVacationDays(): int
    {
        return (int) ($this->data['default_vacation_days'] ?? 18);
    }

    public function getDefaultSickDays(): int
    {
        return (int) ($this->data['default_sick_days'] ?? 10);
    }

    public function isTimeOffResetEnabled(): bool
    {
        return $this->isVacationCarryoverCapEnabled() || $this->isSickCarryoverCapEnabled();
    }

    public function isVacationCarryoverCapEnabled(): bool
    {
        return (bool) ($this->data['time_off_reset_vacation_enabled'] ?? false);
    }

    public function isSickCarryoverCapEnabled(): bool
    {
        return (bool) ($this->data['time_off_reset_sick_enabled'] ?? false);
    }

    public function getTimeOffResetVacationDays(): int
    {
        return (int) ($this->data['time_off_reset_vacation_days'] ?? 0);
    }

    public function getTimeOffResetSickDays(): int
    {
        return (int) ($this->data['time_off_reset_sick_days'] ?? 0);
    }

    /**
     * @return array<int, array{key:string, label:string, active:bool, created_at:string|null, archived_at:string|null}>
     */
    public function getCustomLeaveTypes(): array
    {
        $types = $this->data['custom_leave_types'] ?? [];

        return is_array($types) ? $types : [];
    }

    /**
     * @return array{updated: bool, errors: array<string, string>}
     */
    public function update(array $input): array
    {
        [$sanitized, $errors] = $this->sanitizeInput($input);

        if (! empty($sanitized)) {
            $this->data = $this->normalize(array_merge($this->data, $sanitized));
            update_option(self::OPTION_NAME, $this->data);
        }

        return [
            'updated' => ! empty($sanitized),
            'errors'  => $errors,
        ];
    }

    private function normalize(array $data): array
    {
        $normalized = self::DEFAULTS;
        $hasVacationToggle = array_key_exists('time_off_reset_vacation_enabled', $data);
        $hasSickToggle = array_key_exists('time_off_reset_sick_enabled', $data);

        foreach (self::DEFAULTS as $key => $default) {
            if (! array_key_exists($key, $data)) {
                continue;
            }

            $value = $this->sanitizeValue($key, $data[$key]);
            $normalized[$key] = null === $value ? $default : $value;
        }

        // Existing installations used one toggle for both balances.
        if (! $hasVacationToggle) {
            $normalized['time_off_reset_vacation_enabled'] = $normalized['time_off_reset_enabled'];
        }

        if (! $hasSickToggle) {
            $normalized['time_off_reset_sick_enabled'] = $normalized['time_off_reset_enabled'];
        }

        $normalized['time_off_reset_enabled'] = (
            $normalized['time_off_reset_vacation_enabled']
            || $normalized['time_off_reset_sick_enabled']
        );

        return $normalized;
    }

    /**
     * @return array{0: array<string, mixed>, 1: array<string, string>}
     */
    private function sanitizeInput(array $input): array
    {
        $sanitized = [];
        $errors    = [];

        foreach (self::DEFAULTS as $key => $default) {
            if (! array_key_exists($key, $input)) {
                continue;
            }

            $error = null;
            $value = $this->sanitizeValue($key, $input[$key], $error);

            if (null !== $error) {
                $errors[$key] = $error;
                continue;
            }

            if ($value === null) {
                $value = $default;
            }

            $sanitized[$key] = $value;
        }

        return [$sanitized, $errors];
    }

    private function sanitizeValue(string $key, mixed $value, ?string &$error = null): mixed
    {
        $error = null;

        switch ($key) {
            case 'super_user_emails':
                return $this->sanitizeEmailArray($value);
            case 'work_week':
                $days = $this->sanitizeWorkWeek($value);

                if (empty($days)) {
                    $error = __('Please select at least one work day.', 'timesuite');

                    return null;
                }

                return $days;
            case 'period_cutoff_day':
                $day = absint($value);

                if ($day < 1 || $day > 31) {
                    $error = __('Period cutoff day must be between 1 and 31.', 'timesuite');

                    return null;
                }

                return $day;
            case 'daily_hours':
            case 'leave_standard_day_hours':
                $hours = (float) $value;

                if ($hours < 1 || $hours > 24) {
                    $error = 'leave_standard_day_hours' === $key
                        ? __('Standard leave day hours must be between 1 and 24.', 'timesuite')
                        : __('Daily hours must be between 1 and 24.', 'timesuite');

                    return null;
                }

                return round($hours, 2);
            case 'backdating_allowed':
                return (bool) $value;
            case 'default_previous_month_before_cutoff':
                return (bool) $value;
            case 'office_checkbox_enabled':
                return (bool) $value;
            case 'allow_circular_manager_assignments':
                return (bool) $value;
            case 'comp_time_expiry_months':
                $months = absint($value);

                if ($months > 24) {
                    $error = __('Comp time expiry months must be 24 or less.', 'timesuite');

                    return null;
                }

                return $months;
            case 'holidays':
                return $this->sanitizeHolidays($value, $error);
            case 'timezone':
                return $this->sanitizeTimezone($value, $error);
            case 'audit_retention_days':
                $days = absint($value);

                if ($days > 3650) { // Max 10 years
                    $error = __('Audit retention cannot exceed 10 years.', 'timesuite');

                    return null;
                }

                return $days;
            case 'export_version':
                $version = is_string($value) ? sanitize_text_field($value) : '';

                if (! in_array($version, ['v1', 'v2'], true)) {
                    $error = __('Invalid export version.', 'timesuite');

                    return null;
                }

                return $version;
            case 'overtime_enabled':
                return (bool) $value;
            case 'overtime_daily_threshold':
                $hours = (float) $value;

                if ($hours < 0 || $hours > 24) {
                    $error = __('Daily overtime threshold must be between 0 and 24.', 'timesuite');

                    return null;
                }

                return round($hours, 2);
            case 'overtime_weekly_threshold':
                $hours = (float) $value;

                if ($hours < 0 || $hours > 168) {
                    $error = __('Weekly overtime threshold must be between 0 and 168.', 'timesuite');

                    return null;
                }

                return round($hours, 2);
            case 'timesheet_retention_months':
                $months = absint($value);

                if ($months < 12) {
                    $error = __('Timesheet retention must be at least 12 months.', 'timesuite');

                    return null;
                }

                if ($months > 120) {
                    $error = __('Timesheet retention cannot exceed 10 years.', 'timesuite');

                    return null;
                }

                return $months;
            case 'notifications_enabled':
            case 'notify_on_submit':
            case 'notify_on_approve':
            case 'notify_on_deny':
                return (bool) $value;
            case 'email_from_name':
                return sanitize_text_field((string) $value);
            case 'email_from_address':
                $email = sanitize_email((string) $value);

                if ('' !== $value && '' === $email) {
                    $error = __('Invalid email address for sender.', 'timesuite');

                    return null;
                }

                return $email;
            case 'default_vacation_days':
                $days = absint($value);

                if ($days > 365) {
                    $error = __('Default vacation days cannot exceed 365.', 'timesuite');

                    return null;
                }

                return $days;
            case 'default_sick_days':
                $days = absint($value);

                if ($days > 365) {
                    $error = __('Default sick days cannot exceed 365.', 'timesuite');

                    return null;
                }

                return $days;
            case 'time_off_reset_enabled':
            case 'time_off_reset_vacation_enabled':
            case 'time_off_reset_sick_enabled':
                return (bool) $value;
            case 'time_off_reset_vacation_days':
                $days = absint($value);

                if ($days > 365) {
                    $error = __('Reset day off balance cannot exceed 365.', 'timesuite');

                    return null;
                }

                return $days;
            case 'time_off_reset_sick_days':
                $days = absint($value);

                if ($days > 365) {
                    $error = __('Reset sick day balance cannot exceed 365.', 'timesuite');

                    return null;
                }

                return $days;
            case 'custom_leave_types':
                return $this->sanitizeCustomLeaveTypes($value, $error);
        }

        return null;
    }

    /**
     * @return array<int, array{key:string, label:string, active:bool, created_at:string|null, archived_at:string|null}>|null
     */
    private function sanitizeCustomLeaveTypes(mixed $value, ?string &$error = null): ?array
    {
        if (! is_array($value)) {
            $error = __('Custom leave types payload is invalid.', 'timesuite');

            return null;
        }

        $currentData = isset($this->data) ? $this->data : [];
        $existing = $this->normalizeStoredCustomLeaveTypes($currentData['custom_leave_types'] ?? []);
        $existingByKey = [];
        $takenKeys = array_fill_keys(self::BUILT_IN_DAY_TYPE_KEYS, true);

        foreach ($existing as $item) {
            $key = (string) $item['key'];
            $existingByKey[$key] = $item;
            $takenKeys[$key] = true;
        }

        $processed = [];
        $seenLabels = [];

        foreach ($value as $item) {
            if (! is_array($item)) {
                continue;
            }

            $label = sanitize_text_field((string) ($item['label'] ?? ''));

            if ($label === '') {
                continue;
            }

            $providedKey = sanitize_key((string) ($item['key'] ?? ''));
            $existingItem = $providedKey !== '' ? ($existingByKey[$providedKey] ?? null) : null;

            if ($existingItem !== null && $label !== (string) $existingItem['label']) {
                $error = __('Existing custom leave labels cannot be renamed.', 'timesuite');

                return null;
            }

            $normalizedLabel = strtolower($label);

            if (isset($seenLabels[$normalizedLabel])) {
                $error = __('Custom leave labels must be unique.', 'timesuite');

                return null;
            }

            $seenLabels[$normalizedLabel] = true;
            if ($existingItem !== null) {
                $key = (string) $existingItem['key'];
            } elseif (
                $providedKey !== ''
                && strlen($providedKey) <= self::CUSTOM_LEAVE_KEY_MAX_LENGTH
                && ! isset($takenKeys[$providedKey])
            ) {
                $key = $providedKey;
            } else {
                $key = $this->buildCustomLeaveTypeKey($label, $takenKeys);
            }
            $active = ! array_key_exists('active', $item) ? true : (bool) $item['active'];
            $createdAt = $existingItem['created_at'] ?? current_time('mysql', true);
            $archivedAt = $active
                ? null
                : ($existingItem['archived_at'] ?? current_time('mysql', true));

            $processed[$key] = [
                'key' => $key,
                'label' => $existingItem['label'] ?? $label,
                'active' => $active,
                'created_at' => is_string($createdAt) && $createdAt !== '' ? $createdAt : current_time('mysql', true),
                'archived_at' => is_string($archivedAt) && $archivedAt !== '' ? $archivedAt : null,
            ];
            $takenKeys[$key] = true;
        }

        foreach ($existingByKey as $key => $existingItem) {
            if (isset($processed[$key])) {
                continue;
            }

            $processed[$key] = [
                'key' => $key,
                'label' => (string) $existingItem['label'],
                'active' => false,
                'created_at' => $existingItem['created_at'] ?? current_time('mysql', true),
                'archived_at' => $existingItem['archived_at'] ?? current_time('mysql', true),
            ];
        }

        return array_values($processed);
    }

    /**
     * @return array<int, array{key:string, label:string, active:bool, created_at:string|null, archived_at:string|null}>
     */
    private function normalizeStoredCustomLeaveTypes(mixed $value): array
    {
        if (! is_array($value)) {
            return [];
        }

        $normalized = [];
        $seenKeys = [];

        foreach ($value as $item) {
            if (! is_array($item)) {
                continue;
            }

            $key = sanitize_key((string) ($item['key'] ?? ''));
            $label = sanitize_text_field((string) ($item['label'] ?? ''));

            if (
                $key === ''
                || strlen($key) > self::CUSTOM_LEAVE_KEY_MAX_LENGTH
                || $label === ''
                || isset($seenKeys[$key])
            ) {
                continue;
            }

            $normalized[] = [
                'key' => $key,
                'label' => $label,
                'active' => ! array_key_exists('active', $item) ? true : (bool) $item['active'],
                'created_at' => is_string($item['created_at'] ?? null) ? $item['created_at'] : null,
                'archived_at' => is_string($item['archived_at'] ?? null) ? $item['archived_at'] : null,
            ];
            $seenKeys[$key] = true;
        }

        return $normalized;
    }

    /**
     * @param array<string, bool> $takenKeys
     */
    private function buildCustomLeaveTypeKey(string $label, array $takenKeys): string
    {
        $prefix = self::CUSTOM_LEAVE_KEY_PREFIX;
        $slug = sanitize_key($label);

        if ($slug === '') {
            $slug = 'leave';
        }

        $availableLength = self::CUSTOM_LEAVE_KEY_MAX_LENGTH - strlen($prefix);
        $base = $prefix . substr($slug, 0, max(1, $availableLength));
        $candidate = $base;
        $suffix = 2;

        while (isset($takenKeys[$candidate])) {
            $suffixText = '_' . $suffix;
            $stemLength = self::CUSTOM_LEAVE_KEY_MAX_LENGTH - strlen($prefix) - strlen($suffixText);
            $candidate = $prefix . substr($slug, 0, max(1, $stemLength)) . $suffixText;
            $suffix++;
        }

        return $candidate;
    }

    private function sanitizeTimezone(mixed $value, ?string &$error = null): string
    {
        $timezone = is_string($value) ? sanitize_text_field($value) : '';

        if ('' === $timezone) {
            return ''; // Use WordPress default
        }

        try {
            new \DateTimeZone($timezone);

            return $timezone;
        } catch (\Exception $e) {
            $error = __('Invalid timezone.', 'timesuite');

            return '';
        }
    }

    private function sanitizeEmailArray(mixed $value): array
    {
        $values = $this->ensureArray($value);
        $emails = [];

        foreach ($values as $item) {
            $sanitized = sanitize_email($item);

            if ('' === $sanitized) {
                continue;
            }

            if (! is_email($sanitized)) {
                continue;
            }

            $emails[] = strtolower($sanitized);
        }

        return array_values(array_unique($emails));
    }

    private function sanitizeWorkWeek(mixed $value): array
    {
        return self::normalizeWorkWeekDays($value);
    }

    private static function normalizeWorkWeekDay(mixed $value): ?string
    {
        $day = sanitize_text_field((string) $value);

        if ($day === '') {
            return null;
        }

        if (in_array($day, self::WORK_WEEK_OPTIONS, true)) {
            return $day;
        }

        $key = strtolower($day);

        return self::WORK_WEEK_ALIASES[$key] ?? null;
    }

    private function sanitizeHolidays(mixed $value, ?string &$error = null): ?array
    {
        $values        = $this->ensureArray($value);
        $validHolidays = [];
        $invalid       = [];

        foreach ($values as $item) {
            $item = sanitize_text_field($item);

            if ('' === $item) {
                continue;
            }

            $date = \DateTime::createFromFormat('Y-m-d', $item);

            if (! $date || $date->format('Y-m-d') !== $item) {
                $invalid[] = $item;
                continue;
            }

            $validHolidays[] = $item;
        }

        if (! empty($invalid)) {
            /* translators: %s: comma separated list of invalid dates */
            $error = sprintf(
                __('The following holidays are invalid dates: %s.', 'timesuite'),
                implode(', ', $invalid)
            );

            return null;
        }

        return array_values(array_unique($validHolidays));
    }

    private function ensureArray(mixed $value): array
    {
        if (is_array($value)) {
            return array_map(static fn ($item) => is_string($item) ? $item : (string) $item, $value);
        }

        if (is_string($value)) {
            $parts = preg_split('/[\r\n,]+/', $value) ?: [];

            return array_map('trim', $parts);
        }

        return [];
    }
}
