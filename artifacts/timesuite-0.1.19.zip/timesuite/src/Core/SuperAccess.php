<?php

declare(strict_types=1);

namespace Timesuite\Core;

use WP_User;

/**
 * SuperAccess: Emergency/break-glass capability override.
 *
 * Users whose email is in the "Super user emails" list (Policy Settings)
 * get ALL Timesuite capabilities granted, bypassing the normal role system.
 *
 * This is intended for:
 * - Development and testing
 * - Emergency recovery when locked out
 * - Support access
 *
 * Usage is logged to the audit trail for accountability.
 */
class SuperAccess
{
    /**
     * @var string[]|null
     */
    private static ?array $cached = null;

    /**
     * Track which users have been granted SuperAccess this request (for logging).
     *
     * @var array<int, bool>
     */
    private static array $loggedThisRequest = [];

    public static function register(): void
    {
        add_filter('user_has_cap', [self::class, 'grantCapabilities'], 10, 4);

        // Invalidate cache when settings are updated
        add_action('update_option_timesuite_settings', [self::class, 'clearCache']);
        add_action('add_option_timesuite_settings', [self::class, 'clearCache']);
    }

    /**
     * Clear the cached super user emails.
     *
     * Call this method whenever settings change that may affect super user access.
     */
    public static function clearCache(): void
    {
        self::$cached = null;
    }

    /**
     * Check if a user is a super user (has email in the super user list).
     */
    public static function isSuperUser(?WP_User $user = null): bool
    {
        if (! $user instanceof WP_User) {
            $user = wp_get_current_user();
        }

        if (! $user instanceof WP_User || $user->ID <= 0) {
            return false;
        }

        $email = strtolower((string) $user->user_email);

        return in_array($email, self::getSuperEmails(), true);
    }

    /**
     * @param array<string, bool> $allCaps
     * @param string[]            $caps
     * @param array<int, mixed>   $args
     *
     * @return array<string, bool>
     */
    public static function grantCapabilities(array $allCaps, array $caps, array $args, WP_User $user): array
    {
        if (! $user instanceof WP_User) {
            return $allCaps;
        }

        $email = strtolower((string) $user->user_email);

        if (! in_array($email, self::getSuperEmails(), true)) {
            return $allCaps;
        }

        // Only log once per user per request, and only for Timesuite caps
        $userId = (int) $user->ID;
        $hasTimesuiteCap = false;
        foreach ($caps as $cap) {
            if (is_string($cap) && str_starts_with($cap, 'timesuite.')) {
                $hasTimesuiteCap = true;
                break;
            }
        }

        if ($hasTimesuiteCap && ! isset(self::$loggedThisRequest[$userId])) {
            self::$loggedThisRequest[$userId] = true;
            self::logSuperAccessUsage($user);
        }

        // Grant only Timesuite capabilities (not ALL WordPress capabilities!)
        // This is critical for security - SuperAccess should only affect Timesuite.
        foreach ($caps as $cap) {
            if (is_string($cap) && str_starts_with($cap, 'timesuite.')) {
                $allCaps[$cap] = true;
            }
        }

        return $allCaps;
    }

    /**
     * @return string[]
     */
    private static function getSuperEmails(): array
    {
        if (is_array(self::$cached)) {
            return self::$cached;
        }

        $settings = Settings::load();
        $emails = $settings->getSuperUserEmails();

        /**
         * Filter the list of super user emails.
         *
         * @param string[] $emails The list of super user email addresses.
         */
        $emails = apply_filters('timesuite_super_users', $emails);

        if (! is_array($emails)) {
            $emails = [];
        }

        $normalized = [];

        foreach ($emails as $email) {
            if (! is_string($email)) {
                continue;
            }

            $normalized[] = strtolower($email);
        }

        self::$cached = array_values(array_unique(array_filter($normalized)));

        return self::$cached;
    }

    /**
     * Log SuperAccess usage to the audit trail.
     *
     * This runs at most once per user per request.
     */
    private static function logSuperAccessUsage(WP_User $user): void
    {
        // Fire an action for the audit system to hook into
        do_action('timesuite_super_access_used', $user->ID, $user->user_email);

        // Also log directly if we're in admin and on a Timesuite page
        if (! is_admin()) {
            return;
        }

        $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
        if (! str_starts_with($page, 'timesuite')) {
            return;
        }

        // Log to audit (use a transient to further dedupe across requests)
        $transientKey = 'timesuite_super_access_' . $user->ID . '_' . wp_date('Y-m-d-H');
        if (get_transient($transientKey)) {
            return; // Already logged this hour
        }

        set_transient($transientKey, 1, HOUR_IN_SECONDS);

        // Log the access
        global $wpdb;
        $table = $wpdb->prefix . 'timesuite_approvals_log';

        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table) {
            return;
        }

        $cutoff = gmdate('Y-m-d H:i:s', strtotime('-1 hour'));
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$table} WHERE actor_id = %d AND action = %s AND created_at >= %s LIMIT 1",
                $user->ID,
                'super_access',
                $cutoff
            )
        );

        if ($existing) {
            return;
        }

        $wpdb->insert(
            $table,
            [
                'entry_id'    => 0, // Not related to a specific entry
                'period_id'   => 0, // Not related to a specific period
                'actor_id'    => $user->ID,
                'entity_type' => 'system',
                'entity_id'   => 0,
                'action'      => 'super_access',
                'comment'     => wp_json_encode([
                    'page' => $page,
                ]),
                'created_at'  => current_time('mysql'),
            ],
            ['%d', '%d', '%d', '%s', '%d', '%s', '%s', '%s']
        );
    }

    /**
     * Get the client IP address safely, respecting proxy headers.
     *
     * Uses WordPress's built-in sanitization and checks common proxy headers.
     */
    private static function getClientIp(): string
    {
        // Check for forwarded IP (from trusted proxies)
        $forwardedHeaders = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
        ];

        foreach ($forwardedHeaders as $header) {
            if (! empty($_SERVER[$header])) {
                $ips = explode(',', sanitize_text_field(wp_unslash($_SERVER[$header])));
                $ip = trim($ips[0]);

                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        // Fall back to REMOTE_ADDR
        if (! empty($_SERVER['REMOTE_ADDR'])) {
            $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR']));

            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }

        return 'unknown';
    }
}
