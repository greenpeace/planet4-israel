<?php

declare(strict_types=1);

namespace Timesuite\Core\Support;

use DateTimeImmutable;
use DateTimeZone;

/**
 * Helper class for timezone-aware date/time operations.
 *
 * All date calculations should use this helper to ensure consistent
 * timezone handling across the plugin.
 */
class DateTimeHelper
{
    private DateTimeZone $timezone;

    public function __construct(?string $timezone = null)
    {
        $this->timezone = $this->resolveTimezone($timezone);
    }

    /**
     * Create an instance using the configured org timezone from settings.
     */
    public static function fromSettings(): self
    {
        $settings = get_option('timesuite_settings', []);
        $timezone = $settings['timezone'] ?? null;

        return new self($timezone);
    }

    /**
     * Get the current date in Y-m-d format.
     */
    public function today(): string
    {
        return $this->now()->format('Y-m-d');
    }

    /**
     * Get the current datetime.
     */
    public function now(): DateTimeImmutable
    {
        return new DateTimeImmutable('now', $this->timezone);
    }

    /**
     * Get current year.
     */
    public function currentYear(): int
    {
        return (int) $this->now()->format('Y');
    }

    /**
     * Get current month (1-12).
     */
    public function currentMonth(): int
    {
        return (int) $this->now()->format('n');
    }

    /**
     * Get current day of month (1-31).
     */
    public function currentDay(): int
    {
        return (int) $this->now()->format('j');
    }

    /**
     * Parse a date string into a DateTimeImmutable in the org timezone.
     */
    public function parse(string $date, string $format = 'Y-m-d'): ?DateTimeImmutable
    {
        $dt = DateTimeImmutable::createFromFormat($format, $date, $this->timezone);

        if (! $dt) {
            return null;
        }

        // Ensure the parsed date matches the input (validation)
        if ($dt->format($format) !== $date) {
            return null;
        }

        return $dt;
    }

    /**
     * Create a date from year and month (first day of month).
     */
    public function createFromYearMonth(int $year, int $month): DateTimeImmutable
    {
        return new DateTimeImmutable(
            sprintf('%04d-%02d-01', $year, $month),
            $this->timezone
        );
    }

    /**
     * Get the first day of a month.
     */
    public function firstOfMonth(int $year, int $month): string
    {
        return sprintf('%04d-%02d-01', $year, $month);
    }

    /**
     * Get the last day of a month.
     */
    public function lastOfMonth(int $year, int $month): string
    {
        $dt = $this->createFromYearMonth($year, $month);

        return $dt->format('Y-m-t');
    }

    /**
     * Get the previous month as [year, month].
     *
     * @return array{0: int, 1: int}
     */
    public function previousMonth(int $year, int $month): array
    {
        if ($month === 1) {
            return [$year - 1, 12];
        }

        return [$year, $month - 1];
    }

    /**
     * Check if a date is in the current month.
     */
    public function isCurrentMonth(string $date): bool
    {
        $dt = $this->parse($date);

        if (! $dt) {
            return false;
        }

        $now = $this->now();

        return $dt->format('Y-m') === $now->format('Y-m');
    }

    /**
     * Check if a date is in the previous month.
     */
    public function isPreviousMonth(string $date): bool
    {
        $dt = $this->parse($date);

        if (! $dt) {
            return false;
        }

        [$prevYear, $prevMonth] = $this->previousMonth(
            $this->currentYear(),
            $this->currentMonth()
        );

        return (int) $dt->format('Y') === $prevYear && (int) $dt->format('n') === $prevMonth;
    }

    /**
     * Check if a date is before the previous month (i.e., locked).
     */
    public function isBeforePreviousMonth(string $date): bool
    {
        $dt = $this->parse($date);

        if (! $dt) {
            return false;
        }

        [$prevYear, $prevMonth] = $this->previousMonth(
            $this->currentYear(),
            $this->currentMonth()
        );

        $prevKey = sprintf('%04d-%02d', $prevYear, $prevMonth);
        $dateKey = $dt->format('Y-m');

        return $dateKey < $prevKey;
    }

    /**
     * Format a datetime for storage (UTC).
     */
    public function formatForStorage(DateTimeImmutable $dt): string
    {
        return $dt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
    }

    /**
     * Get current UTC timestamp for storage.
     */
    public function nowUtc(): string
    {
        return gmdate('Y-m-d H:i:s');
    }

    /**
     * Get the configured timezone.
     */
    public function getTimezone(): DateTimeZone
    {
        return $this->timezone;
    }

    /**
     * Get timezone identifier string.
     */
    public function getTimezoneId(): string
    {
        return $this->timezone->getName();
    }

    /**
     * Resolve timezone from string, falling back to WordPress or UTC.
     */
    private function resolveTimezone(?string $timezone): DateTimeZone
    {
        // Try explicit timezone first
        if ($timezone && $this->isValidTimezone($timezone)) {
            return new DateTimeZone($timezone);
        }

        // Fall back to WordPress timezone
        $wpTimezone = wp_timezone_string();

        if ($wpTimezone && $this->isValidTimezone($wpTimezone)) {
            return new DateTimeZone($wpTimezone);
        }

        // Ultimate fallback to UTC
        return new DateTimeZone('UTC');
    }

    /**
     * Check if a timezone string is valid.
     */
    private function isValidTimezone(string $timezone): bool
    {
        try {
            new DateTimeZone($timezone);

            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
}

