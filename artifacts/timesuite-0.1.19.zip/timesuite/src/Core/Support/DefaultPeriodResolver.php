<?php

declare(strict_types=1);

namespace Timesuite\Core\Support;

use Timesuite\Core\Settings;

/**
 * Resolves which month/year each screen (My Timesheet, Manager View, HR
 * Month Overview) should default to when it first loads.
 *
 * This is the single canonical computation — every screen reads the same
 * server-computed value (via Frontend/enqueue.php's localize_script()),
 * rather than each frontend independently reimplementing the cutoff-day
 * math against its own clock. That duplication is exactly the class of bug
 * this plugin has repeatedly hit (see docs/timesheet-status-investigation.md):
 * multiple places computing "what period is this" and drifting apart.
 *
 * Deliberately uses current_time() (WordPress's site-timezone "now"), the
 * same time source MonthlyTimesheetService::getEditability() already uses
 * for the cutoff-day check, so the "what month should I be looking at"
 * decision and the "can I edit this month" decision flip on the exact same
 * real-world moment.
 */
class DefaultPeriodResolver
{
    public function __construct(private Settings $settings)
    {
    }

    /**
     * @return array{year: int, month: int, is_previous: bool}
     */
    public function resolve(): array
    {
        return $this->resolveFor(
            (int) current_time('Y'),
            (int) current_time('n'),
            (int) current_time('j')
        );
    }

    /**
     * Pure date math, split out from resolve() so it can be tested for every
     * calendar edge case (year rollover, cutoff boundary) deterministically,
     * without depending on the real wall clock.
     *
     * @return array{year: int, month: int, is_previous: bool}
     */
    public function resolveFor(int $currentYear, int $currentMonth, int $currentDay): array
    {
        if (! $this->settings->isDefaultPreviousMonthBeforeCutoff()) {
            return ['year' => $currentYear, 'month' => $currentMonth, 'is_previous' => false];
        }

        $cutoff = max(1, min(31, $this->settings->getPeriodCutoffDay()));

        if ($currentDay > $cutoff) {
            return ['year' => $currentYear, 'month' => $currentMonth, 'is_previous' => false];
        }

        [$prevYear, $prevMonth] = 1 === $currentMonth
            ? [$currentYear - 1, 12]
            : [$currentYear, $currentMonth - 1];

        return ['year' => $prevYear, 'month' => $prevMonth, 'is_previous' => true];
    }
}
