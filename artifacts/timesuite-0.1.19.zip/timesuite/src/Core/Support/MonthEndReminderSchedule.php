<?php

declare(strict_types=1);

namespace Timesuite\Core\Support;

use DateTimeImmutable;

/**
 * Decides which timesheet reminder, if any, is due on a given calendar day.
 *
 * Employees are nudged twice as the month closes:
 *
 *   - second-to-last day of the month -> STAGE_FIRST  ("the month ends tomorrow")
 *   - last day of the month           -> STAGE_FINAL  ("today is the last day")
 *
 * Deliberately independent of `period_cutoff_day`. The cutoff governs how long
 * a finished month stays editable for payroll; this reminder is about logging
 * hours while they are still fresh, which is a month-end event. Tying the two
 * together is what produced the long-standing bug this replaced: the old code
 * derived the deadline from the period (cutoff day of the *following* month)
 * while only ever evaluating it from inside the current month, so the gap could
 * never fall to a few days unless the cutoff was 1-3. With any cutoff of 4 or
 * more, reminders never fired at all.
 *
 * Expressed purely in day numbers, so there is no cross-month arithmetic, no
 * year rollover, and no elapsed-seconds math that a daylight-saving shift can
 * knock off by one.
 *
 * The date is passed in rather than read from a clock so every calendar edge
 * case is testable, matching {@see DefaultPeriodResolver::resolveFor()}.
 */
final class MonthEndReminderSchedule
{
    /** Second-to-last day of the month. */
    public const STAGE_FIRST = 'first';

    /** Last day of the month. */
    public const STAGE_FINAL = 'final';

    /**
     * @return array{year: int, month: int, stage: string, days_remaining: int}|null
     *         Null on any day that is not a reminder day.
     */
    public static function resolveFor(int $year, int $month, int $day): ?array
    {
        if ($month < 1 || $month > 12 || $day < 1) {
            return null;
        }

        $daysInMonth = self::daysInMonth($year, $month);

        if ($day > $daysInMonth) {
            return null;
        }

        $daysRemaining = $daysInMonth - $day;

        $stage = match ($daysRemaining) {
            1 => self::STAGE_FIRST,
            0 => self::STAGE_FINAL,
            default => null,
        };

        if (null === $stage) {
            return null;
        }

        return [
            'year'           => $year,
            'month'          => $month,
            'stage'          => $stage,
            'days_remaining' => $daysRemaining,
        ];
    }

    /**
     * Length of the given month, so February and leap years look after
     * themselves rather than needing a special case at the call site.
     */
    private static function daysInMonth(int $year, int $month): int
    {
        return (int) (new DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month)))->format('t');
    }
}
