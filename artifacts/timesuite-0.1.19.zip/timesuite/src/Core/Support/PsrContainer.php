<?php

declare(strict_types=1);

/**
 * Lightweight PSR Container interfaces fallback.
 *
 * Provides the minimal interfaces required by the plugin when the
 * psr/container package is not installed. If the real interfaces are
 * available, these definitions are skipped.
 */

namespace Psr\Container;

if (! interface_exists(ContainerInterface::class)) {
    /**
     * Describes the interface of a container that exposes methods to read its entries.
     */
    interface ContainerInterface
    {
        /**
         * Finds an entry of the container by its identifier and returns it.
         *
         * @throws NotFoundExceptionInterface  No entry was found for this identifier.
         * @throws ContainerExceptionInterface Error while retrieving the entry.
         */
        public function get($id);

        /**
         * Returns true if the container can return an entry for the given identifier.
         * Returns false otherwise.
         */
        public function has($id);
    }
}

if (! interface_exists(ContainerExceptionInterface::class)) {
    /**
     * Base interface representing a generic exception in a container.
     */
    interface ContainerExceptionInterface extends \Throwable
    {
    }
}

if (! interface_exists(NotFoundExceptionInterface::class)) {
    /**
     * No entry was found in the container.
     */
    interface NotFoundExceptionInterface extends ContainerExceptionInterface
    {
    }
}

