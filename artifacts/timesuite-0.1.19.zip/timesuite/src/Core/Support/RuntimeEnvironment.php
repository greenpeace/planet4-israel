<?php

declare(strict_types=1);

namespace Timesuite\Core\Support;

/**
 * Detects whether this install is the live production site.
 *
 * Used to keep automated emails (deadline reminders) from firing out of dev
 * and staging, where the user table is a copy of production and so the
 * addresses belong to real employees.
 *
 * Detection is deliberately veto-based: each check can only rule production
 * OUT, and we conclude "production" when nothing objects. A false negative
 * silently stops real reminders, which is harder to notice than a stray dev
 * email, so the tie-break favours sending. Call sites needing the opposite
 * bias can invert it via the 'timesuite_automated_reminder_emails_allowed'
 * filter.
 */
final class RuntimeEnvironment
{
    /**
     * Host fragments that mean "definitely not the live site".
     */
    private const NON_PRODUCTION_HOST_MARKERS = [
        'localhost',
        '127.0.0.1',
        'www-dev.',
        'www-stage.',
        '-dev.',
        '-stage.',
        'staging',
    ];

    /**
     * Declared environment names that count as production.
     */
    private const PRODUCTION_NAMES = ['production', 'prod', 'live'];

    public static function allowsAutomatedReminderEmails(): bool
    {
        return (bool) apply_filters(
            'timesuite_automated_reminder_emails_allowed',
            self::looksLikeProduction()
        );
    }

    public static function looksLikeProduction(): bool
    {
        // 1. The deploy environment, when the platform declares one. On
        // Planet 4 this is the decisive signal.
        $appEnvironment = self::appEnvironment();

        if ('' !== $appEnvironment && ! self::isProductionName($appEnvironment)) {
            return false;
        }

        // 2. WordPress' own environment type. Note this is inert on Planet 4,
        // whose wp-config template never defines WP_ENVIRONMENT_TYPE, so
        // wp_get_environment_type() returns its 'production' default even on
        // dev. Kept because it is correct on installs that do set it.
        if (function_exists('wp_get_environment_type')
            && 'production' !== strtolower((string) wp_get_environment_type())) {
            return false;
        }

        // 3. The site host, as a backstop for environments that declare
        // nothing at all.
        if (self::hostLooksNonProduction()) {
            return false;
        }

        return true;
    }

    /**
     * Resolve the declared deploy environment, or '' when nothing declares one.
     */
    public static function appEnvironment(): string
    {
        // Constants first, and this ordering is load-bearing on Planet 4: its
        // PHP-FPM pools run with clear_env = yes, so getenv() cannot see any
        // container variable during a web request. The wp-config template
        // bakes APP_ENV into the WP_APP_ENV constant, which survives that.
        foreach (['WP_APP_ENV', 'WP_ENVIRONMENT_TYPE'] as $constantName) {
            if (! defined($constantName)) {
                continue;
            }

            $value = strtolower(trim((string) constant($constantName)));

            if ('' !== $value) {
                return $value;
            }
        }

        // Environment variables still resolve in CLI contexts (WP-CLI cron),
        // where clear_env does not apply. APP_ENV is the Planet 4 runtime name;
        // the others cover generic installs and the CircleCI build-time name.
        foreach (['APP_ENV', 'APP_ENVIRONMENT', 'WP_ENVIRONMENT_TYPE'] as $variableName) {
            $value = getenv($variableName);

            if (! is_string($value)) {
                continue;
            }

            $value = strtolower(trim($value));

            if ('' !== $value) {
                return $value;
            }
        }

        return '';
    }

    private static function isProductionName(string $environment): bool
    {
        return in_array($environment, self::PRODUCTION_NAMES, true);
    }

    private static function hostLooksNonProduction(): bool
    {
        $home = function_exists('home_url') ? (string) home_url() : '';
        $host = strtolower((string) (parse_url($home, PHP_URL_HOST) ?: ''));

        if ('' === $host) {
            return false;
        }

        foreach (self::NON_PRODUCTION_HOST_MARKERS as $marker) {
            if (str_contains($host, $marker)) {
                return true;
            }
        }

        return false;
    }
}
