<?php

declare(strict_types=1);

namespace Timesuite\Core;

use Timesuite\Core\Access\RoleAssignmentService;
use Timesuite\Core\DB\MigrationsRunner;

/**
 * Version tracking and upgrade service.
 *
 * This ensures deterministic upgrades by:
 * 1. Tracking the installed plugin version
 * 2. Running migrations in sequence
 * 3. Handling version-specific upgrade logic
 *
 * "always safe to deploy" backbone.
 */
class VersionService
{
    public const CURRENT_VERSION = '1.0.0';
    public const VERSION_OPTION = 'timesuite_version';

    /**
     * @var array<string, callable> Version-specific upgrade callbacks.
     */
    private array $upgrades = [];

    public function __construct(
        private MigrationsRunner $migrationsRunner,
        private ?RoleAssignmentService $roleService = null
    ) {
        $this->registerUpgrades();
    }

    /**
     * Run on plugin init to ensure plugin is up to date.
     */
    public function ensureCurrentVersion(): void
    {
        $installedVersion = $this->getInstalledVersion();

        // Fresh install
        if ($installedVersion === null) {
            $this->runFreshInstall();
            $this->setVersion(self::CURRENT_VERSION);

            return;
        }

        // Already current
        if (version_compare($installedVersion, self::CURRENT_VERSION, '>=')) {
            return;
        }

        // Run upgrades
        $this->runUpgrades($installedVersion, self::CURRENT_VERSION);
        $this->setVersion(self::CURRENT_VERSION);
    }

    /**
     * Get the currently installed version.
     */
    public function getInstalledVersion(): ?string
    {
        $version = get_option(self::VERSION_OPTION, null);

        return is_string($version) && '' !== $version ? $version : null;
    }

    /**
     * Set the installed version.
     */
    public function setVersion(string $version): void
    {
        update_option(self::VERSION_OPTION, $version, true);
    }

    /**
     * Check if this is a fresh install.
     */
    public function isFreshInstall(): bool
    {
        return $this->getInstalledVersion() === null;
    }

    /**
     * Run fresh install tasks.
     */
    private function runFreshInstall(): void
    {
        // Run all migrations
        $this->migrationsRunner->runAll();

        // Set default settings if not present
        if (! get_option('timesuite_settings')) {
            update_option('timesuite_settings', []);
        }

        do_action('timesuite_installed', self::CURRENT_VERSION);
    }

    /**
     * Run upgrades from one version to another.
     */
    private function runUpgrades(string $fromVersion, string $toVersion): void
    {
        // Always run migrations first
        $this->migrationsRunner->runAll();

        // Run version-specific upgrades in order
        foreach ($this->upgrades as $version => $callback) {
            // Skip if already past this version
            if (version_compare($fromVersion, $version, '>=')) {
                continue;
            }

            // Skip if this version is beyond target
            if (version_compare($version, $toVersion, '>')) {
                continue;
            }

            // Run the upgrade
            try {
                $callback();

                do_action('timesuite_upgraded_to', $version, $fromVersion);
            } catch (\Throwable $e) {
                // Log but don't fail - allow manual recovery
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                    error_log(
                        sprintf(
                            'Timesuite upgrade to %s failed: %s',
                            $version,
                            $e->getMessage()
                        )
                    );
                }
            }
        }

        do_action('timesuite_upgrade_complete', $fromVersion, $toVersion);
    }

    /**
     * Register version-specific upgrade callbacks.
     */
    private function registerUpgrades(): void
    {
        // Example: Migration to meta-based roles in v0.9.0
        $this->upgrades['0.9.0'] = function (): void {
            $this->migrateToMetaRoles();
        };

        // Add future upgrades here:
        // $this->upgrades['1.1.0'] = function (): void { ... };
    }

    /**
     * Migrate from legacy WP roles to meta-based roles.
     */
    private function migrateToMetaRoles(): void
    {
        if ($this->roleService === null) {
            return;
        }

        $results = $this->roleService->migrateAllLegacyRoles();

        if (defined('WP_DEBUG') && WP_DEBUG && ($results['migrated'] > 0)) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            error_log(
                sprintf(
                    'Timesuite: Migrated %d users from legacy WP roles, skipped %d',
                    $results['migrated'],
                    $results['skipped']
                )
            );
        }
    }

    /**
     * Check if a specific feature version is installed.
     *
     * Useful for conditional feature flags during rollout.
     */
    public function hasVersion(string $version): bool
    {
        $installed = $this->getInstalledVersion();

        if ($installed === null) {
            return false;
        }

        return version_compare($installed, $version, '>=');
    }

    /**
     * Force a full re-migration (for recovery).
     *
     * This is dangerous and should only be called manually.
     */
    public function forceRemigrate(): void
    {
        // Reset version to trigger all upgrades
        delete_option(self::VERSION_OPTION);

        // Clear all caches
        \Timesuite\Core\Access\AuthorizationService::clearAllCaches();
        \Timesuite\Core\Access\BootstrapService::clearCache();

        // Re-run
        $this->ensureCurrentVersion();
    }
}
