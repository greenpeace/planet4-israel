<?php

declare(strict_types=1);

namespace Timesuite\Domain\Org\Models;

class UsersOrg
{
    public function __construct(
        private int $id,
        private int $userId,
        private int $orgUnitId,
        private string $roleSlug,
        private string $assignedAt,
        private ?string $removedAt,
        private string $createdAt,
        private string $updatedAt
    ) {
    }

    public static function fromRow(array $row): self
    {
        return new self(
            (int) $row['id'],
            (int) $row['user_id'],
            (int) $row['org_unit_id'],
            (string) $row['role_slug'],
            (string) $row['assigned_at'],
            $row['removed_at'] ?? null,
            (string) $row['created_at'],
            (string) $row['updated_at']
        );
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getUserId(): int
    {
        return $this->userId;
    }

    public function getOrgUnitId(): int
    {
        return $this->orgUnitId;
    }

    public function getRoleSlug(): string
    {
        return $this->roleSlug;
    }

    public function getAssignedAt(): string
    {
        return $this->assignedAt;
    }

    public function getRemovedAt(): ?string
    {
        return $this->removedAt;
    }

    public function getCreatedAt(): string
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): string
    {
        return $this->updatedAt;
    }
}
