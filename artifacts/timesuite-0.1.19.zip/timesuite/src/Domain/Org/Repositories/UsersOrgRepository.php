<?php

declare(strict_types=1);

namespace Timesuite\Domain\Org\Repositories;

use Timesuite\Domain\Org\Models\UsersOrg;
use wpdb;
use const ARRAY_A;

class UsersOrgRepository
{
    private string $table;

    public function __construct(private wpdb $wpdb)
    {
        $this->table = $this->wpdb->prefix . 'timesuite_users_org';
    }

    /**
     * @return UsersOrg[]
     */
    public function findByUserId(int $userId): array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE user_id = %d ORDER BY created_at DESC",
            $userId
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return array_map([UsersOrg::class, 'fromRow'], $rows);
    }

    /**
     * @return UsersOrg[]
     */
    public function findDirectReportsOfManager(int $managerUserId, bool $onlyActive = true): array
    {
        // For active records, directly filter by removed_at IS NULL
        // This is more reliable than MAX(id) which assumes IDs are sequential
        $activeCondition = $onlyActive ? 'AND child.removed_at IS NULL' : '';

        $sql = $this->wpdb->prepare(
            "
                SELECT child.*
                FROM {$this->table} child
                WHERE child.org_unit_id = %d
                    AND child.user_id <> %d
                    {$activeCondition}
                ORDER BY child.created_at DESC
            ",
            [$managerUserId, $managerUserId]
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return array_map([UsersOrg::class, 'fromRow'], $rows);
    }

    /**
     * @param array<string, mixed> $data
     */
    public function upsert(array $data): int
    {
        $now = gmdate('Y-m-d H:i:s');
        $data['updated_at'] = $data['updated_at'] ?? $now;

        if (empty($data['id'])) {
            $data['created_at']  = $data['created_at'] ?? $now;
            $data['assigned_at'] = $data['assigned_at'] ?? $now;

            $columns = [
                'user_id',
                'org_unit_id',
                'role_slug',
                'assigned_at',
                'removed_at',
                'created_at',
                'updated_at',
            ];

            $placeholders = [];
            $values       = [];

            foreach ($columns as $column) {
                $value = $data[$column] ?? null;

                if (null === $value) {
                    $placeholders[] = 'NULL';
                    continue;
                }

                $placeholders[] = is_int($value) ? '%d' : '%s';
                $values[]       = $value;
            }

            $sql = $this->wpdb->prepare(
                "INSERT INTO {$this->table} (" . implode(',', $columns) . ') VALUES (' . implode(',', $placeholders) . ')',
                $values
            );

            $this->wpdb->query($sql);

            return (int) $this->wpdb->insert_id;
        }

        $columns = [
            'user_id',
            'org_unit_id',
            'role_slug',
            'assigned_at',
            'removed_at',
            'updated_at',
        ];

        $setClauses = [];
        $values     = [];

        foreach ($columns as $column) {
            $value = $data[$column] ?? null;

            if (null === $value) {
                $setClauses[] = "{$column} = NULL";
                continue;
            }

            $placeholder = is_int($value) ? '%d' : '%s';
            $setClauses[] = "{$column} = {$placeholder}";
            $values[]     = $value;
        }

        $values[] = (int) $data['id'];

        $sql = $this->wpdb->prepare(
            "UPDATE {$this->table} SET " . implode(',', $setClauses) . ' WHERE id = %d',
            $values
        );

        $this->wpdb->query($sql);

        return (int) $data['id'];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listMappings(?string $department = null): array
    {
        $usersTable    = $this->wpdb->users;
        $metaTable     = $this->wpdb->usermeta;

        // Use created_at to find the latest record per user instead of MAX(id)
        // This is more reliable as created_at represents actual record creation time
        $latestSubquery = "(
            SELECT user_id, MAX(created_at) AS max_created_at 
            FROM {$this->table} 
            GROUP BY user_id
        )";

        $conditions = [];
        $values     = [];

        if ($department) {
            $conditions[] = 'dept.meta_value = %s';
            $values[]     = $department;
        }

        $where = '';

        if (! empty($conditions)) {
            $where = 'AND ' . implode(' AND ', $conditions);
        }

        $sql = "
            SELECT uo.*, u.user_email AS user_email, manager.user_email AS manager_email,
                dept.meta_value AS department,
                hire.meta_value AS employment_start_date,
                employment_end.meta_value AS employment_end_date
            FROM {$this->table} uo
            INNER JOIN {$latestSubquery} latest 
                ON latest.user_id = uo.user_id AND latest.max_created_at = uo.created_at
            INNER JOIN {$usersTable} u ON u.ID = uo.user_id
            LEFT JOIN {$usersTable} manager ON manager.ID = uo.org_unit_id
            LEFT JOIN {$metaTable} dept
                ON dept.user_id = uo.user_id AND dept.meta_key = 'timesuite_department'
            LEFT JOIN {$metaTable} hire
                ON hire.user_id = uo.user_id AND hire.meta_key = 'timesuite_hire_date'
            LEFT JOIN {$metaTable} employment_end
                ON employment_end.user_id = uo.user_id AND employment_end.meta_key = 'timesuite_employment_end_date'
            WHERE 1=1
            {$where}
            ORDER BY u.user_email ASC
        ";

        $prepared = ! empty($values) ? $this->wpdb->prepare($sql, $values) : $sql;

        $rows = $this->wpdb->get_results($prepared, ARRAY_A);

        return array_map(
            static function (array $row): array {
                return [
                    'assignment_id' => (int) $row['id'],
                    'user_id'       => (int) $row['user_id'],
                    'user_email'    => (string) $row['user_email'],
                    'manager_id'    => $row['org_unit_id'] ? (int) $row['org_unit_id'] : null,
                    'manager_email' => $row['manager_email'] ?? null,
                    'department'    => (string) ($row['department'] ?? ''),
                    'employment_start_date' => (string) ($row['employment_start_date'] ?? ''),
                    'employment_end_date' => (string) ($row['employment_end_date'] ?? ''),
                    'role_slug'     => (string) $row['role_slug'],
                    'is_manager'    => 'manager' === $row['role_slug'],
                    'active'        => null === $row['removed_at'],
                ];
            },
            $rows
        );
    }

    public function upsertMapping(
        int $userId,
        ?int $managerId,
        string $roleSlug,
        bool $active,
        ?int $assignmentId = null
    ): void {
        $now = gmdate('Y-m-d H:i:s');

        $data = [
            'id'          => $assignmentId,
            'user_id'     => $userId,
            'org_unit_id' => $managerId ?? 0,
            'role_slug'   => $roleSlug,
            'assigned_at' => $now,
            'removed_at'  => $active ? null : $now,
            'updated_at'  => $now,
        ];

        if (! $assignmentId) {
            $data['created_at'] = $now;
        }

        $this->upsert($data);
    }

    /**
     * Get a single mapping by user ID (most recent assignment).
     *
     * @return array<string, mixed>|null
     */
    public function getMappingByUserId(int $userId): ?array
    {
        $usersTable    = $this->wpdb->users;
        $metaTable     = $this->wpdb->usermeta;

        $sql = $this->wpdb->prepare(
            "
                SELECT uo.*, u.user_email AS user_email, manager.user_email AS manager_email,
                    dept.meta_value AS department,
                    hire.meta_value AS employment_start_date,
                    employment_end.meta_value AS employment_end_date
                FROM {$this->table} uo
                INNER JOIN {$usersTable} u ON u.ID = uo.user_id
                LEFT JOIN {$usersTable} manager ON manager.ID = uo.org_unit_id
                LEFT JOIN {$metaTable} dept
                    ON dept.user_id = uo.user_id AND dept.meta_key = 'timesuite_department'
                LEFT JOIN {$metaTable} hire
                    ON hire.user_id = uo.user_id AND hire.meta_key = 'timesuite_hire_date'
                LEFT JOIN {$metaTable} employment_end
                    ON employment_end.user_id = uo.user_id AND employment_end.meta_key = 'timesuite_employment_end_date'
                WHERE uo.user_id = %d
                ORDER BY uo.id DESC
                LIMIT 1
            ",
            $userId
        );

        $row = $this->wpdb->get_row($sql, ARRAY_A);

        if (! $row) {
            return null;
        }

        return [
            'assignment_id' => (int) $row['id'],
            'user_id'       => (int) $row['user_id'],
            'user_email'    => (string) $row['user_email'],
            'manager_id'    => $row['org_unit_id'] ? (int) $row['org_unit_id'] : null,
            'manager_email' => $row['manager_email'] ?? null,
            'department'    => (string) ($row['department'] ?? ''),
            'employment_start_date' => (string) ($row['employment_start_date'] ?? ''),
            'employment_end_date' => (string) ($row['employment_end_date'] ?? ''),
            'role_slug'     => (string) $row['role_slug'],
            'is_manager'    => 'manager' === $row['role_slug'],
            'active'        => null === $row['removed_at'],
        ];
    }

    public function deleteByUserId(int $userId): int
    {
        $sql = $this->wpdb->prepare(
            "DELETE FROM {$this->table} WHERE user_id = %d",
            $userId
        );

        $this->wpdb->query($sql);

        return (int) $this->wpdb->rows_affected;
    }

    public function detachManager(int $managerId): int
    {
        $now = gmdate('Y-m-d H:i:s');
        $sql = $this->wpdb->prepare(
            "UPDATE {$this->table} SET org_unit_id = 0, updated_at = %s WHERE org_unit_id = %d",
            [$now, $managerId]
        );

        $this->wpdb->query($sql);

        return (int) $this->wpdb->rows_affected;
    }
}
