<?php

declare(strict_types=1);

namespace Timesuite\Domain\Org\Services;

use wpdb;

class LegacyTimesheetCleanupService
{
    public function __construct(private wpdb $wpdb)
    {
    }

    /**
     * @return array{approvals:int, entries:int, periods:int}
     */
    public function removeUserData(int $userId): array
    {
        $entriesTable = $this->wpdb->prefix . 'timesuite_time_entries';
        $periodsTable = $this->wpdb->prefix . 'timesuite_periods';
        $logTable = $this->wpdb->prefix . 'timesuite_approvals_log';

        $hasEntriesTable = $this->tableExists($entriesTable);
        $hasPeriodsTable = $this->tableExists($periodsTable);
        $hasLogTable = $this->tableExists($logTable);

        return [
            'approvals' => $this->deleteApprovalReferences($userId, $logTable, $entriesTable, $periodsTable, $hasLogTable, $hasEntriesTable, $hasPeriodsTable),
            'entries' => $this->deleteRowsByUser($userId, $entriesTable, $hasEntriesTable),
            'periods' => $this->deleteRowsByUser($userId, $periodsTable, $hasPeriodsTable),
        ];
    }

    private function tableExists(string $table): bool
    {
        $sql = $this->wpdb->prepare('SHOW TABLES LIKE %s', $table);
        $result = $this->wpdb->get_var($sql);

        return is_string($result) && $result !== '';
    }

    private function deleteRowsByUser(int $userId, string $table, bool $tableExists): int
    {
        if (! $tableExists) {
            return 0;
        }

        $sql = $this->wpdb->prepare(
            "DELETE FROM {$table} WHERE user_id = %d",
            $userId
        );

        $this->wpdb->query($sql);

        return (int) $this->wpdb->rows_affected;
    }

    private function deleteApprovalReferences(
        int $userId,
        string $logTable,
        string $entriesTable,
        string $periodsTable,
        bool $hasLogTable,
        bool $hasEntriesTable,
        bool $hasPeriodsTable
    ): int {
        if (! $hasLogTable) {
            return 0;
        }

        $clauses = [
            'actor_id = %d',
            'entity_id = %d',
        ];
        $params = [$userId, $userId];

        if ($hasEntriesTable) {
            $clauses[] = "entry_id IN (SELECT id FROM {$entriesTable} WHERE user_id = %d)";
            $params[] = $userId;
        }

        if ($hasPeriodsTable) {
            $clauses[] = "period_id IN (SELECT id FROM {$periodsTable} WHERE user_id = %d)";
            $params[] = $userId;
        }

        $sql = $this->wpdb->prepare(
            "DELETE FROM {$logTable} WHERE " . implode(' OR ', $clauses),
            $params
        );

        $this->wpdb->query($sql);

        return (int) $this->wpdb->rows_affected;
    }
}
