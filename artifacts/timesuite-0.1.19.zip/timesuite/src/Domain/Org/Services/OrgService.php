<?php

declare(strict_types=1);

namespace Timesuite\Domain\Org\Services;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Core\Access\Role;
use Timesuite\Core\Settings;
use Timesuite\Domain\Org\Models\UsersOrg;
use Timesuite\Domain\Org\Repositories\UsersOrgRepository;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use WP_User;

class OrgService
{
    private const USER_META_WORK_WEEK = 'timesuite_work_week';
    private const USER_META_COMP_TIME_EXPIRY = 'timesuite_comp_time_expiry_months';
    private const USER_META_HIRE_DATE = 'timesuite_hire_date';
    private const USER_META_EMPLOYMENT_END_DATE = 'timesuite_employment_end_date';

    public function __construct(
        private UsersOrgRepository $usersOrgRepository,
        private Settings $settings,
        private ?ApprovalLogRepository $logRepository = null
    ) {
    }

    /**
     * @return UsersOrg[]
     */
    public function getAssignmentsForUser(int $userId): array
    {
        return $this->usersOrgRepository->findByUserId($userId);
    }

    /**
     * @return int[]
     */
    public function listDirectReportIds(int $managerUserId, bool $onlyActive = true): array
    {
        $reports = $this->usersOrgRepository->findDirectReportsOfManager($managerUserId, $onlyActive);

        $userIds = [];

        foreach ($reports as $report) {
            $userIds[] = $report->getUserId();
        }

        return array_values(array_unique($userIds));
    }

    public function managerCanAccessUser(int $managerUserId, int $userId): bool
    {
        if ($managerUserId === $userId) {
            $mapping = $this->getMappingForUser($userId);

            return is_array($mapping)
                && ! empty($mapping['active'])
                && (int) ($mapping['manager_id'] ?? 0) === $userId;
        }

        return in_array($userId, $this->listDirectReportIds($managerUserId), true);
    }

    public function getMappings(?string $department = null): array
    {
        return $this->usersOrgRepository->listMappings($department);
    }

    public function getMappingForUser(int $userId): ?array
    {
        return $this->usersOrgRepository->getMappingByUserId($userId);
    }

    /**
     * @return array{user_ids: int[], labels: string[], message: string}|null
     */
    public function getCircularManagerConflict(): ?array
    {
        $managerMap = [];

        foreach ($this->usersOrgRepository->listMappings() as $mapping) {
            if (empty($mapping['active'])) {
                continue;
            }

            $userId = (int) ($mapping['user_id'] ?? 0);

            if ($userId <= 0) {
                continue;
            }

            $managerId = isset($mapping['manager_id']) ? (int) $mapping['manager_id'] : null;
            $managerMap[$userId] = $managerId && $managerId > 0 ? $managerId : null;
        }

        foreach (array_keys($managerMap) as $userId) {
            $cycle = $this->findManagerCycle((int) $userId, $managerMap);

            if ($cycle === null) {
                continue;
            }

            $labels = array_map(fn (int $cycleUserId): string => $this->formatUserLabel($cycleUserId), $cycle);

            return [
                'user_ids' => $cycle,
                'labels' => $labels,
                'message' => sprintf(
                    __('Circular manager assignment exists: %s. Fix this in Org Directory before turning circular assignments off.', 'timesuite'),
                    implode(' -> ', [...$labels, $labels[0] ?? ''])
                ),
            ];
        }

        return null;
    }

    public function ensureActiveDirectoryMembership(int $userId): void
    {
        $existing = $this->usersOrgRepository->getMappingByUserId($userId);

        if (($existing['active'] ?? false) === true) {
            return;
        }

        $managerId = isset($existing['manager_id']) ? (int) $existing['manager_id'] : null;
        $assignmentId = isset($existing['assignment_id']) ? (int) $existing['assignment_id'] : null;
        $roleSlug = isset($existing['role_slug']) && in_array($existing['role_slug'], ['employee', 'manager'], true)
            ? (string) $existing['role_slug']
            : 'employee';

        $this->usersOrgRepository->upsertMapping(
            $userId,
            $managerId,
            $roleSlug,
            true,
            $assignmentId
        );
    }

    /**
     * @param array<int, array<string, mixed>> $entries
     *
     * @return array{added: array<int, array<string, mixed>>, updated: array<int, array<string, mixed>>, removed: array<int, array<string, mixed>>}
     */
    public function synchronize(
        array $entries,
        bool $dryRun,
        int $actorId,
        bool $removeMissing = false,
        bool $allowSelfManager = false
    ): array {
        $currentList = $this->usersOrgRepository->listMappings();
        $currentMap = [];

        foreach ($currentList as $mapping) {
            $currentMap[$mapping['user_id']] = $mapping;
        }

        $desiredMap = [];

        foreach ($entries as $entry) {
            $normalized = $this->normalizeEntry($entry);
            $desiredMap[$normalized['user_id']] = $normalized;
        }

        $this->validateEntries($desiredMap, $currentMap, $allowSelfManager);

        $added = [];
        $updated = [];
        $removed = [];

        foreach ($desiredMap as $userId => $entry) {
            $existing = $currentMap[$userId] ?? null;

            if (!$existing) {
                $added[] = $entry;
                continue;
            }

            // Always update user meta fields (work_week, comp_time_expiry_months) if provided
            // These are stored in user meta, not in the org mapping table
            $hasMetaUpdates = $entry['work_week'] !== null
                || $entry['comp_time_expiry_months'] !== null
                || ($entry['employment_start_date'] ?? null) !== ($existing['employment_start_date'] ?? null)
                || ($entry['employment_end_date'] ?? null) !== ($existing['employment_end_date'] ?? null);

            if ($this->mappingChanged($existing, $entry) || $hasMetaUpdates) {
                $entry['assignment_id'] = $existing['assignment_id'] ?? null;
                $updated[] = $entry;
            }
        }

        if ($removeMissing) {
            foreach ($currentMap as $userId => $mapping) {
                if (!isset($desiredMap[$userId]) && $mapping['active']) {
                    $removed[] = $mapping;
                }
            }
        }

        if (!$dryRun) {
            foreach ($added as $entry) {
                $this->persistEntry($entry, null);
            }

            foreach ($updated as $entry) {
                $this->persistEntry($entry, $entry['assignment_id'] ?? null);
            }

            foreach ($removed as $entry) {
                $entry['active'] = false;
                $this->persistEntry($entry, $entry['assignment_id'] ?? null);
            }

            $this->logRepository?->logImport(
                $actorId,
                count($added),
                count($updated),
                count($removed)
            );
        }

        return [
            'added' => array_values($added),
            'updated' => array_values($updated),
            'removed' => array_values($removed),
        ];
    }

    /**
     * @param array<string, mixed> $entry
     *
     * @return array<string, mixed>
     */
    private function normalizeEntry(array $entry): array
    {
        $managerId = isset($entry['manager_id']) ? (int) $entry['manager_id'] : null;

        if ($managerId !== null && $managerId <= 0) {
            $managerId = null;
        }

        return [
            'assignment_id' => $entry['assignment_id'] ?? null,
            'user_id' => (int) $entry['user_id'],
            'user_email' => (string) ($entry['user_email'] ?? ''),
            'manager_id' => $managerId,
            'manager_email' => $entry['manager_email'] ?? null,
            'department' => (string) ($entry['department'] ?? ''),
            'work_week' => $this->normalizeWorkWeek($entry['work_week'] ?? null),
            'comp_time_expiry_months' => $this->normalizeCompTimeExpiry($entry['comp_time_expiry_months'] ?? null),
            'employment_start_date' => $this->normalizeEmploymentStartDate($entry['employment_start_date'] ?? null),
            'employment_end_date' => $this->normalizeEmploymentStartDate($entry['employment_end_date'] ?? null),
            'is_manager' => (bool) ($entry['is_manager'] ?? false),
            'active' => array_key_exists('active', $entry) ? (bool) $entry['active'] : true,
        ];
    }

    /**
     * Check if the org mapping fields have changed.
     * Note: This only checks fields stored in the org mapping table.
     * User meta fields (work_week, comp_time_expiry_months) are handled separately.
     *
     * @param array<string, mixed> $current
     * @param array<string, mixed> $next
     */
    private function mappingChanged(array $current, array $next): bool
    {
        $fields = ['manager_id', 'is_manager', 'active', 'department'];

        foreach ($fields as $field) {
            $currentValue = $current[$field] ?? null;
            $nextValue = $next[$field] ?? null;

            if ($currentValue !== $nextValue) {
                return true;
            }
        }

        return false;
    }

    private function persistEntry(array $entry, ?int $assignmentId): void
    {
        $this->usersOrgRepository->upsertMapping(
            $entry['user_id'],
            $entry['manager_id'],
            $entry['is_manager'] ? 'manager' : 'employee',
            (bool) $entry['active'],
            $assignmentId
        );

        $this->updateUserMeta($entry['user_id'], 'timesuite_department', $entry['department']);
        $this->updateUserMeta($entry['user_id'], self::USER_META_WORK_WEEK, $entry['work_week']);
        $this->updateUserMeta($entry['user_id'], self::USER_META_COMP_TIME_EXPIRY, $entry['comp_time_expiry_months']);
        $this->updateUserMeta($entry['user_id'], self::USER_META_HIRE_DATE, $entry['employment_start_date'] ?? null);
        $this->updateUserMeta($entry['user_id'], self::USER_META_EMPLOYMENT_END_DATE, $entry['employment_end_date'] ?? null);
        $this->ensureTimesuiteRole($entry['user_id'], (bool) $entry['active']);
    }

    private function normalizeEmploymentStartDate(mixed $value): ?string
    {
        if (! is_string($value) && ! is_numeric($value)) {
            return null;
        }

        $date = trim((string) $value);

        if ($date === '') {
            return null;
        }

        $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d', $date, new \DateTimeZone('UTC'));

        if (! $parsed instanceof \DateTimeImmutable || $parsed->format('Y-m-d') !== $date) {
            return null;
        }

        return $date;
    }

    private function updateUserMeta(int $userId, string $key, mixed $value): void
    {
        if ($value === null) {
            if (function_exists('delete_user_meta')) {
                delete_user_meta($userId, $key);
            }

            return;
        }

        if (is_array($value)) {
            if (empty($value)) {
                if (function_exists('delete_user_meta')) {
                    delete_user_meta($userId, $key);
                }

                return;
            }

            if (function_exists('update_user_meta')) {
                update_user_meta($userId, $key, $value);
            }

            return;
        }

        $stringValue = trim((string) $value);

        if ('' === $stringValue) {
            if (function_exists('delete_user_meta')) {
                delete_user_meta($userId, $key);
            }

            return;
        }

        if (function_exists('update_user_meta')) {
            update_user_meta($userId, $key, $stringValue);
        }
    }

    private function ensureTimesuiteRole(int $userId, bool $active): void
    {
        if (! $active || ! function_exists('get_user_by') || ! function_exists('get_user_meta') || ! function_exists('update_user_meta') || ! class_exists(WP_User::class)) {
            return;
        }

        $user = get_user_by('id', (string) $userId);

        if (! $user instanceof WP_User) {
            return;
        }

        $existingRole = get_user_meta($userId, AuthorizationService::META_KEY, true);

        if (is_string($existingRole) && '' !== trim($existingRole)) {
            return;
        }

        if (in_array('administrator', $user->roles ?? [], true)) {
            return;
        }

        update_user_meta($userId, AuthorizationService::META_KEY, Role::EMPLOYEE);
    }

    /**
     * @param array<int, array<string, mixed>> $desiredMap
     * @param array<int, array<string, mixed>> $currentMap
     */
    private function validateEntries(array $desiredMap, array $currentMap, bool $allowSelfManager): void
    {
        $managerMap = $this->buildManagerMap($currentMap, $desiredMap);
        $allowCircularManagers = $this->settings->allowCircularManagerAssignments();

        foreach ($desiredMap as $entry) {
            $this->validateEntry($entry, $managerMap, $allowSelfManager, $allowCircularManagers);
        }
    }

    /**
     * @param array<string, mixed> $entry
     * @param array<int, int|null> $managerMap
     */
    private function validateEntry(
        array $entry,
        array $managerMap,
        bool $allowSelfManager,
        bool $allowCircularManagers
    ): void {
        $userId = (int) ($entry['user_id'] ?? 0);
        $managerId = isset($entry['manager_id']) ? (int) $entry['manager_id'] : null;

        if (! $allowCircularManagers && $userId > 0 && $managerId !== null && $managerId === $userId) {
            if (! $allowSelfManager) {
                throw new ValidationException(__('Manager cannot be the same as the employee.', 'timesuite'));
            }
        } elseif (! $allowCircularManagers && $userId > 0 && $managerId !== null) {
            $this->assertNoCircularManager($userId, $managerId, $managerMap);
        }

        $workWeek = $entry['work_week'] ?? null;

        if (is_array($workWeek) && !empty($workWeek)) {
            foreach ($workWeek as $day) {
                if (!in_array($day, Settings::WORK_WEEK_OPTIONS, true)) {
                    throw new ValidationException(__('Invalid work week day.', 'timesuite'));
                }
            }
        }

        $expiry = $entry['comp_time_expiry_months'] ?? null;

        if ($expiry !== null && ($expiry < 0 || $expiry > 24)) {
            throw new ValidationException(__('Comp time expiry months must be between 0 and 24.', 'timesuite'));
        }

        $startDate = $entry['employment_start_date'] ?? null;
        $endDate = $entry['employment_end_date'] ?? null;

        if (is_string($startDate) && is_string($endDate) && $startDate !== '' && $endDate !== '' && $endDate < $startDate) {
            throw new ValidationException(__('Employment end date cannot be before employment start date.', 'timesuite'));
        }
    }

    /**
     * @param array<int, array<string, mixed>> $currentMap
     * @param array<int, array<string, mixed>> $desiredMap
     *
     * @return array<int, int|null>
     */
    private function buildManagerMap(array $currentMap, array $desiredMap): array
    {
        $map = [];

        foreach ($currentMap as $entry) {
            $map[(int) $entry['user_id']] = isset($entry['manager_id']) ? (int) $entry['manager_id'] : null;
        }

        foreach ($desiredMap as $entry) {
            $map[(int) $entry['user_id']] = isset($entry['manager_id']) ? (int) $entry['manager_id'] : null;
        }

        return $map;
    }

    /**
     * @param array<int, int|null> $managerMap
     */
    private function assertNoCircularManager(int $userId, int $managerId, array $managerMap): void
    {
        $cursor = $managerId;
        $visited = [];

        while ($cursor > 0 && array_key_exists($cursor, $managerMap)) {
            if ($cursor === $userId) {
                throw new ValidationException(__('Circular manager assignment detected.', 'timesuite'));
            }

            if (isset($visited[$cursor])) {
                break;
            }

            $visited[$cursor] = true;
            $cursor = (int) ($managerMap[$cursor] ?? 0);
        }
    }

    /**
     * @param array<int, int|null> $managerMap
     * @return int[]|null
     */
    private function findManagerCycle(int $startUserId, array $managerMap): ?array
    {
        $cursor = $startUserId;
        $path = [];
        $positions = [];

        while ($cursor > 0 && array_key_exists($cursor, $managerMap)) {
            if (isset($positions[$cursor])) {
                return array_slice($path, $positions[$cursor]);
            }

            $positions[$cursor] = count($path);
            $path[] = $cursor;
            $cursor = (int) ($managerMap[$cursor] ?? 0);
        }

        return null;
    }

    private function formatUserLabel(int $userId): string
    {
        $user = function_exists('get_user_by') ? get_user_by('id', (string) $userId) : null;

        if ($user instanceof WP_User) {
            $name = $user->display_name ?: $user->user_email ?: $user->user_login;

            return sprintf('%s (ID %d)', $name, $userId);
        }

        if (is_object($user)) {
            $name = (string) (($user->display_name ?? '') ?: ($user->user_email ?? '') ?: ($user->user_login ?? ''));

            if ($name !== '') {
                return sprintf('%s (ID %d)', $name, $userId);
            }
        }

        return sprintf('User ID %d', $userId);
    }

    /**
     * @return string[]|null
     */
    private function normalizeWorkWeek(mixed $value): ?array
    {
        $days = Settings::normalizeWorkWeekDays($value);

        return empty($days) ? null : $days;
    }

    private function normalizeCompTimeExpiry(mixed $value): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        $months = absint($value);

        if ($months > 24) {
            return null;
        }

        return $months;
    }

}
