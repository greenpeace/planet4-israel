<?php

declare(strict_types=1);

namespace Timesuite\Domain\Org\Services;

use Timesuite\Domain\Org\Repositories\UsersOrgRepository;
use Timesuite\Domain\Timesheets\Repositories\CompTimeLedgerRepository;
use Timesuite\Domain\Timesheets\Repositories\MonthlyTimesheetRepository;

class UserRemovalService
{
    public function __construct(
        private UsersOrgRepository $usersOrgRepository,
        private LegacyTimesheetCleanupService $legacyTimesheetCleanup,
        private CompTimeLedgerRepository $compTimeLedgerRepository,
        private MonthlyTimesheetRepository $monthlyTimesheetRepository
    ) {
    }

    /**
     * @return array<string, int>
     */
    public function removeUser(int $userId): array
    {
        $legacyDeleted = $this->legacyTimesheetCleanup->removeUserData($userId);
        $ledgerDeleted = $this->compTimeLedgerRepository->deleteByUserId($userId);
        $monthlyDeleted = $this->monthlyTimesheetRepository->deleteByUserId($userId);
        $orgDeleted = $this->usersOrgRepository->deleteByUserId($userId);
        $reportsDetached = $this->usersOrgRepository->detachManager($userId);

        $this->deleteUserMeta($userId);
        $this->markRemoved($userId);

        return [
            'approvals' => $legacyDeleted['approvals'],
            'entries' => $legacyDeleted['entries'],
            'periods' => $legacyDeleted['periods'],
            'ledger' => $ledgerDeleted,
            'monthly_timesheets' => $monthlyDeleted,
            'org' => $orgDeleted,
            'reports_detached' => $reportsDetached,
        ];
    }

    private function deleteUserMeta(int $userId): void
    {
        if (! function_exists('delete_user_meta')) {
            return;
        }

        $keys = [
            'timesuite_department',
            'timesuite_work_week',
            'timesuite_daily_hours_by_day',
            'timesuite_comp_time_expiry_months',
            'timesuite_vacation_contract_hours',
            'timesuite_sick_contract_hours',
            'timesuite_vacation_balance_adjustment_hours',
            'timesuite_sick_balance_adjustment_hours',
        ];

        foreach ($keys as $key) {
            delete_user_meta($userId, $key);
        }
    }

    private function markRemoved(int $userId): void
    {
        if (function_exists('update_user_meta')) {
            update_user_meta($userId, 'timesuite_removed', '1');
        }
    }
}
