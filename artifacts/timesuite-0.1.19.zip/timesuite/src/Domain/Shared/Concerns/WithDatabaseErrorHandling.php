<?php

declare(strict_types=1);

namespace Timesuite\Domain\Shared\Concerns;

use RuntimeException;
use wpdb;

/**
 * Provides database error handling utilities for repositories.
 *
 * Requires the using class to have a $wpdb property.
 */
trait WithDatabaseErrorHandling
{
    /**
     * Execute a query and check for errors.
     *
     * @param string $sql The prepared SQL query to execute.
     *
     * @return int|bool Number of rows affected/selected or false on error.
     *
     * @throws RuntimeException If the query fails and errors are not suppressed.
     */
    protected function executeQuery(string $sql, bool $throwOnError = false): int|bool
    {
        $result = $this->getWpdbInstance()->query($sql);

        if ($throwOnError && false === $result) {
            $this->handleQueryError($sql);
        }

        return $result;
    }

    /**
     * Check if the last query resulted in an error.
     */
    protected function hasQueryError(): bool
    {
        $wpdb = $this->getWpdbInstance();

        return ! empty($wpdb->last_error);
    }

    /**
     * Get the last database error message.
     */
    protected function getLastError(): string
    {
        return $this->getWpdbInstance()->last_error;
    }

    /**
     * Log a database error for debugging.
     *
     * @param string $context Description of what operation was being performed.
     */
    protected function logDatabaseError(string $context): void
    {
        $error = $this->getLastError();

        if (empty($error)) {
            return;
        }

        if (defined('WP_DEBUG') && WP_DEBUG && defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            error_log(sprintf(
                'Timesuite DB Error [%s]: %s',
                $context,
                $error
            ));
        }
    }

    /**
     * Handle a query error by logging and optionally throwing.
     *
     * @throws RuntimeException If throw is enabled.
     */
    protected function handleQueryError(string $sql): void
    {
        $error = $this->getLastError();

        $this->logDatabaseError('Query failed');

        throw new RuntimeException(
            sprintf('Database query failed: %s', $error ?: 'Unknown error')
        );
    }

    /**
     * Execute an insert and return the insert ID, with error checking.
     *
     * @return int The insert ID, or 0 on failure.
     */
    protected function executeInsert(string $sql, bool $throwOnError = false): int
    {
        $result = $this->executeQuery($sql, $throwOnError);

        if (false === $result) {
            return 0;
        }

        return (int) $this->getWpdbInstance()->insert_id;
    }

    /**
     * Execute an update and return rows affected, with error checking.
     *
     * @return int Rows affected, or 0 on failure.
     */
    protected function executeUpdate(string $sql, bool $throwOnError = false): int
    {
        $result = $this->executeQuery($sql, $throwOnError);

        if (false === $result) {
            return 0;
        }

        return (int) $this->getWpdbInstance()->rows_affected;
    }

    /**
     * Get the wpdb instance.
     *
     * Override this method if your class uses a different property name.
     */
    protected function getWpdbInstance(): wpdb
    {
        return $this->wpdb;
    }
}

