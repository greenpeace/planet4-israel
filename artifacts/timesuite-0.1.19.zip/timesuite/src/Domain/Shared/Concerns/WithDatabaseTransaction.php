<?php

declare(strict_types=1);

namespace Timesuite\Domain\Shared\Concerns;

use wpdb;

/**
 * Provides database transaction support for services.
 *
 * Requires the using class to have a $wpdb property.
 */
trait WithDatabaseTransaction
{
    /**
     * Execute a callback within a database transaction.
     *
     * @template T
     *
     * @param callable(): T $callback
     *
     * @return T
     *
     * @throws \Throwable If the callback throws, the transaction is rolled back and the exception re-thrown.
     */
    protected function withTransaction(callable $callback): mixed
    {
        $this->getWpdb()->query('START TRANSACTION');

        try {
            $result = $callback();
            $this->getWpdb()->query('COMMIT');

            return $result;
        } catch (\Throwable $exception) {
            $this->getWpdb()->query('ROLLBACK');
            throw $exception;
        }
    }

    /**
     * Get the wpdb instance.
     *
     * Override this method if your class uses a different property name.
     */
    protected function getWpdb(): wpdb
    {
        return $this->wpdb;
    }
}

