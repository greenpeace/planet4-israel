<?php

declare(strict_types=1);

namespace Timesuite\Domain\Shared\Concerns;

use Timesuite\Domain\Shared\Exceptions\ConcurrencyException;
use wpdb;

/**
 * Provides optimistic locking support for repositories.
 *
 * Requires the using class to have a $wpdb property.
 * Tables must have a `version` INT UNSIGNED column.
 */
trait WithOptimisticLocking
{
    /**
     * Update a row with optimistic locking.
     *
     * @param string               $table   Table name (with prefix).
     * @param array<string, mixed> $data    Data to update.
     * @param int                  $id      Row ID.
     * @param int                  $version Current version (from client).
     *
     * @throws ConcurrencyException If version mismatch (concurrent modification).
     */
    protected function updateWithLock(string $table, array $data, int $id, int $version): void
    {
        $wpdb = $this->getWpdb();

        // Add version increment to data
        $data['version'] = $version + 1;

        // Build SET clause
        $setClauses = [];
        $values     = [];

        foreach ($data as $column => $value) {
            $setClauses[] = "`{$column}` = %s";
            $values[]     = $value;
        }

        // Add WHERE conditions
        $values[] = $id;
        $values[] = $version;

        $sql = $wpdb->prepare(
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            "UPDATE {$table} SET " . implode(', ', $setClauses) . ' WHERE id = %d AND version = %d',
            $values
        );

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $affected = $wpdb->query($sql);

        if ($affected === 0) {
            // Check if row exists
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE id = %d", $id));

            if ($exists) {
                throw new ConcurrencyException(
                    __('This record was modified by another user. Please refresh and try again.', 'timesuite')
                );
            }

            // Row doesn't exist
            throw new ConcurrencyException(
                __('Record not found.', 'timesuite')
            );
        }
    }

    /**
     * Get the wpdb instance.
     *
     * Override this method if your class uses a different property name.
     */
    abstract protected function getWpdb(): wpdb;
}

