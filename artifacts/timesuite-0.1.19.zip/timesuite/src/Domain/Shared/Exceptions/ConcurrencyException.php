<?php

declare(strict_types=1);

namespace Timesuite\Domain\Shared\Exceptions;

/**
 * Exception thrown when an optimistic locking conflict is detected.
 *
 * This indicates that the record was modified by another user/process
 * between the time it was read and the update attempt.
 */
class ConcurrencyException extends \RuntimeException
{
}

