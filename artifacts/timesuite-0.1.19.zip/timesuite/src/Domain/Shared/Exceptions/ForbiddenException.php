<?php

declare(strict_types=1);

namespace Timesuite\Domain\Shared\Exceptions;

use RuntimeException;

class ForbiddenException extends RuntimeException
{
}
