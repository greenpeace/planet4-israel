<?php

declare(strict_types=1);

namespace Timesuite\Domain\Shared\Exceptions;

use RuntimeException;

/**
 * Thrown when a write that the caller believes succeeded did not reach the
 * database.
 *
 * wpdb::query() reports failure by returning false, which is easy to ignore --
 * and ignoring it is how the comp-time ledger silently dropped a real
 * employee's second overtime credit for a whole month. Any repository write
 * whose result is not checked can lose data with no error anywhere, so
 * failures are converted into this exception and allowed to abort the
 * surrounding transaction.
 */
class PersistenceException extends RuntimeException
{
}
