<?php

declare(strict_types=1);

namespace Timesuite\Domain\Shared\Repositories;

use Timesuite\Domain\Shared\Concerns\WithDatabaseErrorHandling;
use wpdb;

/**
 * Centralized repository for logging approval-related actions.
 */
class ApprovalLogRepository
{
    use WithDatabaseErrorHandling;

    private string $table;

    public function __construct(private wpdb $wpdb)
    {
        $this->table = $this->wpdb->prefix . 'timesuite_approvals_log';
    }

    /**
     * Log an action related to a period (submit, approve, deny, lock).
     */
    public function logPeriodAction(
        int $periodId,
        int $actorId,
        string $action,
        ?string $comment = null
    ): void {
        $this->insertLog(
            entryId: 0,
            periodId: $periodId,
            actorId: $actorId,
            entityType: 'period',
            entityId: $periodId,
            action: $action,
            comment: $comment
        );
    }

    /**
     * Log an org import action.
     */
    public function logImport(
        int $actorId,
        int $created,
        int $updated,
        int $skipped
    ): void {
        $comment = sprintf(
            'import created=%d updated=%d skipped=%d',
            $created,
            $updated,
            $skipped
        );

        $this->insertLog(
            entryId: 0,
            periodId: 0,
            actorId: $actorId,
            entityType: 'import',
            entityId: 0,
            action: 'import',
            comment: $comment
        );
    }

    /**
     * Log a timesheet XLSX import action.
     */
    public function logTimesheetImport(
        int $actorId,
        int $created,
        int $updated,
        int $skipped
    ): void {
        $comment = sprintf(
            'timesheet_import created=%d updated=%d skipped=%d',
            $created,
            $updated,
            $skipped
        );

        $this->insertLog(
            entryId: 0,
            periodId: 0,
            actorId: $actorId,
            entityType: 'timesheet_import',
            entityId: 0,
            action: 'import',
            comment: $comment
        );
    }

    /**
     * Log an export action.
     *
     * @param array<string, string|null> $filters
     */
    public function logExport(
        int $actorId,
        array $filters,
        string $format,
        int $rowCount
    ): void {
        $encoded = function_exists('wp_json_encode')
            ? wp_json_encode($filters)
            : json_encode($filters);

        $comment = sprintf(
            'format=%s rows=%d filters=%s',
            $format,
            $rowCount,
            $encoded ?: ''
        );

        $this->insertLog(
            entryId: 0,
            periodId: 0,
            actorId: $actorId,
            entityType: 'export',
            entityId: 0,
            action: 'export',
            comment: $comment
        );
    }

    /**
     * Log a settings change.
     *
     * @param array<string, mixed> $changedFields Fields that were changed.
     */
    public function logSettingsChange(
        int $actorId,
        array $changedFields
    ): void {
        $fieldNames = array_keys($changedFields);
        $comment    = 'settings_changed: ' . implode(', ', $fieldNames);

        $this->insertLog(
            entryId: 0,
            periodId: 0,
            actorId: $actorId,
            entityType: 'settings',
            entityId: 0,
            action: 'update',
            comment: $comment
        );
    }

    /**
     * Log a generic system action.
     *
     * @param array<string, mixed> $context
     */
    public function log(string $action, int $entryId = 0, ?int $actorId = null, array $context = []): void
    {
        $comment = null;

        if (! empty($context)) {
            $encoded = function_exists('wp_json_encode')
                ? wp_json_encode($context)
                : json_encode($context);

            $comment = $encoded ?: null;
        }

        $this->insertLog(
            entryId: $entryId,
            periodId: 0,
            actorId: $actorId ?? 0,
            entityType: 'system',
            entityId: $entryId,
            action: $action,
            comment: $comment
        );
    }

    /**
     * Backward-compatible audit log wrapper used by older call sites.
     */
    public function logAction(
        string $action,
        int $actorId,
        int $entityId = 0,
        int $entryId = 0,
        int $periodId = 0,
        ?string $comment = null
    ): void {
        $entityType = 'system';

        if ($periodId > 0) {
            $entityType = 'period';
        } elseif ($entityId > 0) {
            $entityType = 'user';
        }

        $this->insertLog(
            entryId: $entryId,
            periodId: $periodId,
            actorId: $actorId,
            entityType: $entityType,
            entityId: $entityId,
            action: $action,
            comment: $comment
        );
    }

    /**
     * Log an org mapping change.
     */
    public function logOrgChange(
        int $actorId,
        int $userId,
        string $action,
        ?string $details = null
    ): void {
        $this->insertLog(
            entryId: 0,
            periodId: 0,
            actorId: $actorId,
            entityType: 'org_mapping',
            entityId: $userId,
            action: $action,
            comment: $details
        );
    }

    /**
     * Delete audit logs older than the specified number of days.
     *
     * @param int $days Number of days to retain logs.
     *
     * @return int Number of deleted rows.
     */
    public function deleteOlderThan(int $days): int
    {
        if ($days <= 0) {
            return 0; // Retention disabled
        }

        $cutoffDate = gmdate('Y-m-d H:i:s', strtotime("-{$days} days"));

        $sql = $this->wpdb->prepare(
            "DELETE FROM {$this->table} WHERE created_at < %s",
            $cutoffDate
        );

        $deleted = $this->wpdb->query($sql);

        return is_int($deleted) ? $deleted : 0;
    }

    /**
     * Get log count by date range.
     */
    public function countByDateRange(string $from, string $to): int
    {
        $sql = $this->wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table} WHERE created_at BETWEEN %s AND %s",
            [$from, $to]
        );

        return (int) $this->wpdb->get_var($sql);
    }

    /**
     * Insert a log entry into the approvals_log table.
     */
    private function insertLog(
        int $entryId,
        int $periodId,
        int $actorId,
        string $entityType,
        int $entityId,
        string $action,
        ?string $comment
    ): void {
        $now = gmdate('Y-m-d H:i:s');

        $sql = $this->wpdb->prepare(
            "
                INSERT INTO {$this->table}
                (entry_id, period_id, actor_id, entity_type, entity_id, action, comment, created_at)
                VALUES (%d, %d, %d, %s, %d, %s, %s, %s)
            ",
            [
                $entryId,
                $periodId,
                $actorId,
                $entityType,
                $entityId,
                $action,
                $comment ? sanitize_textarea_field($comment) : null,
                $now,
            ]
        );

        $this->executeQuery($sql);

        if ($this->hasQueryError()) {
            $this->logDatabaseError('ApprovalLogRepository::insertLog');
        }
    }
}
