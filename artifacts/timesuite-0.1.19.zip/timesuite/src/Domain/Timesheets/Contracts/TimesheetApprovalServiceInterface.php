<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Contracts;

/**
 * Interface for timesheet approval workflow operations.
 */
interface TimesheetApprovalServiceInterface
{
    /**
     * Update the overall status of a timesheet month.
     *
     * @return array<string, mixed>
     */
    public function updateMonthStatus(
        int $userId,
        int $year,
        int $month,
        string $status,
        ?int $actorId = null,
        ?string $comment = null
    ): array;

    /**
     * Update approval status for a single day.
     *
     * @return array<string, mixed>
     */
    public function updateDayApproval(
        int $userId,
        int $year,
        int $month,
        string $date,
        string $status,
        int $actorId,
        ?string $comment = null
    ): array;

    /**
     * Reset approval status for a single day.
     *
     * @return array<string, mixed>
     */
    public function resetDayApproval(
        int $userId,
        int $year,
        int $month,
        string $date,
        int $actorId
    ): array;

    /**
     * Approve all days requiring approval.
     *
     * @return array<string, mixed>
     */
    public function approveAllDays(int $userId, int $year, int $month, int $actorId): array;

    /**
     * Deny all days requiring approval.
     *
     * @return array<string, mixed>
     */
    public function denyAllDays(int $userId, int $year, int $month, int $actorId, ?string $comment = null): array;

    /**
     * Reset all day approvals.
     *
     * @return array<string, mixed>
     */
    public function resetAllApprovals(int $userId, int $year, int $month, int $actorId): array;
}
