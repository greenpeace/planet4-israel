<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Contracts;

/**
 * Interface for timesheet CRUD operations.
 */
interface TimesheetServiceInterface
{
    /**
     * Get available day types.
     *
     * @return array<string, string>
     */
    public function getDayTypes(): array;

    /**
     * Get available part-day coverage sources.
     *
     * @return array<string, string>
     */
    public function getPartDaySources(): array;

    /**
     * Get active part-day coverage sources available for new selections.
     *
     * @return array<string, string>
     */
    public function getSelectablePartDaySources(): array;

    /**
     * Check if office checkbox is enabled.
     */
    public function isOfficeCheckboxEnabled(): bool;

    /**
     * Get configured daily hours.
     */
    public function getDailyHours(): float;

    /**
     * Get timesheet data for a specific month.
     *
     * @return array<string, mixed>
     */
    public function getMonth(int $userId, int $year, int $month): array;

    /**
     * Save timesheet data for a specific month.
     *
     * @param array<int, array<string, mixed>> $entries
     *
     * @return array<string, mixed>
     */
    public function saveMonth(
        int $userId,
        int $year,
        int $month,
        array $entries,
        string $status = 'draft',
        ?int $actorId = null,
        bool $canOverrideRules = false
    ): array;

    /**
     * Get metadata for a timesheet month.
     *
     * @return array{status:string, submitted_at:?string, approved_at:?string, denied_at:?string, denied_comment:?string, updated_at:?string}
     */
    public function getMonthMeta(int $userId, int $year, int $month): array;

    /**
     * Check editability of a timesheet month.
     *
     * @return array{editable: bool, reason: string|null, reason_code: string}
     */
    public function getEditability(int $year, int $month, bool $canOverrideRules = false): array;
}
