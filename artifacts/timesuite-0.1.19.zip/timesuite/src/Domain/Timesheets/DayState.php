<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets;

/**
 * Day State - The single deterministic state of a calendar day.
 *
 * Each day has exactly ONE state. The state determines:
 * - Visual appearance
 * - Editability
 * - Available actions
 *
 * State precedence (highest to lowest):
 * 1. DISABLED - Non-working day (not part of contract, holiday, outside contract)
 * 2. LOCKED - Period is locked (payroll closed)
 * 3. APPROVED - Finalized and confirmed
 * 4. PENDING - Submitted, waiting for approval
 * 5. REJECTED - Needs correction
 * 6. EDITABLE - Normal working day, can be edited
 */
final class DayState
{
    // State constants
    public const DISABLED = 'disabled';
    public const LOCKED = 'locked';
    public const APPROVED = 'approved';
    public const PENDING = 'pending';
    public const REJECTED = 'rejected';
    public const EDITABLE = 'editable';

    // Reason constants for DISABLED state
    public const REASON_NON_WORKING_DAY = 'non_working_day';
    public const REASON_HOLIDAY = 'holiday';
    public const REASON_OUTSIDE_CONTRACT = 'outside_contract';
    public const REASON_LOCKED_PERIOD = 'locked_period';

    // All valid states
    private const VALID_STATES = [
        self::DISABLED,
        self::LOCKED,
        self::APPROVED,
        self::PENDING,
        self::REJECTED,
        self::EDITABLE,
    ];

    // State precedence (lower index = higher priority)
    private const PRECEDENCE = [
        self::DISABLED => 0,
        self::LOCKED => 1,
        self::APPROVED => 2,
        self::PENDING => 3,
        self::REJECTED => 4,
        self::EDITABLE => 5,
    ];

    public static function isValid(string $state): bool
    {
        return in_array($state, self::VALID_STATES, true);
    }

    /**
     * Resolve final state when multiple conditions apply.
     * Returns the state with highest precedence.
     *
     * @param string[] $candidateStates
     */
    public static function resolve(array $candidateStates): string
    {
        if (empty($candidateStates)) {
            return self::EDITABLE;
        }

        $highestPriority = PHP_INT_MAX;
        $resolvedState = self::EDITABLE;

        foreach ($candidateStates as $state) {
            if (!isset(self::PRECEDENCE[$state])) {
                continue;
            }

            if (self::PRECEDENCE[$state] < $highestPriority) {
                $highestPriority = self::PRECEDENCE[$state];
                $resolvedState = $state;
            }
        }

        return $resolvedState;
    }

    /**
     * Check if a state allows editing.
     */
    public static function isEditable(string $state): bool
    {
        return in_array($state, [self::EDITABLE, self::PENDING], true);
    }

    /**
     * Check if a state is actionable for an employee.
     */
    public static function isActionableForEmployee(string $state): bool
    {
        return in_array($state, [self::EDITABLE, self::PENDING], true);
    }

    /**
     * Check if a state is actionable for a manager.
     */
    public static function isActionableForManager(string $state): bool
    {
        return $state === self::PENDING;
    }

    /**
     * Check if a state is actionable for HR.
     */
    public static function isActionableForHR(string $state): bool
    {
        return in_array($state, [self::PENDING, self::APPROVED, self::LOCKED], true);
    }
}
