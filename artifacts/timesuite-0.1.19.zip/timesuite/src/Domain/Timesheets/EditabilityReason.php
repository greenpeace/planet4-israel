<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets;

/**
 * Structured reason codes for why a month is or isn't editable right now,
 * distinct from the month's status (draft/submitted/approved/denied/locked).
 *
 * Before this, the UI reused the word "Locked" for two different concepts:
 * the month's STATUS (a locked month, meaning finalized/approved) and the
 * EDIT WINDOW (a read-only period, e.g. because the cutoff day passed).
 * These codes let the frontend show both distinctly — "Month status: Draft"
 * and "Editing: closed (cutoff day passed)" — instead of one ambiguous
 * "Locked" label. See docs/timesheet-status-investigation.md.
 *
 * Purely additive: these ride alongside the existing freetext
 * read_only_reason, which nothing needs to stop using.
 */
final class EditabilityReason
{
    /** The month being viewed is the current month — always editable. */
    public const CURRENT_MONTH_OPEN = 'current_month_open';

    /** HR/Tech Admin override is active — all editability rules are bypassed. */
    public const OVERRIDE_ACTIVE = 'override_active';

    /** Previous month, backdating enabled, still on/before the cutoff day. */
    public const PREVIOUS_MONTH_BEFORE_CUTOFF = 'previous_month_before_cutoff';

    /** Previous month, backdating enabled, but the cutoff day has passed. */
    public const PERIOD_CUTOFF_PASSED = 'period_cutoff_passed';

    /** Previous month, but backdating is disabled entirely. */
    public const BACKDATING_DISABLED = 'backdating_disabled';

    /** Neither the current nor previous month — outside the editable window. */
    public const OUTSIDE_EDITABLE_WINDOW = 'outside_editable_window';

    /** Submitted and awaiting a manager decision. */
    public const SUBMITTED_UNDER_REVIEW = 'submitted_under_review';

    /** Locked, with a pending re-edit request awaiting manager approval. */
    public const MONTH_LOCKED_REEDIT_PENDING = 'month_locked_reedit_pending';

    /** Locked, with a previous re-edit request denied. */
    public const MONTH_LOCKED_REEDIT_DENIED = 'month_locked_reedit_denied';

    /** Locked, no re-edit request in flight. */
    public const MONTH_LOCKED = 'month_locked';

    /** The month was denied by a manager/HR. */
    public const DENIED = 'denied';

    /** Viewing someone else's timesheet (manager/HR view). */
    public const VIEWING_ANOTHER_USER = 'viewing_another_user';
}
