<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Repositories;

use Timesuite\Domain\Shared\Exceptions\PersistenceException;
use wpdb;
use const ARRAY_A;

class CompTimeLedgerRepository
{
    private string $table;

    public function __construct(private wpdb $wpdb)
    {
        $this->table = $this->wpdb->prefix . 'timesuite_comp_time_ledger';
    }

    /**
     * @param array<string, mixed> $data
     */
    public function insert(array $data): void
    {
        $sql = $this->wpdb->prepare(
            "
                INSERT INTO {$this->table}
                    (user_id, direction, minutes, source_type, source_key, work_date, expires_on, notes, created_at, created_by)
                VALUES (%d, %s, %d, %s, %s, %s, %s, %s, %s, %d)
            ",
            [
                (int) $data['user_id'],
                (string) $data['direction'],
                (int) $data['minutes'],
                (string) $data['source_type'],
                $data['source_key'] ?? null,
                $data['work_date'] ?? null,
                $data['expires_on'] ?? null,
                $data['notes'] ?? null,
                (string) $data['created_at'],
                isset($data['created_by']) ? (int) $data['created_by'] : null,
            ]
        );

        $this->execute($sql, 'insert comp-time ledger row');
    }

    public function deleteBySource(int $userId, string $sourceType, string $sourceKey, ?string $direction = null): void
    {
        if ($direction) {
            $sql = $this->wpdb->prepare(
                "DELETE FROM {$this->table} WHERE user_id = %d AND source_type = %s AND source_key = %s AND direction = %s",
                [$userId, $sourceType, $sourceKey, $direction]
            );
        } else {
            $sql = $this->wpdb->prepare(
                "DELETE FROM {$this->table} WHERE user_id = %d AND source_type = %s AND source_key = %s",
                [$userId, $sourceType, $sourceKey]
            );
        }

        // A delete that silently fails is as damaging as an insert that does:
        // applyMonthlyCredits()/applyMonthlyDebits() delete a month's rows and
        // immediately rewrite them, so a swallowed delete turns the rewrite
        // into a unique-key collision and the month keeps stale figures.
        $this->execute($sql, 'delete comp-time ledger rows by source');
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listByUser(int $userId): array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE user_id = %d ORDER BY created_at ASC, id ASC",
            $userId
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return $rows ?: [];
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findBySource(int $userId, string $sourceType, string $sourceKey, string $direction): ?array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE user_id = %d AND source_type = %s AND source_key = %s AND direction = %s LIMIT 1",
            [$userId, $sourceType, $sourceKey, $direction]
        );

        $row = $this->wpdb->get_row($sql, ARRAY_A);

        return $row ?: null;
    }

    public function deleteByUserId(int $userId): int
    {
        $sql = $this->wpdb->prepare(
            "DELETE FROM {$this->table} WHERE user_id = %d",
            $userId
        );

        $this->execute($sql, 'delete comp-time ledger rows for user');

        return (int) $this->wpdb->rows_affected;
    }

    /**
     * Runs a write and refuses to let a failure pass as success.
     *
     * wpdb::query() signals failure by returning false while throwing nothing,
     * so an unchecked call loses data in total silence -- which is exactly how
     * a real employee's second overtime credit vanished for a month. Callers
     * run inside MonthlyTimesheetService's submission transaction, so throwing
     * here rolls the whole submission back rather than leaving the ledger and
     * the timesheet disagreeing.
     */
    private function execute(string $sql, string $description): void
    {
        $result = $this->wpdb->query($sql);

        if (false !== $result) {
            return;
        }

        $error = (string) $this->wpdb->last_error;

        // Duplicate-key is called out separately because it is the one failure
        // with a specific meaning -- the row is already there -- and because
        // misreporting an unrelated failure (deadlock, table gone, connection
        // dropped) as a duplicate would send whoever reads the log looking in
        // entirely the wrong place.
        if ($this->isDuplicateKeyError($error)) {
            throw new PersistenceException(
                sprintf(
                    'Could not %s: a row with the same uniqueness key already exists. %s',
                    $description,
                    $error
                )
            );
        }

        throw new PersistenceException(
            sprintf(
                'Could not %s: the database rejected the write. %s',
                $description,
                '' !== $error ? $error : 'No error message was reported.'
            )
        );
    }

    private function isDuplicateKeyError(string $error): bool
    {
        return stripos($error, 'duplicate entry') !== false
            || str_contains($error, '1062');
    }
}
