<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Repositories;

use wpdb;
use const ARRAY_A;

class HolidayRangeRepository
{
    private string $table;
    private bool $tableReady = false;

    public function __construct(private wpdb $wpdb)
    {
        $this->table = $this->wpdb->prefix . 'timesuite_holiday_ranges';
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getAll(): array
    {
        $this->ensureTable();
        $sql = "SELECT * FROM {$this->table} ORDER BY start_date ASC, end_date ASC, id ASC";

        return $this->wpdb->get_results($sql, ARRAY_A) ?? [];
    }

    public function countAll(): int
    {
        $this->ensureTable();
        $count = $this->wpdb->get_var("SELECT COUNT(*) FROM {$this->table}");

        return (int) $count;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getOverlapping(string $startDate, string $endDate): array
    {
        $this->ensureTable();
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE start_date <= %s AND end_date >= %s ORDER BY start_date ASC, end_date ASC, id ASC",
            $endDate,
            $startDate
        );

        return $this->wpdb->get_results($sql, ARRAY_A) ?? [];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getForRange(string $startDate, string $endDate): array
    {
        return $this->getOverlapping($startDate, $endDate);
    }

    public function insert(string $startDate, string $endDate, string $type, string $createdAt): int
    {
        $this->ensureTable();
        $this->wpdb->insert(
            $this->table,
            [
                'start_date' => $startDate,
                'end_date' => $endDate,
                'type' => $type,
                'created_at' => $createdAt,
            ],
            ['%s', '%s', '%s', '%s']
        );

        return (int) $this->wpdb->insert_id;
    }

    public function delete(int $id): int
    {
        $this->ensureTable();
        $this->wpdb->delete($this->table, ['id' => $id], ['%d']);

        return (int) $this->wpdb->rows_affected;
    }

    public function deleteEndingBefore(string $cutoffDate): int
    {
        $this->ensureTable();
        $sql = $this->wpdb->prepare(
            "DELETE FROM {$this->table} WHERE end_date < %s",
            $cutoffDate
        );

        $this->wpdb->query($sql);

        return (int) $this->wpdb->rows_affected;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getById(int $id): ?array
    {
        $this->ensureTable();
        $sql = $this->wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d LIMIT 1", $id);
        $row = $this->wpdb->get_row($sql, ARRAY_A);

        return $row ?: null;
    }

    private function ensureTable(): void
    {
        if ($this->tableReady) {
            return;
        }

        $this->tableReady = true;

        if ($this->tableExists()) {
            return;
        }

        if (! function_exists('dbDelta')) {
            if (defined('ABSPATH')) {
                $upgradeFile = ABSPATH . 'wp-admin/includes/upgrade.php';

                if (is_readable($upgradeFile)) {
                    require_once $upgradeFile;
                }
            }
        }

        $collation = $this->wpdb->get_charset_collate() ?: 'DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci';
        $sql = "CREATE TABLE {$this->table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            start_date date NOT NULL,
            end_date date NOT NULL,
            type varchar(20) NOT NULL DEFAULT 'holiday',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY date_range (start_date, end_date),
            KEY end_date (end_date)
        ) ENGINE=InnoDB {$collation};";

        if (function_exists('dbDelta')) {
            dbDelta($sql);
        }
    }

    private function tableExists(): bool
    {
        $result = $this->wpdb->get_var(
            $this->wpdb->prepare('SHOW TABLES LIKE %s', $this->table)
        );

        return is_string($result) && $result !== '';
    }
}
