<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Repositories;

use Timesuite\Domain\Shared\Exceptions\PersistenceException;
use wpdb;
use const ARRAY_A;

class MonthlyTimesheetRepository
{
    private string $timesheetsTable;
    private string $entriesTable;
    private ?bool $hasScheduledHoursColumn = null;

    public function __construct(private wpdb $wpdb)
    {
        $this->timesheetsTable = $this->wpdb->prefix . 'timesuite_monthly_timesheets';
        $this->entriesTable    = $this->wpdb->prefix . 'timesuite_monthly_entries';
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getHeader(int $userId, int $year, int $month): ?array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->timesheetsTable} WHERE user_id = %d AND year = %d AND month = %d LIMIT 1",
            [$userId, $year, $month]
        );

        $row = $this->wpdb->get_row($sql, ARRAY_A);

        return $row ?: null;
    }

    /**
     * Every month that has been finalized, oldest first.
     *
     * Read-only, and used only by the comp-time ledger audit: a month that was
     * never finalized never wrote ledger rows, so comparing it against the
     * ledger would report a discrepancy that is simply the normal state of a
     * draft.
     *
     * @param string[] $statuses
     *
     * @return array<int, array{user_id:int, year:int, month:int, status:string}>
     */
    public function listFinalizedMonths(array $statuses = ['submitted', 'approved', 'locked']): array
    {
        if (empty($statuses)) {
            return [];
        }

        $placeholders = implode(', ', array_fill(0, count($statuses), '%s'));

        $sql = $this->wpdb->prepare(
            "SELECT user_id, year, month, status FROM {$this->timesheetsTable}"
                . " WHERE status IN ({$placeholders})"
                . ' ORDER BY user_id ASC, year ASC, month ASC',
            array_values($statuses)
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        if (! $rows) {
            return [];
        }

        return array_map(
            static fn (array $row): array => [
                'user_id' => (int) $row['user_id'],
                'year'    => (int) $row['year'],
                'month'   => (int) $row['month'],
                'status'  => (string) $row['status'],
            ],
            $rows
        );
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getEntries(int $timesheetId): array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->entriesTable} WHERE timesheet_id = %d ORDER BY work_date ASC",
            $timesheetId
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return $rows ?: [];
    }

    /**
     * @param array<string, mixed> $data
     */
    public function upsertHeader(int $userId, int $year, int $month, array $data): int
    {
        $existing = $this->getHeader($userId, $year, $month);
        $now      = current_time('mysql', true);

        $fields = [
            'status' => (string) ($data['status'] ?? 'draft'),
            'updated_at' => (string) ($data['updated_at'] ?? $now),
            'updated_by' => $data['updated_by'] ?? null,
            'submitted_at' => $data['submitted_at'] ?? null,
            'submitted_by' => $data['submitted_by'] ?? null,
            'approved_at' => $data['approved_at'] ?? null,
            'approved_by' => $data['approved_by'] ?? null,
            'denied_at' => $data['denied_at'] ?? null,
            'denied_by' => $data['denied_by'] ?? null,
            'denied_comment' => $data['denied_comment'] ?? null,
        ];

        if ($existing) {
            $setClauses = [];
            $values = [];

            foreach ($fields as $column => $value) {
                if (null === $value) {
                    $setClauses[] = "{$column} = NULL";
                    continue;
                }

                $placeholder = is_int($value) ? '%d' : '%s';
                $setClauses[] = "{$column} = {$placeholder}";
                $values[] = $value;
            }

            $values[] = $userId;
            $values[] = $year;
            $values[] = $month;

            $sql = $this->wpdb->prepare(
                "UPDATE {$this->timesheetsTable} SET " . implode(', ', $setClauses) . ' WHERE user_id = %d AND year = %d AND month = %d',
                $values
            );

            $this->executeOrThrow(
                $sql,
                sprintf('update the monthly timesheet header for %04d-%02d', $year, $month)
            );

            return (int) $existing['id'];
        }

        $fields['user_id'] = $userId;
        $fields['year'] = $year;
        $fields['month'] = $month;
        $fields['created_at'] = (string) ($data['created_at'] ?? $now);

        $columns = array_keys($fields);
        $placeholders = [];
        $values = [];

        foreach ($fields as $value) {
            if (null === $value) {
                $placeholders[] = 'NULL';
                continue;
            }

            $placeholders[] = is_int($value) ? '%d' : '%s';
            $values[] = $value;
        }

        $sql = $this->wpdb->prepare(
            "INSERT INTO {$this->timesheetsTable} (" . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')',
            $values
        );

        $this->executeOrThrow(
            $sql,
            sprintf('create the monthly timesheet header for %04d-%02d', $year, $month)
        );

        return (int) $this->wpdb->insert_id;
    }

    /**
     * Inserts a header row ONLY if one doesn't already exist for this
     * user/year/month — never updates an existing row. Used by the legacy
     * backfill (P1.2, see docs/timesheet-status-investigation.md §11): a
     * backfill runs out-of-band with no request context that's already
     * committed to treating a specific legacy snapshot as canonical, so
     * unlike upsertHeader() (used by the lazy read-path materialization),
     * it must never overwrite a row that already exists — including one
     * that appeared between the caller's own candidate scan and this call.
     *
     * Deliberately plain `INSERT`, not `INSERT IGNORE`: IGNORE would also
     * silently swallow non-duplicate problems (truncation, an implicit
     * NOT NULL default substitution, etc.) and this method would then
     * mis-report them as "row already existed." The table's own
     * `UNIQUE KEY (user_id, year, month)` constraint is what actually
     * makes this race-safe (not any check-then-insert logic in PHP, which
     * would still have a TOCTOU gap) — a duplicate-key failure is detected
     * explicitly via the error message and treated as "already existed";
     * any other failure is a genuine problem and is re-thrown.
     *
     * @param array<string, mixed> $data
     *
     * @return int|null The new header's id, or null if a row already existed.
     *
     * @throws \RuntimeException on any non-duplicate-key insert failure.
     */
    public function insertHeaderIfAbsent(int $userId, int $year, int $month, array $data): ?int
    {
        $now = current_time('mysql', true);

        $fields = [
            'user_id' => $userId,
            'year' => $year,
            'month' => $month,
            'status' => (string) ($data['status'] ?? 'draft'),
            'updated_at' => (string) ($data['updated_at'] ?? $now),
            'updated_by' => $data['updated_by'] ?? null,
            'submitted_at' => $data['submitted_at'] ?? null,
            'submitted_by' => $data['submitted_by'] ?? null,
            'approved_at' => $data['approved_at'] ?? null,
            'approved_by' => $data['approved_by'] ?? null,
            'denied_at' => $data['denied_at'] ?? null,
            'denied_by' => $data['denied_by'] ?? null,
            'denied_comment' => $data['denied_comment'] ?? null,
            'created_at' => (string) ($data['created_at'] ?? $now),
        ];

        $columns = array_keys($fields);
        $placeholders = [];
        $values = [];

        foreach ($fields as $value) {
            if (null === $value) {
                $placeholders[] = 'NULL';
                continue;
            }

            $placeholders[] = is_int($value) ? '%d' : '%s';
            $values[] = $value;
        }

        $sql = $this->wpdb->prepare(
            "INSERT INTO {$this->timesheetsTable} (" . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')',
            $values
        );

        $result = $this->wpdb->query($sql);

        if (false === $result) {
            if ($this->isDuplicateKeyError((string) $this->wpdb->last_error)) {
                return null;
            }

            throw new \RuntimeException(sprintf(
                'Failed to insert monthly timesheet header for user %d, %04d-%02d: %s',
                $userId,
                $year,
                $month,
                (string) $this->wpdb->last_error
            ));
        }

        return (int) $this->wpdb->insert_id;
    }

    private function isDuplicateKeyError(string $error): bool
    {
        return '' !== $error && str_contains($error, 'Duplicate entry');
    }

    /**
     * Atomically materializes a legacy month: header + entries as a single
     * unit, via insertHeaderIfAbsent() (the race-safe, insert-only guard)
     * followed by upsertEntriesOrThrow() -- deliberately NOT the plain
     * upsertEntries(), which never checks its query results and would
     * silently continue past a failed entry write, defeating the rollback
     * below entirely. If entries fail to write AFTER the header insert
     * already succeeded, the whole operation is rolled back — without
     * this, the month would end up with a canonical header row but no
     * entries, which is invisible to both the backfill (the header's mere
     * existence removes it from findLegacyMonthCandidates()) and the lazy
     * read-path (a header row short-circuits before ever consulting legacy
     * meta again) — a silent, hard-to-repair partial state.
     *
     * @param array<string, mixed> $data
     * @param array<string, array<string, mixed>> $entries
     * @param array<string, array<string, mixed>> $approvals
     *
     * @return int|null The new header's id if materialized, or null if a
     *                   row already existed (nothing written).
     */
    public function materializeIfAbsent(
        int $userId,
        int $year,
        int $month,
        array $data,
        array $entries,
        array $approvals
    ): ?int {
        // Routed through the depth-aware helpers rather than raw SQL so this
        // joins an outer transaction instead of implicitly committing it.
        return $this->transactional(function () use ($userId, $year, $month, $data, $entries, $approvals): ?int {
            $timesheetId = $this->insertHeaderIfAbsent($userId, $year, $month, $data);

            if (null === $timesheetId) {
                return null;
            }

            $this->upsertEntriesOrThrow($timesheetId, $userId, $entries, $approvals);

            return $timesheetId;
        });
    }

    /**
     * Finds candidate legacy-only months for the backfill (P1.2), keyset-
     * paginated by umeta_id so a large wp_usermeta table can be scanned in
     * bounded batches without OFFSET's degrading performance.
     *
     * The LIKE/SUBSTRING filtering here is deliberately loose (candidate-
     * finding only) — it mirrors HealthController::findLegacyOnlyMonths()'s
     * approach so the two agree on what counts as "legacy-only," but a
     * malformed meta_key (non-numeric year/month, out-of-range month) can
     * still pass through as a "candidate." Callers MUST strictly re-validate
     * each meta_key before writing anything — see
     * LegacyMonthBackfillService::parseLegacyMetaKey().
     *
     * @return array<int, array{umeta_id: int, user_id: int, meta_key: string}>
     */
    public function findLegacyMonthCandidates(int $afterUmetaId, int $limit): array
    {
        $metaTable = $this->wpdb->usermeta;

        $sql = $this->wpdb->prepare(
            "SELECT m.umeta_id, m.user_id, m.meta_key
             FROM {$metaTable} m
             LEFT JOIN {$this->timesheetsTable} mt
                ON mt.user_id = m.user_id
                AND mt.year = CAST(SUBSTRING(m.meta_key, 17, 4) AS UNSIGNED)
                AND mt.month = CAST(SUBSTRING(m.meta_key, 22, 2) AS UNSIGNED)
             WHERE m.meta_key LIKE 'timesuite\\_month\\_____\\_%%'
               AND m.umeta_id > %d
               AND mt.id IS NULL
             ORDER BY m.umeta_id ASC
             LIMIT %d",
            [$afterUmetaId, $limit]
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return $rows ?: [];
    }

    /**
     * How many months exist ONLY as legacy user_meta, with no row in the
     * canonical table.
     *
     * Read-only and used by the comp-time ledger audit to say honestly how
     * much of the data it actually covered. Mirrors the LEFT JOIN in
     * findLegacyMonthCandidates() so the two agree on what "legacy-only"
     * means; like that method the LIKE filter is loose, so this is a
     * conservative upper bound suitable for a coverage warning, not an exact
     * figure to act on.
     */
    public function countLegacyOnlyMonths(): int
    {
        $metaTable = $this->wpdb->usermeta;

        $sql = "SELECT COUNT(*)
             FROM {$metaTable} m
             LEFT JOIN {$this->timesheetsTable} mt
                ON mt.user_id = m.user_id
                AND mt.year = CAST(SUBSTRING(m.meta_key, 17, 4) AS UNSIGNED)
                AND mt.month = CAST(SUBSTRING(m.meta_key, 22, 2) AS UNSIGNED)
             WHERE m.meta_key LIKE 'timesuite\\_month\\_____\\_%'
               AND mt.id IS NULL";

        return (int) $this->wpdb->get_var($sql);
    }

    /**
     * @param array<string, array<string, mixed>> $entries
     * @param array<string, array<string, mixed>> $approvals
     */
    public function upsertEntries(int $timesheetId, int $userId, array $entries, array $approvals): void
    {
        if (empty($entries)) {
            return;
        }

        $now = current_time('mysql', true);
        $supportsScheduledHours = $this->hasScheduledHoursColumn();

        foreach ($entries as $date => $entry) {
            $sql = $this->buildEntryUpsertSql(
                $timesheetId,
                $userId,
                (string) $date,
                is_array($entry) ? $entry : [],
                is_array($approvals[$date] ?? null) ? $approvals[$date] : [],
                $now,
                $supportsScheduledHours
            );

            $this->executeOrThrow(
                $sql,
                sprintf('write the timesheet entry for %s', (string) $date)
            );
        }
    }

    /**
     * Retained as the name materializeIfAbsent() calls; upsertEntries() now
     * throws on failure itself, so the two are the same operation.
     *
     * They used to differ: upsertEntries() ignored failed writes because its
     * other callers had not been audited for a method that could suddenly
     * throw. That tolerance is exactly the defect class that let the
     * comp-time ledger lose a month of credits in silence, so the throwing
     * behavior is now the only behavior and the callers are handled at the
     * REST boundary.
     *
     * @param array<string, array<string, mixed>> $entries
     * @param array<string, array<string, mixed>> $approvals
     *
     * @throws PersistenceException on any entry-write failure.
     */
    private function upsertEntriesOrThrow(int $timesheetId, int $userId, array $entries, array $approvals): void
    {
        $this->upsertEntries($timesheetId, $userId, $entries, $approvals);
    }

    /**
     * Runs a write and converts a failure into an exception.
     *
     * wpdb::query() returns false on failure and throws nothing, so an
     * unchecked call loses data silently -- and a transaction wrapped around
     * unchecked calls is decoration, because nothing ever reaches the
     * rollback. Every write that a transaction is supposed to protect goes
     * through here.
     */
    private function executeOrThrow(string $sql, string $description): void
    {
        $result = $this->wpdb->query($sql);

        if (false !== $result) {
            return;
        }

        $error = (string) $this->wpdb->last_error;

        throw new PersistenceException(sprintf(
            'Could not %s: the database rejected the write. %s',
            $description,
            '' !== $error ? $error : 'No error message was reported.'
        ));
    }

    /**
     * @param array<string, mixed> $entry
     * @param array<string, mixed> $approval
     */
    private function buildEntryUpsertSql(
        int $timesheetId,
        int $userId,
        string $date,
        array $entry,
        array $approval,
        string $now,
        bool $supportsScheduledHours
    ): string {
        $fields = [
            'timesheet_id' => $timesheetId,
            'user_id' => $userId,
            'work_date' => $date,
            'type' => (string) ($entry['type'] ?? 'working_day'),
            'notes' => $entry['notes'] ?? null,
            'hours' => $entry['hours'] ?? null,
            'coverage_source' => $entry['coverage_source'] ?? null,
            'in_office' => ! empty($entry['in_office']) ? 1 : 0,
            'approval_status' => $approval['status'] ?? null,
            'approval_by' => $approval['by'] ?? null,
            'approval_at' => $approval['at'] ?? null,
            'approval_comment' => $approval['comment'] ?? null,
            'created_at' => $now,
            'updated_at' => $now,
        ];

        if ($supportsScheduledHours) {
            $fields['scheduled_hours'] = $entry['scheduled_hours'] ?? null;
        }

        $columns = array_keys($fields);
        $placeholders = [];
        $values = [];

        foreach ($fields as $value) {
            if (null === $value) {
                $placeholders[] = 'NULL';
                continue;
            }

            $placeholders[] = is_int($value) ? '%d' : '%s';
            $values[] = $value;
        }

        $updates = [
            'type = VALUES(type)',
            'notes = VALUES(notes)',
            'hours = VALUES(hours)',
            'coverage_source = VALUES(coverage_source)',
            'in_office = VALUES(in_office)',
            'approval_status = VALUES(approval_status)',
            'approval_by = VALUES(approval_by)',
            'approval_at = VALUES(approval_at)',
            'approval_comment = VALUES(approval_comment)',
            'updated_at = VALUES(updated_at)',
        ];

        if ($supportsScheduledHours) {
            array_splice($updates, 3, 0, ['scheduled_hours = VALUES(scheduled_hours)']);
        }

        return $this->wpdb->prepare(
            "INSERT INTO {$this->entriesTable} (" . implode(', ', $columns) . ')
            VALUES (' . implode(', ', $placeholders) . ')
            ON DUPLICATE KEY UPDATE ' . implode(', ', $updates),
            $values
        );
    }

    /**
     * Thin transaction-control wrappers so MonthlyTimesheetService can span
     * a single DB transaction across comp-time ledger writes (via
     * CompTimeService/CompTimeLedgerRepository, a different repository but
     * the same underlying wpdb connection) and its own header/entries
     * writes -- see MonthlyTimesheetService::finalizeSubmittedMonth() and
     * docs/p3.1-admin-rescue-actions-plan.md §1.1. Same pattern already
     * used internally by materializeIfAbsent() (P1.2).
     */
    /**
     * Nesting depth, so an inner unit of work can declare "these writes belong
     * together" without opening a second transaction inside the workflow that
     * already owns one.
     *
     * MySQL has no true nested transactions: a second START TRANSACTION
     * implicitly commits the first, which would silently make the outer
     * workflow non-atomic exactly when it matters. Counting depth and issuing
     * the real START/COMMIT only at the outermost level gives one transaction
     * owner per workflow while letting persistMonth() still be atomic when it
     * is called on its own.
     */
    private int $transactionDepth = 0;

    /**
     * @throws PersistenceException when the transaction could not be opened.
     */
    public function beginTransaction(): void
    {
        if (0 === $this->transactionDepth) {
            // A START TRANSACTION that fails leaves the connection in
            // autocommit, so every write the caller is about to make would
            // land individually and could not be rolled back. Nothing must
            // run under the illusion of a transaction that was never opened.
            $this->executeOrThrow('START TRANSACTION', 'open a database transaction');
        }

        $this->transactionDepth++;
    }

    /**
     * @throws PersistenceException when the commit failed; the transaction is
     *                              rolled back first so nothing is left open.
     */
    public function commitTransaction(): void
    {
        if ($this->transactionDepth <= 0) {
            // Nothing open -- most likely an inner unit already rolled the
            // whole transaction back. Committing here would turn a
            // half-rolled-back workflow into a "successful" one.
            return;
        }

        $this->transactionDepth--;

        if (0 !== $this->transactionDepth) {
            return;
        }

        $result = $this->wpdb->query('COMMIT');

        if (false !== $result) {
            return;
        }

        // A failed COMMIT is the most dangerous silent failure available: the
        // caller would return success while the work is still uncommitted and
        // will be discarded when the connection closes. Roll back explicitly
        // so the outcome is definite, then say so.
        $error = (string) $this->wpdb->last_error;
        $this->transactionDepth = 1;
        $this->rollbackTransaction();

        throw new PersistenceException(sprintf(
            'Could not commit the database transaction; it has been rolled back. %s',
            '' !== $error ? $error : 'No error message was reported.'
        ));
    }

    public function rollbackTransaction(): void
    {
        if ($this->transactionDepth <= 0) {
            return;
        }

        // A rollback discards the entire transaction, inner and outer alike,
        // so the depth drops straight to zero rather than unwinding one level.
        // Any outer commitTransaction() that follows then correctly does
        // nothing instead of committing work that was already discarded.
        $this->transactionDepth = 0;
        $this->wpdb->query('ROLLBACK');
    }

    /**
     * Run a unit of work inside a transaction, committing on success and
     * rolling back on any throwable.
     *
     * Safe to nest: an inner call joins the transaction its caller already
     * opened. Use this rather than hand-rolled begin/commit pairs so a
     * forgotten rollback path cannot leave a connection in an open
     * transaction.
     *
     * @template T
     *
     * @param callable():T $work
     *
     * @return T
     */
    public function transactional(callable $work): mixed
    {
        $this->beginTransaction();

        try {
            $result = $work();

            $this->commitTransaction();

            return $result;
        } catch (\Throwable $e) {
            $this->rollbackTransaction();

            throw $e;
        }
    }

    /**
     * Header + entries as one indivisible write.
     *
     * upsertHeader() followed by a loop of entry upserts could previously
     * persist a header with only some of its days -- a month that no workflow
     * intended and that nothing would report. Callers that already own a
     * transaction (a submission applying comp-time, a reopen clearing it) join
     * it rather than opening another.
     *
     * @param array<string, mixed>                  $header
     * @param array<string, array<string, mixed>>   $entries
     * @param array<string, array<string, mixed>>   $approvals
     */
    public function persistMonthAtomically(
        int $userId,
        int $year,
        int $month,
        array $header,
        array $entries,
        array $approvals
    ): int {
        return $this->transactional(function () use ($userId, $year, $month, $header, $entries, $approvals): int {
            $timesheetId = $this->upsertHeader($userId, $year, $month, $header);
            $this->upsertEntries($timesheetId, $userId, $entries, $approvals);

            return $timesheetId;
        });
    }

    public function deleteByUserId(int $userId): int
    {
        $total = 0;

        $sql = $this->wpdb->prepare(
            "DELETE FROM {$this->entriesTable} WHERE user_id = %d",
            $userId
        );
        $this->executeOrThrow($sql, 'delete the timesheet entries for this user');
        $total += (int) $this->wpdb->rows_affected;

        $sql = $this->wpdb->prepare(
            "DELETE FROM {$this->timesheetsTable} WHERE user_id = %d",
            $userId
        );
        $this->executeOrThrow($sql, 'delete the timesheet headers for this user');
        $total += (int) $this->wpdb->rows_affected;

        return $total;
    }

    private function hasScheduledHoursColumn(): bool
    {
        if ($this->hasScheduledHoursColumn !== null) {
            return $this->hasScheduledHoursColumn;
        }

        $column = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SHOW COLUMNS FROM {$this->entriesTable} LIKE %s",
                'scheduled_hours'
            )
        );

        $this->hasScheduledHoursColumn = is_string($column) && $column === 'scheduled_hours';

        return $this->hasScheduledHoursColumn;
    }
}
