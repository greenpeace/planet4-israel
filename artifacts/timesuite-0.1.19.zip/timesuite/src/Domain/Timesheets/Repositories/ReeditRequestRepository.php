<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Repositories;

use wpdb;
use const ARRAY_A;

class ReeditRequestRepository
{
    private string $table;

    public function __construct(private wpdb $wpdb)
    {
        $this->table = $this->wpdb->prefix . 'timesuite_reedit_requests';
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getById(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE id = %d LIMIT 1",
            $id
        );

        $row = $this->wpdb->get_row($sql, ARRAY_A);

        return $row ?: null;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getPendingForMonth(int $userId, int $year, int $month): ?array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table}
             WHERE user_id = %d AND year = %d AND month = %d AND status = 'pending'
             ORDER BY requested_at DESC, id DESC
             LIMIT 1",
            [$userId, $year, $month]
        );

        $row = $this->wpdb->get_row($sql, ARRAY_A);

        return $row ?: null;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getLatestForMonth(int $userId, int $year, int $month): ?array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table}
             WHERE user_id = %d AND year = %d AND month = %d
             ORDER BY requested_at DESC, id DESC
             LIMIT 1",
            [$userId, $year, $month]
        );

        $row = $this->wpdb->get_row($sql, ARRAY_A);

        return $row ?: null;
    }

    public function createPending(
        int $userId,
        int $year,
        int $month,
        int $requestedBy,
        string $employeeReason
    ): int {
        $now = current_time('mysql', true);
        $inserted = $this->wpdb->insert(
            $this->table,
            [
                'user_id' => $userId,
                'year' => $year,
                'month' => $month,
                'status' => 'pending',
                'employee_reason' => sanitize_textarea_field($employeeReason),
                'manager_reason' => null,
                'requested_at' => $now,
                'decided_at' => null,
                'requested_by' => $requestedBy,
                'decided_by' => null,
                'pending_unique' => 1,
                'updated_at' => $now,
            ],
            ['%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s']
        );

        if (! $inserted) {
            return 0;
        }

        return (int) $this->wpdb->insert_id;
    }

    public function markApproved(int $id, int $decidedBy, string $managerReason): bool
    {
        return $this->markDecision($id, 'approved', $decidedBy, $managerReason);
    }

    public function markDenied(int $id, int $decidedBy, string $managerReason): bool
    {
        return $this->markDecision($id, 'denied', $decidedBy, $managerReason);
    }

    /**
     * Rescue action (P3.1): sweep away a stale *pending* re-edit request
     * without recording it as an approve/deny decision. Mirrors
     * markDecision()'s pending_unique=NULL release (so a fresh request can
     * be created later) but uses a distinct 'cancelled' status so the audit
     * trail doesn't lie about a manager having decided. The `status` column
     * is a free-text varchar(20) (see CreateReeditRequests migration), so
     * this needs no schema change.
     *
     * @return bool True if a pending row was cancelled; false if none
     *              matched (already decided/cancelled, or wrong id) --
     *              callers treat false as an idempotent no-op, same as the
     *              approve/deny controllers do.
     */
    public function cancelPending(int $id, int $cancelledBy): bool
    {
        $now = current_time('mysql', true);
        $sql = $this->wpdb->prepare(
            "UPDATE {$this->table}
             SET status = 'cancelled',
                 decided_at = %s,
                 decided_by = %d,
                 pending_unique = NULL,
                 updated_at = %s
             WHERE id = %d
               AND status = 'pending'",
            [
                $now,
                $cancelledBy,
                $now,
                $id,
            ]
        );

        $updated = $this->wpdb->query($sql);

        return is_int($updated) && $updated > 0;
    }

    /**
     * @param int[] $userIds
     *
     * @return array<int, array<string, mixed>>
     */
    public function listPendingForUsers(array $userIds, int $year, int $month): array
    {
        $userIds = array_values(array_filter(array_map('intval', $userIds)));

        if (empty($userIds)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($userIds), '%d'));
        $params = array_merge($userIds, [$year, $month]);

        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table}
             WHERE user_id IN ({$placeholders})
               AND year = %d
               AND month = %d
               AND status = 'pending'
             ORDER BY requested_at DESC, id DESC",
            $params
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return $rows ?: [];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listPendingForUserMonth(int $userId, int $year, int $month): array
    {
        $sql = $this->wpdb->prepare(
            "SELECT * FROM {$this->table}
             WHERE user_id = %d
               AND year = %d
               AND month = %d
               AND status = 'pending'
             ORDER BY requested_at DESC, id DESC",
            [$userId, $year, $month]
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A);

        return $rows ?: [];
    }

    private function markDecision(int $id, string $status, int $decidedBy, string $managerReason): bool
    {
        $now = current_time('mysql', true);
        $sql = $this->wpdb->prepare(
            "UPDATE {$this->table}
             SET status = %s,
                 manager_reason = %s,
                 decided_at = %s,
                 decided_by = %d,
                 pending_unique = NULL,
                 updated_at = %s
             WHERE id = %d
               AND status = 'pending'",
            [
                $status,
                sanitize_textarea_field($managerReason),
                $now,
                $decidedBy,
                $now,
                $id,
            ]
        );

        $updated = $this->wpdb->query($sql);

        return is_int($updated) && $updated > 0;
    }
}
