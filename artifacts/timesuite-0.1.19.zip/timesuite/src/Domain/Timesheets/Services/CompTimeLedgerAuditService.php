<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Services;

use Timesuite\Domain\Timesheets\Repositories\MonthlyTimesheetRepository;

/**
 * Read-only report of months whose comp-time ledger disagrees with the
 * timesheet it was written from.
 *
 * This exists because of a real, silent data loss: the ledger's uniqueness key
 * covered only (user, source_type, source_key, direction), so a month with two
 * overtime dates could store only the first, and the failed write was never
 * checked. UpdateCompTimeLedgerUniquePerWorkDate stops it happening again, but
 * it cannot recover what was already dropped.
 *
 * This service deliberately DOES NOT repair anything, and does not write at
 * all. Balances are money-like: some have already been corrected by hand, and
 * blindly re-adding a missing credit on top of a manual correction would
 * double it. Every finding is context for a human decision.
 */
class CompTimeLedgerAuditService
{
    /**
     * Denied months are audited too. Comp-time is applied at submission and
     * is NOT cleared when a manager denies the month -- only reopening to
     * draft clears it -- so a denied month still holds live ledger rows and
     * can still be missing some of them. Leaving it out would hide real
     * losses in exactly the months most likely to have been resubmitted
     * several times.
     */
    public const AUDITED_STATUSES = ['submitted', 'approved', 'denied', 'locked'];

    public function __construct(
        private MonthlyTimesheetRepository $monthlyRepository,
        private MonthlyTimesheetService $monthlyService,
        private CompTimeService $compTimeService
    ) {
    }

    /**
     * @param string[]|null $statuses
     *
     * @return array{
     *     scanned_months: int,
     *     statuses: string[],
     *     affected: array<int, array<string, mixed>>,
     *     totals: array{missing_credit_minutes:int, missing_debit_minutes:int, affected_users:int},
     *     coverage: array{legacy_only_months:int, complete:bool, warning:?string}
     * }
     */
    public function audit(?array $statuses = null, ?int $userId = null, ?int $year = null, ?int $month = null): array
    {
        $statuses = $statuses ?? self::AUDITED_STATUSES;
        $months = $this->monthlyRepository->listFinalizedMonths($statuses);

        $months = array_values(array_filter(
            $months,
            static function (array $row) use ($userId, $year, $month): bool {
                if (null !== $userId && $row['user_id'] !== $userId) {
                    return false;
                }

                if (null !== $year && $row['year'] !== $year) {
                    return false;
                }

                return null === $month || $row['month'] === $month;
            }
        ));

        $affected = [];
        $missingCreditMinutes = 0;
        $missingDebitMinutes = 0;
        $affectedUsers = [];

        foreach ($months as $monthRow) {
            $finding = $this->auditMonth(
                $monthRow['user_id'],
                $monthRow['year'],
                $monthRow['month'],
                $monthRow['status']
            );

            if (null === $finding) {
                continue;
            }

            $affected[] = $finding;
            $missingCreditMinutes += $finding['missing_credit_minutes'];
            $missingDebitMinutes += $finding['missing_debit_minutes'];
            $affectedUsers[$finding['user_id']] = true;
        }

        return [
            'scanned_months' => count($months),
            'statuses'       => array_values($statuses),
            'affected'       => $affected,
            'totals'         => [
                'missing_credit_minutes' => $missingCreditMinutes,
                'missing_debit_minutes'  => $missingDebitMinutes,
                'affected_users'         => count($affectedUsers),
            ],
            'coverage'       => $this->assessCoverage(),
        ];
    }

    /**
     * Legacy-only months live in wp_usermeta and have no row in the canonical
     * table, so listFinalizedMonths() cannot see them and this audit cannot
     * speak for them.
     *
     * They are counted rather than audited on purpose. Reading one through the
     * normal path would materialize it -- loadMonth() persists a legacy month
     * as a side effect of reading it -- and an audit that writes to the rows
     * it is auditing is not an audit. So the report states plainly that it is
     * incomplete and names the backfill that would make it complete, instead
     * of quietly reporting a clean result over a partial scan.
     *
     * @return array{legacy_only_months:int, complete:bool, warning:?string}
     */
    private function assessCoverage(): array
    {
        $legacyOnly = $this->monthlyRepository->countLegacyOnlyMonths();

        if (0 === $legacyOnly) {
            return [
                'legacy_only_months' => 0,
                'complete'           => true,
                'warning'            => null,
            ];
        }

        return [
            'legacy_only_months' => $legacyOnly,
            'complete'           => false,
            'warning'            => sprintf(
                'INCOMPLETE: %d month(s) exist only as legacy user_meta and were NOT scanned, '
                . 'because reading one through the normal path would materialize it and this audit '
                . 'must not write. Run "wp timesuite backfill-legacy-months" first, then re-run this '
                . 'audit, before treating a clean result as complete.',
                $legacyOnly
            ),
        ];
    }

    /**
     * @return array<string, mixed>|null Null when the month reconciles.
     */
    public function auditMonth(int $userId, int $year, int $month, ?string $status = null): ?array
    {
        $expectation = $this->monthlyService->getCompTimeExpectation($userId, $year, $month);
        $actual = $this->compTimeService->getMonthlyLedgerBreakdown($userId, $year, $month);

        $expectedCredits = $expectation['credits'];
        $expectedDebits  = $expectation['debits'];

        $expectedCreditMinutes = $this->sumMinutes($expectedCredits);
        $expectedDebitMinutes  = $this->sumMinutes($expectedDebits);
        $actualCreditMinutes   = $this->sumRowMinutes($actual['credits']);
        $actualDebitMinutes    = $this->sumRowMinutes($actual['debits']);

        $missingCreditRows = count($expectedCredits) - count($actual['credits']);
        $missingDebitRows  = count($expectedDebits) - count($actual['debits']);
        $missingCreditMinutes = $expectedCreditMinutes - $actualCreditMinutes;
        $missingDebitMinutes  = $expectedDebitMinutes - $actualDebitMinutes;

        $rowCountMismatch = 0 !== $missingCreditRows || 0 !== $missingDebitRows;
        $minutesMismatch  = 0 !== $missingCreditMinutes || 0 !== $missingDebitMinutes;

        if (! $rowCountMismatch && ! $minutesMismatch) {
            return null;
        }

        $manual = $actual['manual_adjustments_all_time'];

        return [
            'user_id' => $userId,
            'year'    => $year,
            'month'   => $month,
            'status'  => $status ?? $expectation['status'],

            'expected_credit_rows'    => count($expectedCredits),
            'actual_credit_rows'      => count($actual['credits']),
            'expected_credit_minutes' => $expectedCreditMinutes,
            'actual_credit_minutes'   => $actualCreditMinutes,
            'missing_credit_minutes'  => $missingCreditMinutes,

            'expected_debit_rows'    => count($expectedDebits),
            'actual_debit_rows'      => count($actual['debits']),
            'expected_debit_minutes' => $expectedDebitMinutes,
            'actual_debit_minutes'   => $actualDebitMinutes,
            'missing_debit_minutes'  => $missingDebitMinutes,

            'expected_credit_dates' => $this->datesOf($expectedCredits),
            'stored_credit_dates'   => $this->rowDatesOf($actual['credits']),
            'expected_debit_dates'  => $this->datesOf($expectedDebits),
            'stored_debit_dates'    => $this->rowDatesOf($actual['debits']),

            // Listed in full so a human can judge each one, and labelled
            // all-time because that is what it is: nothing in a manual
            // adjustment records which month it was meant to repair, so a
            // manual credit sitting here is NOT evidence that THIS month was
            // fixed. Reporting a count alone invited exactly that inference.
            'manual_adjustments_all_time' => $this->describeManualAdjustments($manual),
            'manual_adjustments_note'     => 'Manual adjustments are not linked to any month. '
                . 'They are listed for context only and do NOT prove this month was repaired. '
                . 'Check each one against the employee\'s correction history before acting.',

            'needs_human_review' => true,
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     *
     * @return array<int, array<string, mixed>>
     */
    private function describeManualAdjustments(array $rows): array
    {
        $described = [];

        foreach ($rows as $row) {
            $described[] = [
                'work_date'  => (string) ($row['work_date'] ?? ''),
                'direction'  => (string) ($row['direction'] ?? ''),
                'minutes'    => (int) ($row['minutes'] ?? 0),
                'created_at' => (string) ($row['created_at'] ?? ''),
                'created_by' => isset($row['created_by']) ? (int) $row['created_by'] : null,
                'source_key' => (string) ($row['source_key'] ?? ''),
                'notes'      => (string) ($row['notes'] ?? ''),
            ];
        }

        return $described;
    }

    /**
     * @param array<int, array{date:string, minutes:int}> $items
     */
    private function sumMinutes(array $items): int
    {
        $total = 0;

        foreach ($items as $item) {
            $total += (int) ($item['minutes'] ?? 0);
        }

        return $total;
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     */
    private function sumRowMinutes(array $rows): int
    {
        $total = 0;

        foreach ($rows as $row) {
            $total += (int) ($row['minutes'] ?? 0);
        }

        return $total;
    }

    /**
     * @param array<int, array{date:string, minutes:int}> $items
     *
     * @return string[]
     */
    private function datesOf(array $items): array
    {
        return array_values(array_map(static fn (array $i): string => (string) ($i['date'] ?? ''), $items));
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     *
     * @return string[]
     */
    private function rowDatesOf(array $rows): array
    {
        return array_values(array_map(static fn (array $r): string => (string) ($r['work_date'] ?? ''), $rows));
    }
}
