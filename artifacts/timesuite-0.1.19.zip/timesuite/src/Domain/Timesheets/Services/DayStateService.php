<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Services;

use Timesuite\Core\Settings;
use Timesuite\Domain\Timesheets\DayState;

/**
 * Service for computing the state of each calendar day.
 *
 * This is the SINGLE SOURCE OF TRUTH for day states.
 * All state computation must go through this service.
 * Frontend must NOT compute states - it only renders what this service returns.
 */
class DayStateService
{
    public function __construct(
        private Settings $settings
    ) {
    }

    /**
     * Compute the state for a single day.
     *
     * @param string $date Date in Y-m-d format
     * @param string[] $userWorkWeek User's working days (e.g., ['Sun', 'Mon', 'Tue', 'Wed', 'Thu'])
     * @param string[] $holidays List of holiday dates in Y-m-d format
     * @param bool $isPeriodLocked Whether the period is locked
     * @param string|null $entryStatus The entry's approval status (null, 'draft', 'submitted', 'approved', 'denied')
     * @param string|null $monthStatus The month's overall status
     * @param string|null $entryType The entry's type (e.g. 'day_off', 'travel'). Used to allow overrides on non-working days.
     *
     * @return array{state: string, is_actionable: bool, reason: string|null, metadata: array}
     */
    public function computeDayState(
        string $date,
        array $userWorkWeek,
        array $holidays,
        bool $isPeriodLocked,
        ?string $entryStatus = null,
        ?string $monthStatus = null,
        ?string $approvedBy = null,
        ?string $approvedAt = null,
        ?string $rejectionReason = null,
        ?string $submittedAt = null,
        ?string $entryType = null,
        string $userRole = 'employee'
    ): array {
        $candidateStates = [];
        $reason = null;
        $metadata = [];
        $requiresApproval = $this->requiresApprovalForDate($date, $entryType, $userWorkWeek, $holidays);

        if ($entryType === 'not_employed') {
            return [
                'state' => DayState::DISABLED,
                'is_actionable' => false,
                'reason' => DayState::REASON_OUTSIDE_CONTRACT,
                'metadata' => $metadata,
            ];
        }

        // 1. Check if day is a working day per user's contract
        $dayOfWeek = gmdate('D', strtotime($date));
        if (!in_array($dayOfWeek, $userWorkWeek, true)) {
            // Allow users to override non-working days by selecting a different type.
            // Default day-off type remains disabled (greyed) until overridden.
            if ($entryType === null || $entryType === '' || $entryType === 'day_off') {
                $candidateStates[] = DayState::DISABLED;
                $reason = DayState::REASON_NON_WORKING_DAY;
            }
        }

        // 2. Check if day is a holiday
        if (in_array($date, $holidays, true)) {
            $candidateStates[] = DayState::DISABLED;
            $reason = DayState::REASON_HOLIDAY;
        }

        // 3. Check if period is locked
        if ($isPeriodLocked) {
            $candidateStates[] = DayState::LOCKED;
            if ($reason === null) {
                $reason = DayState::REASON_LOCKED_PERIOD;
            }
        }

        // 4. Check entry/month approval status (only for days that require approval)
        if ($requiresApproval) {
            $status = null;
            if (is_string($entryStatus) && $entryStatus !== '') {
                $status = strtolower($entryStatus);
            } elseif (is_string($monthStatus) && $monthStatus !== '') {
                $fallback = strtolower($monthStatus);
                if ($fallback === 'denied') {
                    $status = 'submitted';
                } elseif (in_array($fallback, ['submitted', 'approved'], true)) {
                    $status = $fallback;
                }
            }

            if ($status === 'approved') {
                $candidateStates[] = DayState::APPROVED;
                if ($approvedBy) {
                    $metadata['approved_by'] = $approvedBy;
                }
                if ($approvedAt) {
                    $metadata['approved_at'] = $approvedAt;
                }
            } elseif ($status === 'submitted') {
                $candidateStates[] = DayState::PENDING;
                if ($submittedAt) {
                    $metadata['submitted_at'] = $submittedAt;
                }
            } elseif ($status === 'denied') {
                $candidateStates[] = DayState::REJECTED;
                if ($rejectionReason) {
                    $metadata['rejection_reason'] = $rejectionReason;
                }
            }
        }

        // 5. Default to editable if nothing else applies
        if (empty($candidateStates)) {
            $candidateStates[] = DayState::EDITABLE;
        }

        // Resolve final state using precedence rules
        $state = DayState::resolve($candidateStates);

        // Compute actionability based on user role
        $isActionable = $this->computeActionability($state, $userRole);

        return [
            'state' => $state,
            'is_actionable' => $isActionable,
            'reason' => $reason,
            'metadata' => $metadata,
        ];
    }

    /**
     * Compute states for an entire month.
     *
     * @param int $year
     * @param int $month
     * @param string[] $userWorkWeek
     * @param string[] $holidays
     * @param bool $isPeriodLocked
     * @param array<string, array{status?: string, approved_by?: string, approved_at?: string, rejection_reason?: string}> $dayEntries Keyed by date
     * @param string|null $monthStatus
     * @param string $userRole
     *
     * @return array<string, array{state: string, is_actionable: bool, reason: string|null, metadata: array}>
     */
    public function computeMonthStates(
        int $year,
        int $month,
        array $userWorkWeek,
        array $holidays,
        bool $isPeriodLocked,
        array $dayEntries = [],
        ?string $monthStatus = null,
        ?string $submittedAt = null,
        ?string $approvedBy = null,
        ?string $approvedAt = null,
        ?string $rejectionReason = null,
        string $userRole = 'employee'
    ): array {
        $states = [];
        $daysInMonth = (int) gmdate('t', strtotime("$year-$month-01"));

        for ($day = 1; $day <= $daysInMonth; $day++) {
            $date = sprintf('%04d-%02d-%02d', $year, $month, $day);
            $entry = $dayEntries[$date] ?? [];

            $states[$date] = $this->computeDayState(
                $date,
                $userWorkWeek,
                $holidays,
                $isPeriodLocked,
                $entry['status'] ?? null,
                $monthStatus,
                $entry['approved_by'] ?? $approvedBy,
                $entry['approved_at'] ?? $approvedAt,
                $entry['rejection_reason'] ?? $rejectionReason,
                $submittedAt,
                $entry['type'] ?? null,
                $userRole
            );
        }

        return $states;
    }

    /**
     * Check if a specific day can be edited.
     */
    public function canEditDay(
        string $date,
        array $userWorkWeek,
        array $holidays,
        bool $isPeriodLocked,
        ?string $monthStatus = null
    ): bool {
        $result = $this->computeDayState(
            $date,
            $userWorkWeek,
            $holidays,
            $isPeriodLocked,
            null,
            $monthStatus
        );

        return DayState::isEditable($result['state']);
    }

    /**
     * Check if a day is a working day per the user's contract.
     */
    public function isWorkingDay(string $date, array $userWorkWeek): bool
    {
        $dayOfWeek = gmdate('D', strtotime($date));
        return in_array($dayOfWeek, $userWorkWeek, true);
    }

    /**
     * Check if a day is a holiday.
     */
    public function isHoliday(string $date, array $holidays): bool
    {
        return in_array($date, $holidays, true);
    }

    /**
     * Determine if a day requires manager approval based on its type and schedule.
     */
    private function requiresApprovalForDate(
        string $date,
        ?string $entryType,
        array $userWorkWeek,
        array $holidays
    ): bool {
        $type = is_string($entryType) ? trim(strtolower($entryType)) : '';

        if ($type === '') {
            if (in_array($date, $holidays, true)) {
                $type = 'holiday';
            } else {
                $dayOfWeek = gmdate('D', strtotime($date));
                $type = in_array($dayOfWeek, $userWorkWeek, true) ? 'working_day' : 'day_off';
            }
        }

        if (in_array($date, $holidays, true)) {
            return ! in_array($type, ['holiday', 'half_holiday'], true);
        }

        if (in_array($type, ['working_day', 'holiday', 'half_holiday', 'not_employed'], true)) {
            return false;
        }

        if ($type === 'day_off' && ! $this->isWorkingDay($date, $userWorkWeek)) {
            return false;
        }

        return true;
    }

    /**
     * Compute actionability based on state and user role.
     */
    private function computeActionability(string $state, string $userRole): bool
    {
        return match ($userRole) {
            'employee' => DayState::isActionableForEmployee($state),
            'manager' => DayState::isActionableForManager($state),
            'hr', 'tech_admin' => DayState::isActionableForHR($state),
            default => false,
        };
    }

    /**
     * Get the user's work week, with fallback to system default.
     *
     * @return string[]
     */
    public function getUserWorkWeek(int $userId): array
    {
        $stored = get_user_meta($userId, 'timesuite_work_week', true);
        $stored = Settings::normalizeWorkWeekDays($stored);

        if (!empty($stored)) {
            return $stored;
        }

        return Settings::normalizeWorkWeekDays($this->settings->getWorkWeek());
    }

    /**
     * Get holidays for a given year.
     *
     * @return string[]
     */
    public function getHolidays(): array
    {
        return $this->settings->getHolidays();
    }
}
