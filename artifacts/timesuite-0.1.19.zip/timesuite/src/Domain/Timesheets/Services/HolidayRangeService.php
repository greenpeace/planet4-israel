<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Services;

use Timesuite\Core\Settings;
use Timesuite\Domain\Shared\Exceptions\NotFoundException;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Timesheets\Repositories\HolidayRangeRepository;

class HolidayRangeService
{
    private const ALLOWED_TYPES = ['holiday', 'half_holiday'];

    private bool $cleanupDone = false;
    private bool $legacyMigrated = false;

    public function __construct(
        private HolidayRangeRepository $repository,
        private Settings $settings
    ) {
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listRanges(): array
    {
        $this->cleanupOldRanges();
        $this->migrateLegacyIfNeeded();

        return $this->repository->getAll();
    }

    /**
     * @return array<string, string> Map of Y-m-d => holiday type.
     */
    public function getHolidayMapForRange(string $startDate, string $endDate): array
    {
        $this->cleanupOldRanges();
        $this->migrateLegacyIfNeeded();

        [$start, $end] = $this->normalizeRange($startDate, $endDate);
        $ranges = $this->repository->getForRange($start, $end);

        if (empty($ranges)) {
            return [];
        }

        $map = [];

        foreach ($ranges as $range) {
            $rangeStart = max($start, (string) ($range['start_date'] ?? $start));
            $rangeEnd = min($end, (string) ($range['end_date'] ?? $end));

            if ($rangeStart > $rangeEnd) {
                continue;
            }

            $cursor = $this->parseDate($rangeStart);
            $limit = $this->parseDate($rangeEnd);
            $type = $this->normalizeType((string) ($range['type'] ?? 'holiday'));

            while ($cursor <= $limit) {
                $map[$cursor->format('Y-m-d')] = $type;
                $cursor = $cursor->modify('+1 day');
            }
        }

        return $map;
    }

    /**
     * @return array<string, mixed>
     */
    public function createRange(string $startDate, string $endDate, string $type): array
    {
        $this->cleanupOldRanges();
        $this->migrateLegacyIfNeeded();

        [$start, $end] = $this->normalizeRange($startDate, $endDate);
        $normalizedType = $this->normalizeType($type);

        if (! in_array($normalizedType, self::ALLOWED_TYPES, true)) {
            throw new ValidationException(__('Invalid holiday type.', 'timesuite'));
        }

        $overlaps = $this->repository->getOverlapping($start, $end);

        if (! empty($overlaps)) {
            throw new ValidationException(__('You cannot add this date range because it overlaps with an existing holiday.', 'timesuite'));
        }

        $now = current_time('mysql', true);
        $id = $this->repository->insert($start, $end, $normalizedType, $now);

        if ($id <= 0) {
            throw new ValidationException(__('Unable to save holiday range. Please refresh and try again.', 'timesuite'));
        }

        $range = $this->repository->getById($id);

        return $range ?? [
            'id' => $id,
            'start_date' => $start,
            'end_date' => $end,
            'type' => $normalizedType,
            'created_at' => $now,
        ];
    }

    public function deleteRange(int $id): void
    {
        $deleted = $this->repository->delete($id);

        if ($deleted <= 0) {
            throw new NotFoundException(__('Holiday range not found.', 'timesuite'));
        }
    }

    private function cleanupOldRanges(): void
    {
        if ($this->cleanupDone) {
            return;
        }

        $this->cleanupDone = true;

        $currentYear = (int) gmdate('Y', (int) current_time('timestamp', true));
        $cutoffYear = $currentYear - 1;
        $cutoffDate = sprintf('%04d-01-01', $cutoffYear);

        $this->repository->deleteEndingBefore($cutoffDate);
    }

    private function migrateLegacyIfNeeded(): void
    {
        if ($this->legacyMigrated) {
            return;
        }

        $this->legacyMigrated = true;

        if ($this->repository->countAll() > 0) {
            return;
        }

        $legacy = $this->settings->getHolidays();

        if (empty($legacy)) {
            return;
        }

        $now = current_time('mysql', true);

        foreach ($legacy as $date) {
            if (! is_string($date)) {
                continue;
            }

            $date = trim($date);

            if ($date === '') {
                continue;
            }

            $parsed = \DateTimeImmutable::createFromFormat('Y-m-d', $date, new \DateTimeZone('UTC'));

            if (! $parsed || $parsed->format('Y-m-d') !== $date) {
                continue;
            }

            $this->repository->insert($date, $date, 'holiday', $now);
        }

        $this->settings->update(['holidays' => []]);
    }

    /**
     * @return array{0:string,1:string}
     */
    private function normalizeRange(string $startDate, string $endDate): array
    {
        $start = $this->parseDate($startDate);
        $end = $this->parseDate($endDate);

        if ($end < $start) {
            [$start, $end] = [$end, $start];
        }

        return [$start->format('Y-m-d'), $end->format('Y-m-d')];
    }

    private function parseDate(string $value): \DateTimeImmutable
    {
        $value = trim($value);
        $date = \DateTimeImmutable::createFromFormat('Y-m-d', $value, new \DateTimeZone('UTC'));

        if (! $date || $date->format('Y-m-d') !== $value) {
            throw new ValidationException(__('Dates must be in YYYY-MM-DD format.', 'timesuite'));
        }

        return $date->setTime(0, 0, 0);
    }

    private function normalizeType(string $type): string
    {
        $normalized = sanitize_key($type);

        if ($normalized === 'half-day' || $normalized === 'half_day') {
            $normalized = 'half_holiday';
        }

        return $normalized;
    }
}
