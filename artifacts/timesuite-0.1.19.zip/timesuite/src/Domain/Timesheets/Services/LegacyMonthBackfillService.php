<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Services;

use Timesuite\Domain\Timesheets\Repositories\MonthlyTimesheetRepository;
use wpdb;

/**
 * One-time backfill (P1.2, see docs/timesheet-status-investigation.md §11)
 * that materializes legacy-only `timesuite_month_YYYY_MM` user-meta entries
 * into `wp_timesuite_monthly_timesheets`, closing the gap the lazy
 * read-path materialization (§3.1/§3.2) leaves open for months nobody has
 * viewed yet.
 *
 * Driven by the `wp timesuite backfill-legacy-months` CLI command
 * (Plugin::registerCliCommands()) rather than an automatic upgrade step —
 * a full wp_usermeta scan is too heavy/unobservable to run implicitly on
 * every plugin boot or version upgrade.
 *
 * Safety properties, all load-bearing:
 * - Insert-only: never overwrites a canonical row that already exists,
 *   including one that appears between the candidate scan and the write
 *   (see MonthlyTimesheetRepository::insertHeaderIfAbsent()).
 * - Strict meta-key validation before any write (see
 *   parseLegacyMetaKey()) — the scan query's LIKE/SUBSTRING filtering is
 *   deliberately loose (candidate-finding only) and must not be trusted
 *   for a write decision.
 * - Legacy user-meta is never deleted — it stays as the recoverable
 *   source of truth even after materialization.
 * - Dry-run performs zero writes.
 */
class LegacyMonthBackfillService
{
    private const LEGACY_META_PREFIX = 'timesuite_month_';

    public function __construct(
        private wpdb $wpdb,
        private MonthlyTimesheetRepository $repository
    ) {
    }

    /**
     * @return array{
     *     scanned: int,
     *     materialized: int,
     *     skipped_existing: int,
     *     skipped_invalid: int,
     *     failed: array<int, array{user_id: int, month: string, error: string}>,
     *     last_umeta_id: int,
     *     dry_run: bool
     * }
     */
    public function run(bool $dryRun = false, int $batchSize = 500): array
    {
        $summary = [
            'scanned' => 0,
            'materialized' => 0,
            'skipped_existing' => 0,
            'skipped_invalid' => 0,
            'failed' => [],
            'last_umeta_id' => 0,
            'dry_run' => $dryRun,
        ];

        $afterUmetaId = 0;

        while (true) {
            $candidates = $this->repository->findLegacyMonthCandidates($afterUmetaId, $batchSize);

            if (empty($candidates)) {
                break;
            }

            foreach ($candidates as $row) {
                $umetaId = (int) ($row['umeta_id'] ?? 0);
                $afterUmetaId = max($afterUmetaId, $umetaId);
                $summary['scanned']++;

                $parsed = $this->parseLegacyMetaKey((string) ($row['meta_key'] ?? ''));

                if (null === $parsed) {
                    $summary['skipped_invalid']++;
                    continue;
                }

                [$year, $month] = $parsed;
                $userId = (int) ($row['user_id'] ?? 0);

                try {
                    $outcome = $this->materializeOne($userId, $year, $month, $dryRun);

                    if ('materialized' === $outcome) {
                        $summary['materialized']++;
                    } else {
                        $summary['skipped_existing']++;
                    }
                } catch (\Throwable $e) {
                    $summary['failed'][] = [
                        'user_id' => $userId,
                        'month' => sprintf('%04d-%02d', $year, $month),
                        'error' => $e->getMessage(),
                    ];
                }
            }

            $summary['last_umeta_id'] = $afterUmetaId;

            if (count($candidates) < $batchSize) {
                break;
            }
        }

        return $summary;
    }

    /**
     * Strictly validates a meta_key before it's allowed anywhere near a
     * write. The scan query's LIKE pattern is loose by design (it mirrors
     * HealthController::findLegacyOnlyMonths()'s candidate-finding
     * approach) — a key like `timesuite_month_xxxx_ab` or
     * `timesuite_month_2026_13` can pass that filter. This is the actual
     * gate: exactly 4 digits for year, exactly 2 digits for month, month
     * in 1-12.
     *
     * @return array{0: int, 1: int}|null [year, month] or null if invalid.
     */
    private function parseLegacyMetaKey(string $metaKey): ?array
    {
        if (1 !== preg_match('/^timesuite_month_(\d{4})_(\d{2})$/', $metaKey, $matches)) {
            return null;
        }

        $year = (int) $matches[1];
        $month = (int) $matches[2];

        if ($month < 1 || $month > 12) {
            return null;
        }

        return [$year, $month];
    }

    /**
     * @return 'materialized'|'skipped_existing'
     */
    private function materializeOne(int $userId, int $year, int $month, bool $dryRun): string
    {
        $legacy = $this->loadLegacyMonth($userId, $year, $month);

        if (null === $legacy) {
            // Meta existed at scan time but is gone or no longer an array
            // by write time (e.g. deleted or overwritten in between) --
            // nothing to materialize.
            return 'skipped_existing';
        }

        if ($dryRun) {
            // Truly read-only: report what WOULD happen, write nothing.
            // Because no insert is attempted, a dry run cannot observe a
            // race that only manifests at write time -- that's what the
            // insert-if-absent guard in the real run is for.
            return 'materialized';
        }

        $entries = is_array($legacy['entries'] ?? null) ? $legacy['entries'] : [];
        $approvals = is_array($legacy['approvals'] ?? null) ? $legacy['approvals'] : [];

        // Header + entries are materialized as a single atomic unit (see
        // MonthlyTimesheetRepository::materializeIfAbsent()) -- if entries
        // fail to write after the header insert already succeeded, the
        // whole thing is rolled back rather than leaving a canonical header
        // with no entries behind (which would be invisible to both future
        // backfill runs and the lazy read-path from then on).
        $timesheetId = $this->repository->materializeIfAbsent($userId, $year, $month, $legacy, $entries, $approvals);

        if (null === $timesheetId) {
            // The atomic insert-only guard caught a row that already
            // existed -- either the scan's own LEFT JOIN missed it, or it
            // was created by something else between the scan and this
            // write. Either way: not overwritten, correctly counted as
            // skipped rather than materialized.
            return 'skipped_existing';
        }

        return 'materialized';
    }

    /**
     * Deliberately duplicated from MonthlyTimesheetService::loadLegacyMonth()
     * / TimesheetApprovalService::loadLegacyMonth() (same ~10-line block,
     * same reasoning as the §3.1 "architecture note" in
     * docs/timesheet-status-investigation.md: a small, documented,
     * cross-referenced duplication here is lower-risk than making this new,
     * narrow, CLI-only service depend on either of those services' private
     * internals or forcing a wider shared-repository consolidation just for
     * this change.
     *
     * @return array<string, mixed>|null
     */
    private function loadLegacyMonth(int $userId, int $year, int $month): ?array
    {
        $data = get_user_meta($userId, self::LEGACY_META_PREFIX . sprintf('%04d_%02d', $year, $month), true);

        if (! is_array($data)) {
            return null;
        }

        if (! isset($data['entries']) || ! is_array($data['entries'])) {
            $data['entries'] = [];
        }

        if (! isset($data['approvals']) || ! is_array($data['approvals'])) {
            $data['approvals'] = [];
        }

        return $data;
    }
}
