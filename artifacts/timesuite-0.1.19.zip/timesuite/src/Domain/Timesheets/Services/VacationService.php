<?php

declare(strict_types=1);

namespace Timesuite\Domain\Timesheets\Services;

use Timesuite\Core\Settings;
use wpdb;

/**
 * Service for tracking vacation / annual leave days and sick days.
 *
 * External UI still works in days, but the internal balance model uses
 * standardized leave hours based on the company leave day setting.
 *
 * Legacy day-based meta is still supported as a fallback:
 * - User meta: `timesuite_vacation_days_contract` - Annual vacation allocation
 * - User meta: `timesuite_sick_days_contract` - Annual sick days allocation
 * - Timesheet entries: Type 'day_off' (and legacy vacation types) - Paid time off used
 * - Timesheet entries: Type 'sick_day' (and legacy sick types) - Sick days used
 */
class VacationService
{
    private const META_VACATION_CONTRACT = 'timesuite_vacation_days_contract';
    private const META_SICK_CONTRACT = 'timesuite_sick_days_contract';
    private const META_VACATION_BALANCE_ADJUSTMENT = 'timesuite_vacation_balance_adjustment';
    private const META_SICK_BALANCE_ADJUSTMENT = 'timesuite_sick_balance_adjustment';
    private const META_VACATION_CONTRACT_HOURS = 'timesuite_vacation_contract_hours';
    private const META_SICK_CONTRACT_HOURS = 'timesuite_sick_contract_hours';
    private const META_VACATION_BALANCE_ADJUSTMENT_HOURS = 'timesuite_vacation_balance_adjustment_hours';
    private const META_SICK_BALANCE_ADJUSTMENT_HOURS = 'timesuite_sick_balance_adjustment_hours';
    private const META_VACATION_CARRYOVER_CAP_DAYS = 'timesuite_vacation_carryover_cap_days';
    private const META_SICK_CARRYOVER_CAP_DAYS = 'timesuite_sick_carryover_cap_days';
    private const META_VACATION_CARRYOVER_HOURS_PREFIX = 'timesuite_vacation_carryover_hours_';
    private const META_SICK_CARRYOVER_HOURS_PREFIX = 'timesuite_sick_carryover_hours_';
    private const META_EMPLOYMENT_END_DATE = 'timesuite_employment_end_date';
    private const OPTION_CARRYOVER_LAST_RUN_YEAR = 'timesuite_annual_carryover_last_run_year';
    private const VACATION_DAY_TYPES = ['day_off', 'pto', 'vacation', 'annual_leave'];
    private const SICK_DAY_TYPES = ['sick_day', 'sick', 'illness'];
    private ?bool $hasScheduledHoursColumn = null;

    public function __construct(
        private wpdb $wpdb,
        private Settings $settings,
        private HolidayRangeService $holidayRangeService
    ) {
    }

    /**
     * Get vacation contract days for a user.
     * Falls back to system default if not set.
     */
    public function getContractDays(int $userId): int
    {
        return (int) round($this->standardHoursToDisplayDays($this->getVacationContractHours($userId)));
    }

    /**
     * Set vacation contract days for a user.
     */
    public function setContractDays(int $userId, int $days): void
    {
        update_user_meta($userId, self::META_VACATION_CONTRACT_HOURS, $this->daysToStandardHours($days));
        update_user_meta($userId, self::META_VACATION_CONTRACT, $days);
    }

    /**
     * Get sick days contract for a user.
     * Falls back to system default if not set.
     */
    public function getSickDaysContract(int $userId): int
    {
        return (int) round($this->standardHoursToDisplayDays($this->getSickContractHours($userId)));
    }

    /**
     * Set sick days contract for a user.
     */
    public function setSickDaysContract(int $userId, int $days): void
    {
        update_user_meta($userId, self::META_SICK_CONTRACT_HOURS, $this->daysToStandardHours($days));
        update_user_meta($userId, self::META_SICK_CONTRACT, $days);
    }

    public function getVacationCarryoverCapDays(int $userId): ?float
    {
        return $this->getUserCarryoverCapDays($userId, self::META_VACATION_CARRYOVER_CAP_DAYS);
    }

    public function getSickCarryoverCapDays(int $userId): ?float
    {
        return $this->getUserCarryoverCapDays($userId, self::META_SICK_CARRYOVER_CAP_DAYS);
    }

    public function setVacationCarryoverCapDays(int $userId, ?float $days): void
    {
        $this->setUserCarryoverCapDays($userId, self::META_VACATION_CARRYOVER_CAP_DAYS, $days);
    }

    public function setSickCarryoverCapDays(int $userId, ?float $days): void
    {
        $this->setUserCarryoverCapDays($userId, self::META_SICK_CARRYOVER_CAP_DAYS, $days);
    }

    /**
     * Get sick days used in a specific year.
     */
    public function getSickDaysUsedInYear(int $userId, int $year): float
    {
        $usedHoursByUser = $this->getSickHoursUsedByUsers([$userId], $year);

        return $this->standardHoursToDisplayDays($usedHoursByUser[$userId] ?? 0.0);
    }

    /**
     * Get sick days remaining for a user in a specific year.
     */
    public function getSickDaysRemaining(int $userId, int $year): float
    {
        $contractHours = $this->getSickContractHours($userId);
        $usedHours = $this->getSickHoursUsedByUsers([$userId], $year)[$userId] ?? 0.0;
        $accruedHours = $this->getAccruedBalance($userId, $year, $contractHours, 'sick');
        $adjustmentHours = $this->getBalanceAdjustmentHours(
            $userId,
            self::META_SICK_BALANCE_ADJUSTMENT_HOURS,
            self::META_SICK_BALANCE_ADJUSTMENT
        );

        return $this->standardHoursToDisplayDays($accruedHours - $usedHours + $adjustmentHours);
    }

    /**
     * Get vacation days used in a specific year.
     */
    public function getDaysUsedInYear(int $userId, int $year): float
    {
        $usedHoursByUser = $this->getVacationHoursUsedByUsers([$userId], $year);

        return $this->standardHoursToDisplayDays($usedHoursByUser[$userId] ?? 0.0);
    }

    /**
     * Get days used by specific entry types in a year.
     *
     * @param string[] $types
     */
    private function getDaysUsedByTypes(int $userId, int $year, array $types): float
    {
        $timesheetTable = $this->wpdb->prefix . 'timesuite_monthly_timesheets';
        $entriesTable = $this->wpdb->prefix . 'timesuite_monthly_entries';

        $typesList = "'" . implode("','", $types) . "'";
        $standardHours = $this->getLeaveStandardDayHours();
        $scheduledHoursExpr = $this->hasScheduledHoursColumn()
            ? 'COALESCE(me.scheduled_hours, %f)'
            : '%f';

        $sql = $this->wpdb->prepare(
            "SELECT SUM(
                CASE 
                    WHEN me.hours IS NOT NULL AND me.hours > 0 THEN me.hours / %f
                    ELSE {$scheduledHoursExpr} / %f
                END
            ) as days_used
            FROM {$entriesTable} me
            JOIN {$timesheetTable} mt ON me.timesheet_id = mt.id
            WHERE mt.user_id = %d 
            AND mt.year = %d
            AND me.type IN ({$typesList})",
            $standardHours,
            $standardHours,
            $standardHours,
            $userId,
            $year
        );

        $result = $this->wpdb->get_var($sql);

        return $result ? round((float) $result, 1) : 0.0;
    }

    /**
     * Get vacation days remaining for a user in a specific year.
     */
    public function getDaysRemaining(int $userId, int $year): float
    {
        $contractHours = $this->getVacationContractHours($userId);
        $usedHours = $this->getVacationHoursUsedByUsers([$userId], $year)[$userId] ?? 0.0;
        $accruedHours = $this->getAccruedBalance($userId, $year, $contractHours, 'vacation');
        $adjustmentHours = $this->getBalanceAdjustmentHours(
            $userId,
            self::META_VACATION_BALANCE_ADJUSTMENT_HOURS,
            self::META_VACATION_BALANCE_ADJUSTMENT
        );

        return $this->standardHoursToDisplayDays($accruedHours - $usedHours + $adjustmentHours);
    }

    /**
     * Alias for getContractDays() for API consistency.
     */
    public function getVacationDaysContract(int $userId): int
    {
        return $this->getContractDays($userId);
    }

    /**
     * Alias for getDaysUsedInYear() for API consistency.
     */
    public function getVacationDaysUsedInYear(int $userId, int $year): float
    {
        return $this->getDaysUsedInYear($userId, $year);
    }

    /**
     * Alias for getDaysRemaining() for API consistency.
     */
    public function getVacationDaysRemaining(int $userId, int $year): float
    {
        return $this->getDaysRemaining($userId, $year);
    }

    /**
     * Get bulk vacation stats for multiple users.
     *
     * @param int[] $userIds
     * @return array<int, array{used: float, remaining: float}>
     */
    public function getBulkVacationStats(array $userIds, int $year): array
    {
        $result = [];
        $bulkStats = $this->getBulkStats($userIds, $year);

        foreach ($bulkStats as $userId => $stats) {
            $result[$userId] = [
                'used' => $stats['vacation_used'],
                'remaining' => $stats['vacation_remaining'],
            ];
        }

        return $result;
    }

    /**
     * Get bulk sick stats for multiple users.
     *
     * @param int[] $userIds
     * @return array<int, array{used: float, remaining: float}>
     */
    public function getBulkSickStats(array $userIds, int $year): array
    {
        $result = [];
        $bulkStats = $this->getBulkStats($userIds, $year);

        foreach ($bulkStats as $userId => $stats) {
            $result[$userId] = [
                'used' => $stats['sick_used'],
                'remaining' => $stats['sick_remaining'],
            ];
        }

        return $result;
    }

    /**
     * Get full vacation and sick day stats for a user.
     *
     * @return array{
     *   vacation_contract: int,
     *   vacation_used: float,
     *   vacation_remaining: float,
     *   sick_contract: int,
     *   sick_used: float,
     *   sick_remaining: float
     * }
     */
    public function getStats(int $userId, ?int $year = null): array
    {
        $hours = $this->getHoursStats($userId, $year);

        $vacationContract = (int) round($this->standardHoursToDisplayDays($hours['vacation_contract_hours']));
        $vacationUsed = $this->standardHoursToDisplayDays($hours['vacation_used_hours']);
        $vacationRemaining = $this->standardHoursToDisplayDays(
            $hours['vacation_accrued_hours'] - $hours['vacation_used_hours'] + $hours['vacation_adjustment_hours']
        );

        $sickContract = (int) round($this->standardHoursToDisplayDays($hours['sick_contract_hours']));
        $sickUsed = $this->standardHoursToDisplayDays($hours['sick_used_hours']);
        $sickRemaining = $this->standardHoursToDisplayDays(
            $hours['sick_accrued_hours'] - $hours['sick_used_hours'] + $hours['sick_adjustment_hours']
        );

        return [
            // Legacy keys for backwards compatibility
            'contract_days' => $vacationContract,
            'days_used' => $vacationUsed,
            'days_remaining' => $vacationRemaining,
            // New explicit keys
            'vacation_contract' => $vacationContract,
            'vacation_used' => $vacationUsed,
            'vacation_remaining' => $vacationRemaining,
            'sick_contract' => $sickContract,
            'sick_used' => $sickUsed,
            'sick_remaining' => $sickRemaining,
        ];
    }

    /**
     * Return the raw standardized-hour balances used by the display-layer day stats.
     *
     * @return array{
     *   year: int,
     *   standard_day_hours: float,
     *   vacation_contract_hours: float,
     *   vacation_used_hours: float,
     *   vacation_accrued_hours: float,
     *   vacation_adjustment_hours: float,
     *   vacation_remaining_hours: float,
     *   sick_contract_hours: float,
     *   sick_used_hours: float,
     *   sick_accrued_hours: float,
     *   sick_adjustment_hours: float,
     *   sick_remaining_hours: float
     * }
     */
    public function getHoursStats(int $userId, ?int $year = null): array
    {
        $year = $year ?? (int) gmdate('Y');

        $vacationContractHours = $this->getVacationContractHours($userId);
        $vacationUsedHours = $this->getVacationHoursUsedByUsers([$userId], $year)[$userId] ?? 0.0;
        $vacationAccruedHours = $this->getAccruedBalance($userId, $year, $vacationContractHours, 'vacation');
        $vacationAdjustmentHours = $this->getBalanceAdjustmentHours(
            $userId,
            self::META_VACATION_BALANCE_ADJUSTMENT_HOURS,
            self::META_VACATION_BALANCE_ADJUSTMENT
        );
        $vacationRemainingHours = $this->roundHours(
            $vacationAccruedHours - $vacationUsedHours + $vacationAdjustmentHours
        );

        $sickContractHours = $this->getSickContractHours($userId);
        $sickUsedHours = $this->getSickHoursUsedByUsers([$userId], $year)[$userId] ?? 0.0;
        $sickAccruedHours = $this->getAccruedBalance($userId, $year, $sickContractHours, 'sick');
        $sickAdjustmentHours = $this->getBalanceAdjustmentHours(
            $userId,
            self::META_SICK_BALANCE_ADJUSTMENT_HOURS,
            self::META_SICK_BALANCE_ADJUSTMENT
        );
        $sickRemainingHours = $this->roundHours(
            $sickAccruedHours - $sickUsedHours + $sickAdjustmentHours
        );

        return [
            'year' => $year,
            'standard_day_hours' => $this->getLeaveStandardDayHours(),
            'vacation_contract_hours' => $vacationContractHours,
            'vacation_used_hours' => $vacationUsedHours,
            'vacation_accrued_hours' => $vacationAccruedHours,
            'vacation_adjustment_hours' => $vacationAdjustmentHours,
            'vacation_remaining_hours' => $vacationRemainingHours,
            'sick_contract_hours' => $sickContractHours,
            'sick_used_hours' => $sickUsedHours,
            'sick_accrued_hours' => $sickAccruedHours,
            'sick_adjustment_hours' => $sickAdjustmentHours,
            'sick_remaining_hours' => $sickRemainingHours,
        ];
    }

    /**
     * Get vacation and sick day stats for multiple users.
     *
     * @param int[] $userIds
     * @return array<int, array{
     *   contract_days: int,
     *   days_used: float,
     *   days_remaining: float,
     *   vacation_contract: int,
     *   vacation_used: float,
     *   vacation_remaining: float,
     *   sick_contract: int,
     *   sick_used: float,
     *   sick_remaining: float
     * }>
     */
    public function getBulkStats(array $userIds, ?int $year = null): array
    {
        $year = $year ?? (int) gmdate('Y');
        $result = [];

        // Get default values
        $vacationContractHours = [];
        $sickContractHours = [];

        foreach ($userIds as $rawUserId) {
            $userId = (int) $rawUserId;
            $vacationContractHours[$userId] = $this->getVacationContractHours($userId);
            $sickContractHours[$userId] = $this->getSickContractHours($userId);
        }

        $vacationUsedHours = $this->getVacationHoursUsedByUsers($userIds, $year);
        $sickUsedHours = $this->getSickHoursUsedByUsers($userIds, $year);

        // Build result
        foreach ($userIds as $userId) {
            $vContractHours = $vacationContractHours[$userId];
            $vUsedHours = $vacationUsedHours[$userId] ?? 0.0;
            $sContractHours = $sickContractHours[$userId];
            $sUsedHours = $sickUsedHours[$userId] ?? 0.0;
            $vAccruedHours = $this->getAccruedBalance($userId, $year, $vContractHours, 'vacation');
            $sAccruedHours = $this->getAccruedBalance($userId, $year, $sContractHours, 'sick');
            $vAdjustmentHours = $this->getBalanceAdjustmentHours(
                $userId,
                self::META_VACATION_BALANCE_ADJUSTMENT_HOURS,
                self::META_VACATION_BALANCE_ADJUSTMENT
            );
            $sAdjustmentHours = $this->getBalanceAdjustmentHours(
                $userId,
                self::META_SICK_BALANCE_ADJUSTMENT_HOURS,
                self::META_SICK_BALANCE_ADJUSTMENT
            );

            $vContract = (int) round($this->standardHoursToDisplayDays($vContractHours));
            $vUsed = $this->standardHoursToDisplayDays($vUsedHours);
            $vRemaining = $this->standardHoursToDisplayDays($vAccruedHours - $vUsedHours + $vAdjustmentHours);
            $sContract = (int) round($this->standardHoursToDisplayDays($sContractHours));
            $sUsed = $this->standardHoursToDisplayDays($sUsedHours);
            $sRemaining = $this->standardHoursToDisplayDays($sAccruedHours - $sUsedHours + $sAdjustmentHours);

            $result[$userId] = [
                // Legacy keys for backwards compatibility
                'contract_days' => $vContract,
                'days_used' => $vUsed,
                'days_remaining' => $vRemaining,
                // Vacation
                'vacation_contract' => $vContract,
                'vacation_used' => $vUsed,
                'vacation_remaining' => $vRemaining,
                // Sick days
                'sick_contract' => $sContract,
                'sick_used' => $sUsed,
                'sick_remaining' => $sRemaining,
            ];
        }

        return $result;
    }

    public function setVacationRemainingBalance(int $userId, float $remaining, ?int $year = null): void
    {
        $year = $year ?? (int) gmdate('Y');
        $contractHours = $this->getVacationContractHours($userId);
        $usedHours = $this->getVacationHoursUsedByUsers([$userId], $year)[$userId] ?? 0.0;
        $accruedHours = $this->getAccruedBalance($userId, $year, $contractHours, 'vacation');
        $baseRemainingHours = $accruedHours - $usedHours;
        $targetRemainingHours = $this->daysToStandardHours($remaining);
        $adjustmentHours = $targetRemainingHours - $baseRemainingHours;

        $this->setBalanceAdjustmentHours(
            $userId,
            self::META_VACATION_BALANCE_ADJUSTMENT_HOURS,
            self::META_VACATION_BALANCE_ADJUSTMENT,
            $adjustmentHours
        );
    }

    public function setSickRemainingBalance(int $userId, float $remaining, ?int $year = null): void
    {
        $year = $year ?? (int) gmdate('Y');
        $contractHours = $this->getSickContractHours($userId);
        $usedHours = $this->getSickHoursUsedByUsers([$userId], $year)[$userId] ?? 0.0;
        $accruedHours = $this->getAccruedBalance($userId, $year, $contractHours, 'sick');
        $baseRemainingHours = $accruedHours - $usedHours;
        $targetRemainingHours = $this->daysToStandardHours($remaining);
        $adjustmentHours = $targetRemainingHours - $baseRemainingHours;

        $this->setBalanceAdjustmentHours(
            $userId,
            self::META_SICK_BALANCE_ADJUSTMENT_HOURS,
            self::META_SICK_BALANCE_ADJUSTMENT,
            $adjustmentHours
        );
    }

    private function getBalanceAdjustmentHours(int $userId, string $hoursMetaKey, string $legacyDaysMetaKey): float
    {
        $storedHours = get_user_meta($userId, $hoursMetaKey, true);

        if ($storedHours !== '' && $storedHours !== null && is_numeric($storedHours)) {
            return $this->roundHours((float) $storedHours);
        }

        $storedDays = get_user_meta($userId, $legacyDaysMetaKey, true);

        if ($storedDays === '' || $storedDays === null || ! is_numeric($storedDays)) {
            return 0.0;
        }

        return $this->daysToStandardHours((float) $storedDays);
    }

    private function setBalanceAdjustmentHours(
        int $userId,
        string $hoursMetaKey,
        string $legacyDaysMetaKey,
        float $value
    ): void
    {
        $rounded = $this->roundHours($value);

        if (abs($rounded) < 0.005) {
            delete_user_meta($userId, $hoursMetaKey);
            delete_user_meta($userId, $legacyDaysMetaKey);
            return;
        }

        update_user_meta($userId, $hoursMetaKey, $rounded);
        delete_user_meta($userId, $legacyDaysMetaKey);
    }

    /**
     * Get days used by types for multiple users efficiently.
     *
     * @param int[] $userIds
     * @param string[] $types
     * @return array<int, float>
     */
    private function getBulkDaysUsedByTypes(array $userIds, int $year, array $types): array
    {
        if (empty($userIds)) {
            return [];
        }

        $timesheetTable = $this->wpdb->prefix . 'timesuite_monthly_timesheets';
        $entriesTable = $this->wpdb->prefix . 'timesuite_monthly_entries';

        $typesList = "'" . implode("','", $types) . "'";
        $userIdsList = implode(',', array_map('intval', $userIds));
        $standardHours = $this->getLeaveStandardDayHours();
        $scheduledHoursExpr = $this->hasScheduledHoursColumn()
            ? 'COALESCE(me.scheduled_hours, %f)'
            : '%f';

        $sql = $this->wpdb->prepare(
            "SELECT mt.user_id,
                SUM(
                    CASE 
                        WHEN me.hours IS NOT NULL AND me.hours > 0 THEN me.hours / %f
                        ELSE {$scheduledHoursExpr} / %f
                    END
                ) as days_used
            FROM {$entriesTable} me
            JOIN {$timesheetTable} mt ON me.timesheet_id = mt.id
            WHERE mt.user_id IN ({$userIdsList})
            AND mt.year = %d
            AND me.type IN ({$typesList})
            GROUP BY mt.user_id",
            $standardHours,
            $standardHours,
            $standardHours,
            $year
        );

        $rows = $this->wpdb->get_results($sql, ARRAY_A) ?? [];

        $result = [];
        foreach ($rows as $row) {
            $result[(int) $row['user_id']] = round((float) $row['days_used'], 1);
        }

        return $result;
    }

    private function roundBalance(float $value): float
    {
        return round($value, 1);
    }

    private function roundHours(float $value): float
    {
        return round($value, 2);
    }

    private function getAccruedBalance(int $userId, int $year, float $contractHours, string $type): float
    {
        if ($contractHours <= 0) {
            return 0.0;
        }

        $monthlyRate = $contractHours / 12;
        $hireDate = $this->getHireDate($userId);
        $employmentEndDate = $this->getEmploymentEndDate($userId);
        $monthsElapsed = $this->calculateAccrualMonths($year, $hireDate, $employmentEndDate);
        $carryoverHours = $this->getCarryoverHours($userId, $year, $type);

        return $this->roundHours($carryoverHours + ($monthlyRate * $monthsElapsed));
    }

    /**
     * Apply Jan 1 carryover caps once per year.
     *
     * @param int[] $userIds
     * @return array{applied: int, capped: int, preserved: int, skipped: int}
     */
    public function applyAnnualCarryoverCaps(array $userIds, ?int $year = null, bool $force = false): array
    {
        $year = $year ?? (int) current_time('Y');

        if (! $force && $this->getLastCarryoverRunYear() >= $year) {
            return ['applied' => 0, 'capped' => 0, 'preserved' => 0, 'skipped' => count($userIds)];
        }

        $vacationGlobalCap = (float) $this->settings->getTimeOffResetVacationDays();
        $sickGlobalCap = (float) $this->settings->getTimeOffResetSickDays();
        $vacationCapEnabled = $this->settings->isVacationCarryoverCapEnabled();
        $sickCapEnabled = $this->settings->isSickCarryoverCapEnabled();
        $applied = 0;
        $capped = 0;
        $preserved = 0;

        foreach (array_unique(array_map('intval', $userIds)) as $userId) {
            if ($userId <= 0) {
                continue;
            }

            $vacationResult = $this->applyCarryoverCapForType(
                $userId,
                $year,
                'vacation',
                $vacationCapEnabled
                    ? ($this->getVacationCarryoverCapDays($userId) ?? $vacationGlobalCap)
                    : null
            );
            $sickResult = $this->applyCarryoverCapForType(
                $userId,
                $year,
                'sick',
                $sickCapEnabled
                    ? ($this->getSickCarryoverCapDays($userId) ?? $sickGlobalCap)
                    : null
            );

            if ($vacationResult !== null || $sickResult !== null) {
                $applied++;
            }

            $capped += ($vacationResult === 'capped' ? 1 : 0) + ($sickResult === 'capped' ? 1 : 0);
            $preserved += ($vacationResult === 'preserved' ? 1 : 0) + ($sickResult === 'preserved' ? 1 : 0);
        }

        if (! $force) {
            update_option(self::OPTION_CARRYOVER_LAST_RUN_YEAR, $year);
        }

        return [
            'applied' => $applied,
            'capped' => $capped,
            'preserved' => $preserved,
            'skipped' => max(0, count($userIds) - $applied),
        ];
    }

    private function applyCarryoverCapForType(int $userId, int $year, string $type, ?float $capDays): ?string
    {
        if ($capDays !== null && $capDays < 0) {
            return null;
        }

        $previousYear = $year - 1;
        $previousRemainingDays = $type === 'sick'
            ? $this->getSickDaysRemaining($userId, $previousYear)
            : $this->getDaysRemaining($userId, $previousYear);
        $carryoverDays = $capDays === null
            ? $previousRemainingDays
            : min($previousRemainingDays, $capDays);
        $carryoverHours = $this->daysToStandardHours($carryoverDays);

        $metaKey = $type === 'sick'
            ? self::META_SICK_CARRYOVER_HOURS_PREFIX . $year
            : self::META_VACATION_CARRYOVER_HOURS_PREFIX . $year;

        update_user_meta($userId, $metaKey, $carryoverHours);

        return $capDays !== null && $previousRemainingDays > $capDays ? 'capped' : 'preserved';
    }

    private function getCarryoverHours(int $userId, int $year, string $type): float
    {
        $metaKey = $type === 'sick'
            ? self::META_SICK_CARRYOVER_HOURS_PREFIX . $year
            : self::META_VACATION_CARRYOVER_HOURS_PREFIX . $year;
        $stored = get_user_meta($userId, $metaKey, true);

        if ($stored === '' || $stored === null || ! is_numeric($stored)) {
            return 0.0;
        }

        return $this->roundHours((float) $stored);
    }

    private function getLastCarryoverRunYear(): int
    {
        $stored = get_option(self::OPTION_CARRYOVER_LAST_RUN_YEAR, 0);

        return is_numeric($stored) ? (int) $stored : 0;
    }

    private function getUserCarryoverCapDays(int $userId, string $metaKey): ?float
    {
        $stored = get_user_meta($userId, $metaKey, true);

        if ($stored === '' || $stored === null || ! is_numeric($stored)) {
            return null;
        }

        return max(0.0, (float) $stored);
    }

    private function setUserCarryoverCapDays(int $userId, string $metaKey, ?float $days): void
    {
        if ($days === null) {
            delete_user_meta($userId, $metaKey);
            return;
        }

        update_user_meta($userId, $metaKey, max(0.0, round($days, 2)));
    }

    private function calculateAccrualMonths(int $year, ?\DateTimeImmutable $hireDate, ?\DateTimeImmutable $employmentEndDate): float
    {
        $currentYear = (int) current_time('Y');

        if ($year > $currentYear) {
            return 0.0;
        }

        $endMonth = $year < $currentYear ? 12 : (int) current_time('n');
        $startMonth = 1;
        $firstMonthFraction = 1.0;
        $lastMonthFraction = 1.0;

        if ($hireDate && (int) $hireDate->format('Y') === $year) {
            $hireMonth = (int) $hireDate->format('n');
            $startMonth = $hireMonth;

            if ($year === $currentYear) {
                $currentDay = (int) current_time('j');
                if ($hireMonth === $endMonth && $currentDay < (int) $hireDate->format('j')) {
                    return 0.0;
                }
            }

            $daysInMonth = (int) $hireDate->format('t');
            $hireDay = (int) $hireDate->format('j');
            $firstMonthFraction = max(0.0, min(1.0, ($daysInMonth - $hireDay + 1) / $daysInMonth));
        }

        if ($hireDate && (int) $hireDate->format('Y') > $year) {
            return 0.0;
        }

        if ($employmentEndDate && (int) $employmentEndDate->format('Y') < $year) {
            return 0.0;
        }

        if ($employmentEndDate && (int) $employmentEndDate->format('Y') === $year) {
            $employmentEndMonth = (int) $employmentEndDate->format('n');

            if ($employmentEndMonth < $endMonth) {
                $endMonth = $employmentEndMonth;
                $lastMonthFraction = max(
                    0.0,
                    min(1.0, (int) $employmentEndDate->format('j') / (int) $employmentEndDate->format('t'))
                );
            } elseif (
                $employmentEndMonth === $endMonth
                && (
                    $year < $currentYear
                    || (int) $employmentEndDate->format('j') <= (int) current_time('j')
                )
            ) {
                $lastMonthFraction = max(
                    0.0,
                    min(1.0, (int) $employmentEndDate->format('j') / (int) $employmentEndDate->format('t'))
                );
            }
        }

        if ($endMonth < $startMonth) {
            return 0.0;
        }

        $months = (float) ($endMonth - $startMonth + 1);

        if ($startMonth === $endMonth) {
            if ($hireDate && (int) $hireDate->format('Y') === $year && (int) $hireDate->format('n') === $startMonth) {
                $startDay = (int) $hireDate->format('j');
                $endDay = $employmentEndDate && (int) $employmentEndDate->format('Y') === $year && (int) $employmentEndDate->format('n') === $startMonth
                    ? (int) $employmentEndDate->format('j')
                    : (int) $hireDate->format('t');

                return max(0.0, min(1.0, ($endDay - $startDay + 1) / (int) $hireDate->format('t')));
            }

            return $lastMonthFraction;
        }

        if ($startMonth === 1 && $firstMonthFraction >= 1.0 && $lastMonthFraction >= 1.0) {
            return $months;
        }

        return max(0.0, $months - 2 + $firstMonthFraction + $lastMonthFraction);
    }

    private function getHireDate(int $userId): ?\DateTimeImmutable
    {
        $value = get_user_meta($userId, 'timesuite_hire_date', true);

        if (! is_string($value) || '' === trim($value)) {
            return null;
        }

        $timezone = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
        $date = \DateTimeImmutable::createFromFormat('Y-m-d', trim($value), $timezone);

        if (! $date instanceof \DateTimeImmutable) {
            return null;
        }

        return $date;
    }

    private function getEmploymentEndDate(int $userId): ?\DateTimeImmutable
    {
        $value = get_user_meta($userId, self::META_EMPLOYMENT_END_DATE, true);

        if (! is_string($value) || '' === trim($value)) {
            return null;
        }

        $timezone = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
        $date = \DateTimeImmutable::createFromFormat('Y-m-d', trim($value), $timezone);

        if (! $date instanceof \DateTimeImmutable) {
            return null;
        }

        return $date;
    }

    /**
     * Calculate vacation days used for multiple users, excluding non-working days/holidays.
     *
     * @param int[] $userIds
     * @return array<int, float>
     */
    private function getVacationHoursUsedByUsers(array $userIds, int $year): array
    {
        if (empty($userIds)) {
            return [];
        }

        $entries = $this->dedupeEntriesByUserDate(
            $this->getEntriesForUsers($userIds, $year, array_merge(self::VACATION_DAY_TYPES, ['half_working']))
        );
        $holidayMap = $this->getHolidayMapForYear($year);
        $workWeeks = [];

        foreach ($userIds as $userId) {
            $workWeeks[(int) $userId] = $this->getUserWorkWeek((int) $userId);
        }

        $usedHours = [];

        foreach ($entries as $row) {
            $userId = (int) ($row['user_id'] ?? 0);
            $date = isset($row['work_date']) ? (string) $row['work_date'] : '';
            $type = isset($row['type']) ? (string) $row['type'] : '';
            $coverageSource = isset($row['coverage_source']) ? (string) $row['coverage_source'] : '';
            $normalizedType = sanitize_key($type);
            $normalizedCoverage = sanitize_key($coverageSource);

            if (! $this->isEntryApproved($row)) {
                continue;
            }

            if ($userId <= 0 || $date === '') {
                continue;
            }

            if ($normalizedType === 'half_working' && $normalizedCoverage === 'half_day_off') {
                if (! $this->shouldCountVacationEntry('day_off', $date, $workWeeks[$userId] ?? [], $holidayMap)) {
                    continue;
                }
                $leaveHours = $this->resolveEntryLeaveHours($row);
            } else {
                if (! $this->shouldCountVacationEntry($normalizedType, $date, $workWeeks[$userId] ?? [], $holidayMap)) {
                    continue;
                }
                $leaveHours = $this->resolveEntryLeaveHours($row);
            }

            $usedHours[$userId] = $this->roundHours(($usedHours[$userId] ?? 0.0) + $leaveHours);
        }

        return $usedHours;
    }

    /**
     * Calculate sick days used for multiple users, excluding non-working days/holidays.
     *
     * @param int[] $userIds
     * @return array<int, float>
     */
    private function getSickHoursUsedByUsers(array $userIds, int $year): array
    {
        if (empty($userIds)) {
            return [];
        }

        $entries = $this->dedupeEntriesByUserDate(
            $this->getEntriesForUsers($userIds, $year, array_merge(self::SICK_DAY_TYPES, ['half_working']))
        );
        $holidayMap = $this->getHolidayMapForYear($year);
        $workWeeks = [];

        foreach ($userIds as $userId) {
            $workWeeks[(int) $userId] = $this->getUserWorkWeek((int) $userId);
        }

        $usedHours = [];

        foreach ($entries as $row) {
            $userId = (int) ($row['user_id'] ?? 0);
            $date = isset($row['work_date']) ? (string) $row['work_date'] : '';
            $type = isset($row['type']) ? (string) $row['type'] : '';
            $coverageSource = isset($row['coverage_source']) ? (string) $row['coverage_source'] : '';
            $normalizedType = sanitize_key($type);
            $normalizedCoverage = sanitize_key($coverageSource);

            if (! $this->isEntryApproved($row)) {
                continue;
            }

            if ($userId <= 0 || $date === '') {
                continue;
            }

            if ($normalizedType === 'half_working' && $normalizedCoverage === 'half_sick_day') {
                if (! $this->shouldCountSickEntry('sick_day', $date, $workWeeks[$userId] ?? [], $holidayMap)) {
                    continue;
                }
                $leaveHours = $this->resolveEntryLeaveHours($row);
            } else {
                if (! $this->shouldCountSickEntry($normalizedType, $date, $workWeeks[$userId] ?? [], $holidayMap)) {
                    continue;
                }
                $leaveHours = $this->resolveEntryLeaveHours($row);
            }

            $usedHours[$userId] = $this->roundHours(($usedHours[$userId] ?? 0.0) + $leaveHours);
        }

        return $usedHours;
    }

    /**
     * @param int[] $userIds
     * @param string[] $types
     * @return array<int, array<string, mixed>>
     */
    private function getEntriesForUsers(array $userIds, int $year, array $types): array
    {
        $timesheetTable = $this->wpdb->prefix . 'timesuite_monthly_timesheets';
        $entriesTable = $this->wpdb->prefix . 'timesuite_monthly_entries';

        $userIdsList = implode(',', array_map('intval', $userIds));
        $typesList = "'" . implode("','", $types) . "'";
        $scheduledHoursSelect = $this->hasScheduledHoursColumn()
            ? 'me.scheduled_hours'
            : 'NULL as scheduled_hours';

        $sql = $this->wpdb->prepare(
            "SELECT mt.id as timesheet_id, mt.user_id, mt.status as timesheet_status, me.work_date, me.type, me.hours, {$scheduledHoursSelect}, me.coverage_source, me.approval_status
            FROM {$entriesTable} me
            JOIN {$timesheetTable} mt ON me.timesheet_id = mt.id
            WHERE mt.user_id IN ({$userIdsList})
            AND mt.year = %d
            AND me.type IN ({$typesList})
            ORDER BY mt.id DESC, me.work_date ASC",
            $year
        );

        return $this->wpdb->get_results($sql, ARRAY_A) ?? [];
    }

    /**
     * Keep only the latest row per user/date to avoid double-counting if multiple
     * timesheet versions are present for the same month in historical data.
     *
     * @param array<int, array<string, mixed>> $rows
     * @return array<int, array<string, mixed>>
     */
    private function dedupeEntriesByUserDate(array $rows): array
    {
        $deduped = [];

        foreach ($rows as $row) {
            $userId = (int) ($row['user_id'] ?? 0);
            $date = (string) ($row['work_date'] ?? '');

            if ($userId <= 0 || $date === '') {
                continue;
            }

            $key = $userId . '|' . $date;
            $timesheetId = (int) ($row['timesheet_id'] ?? 0);

            if (! isset($deduped[$key])) {
                $deduped[$key] = $row;
                continue;
            }

            $existingTimesheetId = (int) ($deduped[$key]['timesheet_id'] ?? 0);

            if ($timesheetId >= $existingTimesheetId) {
                $deduped[$key] = $row;
            }
        }

        return array_values($deduped);
    }

    /**
     * @return array<string, string> Map of Y-m-d => holiday type.
     */
    private function getHolidayMapForYear(int $year): array
    {
        $startDate = sprintf('%04d-01-01', $year);
        $endDate = sprintf('%04d-12-31', $year);

        return $this->holidayRangeService->getHolidayMapForRange($startDate, $endDate);
    }

    /**
     * @param array<string, string> $holidayMap
     */
    private function shouldCountVacationEntry(
        string $type,
        string $date,
        array $workWeek,
        array $holidayMap
    ): bool {
        $normalized = sanitize_key($type);

        if (! in_array($normalized, self::VACATION_DAY_TYPES, true)) {
            return false;
        }

        if (isset($holidayMap[$date])) {
            return false;
        }

        $dayCode = gmdate('D', strtotime($date));
        if (! in_array($dayCode, $workWeek, true)) {
            return false;
        }

        return true;
    }

    /**
     * @param array<string, string> $holidayMap
     */
    private function shouldCountSickEntry(
        string $type,
        string $date,
        array $workWeek,
        array $holidayMap
    ): bool {
        $normalized = sanitize_key($type);

        if (! in_array($normalized, self::SICK_DAY_TYPES, true)) {
            return false;
        }

        if (isset($holidayMap[$date])) {
            return false;
        }

        $dayCode = gmdate('D', strtotime($date));
        if (! in_array($dayCode, $workWeek, true)) {
            return false;
        }

        return true;
    }

    private function getLeaveStandardDayHours(): float
    {
        $standard = (float) $this->settings->getLeaveStandardDayHours();

        if ($standard > 0) {
            return $standard;
        }

        $fallback = (float) $this->settings->getDailyHours();

        return $fallback > 0 ? $fallback : 1.0;
    }

    private function daysToStandardHours(float $days): float
    {
        return $this->roundHours($days * $this->getLeaveStandardDayHours());
    }

    private function standardHoursToDisplayDays(float $hours): float
    {
        if ($hours <= 0) {
            return 0.0;
        }

        return $this->roundBalance($hours / $this->getLeaveStandardDayHours());
    }

    private function getVacationContractHours(int $userId): float
    {
        return $this->getContractHours(
            $userId,
            self::META_VACATION_CONTRACT_HOURS,
            self::META_VACATION_CONTRACT,
            $this->settings->getDefaultVacationDays()
        );
    }

    private function getSickContractHours(int $userId): float
    {
        return $this->getContractHours(
            $userId,
            self::META_SICK_CONTRACT_HOURS,
            self::META_SICK_CONTRACT,
            $this->settings->getDefaultSickDays()
        );
    }

    private function getContractHours(int $userId, string $hoursMetaKey, string $legacyDaysMetaKey, int $defaultDays): float
    {
        $storedHours = get_user_meta($userId, $hoursMetaKey, true);

        if ($storedHours !== '' && $storedHours !== null && is_numeric($storedHours)) {
            return $this->roundHours((float) $storedHours);
        }

        $storedDays = get_user_meta($userId, $legacyDaysMetaKey, true);

        if ($storedDays === '' || $storedDays === null) {
            return $this->daysToStandardHours((float) $defaultDays);
        }

        return $this->daysToStandardHours((float) $storedDays);
    }

    /**
     * @param array<string, mixed> $row
     */
    private function resolveEntryLeaveHours(array $row): float
    {
        $type = isset($row['type']) ? sanitize_key((string) $row['type']) : '';
        $coverageSource = isset($row['coverage_source']) ? sanitize_key((string) $row['coverage_source']) : '';
        $hours = $row['hours'] ?? null;
        $scheduledHours = $row['scheduled_hours'] ?? null;

        if (
            $type === 'half_working'
            && in_array($coverageSource, ['half_day_off', 'half_sick_day', 'time_in_lieu'], true)
            && is_numeric($hours)
            && is_numeric($scheduledHours)
        ) {
            return $this->roundHours(max(0.0, (float) $scheduledHours - (float) $hours));
        }

        if (is_numeric($hours) && (float) $hours > 0) {
            return $this->roundHours((float) $hours);
        }

        if (is_numeric($scheduledHours) && (float) $scheduledHours > 0) {
            return $this->roundHours((float) $scheduledHours);
        }

        return $this->getLeaveStandardDayHours();
    }

    /**
     * @param array<string, mixed> $row
     */
    private function isEntryApproved(array $row): bool
    {
        $approval = strtolower((string) ($row['approval_status'] ?? ''));
        if ($approval === 'approved') {
            return true;
        }

        $timesheetStatus = strtolower((string) ($row['timesheet_status'] ?? ''));

        return in_array($timesheetStatus, ['approved', 'locked'], true);
    }

    /**
     * @return string[]
     */
    private function getUserWorkWeek(int $userId): array
    {
        $stored = get_user_meta($userId, 'timesuite_work_week', true);
        $stored = Settings::normalizeWorkWeekDays($stored);

        if (! empty($stored)) {
            return $stored;
        }

        return Settings::normalizeWorkWeekDays($this->settings->getWorkWeek());
    }

    private function hasScheduledHoursColumn(): bool
    {
        if ($this->hasScheduledHoursColumn !== null) {
            return $this->hasScheduledHoursColumn;
        }

        $entriesTable = $this->wpdb->prefix . 'timesuite_monthly_entries';
        $column = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SHOW COLUMNS FROM {$entriesTable} LIKE %s",
                'scheduled_hours'
            )
        );

        $this->hasScheduledHoursColumn = is_string($column) && $column === 'scheduled_hours';

        return $this->hasScheduledHoursColumn;
    }
}
