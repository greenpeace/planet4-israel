<?php

declare(strict_types=1);

namespace Timesuite\Frontend;

use function add_action;
use function add_filter;
use function apply_filters;
use function esc_url_raw;
use function plugins_url;
use function rest_url;
use function sanitize_text_field;
use function trailingslashit;
use function current_user_can;
use function wp_create_nonce;
use function wp_enqueue_script;
use function wp_enqueue_style;
use function wp_get_current_user;
use function wp_localize_script;
use function wp_register_script;
use function wp_register_style;
use function wp_script_add_data;

const SCRIPT_HANDLE = 'timesuite-app';
const THEME_SCRIPT_HANDLE = 'timesuite-theme';
const CONTAINER_ID  = 'timesuite-app-root';

add_action('admin_enqueue_scripts', __NAMESPACE__ . '\\enqueue_admin');
add_action('wp_enqueue_scripts', __NAMESPACE__ . '\\enqueue_front');
add_action('admin_notices', __NAMESPACE__ . '\\maybe_show_manifest_notice');
add_filter('script_loader_tag', __NAMESPACE__ . '\\add_module_type_to_app_scripts', 10, 3);

function enqueue_admin(string $hook = ''): void
{
    $shouldLoadApp = should_enqueue_admin($hook);
    $shouldLoadStylesOnly = should_enqueue_admin_styles_only($hook);

    if (! $shouldLoadApp && ! $shouldLoadStylesOnly) {
        return;
    }

    enqueue_theme_script();

    if ($shouldLoadStylesOnly) {
        enqueue_styles_only();

        return;
    }

    enqueue_bundle();
}

function enqueue_front(): void
{
    $shouldLoad = (bool) apply_filters('timesuite_enqueue_frontend', false);

    if (! $shouldLoad) {
        return;
    }

    enqueue_theme_script();
    enqueue_bundle();
}

function enqueue_bundle(): void
{
    if (defined('TIMESUITE_VITE_DEV') && TIMESUITE_VITE_DEV) {
        enqueue_dev_server();

        return;
    }

    $manifest = get_manifest();

    if (! $manifest) {
        return;
    }

    $entry = get_manifest_entry($manifest);

    if (! $entry) {
        return;
    }

    $pluginFile = TIMESUITE_PLUGIN_PATH . 'timesuite.php';
    $scriptUrl  = plugins_url('assets/' . ltrim($entry['file'], '/'), $pluginFile);

    wp_register_script(SCRIPT_HANDLE, $scriptUrl, [], null, true);
    wp_script_add_data(SCRIPT_HANDLE, 'type', 'module');

    enqueue_manifest_styles($entry, $pluginFile);

    localize_script();
    wp_enqueue_script(SCRIPT_HANDLE);
}

function should_enqueue_admin(string $hook): bool
{
    $allowedHooks = [
        'toplevel_page_timesuite',
        'timesuite_page_timesuite-timesheet',
        'timesuite_page_timesuite-manager',
        'timesuite_page_timesuite-settings',
        'timesuite_page_timesuite-policy-settings',
        'timesuite_page_timesuite-audit',
        'timesuite_page_timesuite-status',
        'timesuite_page_timesuite-rescue',
    ];

    if ('' !== $hook && in_array($hook, $allowedHooks, true)) {
        return true;
    }

    $page = isset($_GET['page']) ? sanitize_text_field((string) $_GET['page']) : '';
    $allowedPages = [
        'timesuite',
        'timesuite-timesheet',
        'timesuite-manager',
        'timesuite-settings',
        'timesuite-policy-settings',
        'timesuite-audit',
        'timesuite-status',
        'timesuite-rescue',
    ];

    return in_array($page, $allowedPages, true);
}

function should_enqueue_admin_styles_only(string $hook): bool
{
    $allowedHooks = [];

    if ('' !== $hook && in_array($hook, $allowedHooks, true)) {
        return true;
    }

    $page = isset($_GET['page']) ? sanitize_text_field((string) $_GET['page']) : '';
    $allowedPages = [];

    return in_array($page, $allowedPages, true);
}

function enqueue_dev_server(): void
{
    $devBase = defined('TIMESUITE_VITE_DEV_SERVER') ? TIMESUITE_VITE_DEV_SERVER : 'http://localhost:5173';

    wp_enqueue_script('timesuite-vite-client', $devBase . '/@vite/client', [], null, true);
    wp_script_add_data('timesuite-vite-client', 'type', 'module');
    wp_register_script(SCRIPT_HANDLE, $devBase . '/src/Frontend/app/index.tsx', [], null, true);
    wp_script_add_data(SCRIPT_HANDLE, 'type', 'module');
    localize_script();
    wp_enqueue_script(SCRIPT_HANDLE);
}

function add_module_type_to_app_scripts(string $tag, string $handle, string $src): string
{
    if (! in_array($handle, [SCRIPT_HANDLE, 'timesuite-vite-client'], true)) {
        return $tag;
    }

    if (str_contains($tag, ' type=')) {
        return $tag;
    }

    return str_replace('<script ', '<script type="module" ', $tag);
}

function localize_script(): void
{
    $user = wp_get_current_user();

    $settings = \Timesuite\Core\Settings::load();
    $defaultPeriod = (new \Timesuite\Core\Support\DefaultPeriodResolver($settings))->resolve();

    wp_localize_script(
        SCRIPT_HANDLE,
        'timesuiteSettings',
        [
            'root'  => esc_url_raw(rest_url()),
            'nonce' => wp_create_nonce('wp_rest'),
            'pluginUrl' => defined('TIMESUITE_PLUGIN_URL') ? TIMESUITE_PLUGIN_URL : '',
            'currentUser' => [
                'id'    => $user->ID,
                'email' => $user->user_email,
                'timesuite_role' => (new \Timesuite\Core\Access\AuthorizationService())->getRoleForUser((int) $user->ID),
                'is_super_access' => \Timesuite\Core\SuperAccess::isSuperUser($user),
                'caps'  => get_current_user_timesuite_caps(),
            ],
            // Single canonical "what month should this screen open on"
            // value, computed once server-side and shared by My Timesheet,
            // Manager View, and HR Month Overview — see
            // docs/timesheet-status-investigation.md for why this is a
            // shared value rather than three separate client computations.
            'defaultPeriod' => $defaultPeriod,
        ]
    );
}

function enqueue_theme_script(): void
{
    static $enqueued = false;

    if ($enqueued) {
        return;
    }

    $enqueued = true;

    $script = <<<JS
(() => {
  const key = 'timesuite_theme';
  const root = document.documentElement;
  const readPreference = () => {
    try {
      return localStorage.getItem(key);
    } catch (error) {
      return null;
    }
  };
  const applyPreference = (value) => {
    if (value === 'light') {
      root.setAttribute('data-theme', 'light');
    } else if (value === 'dark') {
      root.setAttribute('data-theme', 'dark');
    } else {
      root.removeAttribute('data-theme');
    }
  };
  const setPreference = (isLight) => {
    try {
      localStorage.setItem(key, isLight ? 'light' : 'dark');
    } catch (error) {
      // Ignore storage errors.
    }
    applyPreference(isLight ? 'light' : 'dark');
  };
  const syncToggles = () => {
    const isLight = readPreference() === 'light';
    document.querySelectorAll('[data-timesuite-theme-switch]').forEach((input) => {
      if (input instanceof HTMLInputElement) {
        input.checked = isLight;
      }
    });
  };

  applyPreference(readPreference());
  document.addEventListener('change', (event) => {
    const target = event.target;
    if (
      !(target instanceof HTMLInputElement) ||
      !target.matches('[data-timesuite-theme-switch]')
    ) {
      return;
    }
    setPreference(target.checked);
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', syncToggles);
  } else {
    syncToggles();
  }
})();
JS;

    wp_register_script(THEME_SCRIPT_HANDLE, '', [], null, false);
    wp_add_inline_script(THEME_SCRIPT_HANDLE, $script);
    wp_enqueue_script(THEME_SCRIPT_HANDLE);
}

function enqueue_styles_only(): void
{
    $manifest = get_manifest();

    if (! $manifest) {
        return;
    }

    $entry = get_manifest_entry($manifest);

    if (! $entry) {
        return;
    }

    $pluginFile = TIMESUITE_PLUGIN_PATH . 'timesuite.php';
    enqueue_manifest_styles($entry, $pluginFile);
}

/**
 * @param array<string, mixed> $entry
 */
function enqueue_manifest_styles(array $entry, string $pluginFile): void
{
    if (empty($entry['css']) || ! is_array($entry['css'])) {
        return;
    }

    foreach ($entry['css'] as $index => $cssFile) {
        $styleHandle = SCRIPT_HANDLE . '-style-' . $index;
        wp_register_style(
            $styleHandle,
            plugins_url('assets/' . ltrim($cssFile, '/'), $pluginFile),
            [],
            null
        );
        wp_enqueue_style($styleHandle);
    }
}

/**
 * @param array<string, mixed> $manifest
 *
 * @return array<string, mixed>|null
 */
function get_manifest_entry(array $manifest): ?array
{
    $entryKey = 'src/Frontend/app/index.tsx';
    $entry    = $manifest[$entryKey] ?? reset($manifest);

    return is_array($entry) ? $entry : null;
}

/**
 * Ensure frontend permissions match `current_user_can()` (including SuperAccess).
 *
 * @return string[]
 */
function get_current_user_timesuite_caps(): array
{
    $capabilities = [
        'timesuite.timesheet.create',
        'timesuite.timesheet.edit_own',
        'timesuite.timesheet.submit_own',
        'timesuite.timesheet.view_own',
        'timesuite.timesheet.bulk_import_own',
        'timesuite.timesheet.view_team',
        'timesuite.timesheet.approve_team',
        'timesuite.timesheet.comment_team',
        'timesuite.timesheet.view_all',
        'timesuite.period.lock',
        'timesuite.export.run',
        'timesuite.export.sensitive',
        'timesuite.roles.manage',
        'timesuite.org.view',
        'timesuite.org.edit',
        'timesuite.org.import',
        'timesuite.org.delete',
        'timesuite.settings.view',
        'timesuite.settings.manage',
        'timesuite.audit.view',
        'timesuite.system.view',
        // legacy
        'timesuite.org.manage',
    ];

    $user = wp_get_current_user();
    if (\Timesuite\Core\SuperAccess::isSuperUser($user)) {
        return $capabilities;
    }

    $granted = [];

    foreach ($capabilities as $capability) {
        if (current_user_can($capability)) {
            $granted[] = $capability;
        }
    }

    return $granted;
}

function get_manifest(): ?array
{
    $baseDir = trailingslashit(TIMESUITE_PLUGIN_PATH) . 'assets/';
    $paths   = [
        $baseDir . 'manifest.json',
        $baseDir . '.vite/manifest.json',
    ];

    $content = null;

    foreach ($paths as $path) {
        if (is_readable($path)) {
            $content = file_get_contents($path);
            break;
        }
    }

    if (! $content) {
        return null;
    }

    $decoded = json_decode($content, true);

    return is_array($decoded) ? $decoded : null;
}

/**
 * Show admin notice when manifest.json is missing (build required).
 */
function maybe_show_manifest_notice(): void
{
    // Only show on Timesuite pages
    if (! should_enqueue_admin('')) {
        return;
    }

    // Only show to admins
    if (! current_user_can('manage_options')) {
        return;
    }

    // Skip in dev mode
    if (defined('TIMESUITE_VITE_DEV') && TIMESUITE_VITE_DEV) {
        return;
    }

    // Check if manifest exists
    $manifest = get_manifest();

    if (null !== $manifest) {
        return;
    }

    $message = sprintf(
        /* translators: 1: npm run build command, 2: manifest.json path */
        __(
            '<strong>Timesuite:</strong> Frontend assets not found. Please run %1$s in the plugin directory to build the frontend, or ensure %2$s exists.',
            'timesuite'
        ),
        '<code>npm run build</code>',
        '<code>assets/.vite/manifest.json</code>'
    );

    printf(
        '<div class="notice notice-error"><p>%s</p></div>',
        wp_kses(
            $message,
            [
                'strong' => [],
                'code'   => [],
            ]
        )
    );
}
