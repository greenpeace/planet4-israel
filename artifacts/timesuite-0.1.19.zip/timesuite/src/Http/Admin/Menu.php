<?php

declare(strict_types=1);

namespace Timesuite\Http\Admin;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Core\Access\BootstrapService;
use Timesuite\Core\Access\Role;
use Timesuite\Core\SuperAccess;
use Timesuite\Http\Admin\Pages\AccessRequiredPage;
use Timesuite\Http\Admin\Pages\BootstrapPage;
use Timesuite\Http\Admin\Pages\DashboardPage;
use Timesuite\Http\Admin\Pages\DiagnosticPage;

class Menu
{
    public function __construct(
        private DashboardPage $dashboardPage,
        private BootstrapPage $bootstrapPage,
        private AccessRequiredPage $accessRequiredPage,
        private DiagnosticPage $diagnosticPage,
        private AuthorizationService $authService
    ) {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'addMenus']);
        add_action('admin_menu', [$this, 'addDiagnosticPage'], 999); // Always add diagnostic
        add_action('admin_init', [$this, 'maybeRedirectUnauthorizedAdminAccess']);
    }

    /**
     * Always-available diagnostic page for WP admins to debug access issues.
     * Access via: admin.php?page=timesuite-diagnostic
     */
    public function addDiagnosticPage(): void
    {
        add_submenu_page(
            null, // Hidden from menu
            __('Timesuite Diagnostic', 'timesuite'),
            __('Diagnostic', 'timesuite'),
            'manage_options',
            'timesuite-diagnostic',
            [$this->diagnosticPage, 'render']
        );
    }

    public function addMenus(): void
    {
        // Bootstrap mode: no tech_admin exists yet
        // Uses BootstrapService (single source of truth for bootstrap state)
        if (BootstrapService::isBootstrapMode()) {
            $this->addBootstrapMenu();
            return;
        }

        // If user has NO Timesuite access but IS a WP admin, show a friendly landing page.
        if ($this->currentUserIsWpAdminWithoutTimesuiteAccess()) {
            $this->addAccessRequiredMenu();
            return;
        }

        // Normal mode: add all menus
        $this->addNormalMenus();
    }

    private function currentUserIsWpAdminWithoutTimesuiteAccess(): bool
    {
        if (! current_user_can('manage_options')) {
            return false;
        }

        if (SuperAccess::isSuperUser()) {
            return false;
        }

        // Use AuthorizationService for consistent role checking
        $role = $this->authService->getRoleForUser((int) get_current_user_id());

        return $role === Role::NONE;
    }

    /**
     * Add bootstrap-only menu for first-time setup.
     *
     * Only WordPress administrators can see this.
     */
    private function addBootstrapMenu(): void
    {
        $menuHook = add_menu_page(
            __('Timesuite Setup', 'timesuite'),
            __('Timesuite', 'timesuite'),
            'manage_options', // WP admin capability
            'timesuite',
            [$this->bootstrapPage, 'render'],
            'dashicons-clock',
            59
        );

        $submenuHook = add_submenu_page(
            'timesuite',
            __('Setup', 'timesuite'),
            __('Setup', 'timesuite'),
            'manage_options',
            'timesuite',
            [$this->bootstrapPage, 'render']
        );

        $this->hookBootstrapPageNoticeSuppression($menuHook);
        $this->hookBootstrapPageNoticeSuppression($submenuHook);

        // Register hidden handlers for common Timesuite pages so direct URLs don't
        // show WP's generic "Sorry..." screen during bootstrap.
        $this->registerHiddenTimesuitePages('manage_options', function (): void {
            wp_safe_redirect(admin_url('admin.php?page=timesuite'));
            exit;
        });
    }

    /**
     * Hide unrelated third-party admin notices on the bootstrap screen.
     *
     * The setup page is a focused first-run flow; generic notices from other plugins
     * can obscure the primary action and create confusion.
     */
    private function hookBootstrapPageNoticeSuppression(string|false $hookSuffix): void
    {
        if (! is_string($hookSuffix) || $hookSuffix === '') {
            return;
        }

        add_action('load-' . $hookSuffix, static function (): void {
            remove_all_actions('all_admin_notices');
            remove_all_actions('admin_notices');
            remove_all_actions('network_admin_notices');
            remove_all_actions('user_admin_notices');
        }, 0);
    }

    /**
     * Add a minimal Timesuite menu for WP admins who do not have a Timesuite role.
     * This prevents the confusing WP core "Sorry..." screen.
     */
    private function addAccessRequiredMenu(): void
    {
        add_menu_page(
            __('Timesuite', 'timesuite'),
            __('Timesuite', 'timesuite'),
            'manage_options',
            'timesuite',
            [$this->accessRequiredPage, 'render'],
            'dashicons-clock',
            59
        );

        add_submenu_page(
            'timesuite',
            __('Access', 'timesuite'),
            __('Access', 'timesuite'),
            'manage_options',
            'timesuite',
            [$this->accessRequiredPage, 'render']
        );

        // Register hidden handlers for common Timesuite pages so direct URLs don't
        // show WP's generic "Sorry..." screen; instead we route to our explanation.
        $this->registerHiddenTimesuitePages('manage_options', function (): void {
            wp_safe_redirect(admin_url('admin.php?page=timesuite'));
            exit;
        });
    }

    /**
     * If a WP admin (manage_options) without Timesuite access tries to load a Timesuite
     * submenu directly (e.g. admin.php?page=timesuite-settings), redirect them to the
     * friendly access page instead of showing WP's generic "Sorry..." screen.
     */
    public function maybeRedirectUnauthorizedAdminAccess(): void
    {
        if (! is_admin()) {
            return;
        }

        if (! $this->currentUserIsWpAdminWithoutTimesuiteAccess()) {
            return;
        }

        $page = isset($_GET['page']) ? sanitize_text_field((string) $_GET['page']) : '';
        if ($page === '' || ! str_starts_with($page, 'timesuite')) {
            return;
        }

        // Allow the main slug (timesuite) which is our friendly access page.
        // Also allow the diagnostic page (always accessible to WP admins).
        if ($page === 'timesuite' || $page === 'timesuite-diagnostic') {
            return;
        }

        wp_safe_redirect(admin_url('admin.php?page=timesuite'));
        exit;
    }

    /**
     * Register hidden Timesuite admin pages (no menu item) so direct links are handled.
     *
     * @param string   $capability Capability required to access these pages.
     * @param callable $handler    Callback invoked if accessed.
     */
    private function registerHiddenTimesuitePages(string $capability, callable $handler): void
    {
        // NOTE: parent slug null => hidden page (not shown in menu).
        $slugs = [
            'timesuite-timesheet',
            'timesuite-manager',
            'timesuite-settings',
            'timesuite-policy-settings',
            'timesuite-audit',
            'timesuite-status',
        ];

        foreach ($slugs as $slug) {
            add_submenu_page(
                null,
                __('Timesuite', 'timesuite'),
                __('Timesuite', 'timesuite'),
                $capability,
                $slug,
                $handler
            );
        }
    }

    /**
     * Add normal Timesuite menus for users with proper roles.
     */
    private function addNormalMenus(): void
    {
        $dashboardCap = 'timesuite.timesheet.view_own';

        add_menu_page(
            __('Timesuite', 'timesuite'),
            __('Timesuite', 'timesuite'),
            $dashboardCap,
            'timesuite',
            [$this->dashboardPage, 'renderDashboard'],
            'dashicons-clock',
            59
        );

        // Dashboard - main landing page
        add_submenu_page(
            'timesuite',
            __('Dashboard', 'timesuite'),
            __('Dashboard', 'timesuite'),
            $dashboardCap,
            'timesuite',
            [$this->dashboardPage, 'renderDashboard']
        );

        // My Timesheet
        add_submenu_page(
            'timesuite',
            __('My Timesheet', 'timesuite'),
            __('My Timesheet', 'timesuite'),
            $dashboardCap,
            'timesuite-timesheet',
            [$this->dashboardPage, 'renderTimesheets']
        );

        if ($this->dashboardPage->currentUserCanSeeManagerView()) {
            add_submenu_page(
                'timesuite',
                __('Manager View', 'timesuite'),
                __('Manager View', 'timesuite'),
                'read',
                'timesuite-manager',
                [$this->dashboardPage, 'renderManager']
            );
        }

        if ($this->dashboardPage->currentUserCanSeeOrgSettings()) {
            add_submenu_page(
                'timesuite',
                __('Org Directory', 'timesuite'),
                __('Org Directory', 'timesuite'),
                'timesuite.org.edit',
                'timesuite-settings',
                [$this->dashboardPage, 'renderSettings']
            );
        }

        add_submenu_page(
            'timesuite',
            __('Policy Settings', 'timesuite'),
            __('Policy Settings', 'timesuite'),
            'timesuite.settings.manage',
            'timesuite-policy-settings',
            [$this->dashboardPage, 'renderPolicySettings']
        );

        // Audit Log - for HR and admins
        if ($this->dashboardPage->currentUserCanSeeAuditLog()) {
            add_submenu_page(
                'timesuite',
                __('Audit Log', 'timesuite'),
                __('Audit Log', 'timesuite'),
                'timesuite.audit.view',
                'timesuite-audit',
                [$this->dashboardPage, 'renderAuditLog']
            );
        }

        // System Status - admins only
        add_submenu_page(
            'timesuite',
            __('System Status', 'timesuite'),
            __('System Status', 'timesuite'),
            'timesuite.system.view',
            'timesuite-status',
            [$this->dashboardPage, 'renderSystemStatus']
        );

        // Admin Rescue - HR and Tech-Admin only (P3.1). 'timesuite.settings.manage'
        // is held by both roles alongside period.lock/org.edit -- do NOT use
        // timesuite.system.view here, that's Tech-Admin-only and would
        // exclude HR. See docs/p3.1-admin-rescue-actions-plan.md §0.
        if ($this->dashboardPage->currentUserCanSeeRescue()) {
            add_submenu_page(
                'timesuite',
                __('Admin Rescue', 'timesuite'),
                __('Admin Rescue', 'timesuite'),
                'timesuite.settings.manage',
                'timesuite-rescue',
                [$this->dashboardPage, 'renderRescue']
            );
        }
    }
}
