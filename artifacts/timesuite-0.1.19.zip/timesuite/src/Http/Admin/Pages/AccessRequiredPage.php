<?php

declare(strict_types=1);

namespace Timesuite\Http\Admin\Pages;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Core\Access\Role;
use Timesuite\Core\SuperAccess;

/**
 * Shown to WordPress administrators when they try to access Timesuite
 * but do not have a Timesuite role assigned.
 *
 * This does NOT grant any Timesuite permissions; it's purely explanatory.
 */
class AccessRequiredPage
{
    public function render(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'timesuite'));
        }

        $currentUserId = (int) get_current_user_id();
        $authService = new AuthorizationService();
        $role = $authService->getRoleForUser($currentUserId);
        $isSuper = SuperAccess::isSuperUser();

        // If they do have access now, send them to Timesuite.
        if ($isSuper || $role !== Role::NONE) {
            wp_safe_redirect(admin_url('admin.php?page=timesuite'));
            exit;
        }

        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Timesuite access required', 'timesuite'); ?></h1>
            <p>
                <?php esc_html_e('This WordPress account is not assigned a Timesuite role yet, so Timesuite features are not available.', 'timesuite'); ?>
            </p>
            <p>
                <?php esc_html_e('Ask a Timesuite Technical Admin to grant you access from Timesuite → Org Directory.', 'timesuite'); ?>
            </p>
            <p>
                <strong><?php esc_html_e('Note:', 'timesuite'); ?></strong>
                <?php esc_html_e('WordPress Administrator does not automatically grant Timesuite access (by design).', 'timesuite'); ?>
            </p>
        </div>
        <?php
    }
}


