<?php

declare(strict_types=1);

namespace Timesuite\Http\Admin\Pages;

use Timesuite\Core\Access\BootstrapService;
use Timesuite\Core\Access\Role;
use Timesuite\Core\Access\RoleAssignmentService;
use Timesuite\Domain\Org\Services\OrgService;

/**
 * Bootstrap page shown when no Timesuite tech_admin exists.
 *
 * This page allows WordPress administrators to assign the first Timesuite admin,
 * ensuring there's always a way to access the plugin without getting locked out.
 *
 * Once a tech_admin is assigned, this page disappears and normal access controls apply.
 *
 * All role assignment goes through RoleAssignmentService (single entry point).
 */
class BootstrapPage
{
    private const NONCE_ACTION = 'timesuite_bootstrap';

    public function __construct(
        private RoleAssignmentService $roleService,
        private OrgService $orgService
    ) {
    }

    /**
     * Check if the bootstrap page should be shown.
     *
     * Returns true only if:
     * 1. No Timesuite tech_admin exists (bootstrap mode)
     * 2. Current user is a WordPress administrator
     */
    public static function shouldShow(): bool
    {
        // Use BootstrapService (single source of truth for bootstrap state)
        return BootstrapService::canAccessBootstrap(get_current_user_id());
    }

    /**
     * Render the bootstrap page.
     */
    public function render(): void
    {
        // Double-check conditions using BootstrapService
        if (! BootstrapService::isBootstrapMode()) {
            wp_safe_redirect(admin_url('admin.php?page=timesuite'));
            exit;
        }

        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'timesuite'));
        }

        $message = '';
        $messageType = '';

        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['timesuite_bootstrap_nonce'])) {
            $result = $this->handleSubmit();
            if ($result === true) {
                // Success - redirect to main Timesuite page
                wp_safe_redirect(admin_url('admin.php?page=timesuite&bootstrapped=1'));
                exit;
            }
            $message = $result;
            $messageType = 'error';
        }

        $this->renderPage($message, $messageType);
    }

    /**
     * Handle form submission.
     *
     * @return bool|string True on success, error message on failure.
     */
    private function handleSubmit(): bool|string
    {
        if (! wp_verify_nonce($_POST['timesuite_bootstrap_nonce'] ?? '', self::NONCE_ACTION)) {
            return __('Security check failed. Please try again.', 'timesuite');
        }

        $userId = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;

        if ($userId <= 0) {
            return __('Please select a user.', 'timesuite');
        }

        $user = get_user_by('id', $userId);
        if (! $user) {
            return __('Selected user not found.', 'timesuite');
        }

        try {
            // Use RoleAssignmentService - the single entry point for all role changes
            // skipAuthCheck=true because this is bootstrap (no tech_admin exists to authorize)
            $success = $this->roleService->assignRole(
                $userId,
                Role::TECH_ADMIN,
                get_current_user_id(),
                'bootstrap_setup',
                true // Skip auth check - no tech_admin exists to authorize yet
            );

            if (! $success) {
                return __('Failed to assign role. Please try again.', 'timesuite');
            }
        } catch (\Throwable $e) {
            return sprintf(
                __('Failed to assign role: %s', 'timesuite'),
                $e->getMessage()
            );
        }

        try {
            $this->orgService->ensureActiveDirectoryMembership($userId);
        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Timesuite: Failed to create bootstrap directory mapping: ' . $e->getMessage());
            }
        }

        // Log this action (already done by RoleAssignmentService, but fire action for hooks)
        do_action('timesuite_bootstrap_completed', $userId, get_current_user_id());

        return true;
    }

    /**
     * Render the bootstrap page HTML.
     */
    private function renderPage(string $message, string $messageType): void
    {
        // Use BootstrapService to get available admins
        $users = get_users([
            'role__in' => ['administrator'],
            'orderby' => 'display_name',
            'order' => 'ASC',
        ]);

        ?>
        <div class="wrap timesuite-bootstrap">
            <style>
                .timesuite-bootstrap {
                    max-width: 600px;
                    margin: 40px auto;
                }
                .timesuite-bootstrap-card {
                    background: #fff;
                    border: 1px solid #c3c4c7;
                    border-radius: 4px;
                    padding: 24px;
                    box-shadow: 0 1px 1px rgba(0,0,0,.04);
                }
                .timesuite-bootstrap-header {
                    text-align: center;
                    margin-bottom: 24px;
                }
                .timesuite-bootstrap-header h1 {
                    margin: 0 0 8px;
                    font-size: 24px;
                    font-weight: 600;
                }
                .timesuite-bootstrap-header p {
                    margin: 0;
                    color: #646970;
                }
                .timesuite-bootstrap-icon {
                    font-size: 48px;
                    margin-bottom: 16px;
                }
                .timesuite-bootstrap-form label {
                    display: block;
                    margin-bottom: 8px;
                    font-weight: 500;
                }
                .timesuite-bootstrap-form select {
                    width: 100%;
                    padding: 8px 12px;
                    font-size: 14px;
                    margin-bottom: 16px;
                }
                .timesuite-bootstrap-form .button-primary {
                    width: 100%;
                    height: 40px;
                    font-size: 14px;
                }
                .timesuite-bootstrap-note {
                    margin-top: 16px;
                    padding: 12px;
                    background: #f0f6fc;
                    border-left: 4px solid #72aee6;
                    font-size: 13px;
                    color: #1d2327;
                }
                .timesuite-bootstrap-note strong {
                    display: block;
                    margin-bottom: 4px;
                }
                .timesuite-bootstrap .notice {
                    margin: 0 0 16px;
                }
            </style>

            <div class="timesuite-bootstrap-card">
                <div class="timesuite-bootstrap-header">
                    <div class="timesuite-bootstrap-icon">🔐</div>
                    <h1><?php esc_html_e('Welcome to Timesuite', 'timesuite'); ?></h1>
                    <p><?php esc_html_e('Set up your first administrator to get started.', 'timesuite'); ?></p>
                </div>

                <?php if ($message): ?>
                    <div class="notice notice-<?php echo esc_attr($messageType); ?> inline">
                        <p><?php echo esc_html($message); ?></p>
                    </div>
                <?php endif; ?>

                <form method="post" class="timesuite-bootstrap-form">
                    <?php wp_nonce_field(self::NONCE_ACTION, 'timesuite_bootstrap_nonce'); ?>

                    <label for="user_id">
                        <?php esc_html_e('Select the first Timesuite Administrator', 'timesuite'); ?>
                    </label>
                    <select name="user_id" id="user_id" required>
                        <option value=""><?php esc_html_e('— Select a user —', 'timesuite'); ?></option>
                        <?php foreach ($users as $user): ?>
                            <option value="<?php echo esc_attr($user->ID); ?>" <?php selected($user->ID, get_current_user_id()); ?>>
                                <?php echo esc_html($user->display_name); ?> (<?php echo esc_html($user->user_email); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <button type="submit" class="button button-primary">
                        <?php esc_html_e('Assign as Timesuite Admin', 'timesuite'); ?>
                    </button>
                </form>

                <div class="timesuite-bootstrap-note">
                    <strong><?php esc_html_e('What is a Timesuite Admin?', 'timesuite'); ?></strong>
                    <?php esc_html_e('The Timesuite Admin (Technical Admin) has full access to all plugin features including settings, org directory, imports, exports, and system status. You can add more admins later from the Org Directory.', 'timesuite'); ?>
                </div>
            </div>
        </div>
        <?php
    }
}
