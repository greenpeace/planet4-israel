<?php

declare(strict_types=1);

namespace Timesuite\Http\Admin\Pages;

use function current_user_can;
use function esc_attr;
use function esc_html;
use function esc_html__;
use function printf;
use function wp_die;

class DashboardPage
{
    public function renderTimesheets(): void
    {
        $this->renderScreen(
            'timesheets',
            'timesuite.timesheet.view_own',
            esc_html__('Your Timesheets', 'timesuite'),
            esc_html__('Review and submit your monthly calendar.', 'timesuite')
        );
    }

    public function renderManager(): void
    {
        if (!$this->currentUserCanSeeManagerView()) {
            wp_die(__('You do not have access to this Timesuite area.', 'timesuite'));
        }

        $this->renderScreen(
            'manager',
            'read',
            esc_html__('Manager View', 'timesuite'),
            esc_html__('Browse direct reports and keep them on track.', 'timesuite')
        );
    }

    public function renderSettings(): void
    {
        $this->renderScreen(
            'settings',
            'timesuite.org.edit',
            esc_html__('Org Directory', 'timesuite'),
            esc_html__('Manage employees, managers, and departments.', 'timesuite')
        );
    }

    public function renderPolicySettings(): void
    {
        $this->renderScreen(
            'policy',
            'timesuite.settings.manage',
            esc_html__('Policy Settings', 'timesuite'),
            esc_html__('Configure organization-wide timesheet rules.', 'timesuite')
        );
    }

    public function renderDashboard(): void
    {
        $this->renderScreen(
            'dashboard',
            'timesuite.timesheet.view_own',
            esc_html__('Dashboard', 'timesuite'),
            esc_html__('Overview of your timesheets, approvals, and deadlines.', 'timesuite')
        );
    }

    public function renderAuditLog(): void
    {
        $this->renderScreen(
            'audit-log',
            'timesuite.audit.view',
            esc_html__('Audit Log', 'timesuite'),
            esc_html__('View activity history and approval records.', 'timesuite')
        );
    }

    public function renderSystemStatus(): void
    {
        $this->renderScreen(
            'status',
            'timesuite.system.view',
            esc_html__('System Status', 'timesuite'),
            esc_html__('View system health and configuration.', 'timesuite')
        );
    }

    public function renderRescue(): void
    {
        if (!$this->currentUserCanSeeRescue()) {
            wp_die(__('You do not have access to this Timesuite area.', 'timesuite'));
        }

        // currentUserCanSeeRescue() already checked the correct "any of
        // settings.manage / period.lock / org.edit" gate above -- pass
        // 'read' here (matching renderManager()'s pattern) so renderScreen()
        // doesn't re-check a single capability and incorrectly exclude a
        // user who qualifies via period.lock or org.edit alone.
        $this->renderScreen(
            'rescue',
            'read',
            esc_html__('Admin Rescue', 'timesuite'),
            esc_html__('Manually repair a stuck employee timesheet. All actions are audited.', 'timesuite')
        );
    }

    public function currentUserCanSeeManagerView(): bool
    {
        return current_user_can('timesuite.timesheet.approve_team')
            || current_user_can('timesuite.period.lock')
            || current_user_can('timesuite.settings.manage');
    }

    public function currentUserCanSeeOrgSettings(): bool
    {
        return current_user_can('timesuite.org.edit');
    }

    public function currentUserCanSeeAuditLog(): bool
    {
        return current_user_can('timesuite.audit.view')
            || current_user_can('timesuite.settings.manage');
    }

    /**
     * Mirrors AuthorizationService::hasOrgManagementPowers() in capability
     * terms -- held by both HR and Tech-Admin (see Role::capabilities()).
     * Do NOT use timesuite.system.view here: that is Tech-Admin-only and
     * would incorrectly exclude HR. See
     * docs/p3.1-admin-rescue-actions-plan.md §0.
     */
    public function currentUserCanSeeRescue(): bool
    {
        return current_user_can('timesuite.settings.manage')
            || current_user_can('timesuite.period.lock')
            || current_user_can('timesuite.org.edit');
    }

    private function renderScreen(string $screen, string $capability, string $title, string $description): void
    {
        if ('read' !== $capability && !current_user_can($capability)) {
            wp_die(__('You do not have access to this Timesuite area.', 'timesuite'));
        }

        // Check if assets are built (skip in dev mode)
        if (!$this->isDevMode() && !$this->areAssetsBuilt()) {
            $this->renderBuildRequiredScreen();

            return;
        }

        echo '<div class="wrap timesuite-dashboard-wrap">';
        printf('<h1>%s</h1>', esc_html($title));
        printf('<p class="description">%s</p>', esc_html($description));
        printf(
            '<div id="timesuite-app-root" data-screen="%s"><div class="notice notice-info inline"><p>%s</p></div></div>',
            esc_attr($screen),
            esc_html__('Loading Timesuite…', 'timesuite')
        );
        echo '<noscript>' . esc_html__('Please enable JavaScript to use the Timesuite dashboard.', 'timesuite') . '</noscript>';
        
        // Debug: Check if timesuiteSettings is defined
        echo '<script>console.log("[Timesuite PHP Debug] timesuiteSettings:", typeof window.timesuiteSettings !== "undefined" ? "defined" : "NOT DEFINED");</script>';
        
        // If the JS bundle fails to load or crashes before mounting, show a helpful message.
        $diagUrl = esc_url(admin_url('admin.php?page=timesuite-diagnostic'));
        echo '<script>(function(){
            console.log("[Timesuite PHP Debug] Fallback timer started");
            setTimeout(function(){
                console.log("[Timesuite PHP Debug] Fallback timer fired");
                var el=document.getElementById("timesuite-app-root");
                if(!el){ console.log("[Timesuite PHP Debug] Container not found"); return; }
                if(el.dataset && el.dataset.mounted==="1"){ console.log("[Timesuite PHP Debug] App mounted OK"); return; }
                console.log("[Timesuite PHP Debug] App NOT mounted, showing error");
                el.innerHTML=' . wp_json_encode('<div class="notice notice-error inline"><p><strong>Timesuite UI failed to load.</strong></p><p>The JavaScript bundle did not mount. Check your browser console (F12) for errors.</p><p><a href="' . $diagUrl . '" class="button">Go to Diagnostic Page</a></p></div>') . ';
            },3000);
        })();</script>';
        echo '</div>';
    }

    /**
     * Check if the Vite dev server mode is enabled.
     */
    private function isDevMode(): bool
    {
        return defined('TIMESUITE_VITE_DEV') && TIMESUITE_VITE_DEV;
    }

    /**
     * Check if frontend assets have been built.
     */
    private function areAssetsBuilt(): bool
    {
        $manifestPaths = [
            TIMESUITE_PLUGIN_PATH . 'assets/manifest.json',
            TIMESUITE_PLUGIN_PATH . 'assets/.vite/manifest.json',
        ];

        foreach ($manifestPaths as $path) {
            if (is_readable($path)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Render a helpful screen when assets are not built.
     */
    private function renderBuildRequiredScreen(): void
    {
        $pluginPath = TIMESUITE_PLUGIN_PATH;
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Timesuite Setup Required', 'timesuite'); ?></h1>

            <div class="notice notice-warning" style="padding: 20px; margin-top: 20px;">
                <h2 style="margin-top: 0;">
                    <?php esc_html_e('Frontend assets need to be built', 'timesuite'); ?>
                </h2>

                <p><?php esc_html_e('The Timesuite user interface has not been compiled yet. This typically happens after a fresh installation or update.', 'timesuite'); ?></p>

                <h3><?php esc_html_e('Quick Fix', 'timesuite'); ?></h3>
                <p><?php esc_html_e('Run these commands in your terminal:', 'timesuite'); ?></p>

                <pre style="background: #23282d; color: #fff; padding: 15px; border-radius: 4px; overflow-x: auto;">
<code>cd <?php echo esc_html($pluginPath); ?>

# Install dependencies (first time only)
npm install

# Build the frontend
npm run build</code></pre>

                <h3><?php esc_html_e('Using Local by Flywheel?', 'timesuite'); ?></h3>
                <p><?php esc_html_e('Open the "Site Shell" from your Local site, then run the commands above.', 'timesuite'); ?></p>

                <h3><?php esc_html_e('Development Mode', 'timesuite'); ?></h3>
                <p><?php esc_html_e('For development with hot reload, add this to wp-config.php:', 'timesuite'); ?></p>
                <pre style="background: #23282d; color: #fff; padding: 15px; border-radius: 4px; overflow-x: auto;">
<code>define('TIMESUITE_VITE_DEV', true);
define('TIMESUITE_VITE_DEV_SERVER', 'http://localhost:5173');</code></pre>
                <p><?php esc_html_e('Then run:', 'timesuite'); ?> <code>npm run dev</code></p>

                <p style="margin-top: 20px;">
                    <a href="<?php echo esc_url(admin_url('plugins.php')); ?>" class="button">
                        <?php esc_html_e('Back to Plugins', 'timesuite'); ?>
                    </a>
                    <a href="<?php echo esc_url(add_query_arg('_refresh', time())); ?>" class="button button-primary" style="margin-left: 10px;">
                        <?php esc_html_e('Refresh Page', 'timesuite'); ?>
                    </a>
                </p>
            </div>
        </div>
        <?php
    }
}
