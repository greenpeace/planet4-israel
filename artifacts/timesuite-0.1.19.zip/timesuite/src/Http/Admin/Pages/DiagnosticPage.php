<?php

declare(strict_types=1);

namespace Timesuite\Http\Admin\Pages;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Core\Access\BootstrapService;
use Timesuite\Core\Access\Role;
use Timesuite\Core\SuperAccess;
use Timesuite\Core\Settings;

/**
 * Diagnostic page for debugging access issues.
 * Only accessible to WordPress administrators.
 */
class DiagnosticPage
{
    public function render(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die('Access denied');
        }

        $currentUser = wp_get_current_user();
        $userId = (int) $currentUser->ID;
        $settings = Settings::load();
        $authService = new AuthorizationService();

        // Get raw meta value
        $rawMeta = get_user_meta($userId, AuthorizationService::META_KEY, true);
        $effectiveRole = $authService->getRoleForUser($userId);
        $isSuperUser = SuperAccess::isSuperUser($currentUser);
        $hasTechAdmin = BootstrapService::hasTechAdmin();
        $superEmails = $settings->getSuperUserEmails();

        // Handle reset action
        $message = '';
        if (isset($_POST['reset_my_role']) && wp_verify_nonce($_POST['_wpnonce'] ?? '', 'timesuite_diag_reset')) {
            delete_user_meta($userId, AuthorizationService::META_KEY);
            AuthorizationService::clearCacheForUser($userId);
            $message = 'Your Timesuite role has been cleared. Refresh the page.';
            $rawMeta = '';
            $effectiveRole = Role::NONE;
        }

        if (isset($_POST['make_me_admin']) && wp_verify_nonce($_POST['_wpnonce'] ?? '', 'timesuite_diag_admin')) {
            update_user_meta($userId, AuthorizationService::META_KEY, Role::TECH_ADMIN);
            AuthorizationService::clearCacheForUser($userId);
            BootstrapService::clearCache();
            $message = 'You are now a Timesuite Tech Admin. Go to Timesuite menu.';
            $rawMeta = Role::TECH_ADMIN;
            $effectiveRole = Role::TECH_ADMIN;
        }

        ?>
        <div class="wrap">
            <h1>Timesuite Access Diagnostic</h1>

            <?php if ($message): ?>
                <div class="notice notice-success"><p><?php echo esc_html($message); ?></p></div>
            <?php endif; ?>

            <table class="widefat" style="max-width: 600px;">
                <tbody>
                    <tr>
                        <th>Your WordPress User ID</th>
                        <td><?php echo esc_html($userId); ?></td>
                    </tr>
                    <tr>
                        <th>Your Email</th>
                        <td><?php echo esc_html($currentUser->user_email); ?></td>
                    </tr>
                    <tr>
                        <th>WordPress Role</th>
                        <td><?php echo esc_html(implode(', ', $currentUser->roles)); ?></td>
                    </tr>
                    <tr>
                        <th>Has manage_options?</th>
                        <td><?php echo current_user_can('manage_options') ? '✅ Yes' : '❌ No'; ?></td>
                    </tr>
                    <tr>
                        <th>Raw Timesuite Role (meta)</th>
                        <td><code><?php echo esc_html($rawMeta ?: '(not set)'); ?></code></td>
                    </tr>
                    <tr>
                        <th>Effective Timesuite Role</th>
                        <td><strong><?php echo esc_html($effectiveRole); ?></strong></td>
                    </tr>
                    <tr>
                        <th>Is SuperAccess User?</th>
                        <td><?php echo $isSuperUser ? '✅ Yes (bypass active)' : '❌ No'; ?></td>
                    </tr>
                    <tr>
                        <th>Any Tech Admin Exists?</th>
                        <td><?php echo $hasTechAdmin ? '✅ Yes' : '❌ No (bootstrap mode)'; ?></td>
                    </tr>
                    <tr>
                        <th>Super User Emails (Policy Settings)</th>
                        <td><code><?php echo esc_html(implode(', ', $superEmails) ?: '(none)'); ?></code></td>
                    </tr>
                </tbody>
            </table>

            <h2>Actions</h2>
            <form method="post" style="display: inline-block; margin-right: 10px;">
                <?php wp_nonce_field('timesuite_diag_reset'); ?>
                <button type="submit" name="reset_my_role" class="button">
                    Clear My Timesuite Role
                </button>
            </form>

            <form method="post" style="display: inline-block;">
                <?php wp_nonce_field('timesuite_diag_admin'); ?>
                <button type="submit" name="make_me_admin" class="button button-primary">
                    Make Me Timesuite Tech Admin
                </button>
            </form>

            <p style="margin-top: 20px;">
                <a href="<?php echo esc_url(admin_url('admin.php?page=timesuite')); ?>" class="button">
                    Go to Timesuite →
                </a>
            </p>
        </div>
        <?php
    }
}

