<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest;

use Timesuite\Domain\Shared\Exceptions\ForbiddenException;
use Timesuite\Domain\Shared\Exceptions\NotFoundException;
use Timesuite\Domain\Shared\Exceptions\PersistenceException;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Http\Rest\Concerns\RateLimiting;
use Timesuite\Http\Rest\Concerns\Sanitization;
use WP_Error;
use WP_REST_Request;

/**
 * Base controller providing shared REST utilities.
 *
 * All REST controllers should extend this class to ensure consistent
 * error handling, nonce verification, and authentication patterns.
 */
abstract class AbstractRestController
{
    use RateLimiting;
    use Sanitization;

    protected const ROUTE_NAMESPACE = 'timesuite/v1';

    /**
     * Register REST routes. Called during rest_api_init.
     */
    abstract public function registerRoutes(): void;

    /**
     * Register the controller by hooking into rest_api_init.
     */
    public function register(): void
    {
        add_action('rest_api_init', [$this, 'registerRoutes']);
    }

    /**
     * Verify the WordPress REST nonce to prevent CSRF attacks.
     */
    protected function verifyNonce(WP_REST_Request $request): bool
    {
        $nonce = $this->resolveNonce($request);

        if (! is_string($nonce) || '' === $nonce) {
            return false;
        }

        return (bool) wp_verify_nonce($nonce, 'wp_rest');
    }

    /**
     * Resolve nonce from header or query param.
     */
    protected function resolveNonce(WP_REST_Request $request): ?string
    {
        $header = $request->get_header('X-WP-Nonce');

        if (is_string($header) && '' !== $header) {
            return $header;
        }

        $param = $request->get_param('_wpnonce');

        return is_string($param) ? $param : null;
    }

    /**
     * Ensure current user is authenticated.
     *
     * @return int|WP_Error User ID on success, WP_Error on failure.
     */
    protected function ensureAuthenticated(): int|WP_Error
    {
        $userId = get_current_user_id();

        if (! $userId) {
            return $this->authError();
        }

        return $userId;
    }

    /**
     * Create a standard WP_Error for validation failures.
     *
     * @param string|ValidationException $messageOrException
     */
    protected function validationError(string|ValidationException $messageOrException): WP_Error
    {
        $message = $messageOrException instanceof ValidationException
            ? $messageOrException->getMessage()
            : $messageOrException;

        return new WP_Error('timesuite_validation', $message, ['status' => 400]);
    }

    /**
     * Create a standard WP_Error for forbidden actions.
     *
     * @param string|ForbiddenException $messageOrException
     */
    protected function forbiddenError(string|ForbiddenException $messageOrException): WP_Error
    {
        $message = $messageOrException instanceof ForbiddenException
            ? $messageOrException->getMessage()
            : $messageOrException;

        return new WP_Error('timesuite_forbidden', $message, ['status' => 403]);
    }

    /**
     * Create a standard WP_Error for authentication failures.
     */
    protected function authError(): WP_Error
    {
        return new WP_Error('timesuite_auth', __('Not authenticated.', 'timesuite'), ['status' => 401]);
    }

    /**
     * Create a standard WP_Error for nonce failures.
     */
    protected function nonceError(): WP_Error
    {
        return new WP_Error('timesuite_nonce', __('Invalid nonce.', 'timesuite'), ['status' => 403]);
    }

    /**
     * Create a standard WP_Error for not found errors.
     *
     * @param string|NotFoundException $messageOrException
     */
    protected function notFoundError(string|NotFoundException $messageOrException): WP_Error
    {
        $message = $messageOrException instanceof NotFoundException
            ? $messageOrException->getMessage()
            : $messageOrException;

        return new WP_Error('timesuite_not_found', $message, ['status' => 404]);
    }

    /**
     * Create a standard WP_Error for internal server errors.
     */
    protected function serverError(string $message): WP_Error
    {
        return new WP_Error('timesuite_server', $message, ['status' => 500]);
    }

    /**
     * Turn a failed database write into a safe, structured 500.
     *
     * A PersistenceException carries the raw driver message -- table names,
     * column names, key names, sometimes fragments of the row. That is exactly
     * what an operator needs in the log and exactly what an employee must
     * never be shown, so the detail goes to error_log and the caller gets a
     * fixed, generic message with a stable error code the UI can branch on.
     *
     * These exceptions exist because ledger and timesheet writes now abort
     * rather than failing silently; every surface that can trigger one has to
     * catch it, or a rolled-back transaction surfaces to the user as an
     * unhandled fatal.
     *
     * @param string               $operation Short operator-facing description of what failed.
     * @param array<string, mixed> $context   Extra key/values for the log line.
     */
    protected function persistenceError(
        PersistenceException $exception,
        string $operation,
        array $context = []
    ): WP_Error {
        $encodedContext = '';

        if (! empty($context)) {
            $encoded = function_exists('wp_json_encode')
                ? wp_json_encode($context)
                : json_encode($context);

            $encodedContext = ' ' . (string) $encoded;
        }

        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        error_log(sprintf(
            'Timesuite: database write failed during %s.%s Detail: %s',
            $operation,
            $encodedContext,
            $exception->getMessage()
        ));

        return new WP_Error(
            'timesuite_persistence_failed',
            __('Your change could not be saved because of a database error. Nothing was changed. Please try again, and contact an administrator if it keeps happening.', 'timesuite'),
            ['status' => 500]
        );
    }

    /**
     * Check rate limit for an action and return error if exceeded.
     *
     * @param string $action The action being rate-limited.
     * @param int    $limit  Maximum requests allowed (default: 10 for expensive operations).
     * @param int    $window Time window in seconds (default: 60).
     *
     * @return WP_Error|null Returns WP_Error if rate limited, null otherwise.
     */
    protected function enforceRateLimit(string $action, int $limit = 10, int $window = 60): ?WP_Error
    {
        return $this->checkRateLimit($action, $limit, $window);
    }

    /**
     * Check if current user has a specific capability.
     *
     * Used directly in permission_callback closures for inline capability checks.
     * Returns bool|WP_Error for proper REST API error handling.
     *
     * @param string $capability The capability to check.
     *
     * @return bool|WP_Error
     */
    protected function checkPermission(string $capability): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to access this resource.', 'timesuite'),
                ['status' => 401]
            );
        }

        if (! current_user_can($capability)) {
            return new WP_Error(
                'timesuite_forbidden',
                __('You do not have permission to perform this action.', 'timesuite'),
                ['status' => 403]
            );
        }

        return true;
    }

    /**
     * Create a permission callback that checks for a specific capability.
     *
     * Returns a closure suitable for use as permission_callback that returns
     * proper WP_Error objects for better frontend error handling.
     *
     * @param string $capability The capability to check.
     * @param string $errorMessage Custom error message for forbidden access.
     *
     * @return callable
     */
    protected function requireCapability(string $capability, string $errorMessage = ''): callable
    {
        return function () use ($capability, $errorMessage): bool|WP_Error {
            if (! is_user_logged_in()) {
                return new WP_Error(
                    'timesuite_unauthorized',
                    __('You must be logged in to access this resource.', 'timesuite'),
                    ['status' => 401]
                );
            }

            if (! current_user_can($capability)) {
                return new WP_Error(
                    'timesuite_forbidden',
                    $errorMessage ?: __('You do not have permission to perform this action.', 'timesuite'),
                    ['status' => 403]
                );
            }

            return true;
        };
    }

    /**
     * Create a permission callback that checks for any of the given capabilities.
     *
     * @param string[] $capabilities List of capabilities (user must have at least one).
     * @param string $errorMessage Custom error message for forbidden access.
     *
     * @return callable
     */
    protected function requireAnyCapability(array $capabilities, string $errorMessage = ''): callable
    {
        return function () use ($capabilities, $errorMessage): bool|WP_Error {
            if (! is_user_logged_in()) {
                return new WP_Error(
                    'timesuite_unauthorized',
                    __('You must be logged in to access this resource.', 'timesuite'),
                    ['status' => 401]
                );
            }

            foreach ($capabilities as $capability) {
                if (current_user_can($capability)) {
                    return true;
                }
            }

            return new WP_Error(
                'timesuite_forbidden',
                $errorMessage ?: __('You do not have permission to perform this action.', 'timesuite'),
                ['status' => 403]
            );
        };
    }

    /**
     * Create a permission callback that only requires user to be logged in.
     *
     * @return callable
     */
    protected function requireLoggedIn(): callable
    {
        return function (): bool|WP_Error {
            if (! is_user_logged_in()) {
                return new WP_Error(
                    'timesuite_unauthorized',
                    __('You must be logged in to access this resource.', 'timesuite'),
                    ['status' => 401]
                );
            }

            return true;
        };
    }
}
