<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Concerns;

use WP_Error;

/**
 * Provides file upload validation utilities for REST controllers.
 */
trait FileUploadValidation
{
    /**
     * Validate an uploaded file's MIME type matches its extension.
     *
     * @param array<string, mixed> $file The $_FILES array entry.
     * @param string[] $allowedExtensions List of allowed extensions (without dot).
     * @param string[] $allowedMimes List of allowed MIME types.
     *
     * @return bool|WP_Error True if valid, WP_Error if invalid.
     */
    protected function validateUploadedFile(
        array $file,
        array $allowedExtensions,
        array $allowedMimes
    ): bool|WP_Error {
        $name = (string) ($file['name'] ?? '');
        $tmpPath = (string) ($file['tmp_name'] ?? '');
        $size = isset($file['size']) ? (int) $file['size'] : 0;

        // Check file exists.
        if ('' === $tmpPath || (! is_uploaded_file($tmpPath) && ! file_exists($tmpPath))) {
            return new WP_Error(
                'timesuite_upload_missing',
                __('Uploaded file missing.', 'timesuite'),
                ['status' => 400]
            );
        }

        // Check size.
        if ($size <= 0) {
            return new WP_Error(
                'timesuite_upload_empty',
                __('Uploaded file is empty.', 'timesuite'),
                ['status' => 400]
            );
        }

        // Check extension.
        $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));

        if (! in_array($extension, $allowedExtensions, true)) {
            return new WP_Error(
                'timesuite_upload_extension',
                sprintf(
                    /* translators: %s: comma-separated list of allowed extensions */
                    __('Invalid file type. Allowed: %s', 'timesuite'),
                    implode(', ', $allowedExtensions)
                ),
                ['status' => 400]
            );
        }

        // Verify MIME type using WordPress function.
        $mimeCheck = $this->verifyFileMimeType($tmpPath, $name, $allowedMimes);

        if (is_wp_error($mimeCheck)) {
            return $mimeCheck;
        }

        return true;
    }

    /**
     * Verify file MIME type matches expected types.
     *
     * @param string $filePath Path to the file.
     * @param string $fileName Original filename.
     * @param string[] $allowedMimes Allowed MIME types.
     *
     * @return bool|WP_Error True if valid, WP_Error if invalid.
     */
    protected function verifyFileMimeType(
        string $filePath,
        string $fileName,
        array $allowedMimes
    ): bool|WP_Error {
        // Use WordPress MIME checking if available.
        if (function_exists('wp_check_filetype_and_ext')) {
            $fileInfo = wp_check_filetype_and_ext($filePath, $fileName);

            // If WordPress couldn't determine the type, try finfo.
            if (empty($fileInfo['type'])) {
                return $this->verifyWithFinfo($filePath, $allowedMimes);
            }

            if (! in_array($fileInfo['type'], $allowedMimes, true)) {
                return new WP_Error(
                    'timesuite_upload_mime',
                    __('File content does not match its extension.', 'timesuite'),
                    ['status' => 400]
                );
            }

            return true;
        }

        // Fallback to finfo.
        return $this->verifyWithFinfo($filePath, $allowedMimes);
    }

    /**
     * Verify MIME type using PHP's finfo extension.
     *
     * @param string $filePath Path to the file.
     * @param string[] $allowedMimes Allowed MIME types.
     *
     * @return bool|WP_Error True if valid, WP_Error if invalid.
     */
    private function verifyWithFinfo(string $filePath, array $allowedMimes): bool|WP_Error
    {
        if (! function_exists('finfo_open')) {
            // Can't verify, allow it (rely on extension check).
            return true;
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);

        if (! $finfo) {
            return true;
        }

        $detectedMime = finfo_file($finfo, $filePath);
        finfo_close($finfo);

        if (false === $detectedMime) {
            return true;
        }

        // For spreadsheets, the detected MIME might be application/zip.
        // Allow it for XLSX files.
        $xlsxMimes = [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/zip',
            'application/octet-stream',
        ];

        $csvMimes = [
            'text/csv',
            'text/plain',
            'application/csv',
            'application/octet-stream',
        ];

        // Check if detected MIME is in allowed list or is a valid variant.
        if (in_array($detectedMime, $allowedMimes, true)) {
            return true;
        }

        // Allow ZIP-based detection for XLSX.
        if (
            in_array('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', $allowedMimes, true)
            && in_array($detectedMime, $xlsxMimes, true)
        ) {
            return true;
        }

        // Allow text-based detection for CSV.
        if (
            in_array('text/csv', $allowedMimes, true)
            && in_array($detectedMime, $csvMimes, true)
        ) {
            return true;
        }

        return new WP_Error(
            'timesuite_upload_mime',
            __('File content does not match its extension.', 'timesuite'),
            ['status' => 400]
        );
    }
}

