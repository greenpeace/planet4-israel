<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Concerns;

use WP_REST_Request;
use WP_REST_Response;

/**
 * Provides pagination support for REST API endpoints.
 */
trait Pagination
{
    /**
     * Default number of items per page.
     */
    protected int $defaultPerPage = 50;

    /**
     * Maximum allowed items per page.
     */
    protected int $maxPerPage = 100;

    /**
     * Get pagination parameters from request.
     *
     * @return array{page: int, per_page: int, offset: int}
     */
    protected function getPaginationParams(WP_REST_Request $request): array
    {
        $page = max(1, (int) ($request->get_param('page') ?? 1));
        $perPage = (int) ($request->get_param('per_page') ?? $this->defaultPerPage);
        $perPage = max(1, min($perPage, $this->maxPerPage));
        $offset = ($page - 1) * $perPage;

        return [
            'page'     => $page,
            'per_page' => $perPage,
            'offset'   => $offset,
        ];
    }

    /**
     * Get standard pagination arguments for route registration.
     *
     * @return array<string, array<string, mixed>>
     */
    protected function getPaginationArgs(): array
    {
        return [
            'page' => [
                'description'       => __('Current page of the collection.', 'timesuite'),
                'type'              => 'integer',
                'default'           => 1,
                'minimum'           => 1,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'description'       => __('Maximum number of items to be returned per page.', 'timesuite'),
                'type'              => 'integer',
                'default'           => $this->defaultPerPage,
                'minimum'           => 1,
                'maximum'           => $this->maxPerPage,
                'sanitize_callback' => 'absint',
            ],
        ];
    }

    /**
     * Paginate an array of items.
     *
     * @template T
     *
     * @param T[] $items All items to paginate.
     * @param int $page  Current page number (1-based).
     * @param int $perPage Items per page.
     *
     * @return array{items: T[], total: int, pages: int, page: int, per_page: int}
     */
    protected function paginateArray(array $items, int $page, int $perPage): array
    {
        $total = count($items);
        $pages = (int) ceil($total / $perPage);
        $offset = ($page - 1) * $perPage;

        return [
            'items'    => array_values(array_slice($items, $offset, $perPage)),
            'total'    => $total,
            'pages'    => $pages,
            'page'     => $page,
            'per_page' => $perPage,
        ];
    }

    /**
     * Create a paginated response with proper headers.
     *
     * @template T
     *
     * @param T[] $items Items for current page.
     * @param int $total Total number of items.
     * @param int $page  Current page number.
     * @param int $perPage Items per page.
     * @param WP_REST_Request $request The original request.
     *
     * @return WP_REST_Response
     */
    protected function paginatedResponse(
        array $items,
        int $total,
        int $page,
        int $perPage,
        WP_REST_Request $request
    ): WP_REST_Response {
        $pages = (int) ceil($total / $perPage);

        $response = new WP_REST_Response([
            'items'    => $items,
            'total'    => $total,
            'pages'    => $pages,
            'page'     => $page,
            'per_page' => $perPage,
        ], 200);

        // Add standard pagination headers
        $response->header('X-WP-Total', (string) $total);
        $response->header('X-WP-TotalPages', (string) $pages);

        // Add Link headers for navigation
        $links = $this->buildLinkHeader($request, $page, $pages);

        if (! empty($links)) {
            $response->header('Link', implode(', ', $links));
        }

        return $response;
    }

    /**
     * Build Link header parts for pagination navigation.
     *
     * @return string[]
     */
    private function buildLinkHeader(WP_REST_Request $request, int $page, int $pages): array
    {
        $links = [];
        $baseUrl = rest_url($request->get_route());
        $params = $request->get_query_params();

        // First page
        if ($page > 1) {
            $params['page'] = 1;
            $links[] = sprintf('<%s>; rel="first"', add_query_arg($params, $baseUrl));
        }

        // Previous page
        if ($page > 1) {
            $params['page'] = $page - 1;
            $links[] = sprintf('<%s>; rel="prev"', add_query_arg($params, $baseUrl));
        }

        // Next page
        if ($page < $pages) {
            $params['page'] = $page + 1;
            $links[] = sprintf('<%s>; rel="next"', add_query_arg($params, $baseUrl));
        }

        // Last page
        if ($page < $pages) {
            $params['page'] = $pages;
            $links[] = sprintf('<%s>; rel="last"', add_query_arg($params, $baseUrl));
        }

        return $links;
    }
}

