<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Concerns;

use WP_Error;

/**
 * Provides rate limiting functionality for REST API endpoints.
 *
 * Uses WordPress transients for storage, making it compatible with
 * object caching backends (Redis, Memcached) when available.
 */
trait RateLimiting
{
    /**
     * Default rate limit: requests per window.
     */
    protected int $rateLimit = 60;

    /**
     * Default window size in seconds.
     */
    protected int $rateLimitWindow = 60;

    /**
     * Predefined rate limits for different action types.
     * Override in your controller if needed.
     *
     * @var array<string, array{limit: int, window: int}>
     */
    protected static array $rateLimitPresets = [
        // Reads: generous limits
        'read'         => ['limit' => 120, 'window' => 60],
        'list'         => ['limit' => 60,  'window' => 60],

        // Writes: moderate limits
        'write'        => ['limit' => 30,  'window' => 60],
        'save'         => ['limit' => 30,  'window' => 60],

        // Imports: strict limits (resource intensive)
        'import'       => ['limit' => 5,   'window' => 300], // 5 per 5 minutes
        'bulk_import'  => ['limit' => 3,   'window' => 300], // 3 per 5 minutes

        // Exports: moderate limits (resource intensive)
        'export'       => ['limit' => 10,  'window' => 300], // 10 per 5 minutes

        // Bulk actions: strict limits
        'bulk_action'  => ['limit' => 10,  'window' => 60],
        'approve_all'  => ['limit' => 5,   'window' => 60],
        'deny_all'     => ['limit' => 5,   'window' => 60],

        // Auth-related: very strict
        'auth'         => ['limit' => 10,  'window' => 300],
    ];

    /**
     * Check rate limit using a preset configuration.
     *
     * @param string $preset Preset name (e.g., 'import', 'export', 'bulk_action').
     *
     * @return WP_Error|null Returns WP_Error if rate limited, null otherwise.
     */
    protected function checkRateLimitPreset(string $preset): ?WP_Error
    {
        $config = self::$rateLimitPresets[$preset] ?? self::$rateLimitPresets['write'];

        return $this->checkRateLimit($preset, $config['limit'], $config['window']);
    }

    /**
     * Check if the current request exceeds the rate limit.
     *
     * @param string $action  The action being rate-limited (e.g., 'import', 'export').
     * @param int    $limit   Maximum requests allowed (defaults to $this->rateLimit).
     * @param int    $window  Time window in seconds (defaults to $this->rateLimitWindow).
     *
     * @return WP_Error|null Returns WP_Error if rate limited, null otherwise.
     */
    protected function checkRateLimit(string $action, ?int $limit = null, ?int $window = null): ?WP_Error
    {
        $userId = get_current_user_id();

        if (0 === $userId) {
            // Unauthenticated requests use IP-based limiting
            $identifier = $this->getClientIp();
        } else {
            $identifier = 'user_' . $userId;
        }

        $limit = $limit ?? $this->rateLimit;
        $window = $window ?? $this->rateLimitWindow;

        $key = $this->getRateLimitKey($action, $identifier);
        $data = $this->getRateLimitData($key);

        $currentTime = time();
        $windowStart = $currentTime - $window;

        // Filter out expired entries
        $requests = array_filter(
            $data['requests'] ?? [],
            static fn (int $timestamp): bool => $timestamp > $windowStart
        );

        $requestCount = count($requests);

        if ($requestCount >= $limit) {
            $retryAfter = max(1, min($requests) - $windowStart);

            return new WP_Error(
                'rate_limit_exceeded',
                sprintf(
                    /* translators: 1: number of seconds until rate limit resets */
                    __('Rate limit exceeded. Please try again in %d seconds.', 'timesuite'),
                    $retryAfter
                ),
                [
                    'status'      => 429,
                    'retry_after' => $retryAfter,
                    'limit'       => $limit,
                    'remaining'   => 0,
                    'reset'       => $windowStart + $window,
                ]
            );
        }

        // Add current request
        $requests[] = $currentTime;

        // Store updated data
        $this->setRateLimitData($key, ['requests' => array_values($requests)], $window);

        // Set rate limit headers (will be added to response)
        $this->setRateLimitHeaders($limit, $limit - $requestCount - 1, $windowStart + $window);

        return null;
    }

    /**
     * Generate a unique cache key for rate limiting.
     */
    private function getRateLimitKey(string $action, string $identifier): string
    {
        return 'timesuite_rate_' . md5($action . '_' . $identifier);
    }

    /**
     * Get rate limit data from transient.
     *
     * @return array{requests: int[]}
     */
    private function getRateLimitData(string $key): array
    {
        $data = get_transient($key);

        if (! is_array($data)) {
            return ['requests' => []];
        }

        return $data;
    }

    /**
     * Store rate limit data in transient.
     *
     * @param array{requests: int[]} $data
     */
    private function setRateLimitData(string $key, array $data, int $expiration): void
    {
        set_transient($key, $data, $expiration);
    }

    /**
     * Set rate limit headers on the response.
     *
     * These headers inform clients about their rate limit status.
     */
    private function setRateLimitHeaders(int $limit, int $remaining, int $reset): void
    {
        // Headers will be sent with the REST API response
        add_filter('rest_post_dispatch', function ($response) use ($limit, $remaining, $reset) {
            if ($response instanceof \WP_REST_Response) {
                $response->header('X-RateLimit-Limit', (string) $limit);
                $response->header('X-RateLimit-Remaining', (string) max(0, $remaining));
                $response->header('X-RateLimit-Reset', (string) $reset);
            }

            return $response;
        }, 10, 1);
    }

    /**
     * Get the client's IP address.
     */
    private function getClientIp(): string
    {
        // Check for proxy headers (in order of trust)
        $headers = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
            'REMOTE_ADDR',
        ];

        foreach ($headers as $header) {
            if (! empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];

                // X-Forwarded-For may contain multiple IPs; take the first
                if (str_contains($ip, ',')) {
                    $ip = trim(explode(',', $ip)[0]);
                }

                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }
}

