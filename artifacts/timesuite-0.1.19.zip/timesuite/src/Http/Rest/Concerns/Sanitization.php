<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Concerns;

use Timesuite\Domain\Shared\Exceptions\ValidationException;
use WP_REST_Request;

/**
 * Provides shared sanitization helpers for REST controllers.
 *
 * Centralizes input parsing/sanitization to ensure consistency
 * across all endpoints.
 */
trait Sanitization
{
    /**
     * Parse and validate a date parameter (Y-m-d format).
     *
     * @param mixed $value The raw parameter value.
     * @param bool  $required Whether the parameter is required.
     * @param string $fieldName Field name for error messages.
     *
     * @return string|null The validated date string, or null if optional and empty.
     *
     * @throws ValidationException If validation fails.
     */
    protected function sanitizeDate(mixed $value, bool $required = false, string $fieldName = 'date'): ?string
    {
        if (! is_string($value) || '' === trim($value)) {
            if ($required) {
                throw new ValidationException(
                    /* translators: %s: field name */
                    sprintf(__('%s is required.', 'timesuite'), $fieldName)
                );
            }

            return null;
        }

        $value = trim($value);
        $dt = \DateTime::createFromFormat('Y-m-d', $value);

        if (! $dt || $dt->format('Y-m-d') !== $value) {
            throw new ValidationException(
                /* translators: %s: field name */
                sprintf(__('%s must be in YYYY-MM-DD format.', 'timesuite'), $fieldName)
            );
        }

        return $value;
    }

    /**
     * Parse and validate a year parameter.
     *
     * @param mixed $value The raw parameter value.
     * @param int   $minYear Minimum allowed year (default: 2000).
     * @param int   $maxYear Maximum allowed year (default: 2100).
     *
     * @return int The validated year.
     *
     * @throws ValidationException If validation fails.
     */
    protected function sanitizeYear(mixed $value, int $minYear = 2000, int $maxYear = 2100): int
    {
        $year = (int) $value;

        if ($year < $minYear || $year > $maxYear) {
            throw new ValidationException(
                /* translators: 1: minimum year, 2: maximum year */
                sprintf(__('Year must be between %1$d and %2$d.', 'timesuite'), $minYear, $maxYear)
            );
        }

        return $year;
    }

    /**
     * Parse and validate a month parameter (1-12).
     *
     * @param mixed $value The raw parameter value.
     *
     * @return int The validated month.
     *
     * @throws ValidationException If validation fails.
     */
    protected function sanitizeMonth(mixed $value): int
    {
        $month = (int) $value;

        if ($month < 1 || $month > 12) {
            throw new ValidationException(__('Month must be between 1 and 12.', 'timesuite'));
        }

        return $month;
    }

    /**
     * Parse and validate a positive integer.
     *
     * @param mixed  $value The raw parameter value.
     * @param bool   $required Whether the parameter is required.
     * @param string $fieldName Field name for error messages.
     * @param int    $min Minimum allowed value (default: 1).
     * @param int    $max Maximum allowed value (default: PHP_INT_MAX).
     *
     * @return int|null The validated integer, or null if optional and empty.
     *
     * @throws ValidationException If validation fails.
     */
    protected function sanitizePositiveInt(
        mixed $value,
        bool $required = false,
        string $fieldName = 'value',
        int $min = 1,
        int $max = PHP_INT_MAX
    ): ?int {
        if (null === $value || '' === $value) {
            if ($required) {
                throw new ValidationException(
                    /* translators: %s: field name */
                    sprintf(__('%s is required.', 'timesuite'), $fieldName)
                );
            }

            return null;
        }

        $int = (int) $value;

        if ($int < $min || $int > $max) {
            throw new ValidationException(
                /* translators: 1: field name, 2: minimum value, 3: maximum value */
                sprintf(__('%1$s must be between %2$d and %3$d.', 'timesuite'), $fieldName, $min, $max)
            );
        }

        return $int;
    }

    /**
     * Parse and validate an enum value against allowed options.
     *
     * @param mixed    $value The raw parameter value.
     * @param string[] $allowedValues List of allowed values.
     * @param bool     $required Whether the parameter is required.
     * @param string   $fieldName Field name for error messages.
     *
     * @return string|null The validated enum value, or null if optional and empty.
     *
     * @throws ValidationException If validation fails.
     */
    protected function sanitizeEnum(
        mixed $value,
        array $allowedValues,
        bool $required = false,
        string $fieldName = 'value'
    ): ?string {
        if (! is_string($value) || '' === trim($value)) {
            if ($required) {
                throw new ValidationException(
                    /* translators: %s: field name */
                    sprintf(__('%s is required.', 'timesuite'), $fieldName)
                );
            }

            return null;
        }

        $value = trim($value);

        if (! in_array($value, $allowedValues, true)) {
            throw new ValidationException(
                /* translators: 1: field name, 2: comma-separated allowed values */
                sprintf(
                    __('%1$s must be one of: %2$s.', 'timesuite'),
                    $fieldName,
                    implode(', ', $allowedValues)
                )
            );
        }

        return $value;
    }

    /**
     * Parse and validate a text field with optional length limits.
     *
     * @param mixed  $value The raw parameter value.
     * @param bool   $required Whether the parameter is required.
     * @param string $fieldName Field name for error messages.
     * @param int    $maxLength Maximum allowed length (default: 255).
     *
     * @return string|null The sanitized string, or null if optional and empty.
     *
     * @throws ValidationException If validation fails.
     */
    protected function sanitizeText(
        mixed $value,
        bool $required = false,
        string $fieldName = 'value',
        int $maxLength = 255
    ): ?string {
        if (! is_string($value)) {
            $value = is_scalar($value) ? (string) $value : '';
        }

        $value = sanitize_text_field($value);

        if ('' === $value) {
            if ($required) {
                throw new ValidationException(
                    /* translators: %s: field name */
                    sprintf(__('%s is required.', 'timesuite'), $fieldName)
                );
            }

            return null;
        }

        if (mb_strlen($value) > $maxLength) {
            throw new ValidationException(
                /* translators: 1: field name, 2: maximum length */
                sprintf(__('%1$s must not exceed %2$d characters.', 'timesuite'), $fieldName, $maxLength)
            );
        }

        return $value;
    }

    /**
     * Parse and validate an email address.
     *
     * @param mixed  $value The raw parameter value.
     * @param bool   $required Whether the parameter is required.
     * @param string $fieldName Field name for error messages.
     *
     * @return string|null The validated email, or null if optional and empty.
     *
     * @throws ValidationException If validation fails.
     */
    protected function sanitizeEmail(
        mixed $value,
        bool $required = false,
        string $fieldName = 'email'
    ): ?string {
        if (! is_string($value) || '' === trim($value)) {
            if ($required) {
                throw new ValidationException(
                    /* translators: %s: field name */
                    sprintf(__('%s is required.', 'timesuite'), $fieldName)
                );
            }

            return null;
        }

        $email = sanitize_email(trim($value));

        if (! is_email($email)) {
            throw new ValidationException(
                /* translators: %s: field name */
                sprintf(__('%s must be a valid email address.', 'timesuite'), $fieldName)
            );
        }

        return strtolower($email);
    }

    /**
     * Parse and validate a boolean value.
     *
     * Accepts: true/false, 1/0, "true"/"false", "1"/"0", "yes"/"no", "on"/"off"
     *
     * @param mixed $value The raw parameter value.
     * @param bool  $default Default value if not provided.
     *
     * @return bool The parsed boolean value.
     */
    protected function sanitizeBool(mixed $value, bool $default = false): bool
    {
        if (null === $value || '' === $value) {
            return $default;
        }

        if (is_bool($value)) {
            return $value;
        }

        if (is_int($value)) {
            return $value !== 0;
        }

        $value = strtolower(trim((string) $value));

        return in_array($value, ['1', 'true', 'yes', 'on'], true);
    }

    /**
     * Parse and validate a user ID, optionally checking existence.
     *
     * @param mixed $value The raw parameter value.
     * @param bool  $required Whether the parameter is required.
     * @param bool  $checkExists Whether to verify the user exists.
     *
     * @return int|null The validated user ID, or null if optional and empty.
     *
     * @throws ValidationException If validation fails.
     */
    protected function sanitizeUserId(
        mixed $value,
        bool $required = false,
        bool $checkExists = true
    ): ?int {
        $userId = $this->sanitizePositiveInt($value, $required, __('User ID', 'timesuite'));

        if (null === $userId) {
            return null;
        }

        if ($checkExists && ! get_user_by('id', $userId)) {
            throw new ValidationException(__('User not found.', 'timesuite'));
        }

        return $userId;
    }

    /**
     * Extract and sanitize year/month from request.
     *
     * @param WP_REST_Request $request The REST request.
     *
     * @return array{year: int, month: int}
     *
     * @throws ValidationException If validation fails.
     */
    protected function extractYearMonth(WP_REST_Request $request): array
    {
        return [
            'year' => $this->sanitizeYear($request->get_param('year')),
            'month' => $this->sanitizeMonth($request->get_param('month')),
        ];
    }
}

