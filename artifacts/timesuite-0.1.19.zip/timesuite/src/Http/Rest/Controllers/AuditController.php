<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Http\Rest\AbstractRestController;
use Timesuite\Http\Rest\Concerns\Pagination;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use wpdb;

/**
 * Audit log controller for viewing activity history.
 */
class AuditController extends AbstractRestController
{
    use Pagination;

    public function __construct(private wpdb $wpdb)
    {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/audit',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'listLogs'],
                'permission_callback' => function () {
                    return $this->checkPermission('timesuite.audit.view');
                },
                'args'                => [
                    'page'        => [
                        'type'    => 'integer',
                        'default' => 1,
                        'minimum' => 1,
                    ],
                    'per_page'    => [
                        'type'    => 'integer',
                        'default' => 50,
                        'minimum' => 1,
                        'maximum' => 100,
                    ],
                    'action'      => [
                        'type' => 'string',
                    ],
                    'entity_type' => [
                        'type' => 'string',
                    ],
                    'actor_id'    => [
                        'type' => 'integer',
                    ],
                    'from'        => [
                        'type'   => 'string',
                        'format' => 'date',
                    ],
                    'to'          => [
                        'type'   => 'string',
                        'format' => 'date',
                    ],
                ],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/audit/summary',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getSummary'],
                'permission_callback' => function () {
                    return $this->checkPermission('timesuite.audit.view');
                },
            ]
        );
    }

    /**
     * List audit log entries with pagination and filters.
     */
    public function listLogs(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $page       = (int) $request->get_param('page');
        $perPage    = (int) $request->get_param('per_page');
        $action     = $request->get_param('action');
        $entityType = $request->get_param('entity_type');
        $actorId    = $request->get_param('actor_id');
        $from       = $request->get_param('from');
        $to         = $request->get_param('to');

        $table      = $this->wpdb->prefix . 'timesuite_approvals_log';
        $usersTable = $this->wpdb->users;

        // Build WHERE conditions
        $conditions = [];
        $values     = [];

        if ($action) {
            $conditions[] = 'al.action = %s';
            $values[]     = sanitize_text_field($action);
        }

        if ($entityType) {
            $conditions[] = 'al.entity_type = %s';
            $values[]     = sanitize_text_field($entityType);
        }

        if ($actorId) {
            $conditions[] = 'al.actor_id = %d';
            $values[]     = absint($actorId);
        }

        if ($from) {
            $conditions[] = 'DATE(al.created_at) >= %s';
            $values[]     = sanitize_text_field($from);
        }

        if ($to) {
            $conditions[] = 'DATE(al.created_at) <= %s';
            $values[]     = sanitize_text_field($to);
        }

        $where = empty($conditions) ? '' : 'WHERE ' . implode(' AND ', $conditions);

        // Get total count
        $countSql = "SELECT COUNT(*) FROM {$table} al {$where}";

        if (! empty($values)) {
            $countSql = $this->wpdb->prepare($countSql, $values);
        }

        $total = (int) $this->wpdb->get_var($countSql);

        // Get paginated results
        $offset    = ($page - 1) * $perPage;
        $values[]  = $perPage;
        $values[]  = $offset;

        $dataSql = "
            SELECT 
                al.id,
                al.entry_id,
                al.period_id,
                al.actor_id,
                al.entity_type,
                al.entity_id,
                al.action,
                al.comment,
                al.created_at,
                u.display_name AS actor_name,
                u.user_email AS actor_email
            FROM {$table} al
            LEFT JOIN {$usersTable} u ON u.ID = al.actor_id
            {$where}
            ORDER BY al.created_at DESC
            LIMIT %d OFFSET %d
        ";

        $dataSql = $this->wpdb->prepare($dataSql, $values);
        $results = $this->wpdb->get_results($dataSql, ARRAY_A) ?? [];

        // Format results
        $logs = array_map(function (array $row): array {
            return [
                'id'          => (int) $row['id'],
                'actor'       => [
                    'id'    => (int) $row['actor_id'],
                    'name'  => $row['actor_name'] ?: $row['actor_email'] ?: __('System', 'timesuite'),
                    'email' => $row['actor_email'] ?? '',
                ],
                'action'      => $row['action'],
                'entity_type' => $row['entity_type'],
                'entity_id'   => (int) $row['entity_id'],
                'comment'     => $row['comment'],
                'created_at'  => $row['created_at'],
                'description' => $this->formatLogDescription($row),
            ];
        }, $results);

        return new WP_REST_Response([
            'logs'     => $logs,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'pages'    => (int) ceil($total / $perPage),
        ], 200);
    }

    /**
     * Get audit log summary statistics.
     */
    public function getSummary(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $table = $this->wpdb->prefix . 'timesuite_approvals_log';

        // Total count
        $total = (int) $this->wpdb->get_var("SELECT COUNT(*) FROM {$table}");

        // Counts by action
        $actionCounts = $this->wpdb->get_results(
            "SELECT action, COUNT(*) as count FROM {$table} GROUP BY action ORDER BY count DESC",
            ARRAY_A
        ) ?? [];

        // Counts by entity type
        $typeCounts = $this->wpdb->get_results(
            "SELECT entity_type, COUNT(*) as count FROM {$table} GROUP BY entity_type ORDER BY count DESC",
            ARRAY_A
        ) ?? [];

        // Recent 24h count
        $last24h = (int) $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s",
                gmdate('Y-m-d H:i:s', strtotime('-24 hours'))
            )
        );

        // Recent 7 days count
        $last7d = (int) $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s",
                gmdate('Y-m-d H:i:s', strtotime('-7 days'))
            )
        );

        // Oldest entry
        $oldest = $this->wpdb->get_var("SELECT MIN(created_at) FROM {$table}");

        return new WP_REST_Response([
            'total'        => $total,
            'last_24h'     => $last24h,
            'last_7d'      => $last7d,
            'by_action'    => $this->formatCounts($actionCounts),
            'by_type'      => $this->formatCounts($typeCounts),
            'oldest_entry' => $oldest,
        ], 200);
    }

    /**
     * Format a log entry into a human-readable description.
     */
    private function formatLogDescription(array $row): string
    {
        $actorName = $row['actor_name'] ?: $row['actor_email'] ?: __('System', 'timesuite');
        $action    = $row['action'];
        $type      = $row['entity_type'];

        $descriptions = [
            'submit'  => sprintf(__('%s submitted a timesheet', 'timesuite'), $actorName),
            'approve' => sprintf(__('%s approved a timesheet', 'timesuite'), $actorName),
            'deny'    => sprintf(__('%s denied a timesheet', 'timesuite'), $actorName),
            'lock'    => sprintf(__('%s locked a period', 'timesuite'), $actorName),
            'month_locked' => sprintf(__('%s locked a month', 'timesuite'), $actorName),
            'month_reopened' => sprintf(__('%s reopened a locked month', 'timesuite'), $actorName),
            'undo_submit' => sprintf(__('%s moved a month back to draft', 'timesuite'), $actorName),
            'request_created' => sprintf(__('%s requested to re-edit a locked month', 'timesuite'), $actorName),
            'request_approved' => sprintf(__('%s approved a re-edit request', 'timesuite'), $actorName),
            'request_denied' => sprintf(__('%s denied a re-edit request', 'timesuite'), $actorName),
            'reset'   => sprintf(__('%s reset a timesheet', 'timesuite'), $actorName),
            'import'  => sprintf(__('%s imported data', 'timesuite'), $actorName),
            'export'  => sprintf(__('%s exported data', 'timesuite'), $actorName),
            'update'  => sprintf(__('%s updated %s', 'timesuite'), $actorName, $type),
            'create'  => sprintf(__('%s created %s', 'timesuite'), $actorName, $type),
            'delete'  => sprintf(__('%s deleted %s', 'timesuite'), $actorName, $type),
        ];

        return $descriptions[$action] ?? sprintf(__('%s performed %s on %s', 'timesuite'), $actorName, $action, $type);
    }

    /**
     * Format count results into a key-value array.
     *
     * @param array<int, array{action?: string, entity_type?: string, count: string}> $results
     *
     * @return array<string, int>
     */
    private function formatCounts(array $results): array
    {
        $formatted = [];

        foreach ($results as $row) {
            $key             = $row['action'] ?? $row['entity_type'] ?? 'unknown';
            $formatted[$key] = (int) $row['count'];
        }

        return $formatted;
    }
}

