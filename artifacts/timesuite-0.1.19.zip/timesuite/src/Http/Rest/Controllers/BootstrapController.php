<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Core\Access\BootstrapService;
use Timesuite\Core\Access\Role;
use Timesuite\Core\Access\RoleAssignmentService;
use Timesuite\Http\Rest\AbstractRestController;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Bootstrap Controller: First-time setup for Timesuite.
 *
 * Uses the "Bootstrap Gate" approach:
 * - When no tech_admin exists, WP admins can access this endpoint
 * - ONLY bootstrap routes are allowed in bootstrap mode (no global cap filtering)
 * - Once a tech_admin is set, bootstrap mode exits and normal security applies
 *
 * This is the ONLY entry point for first-time setup.
 */
class BootstrapController extends AbstractRestController
{
    public function __construct(
        private RoleAssignmentService $roleService
    ) {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/bootstrap/status',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'getStatus'],
                'permission_callback' => function () {
                    // Any logged-in user can check status
                    return is_user_logged_in();
                },
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/bootstrap/setup',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'setupFirstAdmin'],
                'permission_callback' => function () {
                    // Only WP admins can set up the first admin
                    // And only in bootstrap mode
                    return BootstrapService::canAccessBootstrap(get_current_user_id());
                },
                'args'                => [
                    'user_id' => [
                        'required'          => true,
                        'type'              => 'integer',
                        'validate_callback' => static fn($value) => is_numeric($value) && (int) $value > 0,
                    ],
                ],
            ]
        );
    }

    /**
     * Get bootstrap mode status.
     *
     * Returns whether the system is in bootstrap mode (no tech admin exists)
     * and whether the current user has permission to set one up.
     */
    public function getStatus(WP_REST_Request $request): WP_REST_Response
    {
        return new WP_REST_Response(BootstrapService::getStatus(), 200);
    }

    /**
     * Set up the first Timesuite tech admin.
     *
     * This endpoint is only available in bootstrap mode and only to WordPress administrators.
     * It assigns the tech_admin role to the specified user and exits bootstrap mode.
     *
     * All role assignment goes through RoleAssignmentService (single entry point).
     */
    public function setupFirstAdmin(WP_REST_Request $request): WP_REST_Response
    {
        // Double-check bootstrap mode (defense in depth)
        if (! BootstrapService::isBootstrapMode()) {
            return new WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Bootstrap mode is not active. A tech admin already exists.', 'timesuite'),
                ],
                400
            );
        }

        $userId = (int) $request->get_param('user_id');

        // Validate user exists
        $user = get_user_by('id', $userId);

        if (! $user) {
            return new WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('User not found.', 'timesuite'),
                ],
                404
            );
        }

        try {
            // Use RoleAssignmentService - the single entry point for all role changes
            // skipAuthCheck=true because this is bootstrap (no tech_admin exists to authorize)
            $success = $this->roleService->assignRole(
                $userId,
                Role::TECH_ADMIN,
                get_current_user_id(),
                'bootstrap_setup',
                true // Skip auth check - no tech_admin exists to authorize yet
            );

            if (! $success) {
                throw new \RuntimeException('Failed to assign role');
            }
        } catch (\Throwable $e) {
            return new WP_REST_Response(
                [
                    'success' => false,
                    'message' => __('Failed to assign tech admin role.', 'timesuite'),
                    'error'   => WP_DEBUG ? $e->getMessage() : null,
                ],
                500
            );
        }

        // Cache is automatically cleared by RoleAssignmentService

        return new WP_REST_Response(
            [
                'success' => true,
                'message' => sprintf(
                    /* translators: %s: user email */
                    __('Successfully set up %s as the first Timesuite administrator.', 'timesuite'),
                    $user->user_email
                ),
                'user'    => [
                    'id'    => (int) $user->ID,
                    'name'  => $user->display_name ?: $user->user_email,
                    'email' => $user->user_email,
                ],
            ],
            200
        );
    }
}
