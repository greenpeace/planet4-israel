<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Core\Access\Role;
use Timesuite\Core\Access\RoleAssignmentService;
use Timesuite\Core\Settings;
use Timesuite\Domain\Org\Services\OrgService;
use Timesuite\Domain\Org\Services\UserRemovalService;
use Timesuite\Domain\Shared\Exceptions\ForbiddenException;
use Timesuite\Domain\Shared\Exceptions\PersistenceException;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Timesheets\Services\CompTimeService;
use Timesuite\Domain\Timesheets\Services\VacationService;
use Timesuite\Http\Rest\AbstractRestController;
use Timesuite\Http\Rest\Concerns\Pagination;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class DirectoryController extends AbstractRestController
{
    use Pagination;

    private const USER_META_DAILY_HOURS_BY_DAY = 'timesuite_daily_hours_by_day';
    private const USER_META_HIRE_DATE = 'timesuite_hire_date';
    private const USER_META_EMPLOYMENT_END_DATE = 'timesuite_employment_end_date';

    public function __construct(
        private OrgService $orgService,
        private Settings $settings,
        private UserRemovalService $userRemovalService,
        private AuthorizationService $authService,
        private RoleAssignmentService $roleService,
        private VacationService $vacationService,
        private CompTimeService $compTimeService
    ) {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/directory/users',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'listUsers'],
                    'permission_callback' => [$this, 'checkLoggedIn'],
                    'args'                => $this->getPaginationArgs(),
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'saveUser'],
                    'permission_callback' => [$this, 'checkManageDirectoryPermission'],
                ],
            ]
        );

        // Deliberately its own endpoint. A Time-in-Lieu balance adjustment is
        // the one write in this controller that can fail at the database
        // level, and it used to run last inside saveUser() -- after the
        // profile fields had already been written. Reporting "nothing was
        // changed" there was simply false. On its own it is the entire
        // request, so a failure really does leave everything untouched.
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/directory/users/comp-time-balance',
            [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'saveCompTimeBalance'],
                    'permission_callback' => [$this, 'checkManageDirectoryPermission'],
                ],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/directory/users/(?P<id>\\d+)',
            [
                [
                    'methods'             => WP_REST_Server::DELETABLE,
                    'callback'            => [$this, 'deleteUser'],
                    'permission_callback' => [$this, 'checkDeleteUserPermission'],
                ],
            ]
        );
    }

    public function listUsers(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        $pagination = $this->getPaginationParams($request);
        $mappings = $this->orgService->getMappings();
        $mappingByUser = [];

        foreach ($mappings as $mapping) {
            $mappingByUser[(int) $mapping['user_id']] = $mapping;
        }

        $ids   = $this->resolveVisibleUserIds($currentUser);
        $users = [];
        $defaultWorkWeek = $this->settings->getWorkWeek();
        $defaultDailyHours = $this->settings->getDailyHours();
        $defaultExpiryMonths = $this->settings->getCompTimeExpiryMonths();
        $defaultVacationDays = $this->settings->getDefaultVacationDays();
        $currentYear = (int) gmdate('Y');

        // Get vacation stats for all users efficiently
        $vacationStats = $this->vacationService->getBulkStats($ids, $currentYear);

        foreach ($ids as $rawUserId) {
            $userId = (int) $rawUserId; // Ensure userId is int (WordPress can return strings)
            $user = get_user_by('id', $userId);

            if (! $user) {
                continue;
            }

            if ((string) get_user_meta($userId, 'timesuite_removed', true) === '1') {
                continue;
            }

            $mapping = $mappingByUser[$userId] ?? null;
            $workWeek = get_user_meta($userId, 'timesuite_work_week', true);
            $expiryMonths = get_user_meta($userId, 'timesuite_comp_time_expiry_months', true);
            $storedDailyHoursByDay = $this->normalizeStoredDailyHoursByDay(
                get_user_meta($userId, self::USER_META_DAILY_HOURS_BY_DAY, true)
            );
            $employmentStartDate = $this->normalizeDateValue(
                get_user_meta($userId, self::USER_META_HIRE_DATE, true)
            );
            $employmentEndDate = $this->normalizeDateValue(
                get_user_meta($userId, self::USER_META_EMPLOYMENT_END_DATE, true)
            );

            if (! is_array($workWeek) || empty($workWeek)) {
                $workWeek = $defaultWorkWeek;
            }

            if ('' === $expiryMonths || $expiryMonths === null) {
                $expiryMonths = $defaultExpiryMonths;
            }

            // Get vacation and sick stats for this user
            $userStats = $vacationStats[$userId] ?? [
                'vacation_contract' => $defaultVacationDays,
                'vacation_used' => 0,
                'vacation_remaining' => $defaultVacationDays,
                'sick_contract' => $this->settings->getDefaultSickDays(),
                'sick_used' => 0,
                'sick_remaining' => $this->settings->getDefaultSickDays(),
            ];

            // Get comp time balance (ensure int type for userId)
            $compTimeBalance = $this->compTimeService->getAvailableMinutes((int) $userId, gmdate('Y-m-d'));

            $users[] = [
                'id'          => $userId,
                'name'        => $user->display_name ?: $user->user_login,
                'email'       => $user->user_email,
                'department'  => get_user_meta($userId, 'timesuite_department', true) ?: '',
                'employment_start_date' => $employmentStartDate,
                'employment_end_date' => $employmentEndDate,
                'work_week'   => $workWeek,
                'daily_hours_by_day' => $this->buildEffectiveDailyHoursByDay($workWeek, $storedDailyHoursByDay),
                'has_custom_daily_hours' => ! empty($storedDailyHoursByDay),
                'comp_time_expiry_months' => (int) $expiryMonths,
                'manager_id'  => $mapping['manager_id'] ?? null,
                'manager_name'=> $this->resolveManagerName((int) ($mapping['manager_id'] ?? 0)),
                'timesuite_role' => $this->authService->getRoleForUser((int) $userId),
                // Vacation tracking
                'vacation_days_contract' => $userStats['vacation_contract'],
                'vacation_days_used' => $userStats['vacation_used'],
                'vacation_days_remaining' => $userStats['vacation_remaining'],
                'vacation_carryover_cap_days' => $this->vacationService->getVacationCarryoverCapDays($userId),
                // Sick days tracking
                'sick_days_contract' => $userStats['sick_contract'],
                'sick_days_used' => $userStats['sick_used'],
                'sick_days_remaining' => $userStats['sick_remaining'],
                'sick_carryover_cap_days' => $this->vacationService->getSickCarryoverCapDays($userId),
                // Comp time / Time in lieu
                'comp_time_balance_minutes' => $compTimeBalance,
            ];
        }

        // Paginate results
        $total = count($users);
        $paginatedUsers = array_slice($users, $pagination['offset'], $pagination['per_page']);

        $response = $this->paginatedResponse(
            $paginatedUsers,
            $total,
            $pagination['page'],
            $pagination['per_page'],
            $request
        );

        // Add defaults to response data
        $data = $response->get_data();
        $data['defaults'] = [
            'work_week' => $defaultWorkWeek,
            'work_week_options' => Settings::WORK_WEEK_OPTIONS,
            'daily_hours' => $defaultDailyHours,
            'leave_standard_day_hours' => $this->settings->getLeaveStandardDayHours(),
            'comp_time_expiry_months' => $defaultExpiryMonths,
            'default_vacation_days' => $defaultVacationDays,
            'default_sick_days' => $this->settings->getDefaultSickDays(),
            'time_off_reset_enabled' => $this->settings->isTimeOffResetEnabled(),
            'time_off_reset_vacation_enabled' => $this->settings->isVacationCarryoverCapEnabled(),
            'time_off_reset_sick_enabled' => $this->settings->isSickCarryoverCapEnabled(),
            'time_off_reset_vacation_days' => $this->settings->getTimeOffResetVacationDays(),
            'time_off_reset_sick_days' => $this->settings->getTimeOffResetSickDays(),
        ];
        // Rename items to users for backwards compatibility
        $data['users'] = $data['items'];
        unset($data['items']);
        $response->set_data($data);

        return $response;
    }

    public function saveUser(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        // Use AuthorizationService instead of duplicated hasHrPowers()
        if (! $this->authService->hasOrgManagementPowers($currentUser)) {
            return $this->forbiddenError(__('Insufficient permissions.', 'timesuite'));
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $body = $request->get_json_params();

        if (! is_array($body)) {
            return $this->validationError(__('Invalid payload.', 'timesuite'));
        }

        $email      = isset($body['email']) ? sanitize_email((string) $body['email']) : '';
        $name       = isset($body['name']) ? sanitize_text_field((string) $body['name']) : '';
        $department = isset($body['department']) ? sanitize_text_field((string) $body['department']) : '';
        $employmentStartDate = $this->normalizeOptionalDateField(
            $body['employment_start_date'] ?? null,
            'timesuite_employment_start_date',
            'employment_start_date',
            __('Employment start date must use YYYY-MM-DD format.', 'timesuite')
        );
        if (is_wp_error($employmentStartDate)) {
            return $employmentStartDate;
        }
        $employmentEndDate = $this->normalizeOptionalDateField(
            $body['employment_end_date'] ?? null,
            'timesuite_employment_end_date',
            'employment_end_date',
            __('Employment end date must use YYYY-MM-DD format.', 'timesuite')
        );
        if (is_wp_error($employmentEndDate)) {
            return $employmentEndDate;
        }
        if ($employmentStartDate !== null && $employmentEndDate !== null && $employmentEndDate < $employmentStartDate) {
            return new WP_Error('timesuite_employment_end_before_start', __('Employment end date cannot be before employment start date.', 'timesuite'), [
                'status' => 400,
                'field' => 'employment_end_date',
            ]);
        }
        $managerId  = isset($body['manager_id']) ? (int) $body['manager_id'] : null;
        $workWeek   = isset($body['work_week']) && is_array($body['work_week']) ? $body['work_week'] : null;
        $dailyHoursByDay = $body['daily_hours_by_day'] ?? null;
        $expiryMonths = $body['comp_time_expiry_months'] ?? null;
        $vacationDaysContract = $body['vacation_days_contract'] ?? null;
        $sickDaysContract = $body['sick_days_contract'] ?? null;
        $vacationDaysRemaining = $body['vacation_days_remaining'] ?? null;
        $sickDaysRemaining = $body['sick_days_remaining'] ?? null;
        $vacationCarryoverCapDays = $body['vacation_carryover_cap_days'] ?? null;
        $sickCarryoverCapDays = $body['sick_carryover_cap_days'] ?? null;
        $timesuiteRole = isset($body['timesuite_role']) ? strtolower(trim((string) $body['timesuite_role'])) : '';
        $requestedUserId = isset($body['user_id']) ? (int) $body['user_id'] : null;

        if ($requestedUserId !== null && $requestedUserId <= 0) {
            $requestedUserId = null;
        }

        $existingUser = null;

        if ($requestedUserId) {
            $existingUser = get_user_by('id', $requestedUserId);

            if (! $existingUser) {
                return $this->notFoundError(__('User not found.', 'timesuite'));
            }
        }

        if (! is_email($email)) {
            return new WP_Error('timesuite_email', __('Valid email is required.', 'timesuite'), [
                'status' => 400,
                'field'  => 'email',
            ]);
        }

        if ($vacationDaysRemaining !== null && $vacationDaysRemaining !== '') {
            if (! is_numeric($vacationDaysRemaining)) {
                return new WP_Error('timesuite_vacation_remaining', __('Vacation balance must be a number.', 'timesuite'), [
                    'status' => 400,
                    'field'  => 'vacation_days_remaining',
                ]);
            }

            $vacationDaysRemaining = (float) $vacationDaysRemaining;
        } else {
            $vacationDaysRemaining = null;
        }

        if ($sickDaysRemaining !== null && $sickDaysRemaining !== '') {
            if (! is_numeric($sickDaysRemaining)) {
                return new WP_Error('timesuite_sick_remaining', __('Sick balance must be a number.', 'timesuite'), [
                    'status' => 400,
                    'field'  => 'sick_days_remaining',
                ]);
            }

            $sickDaysRemaining = (float) $sickDaysRemaining;
        } else {
            $sickDaysRemaining = null;
        }

        $vacationCarryoverCapDays = $this->normalizeOptionalDaysField(
            $vacationCarryoverCapDays,
            'timesuite_vacation_carryover_cap',
            'vacation_carryover_cap_days',
            __('Vacation carryover cap must be a number.', 'timesuite')
        );

        if (is_wp_error($vacationCarryoverCapDays)) {
            return $vacationCarryoverCapDays;
        }

        $sickCarryoverCapDays = $this->normalizeOptionalDaysField(
            $sickCarryoverCapDays,
            'timesuite_sick_carryover_cap',
            'sick_carryover_cap_days',
            __('Sick carryover cap must be a number.', 'timesuite')
        );

        if (is_wp_error($sickCarryoverCapDays)) {
            return $sickCarryoverCapDays;
        }

        $emailChanged = $existingUser && strtolower((string) $existingUser->user_email) !== strtolower($email);

        if ($existingUser && $emailChanged) {
            return new WP_Error('timesuite_email_locked', __('Email cannot be changed for an existing directory user. Remove the user and create a new entry instead.', 'timesuite'), [
                'status' => 400,
                'field'  => 'email',
            ]);
        }

        if ('' === $name) {
            return new WP_Error('timesuite_name', __('Name is required.', 'timesuite'), [
                'status' => 400,
                'field'  => 'name',
            ]);
        }

        $user = $existingUser ?: get_user_by('email', $email);
        $userId = $user ? (int) $user->ID : null;

        if ($userId) {
            $updatePayload = [
                'ID'           => $userId,
                'display_name' => $name,
            ];

            if ($emailChanged) {
                $updatePayload['user_email'] = $email;
            }

            $updated = wp_update_user($updatePayload);

            if (is_wp_error($updated)) {
                return $updated;
            }

            $userId = (int) $updated;
        } else {
            $username = sanitize_user(current(explode('@', $email)) ?: $email, true);

            if (username_exists($username)) {
                $username .= wp_generate_password(4, false);
            }

            $userId = wp_insert_user([
                'user_login'   => $username,
                'user_email'   => $email,
                'display_name' => $name,
                'user_pass'    => wp_generate_password(20),
            ]);

            if (is_wp_error($userId)) {
                return $userId;
            }
        }

        if (function_exists('delete_user_meta')) {
            delete_user_meta($userId, 'timesuite_removed');
        }

        // Handle role assignment through RoleAssignmentService (single entry point)
        if ('' !== $timesuiteRole) {
            // Check if current user can manage roles
            if (! $this->authService->canManageRoles($currentUser)) {
                return $this->forbiddenError(__('You do not have permission to change Timesuite access roles.', 'timesuite'));
            }

            // Validate role
            if (! Role::isValid($timesuiteRole)) {
                return new WP_Error('timesuite_role', __('Invalid Timesuite role.', 'timesuite'), [
                    'status' => 400,
                    'field'  => 'timesuite_role',
                ]);
            }

            try {
                // Use RoleAssignmentService - the single entry point for all role changes
                $this->roleService->assignRole(
                    $userId,
                    $timesuiteRole,
                    $currentUser,
                    'directory_update'
                );
            } catch (ForbiddenException $e) {
                return $this->forbiddenError($e->getMessage());
            } catch (ValidationException $e) {
                return $this->validationError($e->getMessage());
            }
        }

        $managerEmail = null;
        $allowSelfManager = $this->authService->hasOrgManagementPowers($currentUser);

        if ($managerId) {
            $manager = get_user_by('id', $managerId);

            if (! $manager) {
                return new WP_Error('timesuite_manager', __('Manager not found.', 'timesuite'), [
                    'status' => 400,
                    'field'  => 'manager_id',
                ]);
            }

            $managerEmail = $manager->user_email;
        }

        if ($managerId && $managerId === $userId) {
            if (! $allowSelfManager) {
                return new WP_Error('timesuite_manager_self', __('Manager cannot be the same user.', 'timesuite'), [
                    'status' => 400,
                    'field'  => 'manager_id',
                ]);
            }
        }

        $entry = [
            'user_id'       => $userId,
            'user_email'    => $email,
            'manager_id'    => $managerId ?: null,
            'manager_email' => $managerEmail,
            'department'    => $department,
            'employment_start_date' => $employmentStartDate,
            'employment_end_date' => $employmentEndDate,
            'work_week'     => $workWeek,
            'comp_time_expiry_months' => $expiryMonths,
            'vacation_days_contract' => $vacationDaysContract,
            'is_manager'    => false,
            'active'        => true,
        ];

        $effectiveWorkWeekForSchedule = is_array($workWeek) && ! empty($workWeek)
            ? array_values(
                array_filter(
                    array_map(static fn ($day) => sanitize_text_field((string) $day), $workWeek),
                    static fn ($day) => in_array($day, Settings::WORK_WEEK_OPTIONS, true)
                )
            )
            : $this->settings->getWorkWeek();

        $dailyHoursError = null;
        $normalizedDailyHoursByDay = $this->normalizeDailyHoursByDayInput(
            $dailyHoursByDay,
            $effectiveWorkWeekForSchedule,
            $dailyHoursError
        );

        if ($dailyHoursError !== null) {
            return new WP_Error('timesuite_daily_hours_by_day', $dailyHoursError, [
                'status' => 400,
                'field' => 'daily_hours_by_day',
            ]);
        }

        try {
            $this->orgService->synchronize([$entry], false, $currentUser, false, $allowSelfManager);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        }

        if ($normalizedDailyHoursByDay === null || empty($normalizedDailyHoursByDay)) {
            delete_user_meta($userId, self::USER_META_DAILY_HOURS_BY_DAY);
        } else {
            update_user_meta($userId, self::USER_META_DAILY_HOURS_BY_DAY, $normalizedDailyHoursByDay);
        }

        if ($employmentStartDate === null) {
            delete_user_meta($userId, self::USER_META_HIRE_DATE);
        } else {
            update_user_meta($userId, self::USER_META_HIRE_DATE, $employmentStartDate);
        }

        if ($employmentEndDate === null) {
            delete_user_meta($userId, self::USER_META_EMPLOYMENT_END_DATE);
        } else {
            update_user_meta($userId, self::USER_META_EMPLOYMENT_END_DATE, $employmentEndDate);
        }

        // Save vacation days contract if provided
        if ($vacationDaysContract !== null && $vacationDaysContract !== '') {
            $this->vacationService->setContractDays($userId, (int) $vacationDaysContract);
        }

        // Save sick days contract if provided
        if ($sickDaysContract !== null && $sickDaysContract !== '') {
            $this->vacationService->setSickDaysContract($userId, (int) $sickDaysContract);
        }

        if ($vacationDaysRemaining !== null) {
            $this->vacationService->setVacationRemainingBalance($userId, $vacationDaysRemaining);
        }

        if ($sickDaysRemaining !== null) {
            $this->vacationService->setSickRemainingBalance($userId, $sickDaysRemaining);
        }

        $this->vacationService->setVacationCarryoverCapDays($userId, $vacationCarryoverCapDays);
        $this->vacationService->setSickCarryoverCapDays($userId, $sickCarryoverCapDays);

        $responseUser = get_user_by('id', $userId);
        $storedWorkWeek = get_user_meta($userId, 'timesuite_work_week', true);
        $storedExpiry = get_user_meta($userId, 'timesuite_comp_time_expiry_months', true);
        $storedDailyHoursByDay = $this->normalizeStoredDailyHoursByDay(
            get_user_meta($userId, self::USER_META_DAILY_HOURS_BY_DAY, true)
        );

        if (! is_array($storedWorkWeek) || empty($storedWorkWeek)) {
            $storedWorkWeek = $this->settings->getWorkWeek();
        }

        // Get vacation and sick stats for response
        $stats = $this->vacationService->getStats($userId);

        return new WP_REST_Response(
            [
                'user' => [
                    'id'         => $userId,
                    'name'       => $responseUser?->display_name ?? $name,
                    'email'      => $email,
                    'department' => $department,
                    'employment_start_date' => $employmentStartDate,
                    'employment_end_date' => $employmentEndDate,
                    'work_week'  => is_array($storedWorkWeek) ? $storedWorkWeek : null,
                    'daily_hours_by_day' => $this->buildEffectiveDailyHoursByDay($storedWorkWeek, $storedDailyHoursByDay),
                    'has_custom_daily_hours' => ! empty($storedDailyHoursByDay),
                    'comp_time_expiry_months' => '' === $storedExpiry || $storedExpiry === null ? null : (int) $storedExpiry,
                    'manager_id' => $managerId,
                    'timesuite_role' => $this->authService->getRoleForUser((int) $userId),
                    'vacation_days_contract' => $stats['vacation_contract'],
                    'vacation_days_used' => $stats['vacation_used'],
                    'vacation_days_remaining' => $stats['vacation_remaining'],
                    'vacation_carryover_cap_days' => $this->vacationService->getVacationCarryoverCapDays($userId),
                    'sick_days_contract' => $stats['sick_contract'],
                    'sick_days_used' => $stats['sick_used'],
                    'sick_days_remaining' => $stats['sick_remaining'],
                    'sick_carryover_cap_days' => $this->vacationService->getSickCarryoverCapDays($userId),
                    'comp_time_balance_minutes' => $this->compTimeService->getAvailableMinutes($userId, gmdate('Y-m-d')),
                ],
            ],
            200
        );
    }

    /**
     * Set an employee's Time-in-Lieu balance by hand.
     *
     * Its own endpoint on purpose. This writes a manual ledger row, which is
     * the only write in this controller that can be rejected by the database,
     * and it previously ran at the end of saveUser() -- after the profile
     * fields had already been saved. A failure there returned "nothing was
     * changed", which was untrue and is exactly the kind of false
     * confirmation that let a real balance shortfall go unnoticed for a month.
     *
     * Alone in a request, the claim holds: this write is the whole operation,
     * so if it fails nothing was changed.
     */
    public function saveCompTimeBalance(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->authService->hasOrgManagementPowers($currentUser)) {
            return $this->forbiddenError(__('Insufficient permissions.', 'timesuite'));
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $body = $request->get_json_params();

        if (! is_array($body)) {
            return $this->validationError(__('Invalid payload.', 'timesuite'));
        }

        $userId = isset($body['user_id']) ? (int) $body['user_id'] : 0;

        if ($userId <= 0) {
            return $this->validationError(__('Unknown target user.', 'timesuite'));
        }

        // Confirm the employee exists BEFORE writing. A ledger row is keyed
        // only by user_id, so an adjustment against a wrong or stale id would
        // be accepted by the database and then sit in the ledger belonging to
        // nobody -- silently inflating or deflating a balance that the audit
        // would later report as an unexplained discrepancy.
        $user = get_user_by('id', $userId);

        if (! $user) {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        if ((string) get_user_meta($userId, 'timesuite_removed', true) === '1') {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        // Existing in WordPress is not the same as being a Timesuite employee.
        // Any WordPress account -- a subscriber, a plugin's service user, a
        // former employee whose mapping was deactivated -- would otherwise
        // accept a Time-in-Lieu adjustment it can never spend, leaving a
        // credit in the ledger with no timesheet behind it. An active org
        // mapping is what makes someone an employee here.
        $mapping = $this->orgService->getMappingForUser($userId);

        if (null === $mapping || empty($mapping['active'])) {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        $minutes = $body['comp_time_balance_minutes'] ?? null;

        if ($minutes === null || $minutes === '') {
            return new WP_Error('timesuite_comp_time_balance', __('Comp time balance is required.', 'timesuite'), [
                'status' => 400,
                'field'  => 'comp_time_balance_minutes',
            ]);
        }

        if (! is_numeric($minutes)) {
            return new WP_Error('timesuite_comp_time_balance', __('Comp time balance must be a number.', 'timesuite'), [
                'status' => 400,
                'field'  => 'comp_time_balance_minutes',
            ]);
        }

        $minutes = max(0, (int) round((float) $minutes));

        try {
            $this->compTimeService->setAvailableMinutes($userId, $minutes, $currentUser);
        } catch (PersistenceException $exception) {
            return $this->persistenceError(
                $exception,
                'manual comp-time balance adjustment',
                ['user_id' => $userId, 'target_minutes' => $minutes]
            );
        }

        return new WP_REST_Response(
            [
                'saved' => true,
                'user_id' => $userId,
                'comp_time_balance_minutes' => $this->compTimeService->getAvailableMinutes(
                    $userId,
                    gmdate('Y-m-d')
                ),
            ],
            200
        );
    }

    public function deleteUser(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $userId = (int) $request->get_param('id');

        if ($userId <= 0) {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        if ($userId === $currentUser) {
            return $this->validationError(__('You cannot remove your own account.', 'timesuite'));
        }

        $user = get_user_by('id', $userId);

        if (! $user) {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        $counts = $this->userRemovalService->removeUser($userId);

        return new WP_REST_Response(
            [
                'deleted' => true,
                'counts'  => $counts,
            ],
            200
        );
    }

    private function normalizeOptionalDaysField(
        mixed $value,
        string $code,
        string $field,
        string $message
    ): float|WP_Error|null {
        if ($value === null || $value === '') {
            return null;
        }

        if (! is_numeric($value)) {
            return new WP_Error($code, $message, [
                'status' => 400,
                'field'  => $field,
            ]);
        }

        return max(0.0, round((float) $value, 2));
    }

    private function normalizeOptionalDateField(mixed $value, string $code, string $field, string $message): string|WP_Error|null
    {
        if ($value === null || trim((string) $value) === '') {
            return null;
        }

        $date = trim((string) $value);
        $normalized = $this->normalizeDateValue($date);

        if ($normalized === null) {
            return new WP_Error($code, $message, [
                'status' => 400,
                'field' => $field,
            ]);
        }

        return $normalized;
    }

    private function normalizeDateValue(mixed $value): ?string
    {
        if (! is_string($value) && ! is_numeric($value)) {
            return null;
        }

        $date = trim((string) $value);

        if ($date === '') {
            return null;
        }

        $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d', $date, new \DateTimeZone('UTC'));

        if (! $parsed instanceof \DateTimeImmutable || $parsed->format('Y-m-d') !== $date) {
            return null;
        }

        return $date;
    }

    /**
     * @return int[]
     */
    private function resolveVisibleUserIds(int $currentUser): array
    {
        // Use AuthorizationService for consistent authorization logic
        if ($this->authService->hasOrgManagementPowers($currentUser)) {
            $activeUserIds = [];

            foreach ($this->orgService->getMappings() as $mapping) {
                if (! ($mapping['active'] ?? false)) {
                    continue;
                }

                $userId = (int) ($mapping['user_id'] ?? 0);

                if ($userId > 0) {
                    $activeUserIds[] = $userId;
                }
            }

            return array_values(array_unique($activeUserIds));
        }

        if ($this->authService->canViewTeamTimesheets($currentUser)) {
            $reports = $this->orgService->listDirectReportIds($currentUser);

            return array_values(array_unique(array_merge([$currentUser], $reports)));
        }

        return [$currentUser];
    }

    /**
     * Permission callback for logged-in users.
     *
     * @return bool|WP_Error
     */
    public function checkLoggedIn(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to access the directory.', 'timesuite'),
                ['status' => 401]
            );
        }

        return true;
    }

    /**
     * Permission callback for managing directory.
     *
     * @return bool|WP_Error
     */
    public function checkManageDirectoryPermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to manage the directory.', 'timesuite'),
                ['status' => 401]
            );
        }

        // Use AuthorizationService for consistent authorization logic
        if (! $this->authService->hasOrgManagementPowers(get_current_user_id())) {
            return new WP_Error(
                'timesuite_forbidden',
                __('You do not have permission to manage the directory.', 'timesuite'),
                ['status' => 403]
            );
        }

        return true;
    }

    /**
     * Permission callback for deleting users from directory.
     *
     * @return bool|WP_Error
     */
    public function checkDeleteUserPermission(WP_REST_Request $request): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to remove users.', 'timesuite'),
                ['status' => 401]
            );
        }

        $currentUser = get_current_user_id();

        if (! $currentUser) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('Unable to determine current user.', 'timesuite'),
                ['status' => 401]
            );
        }

        $userId = (int) $request->get_param('id');

        if ($userId <= 0) {
            return new WP_Error(
                'timesuite_validation',
                __('Invalid user ID.', 'timesuite'),
                ['status' => 400]
            );
        }

        if ($userId === $currentUser) {
            return new WP_Error(
                'timesuite_forbidden',
                __('You cannot remove yourself from the directory.', 'timesuite'),
                ['status' => 403]
            );
        }

        // Use AuthorizationService for consistent authorization logic
        if ($this->authService->hasOrgManagementPowers($currentUser)) {
            return true;
        }

        if (! $this->authService->canApproveTimesheets($currentUser)) {
            return new WP_Error(
                'timesuite_forbidden',
                __('You do not have permission to remove users.', 'timesuite'),
                ['status' => 403]
            );
        }

        if (! $this->orgService->managerCanAccessUser($currentUser, $userId)) {
            return new WP_Error(
                'timesuite_forbidden',
                __('You can only remove users who report to you.', 'timesuite'),
                ['status' => 403]
            );
        }

        return true;
    }

    /**
     * @return array<string, float>
     */
    private function normalizeStoredDailyHoursByDay(mixed $value): array
    {
        if (! is_array($value)) {
            return [];
        }

        $normalized = [];

        foreach ($value as $day => $hours) {
            $normalizedDays = Settings::normalizeWorkWeekDays([(string) $day]);
            $dayCode = $normalizedDays[0] ?? null;

            if ($dayCode === null || ! is_numeric($hours)) {
                continue;
            }

            $floatHours = round((float) $hours, 2);

            if ($floatHours < 1 || $floatHours > 24) {
                continue;
            }

            $normalized[$dayCode] = $floatHours;
        }

        return $normalized;
    }

    /**
     * @param string[] $workWeek
     *
     * @return array<string, float>
     */
    private function buildEffectiveDailyHoursByDay(array $workWeek, array $storedOverrides): array
    {
        $effective = [];
        $defaultDailyHours = round($this->settings->getDailyHours(), 2);

        foreach ($workWeek as $day) {
            if (! in_array($day, Settings::WORK_WEEK_OPTIONS, true)) {
                continue;
            }

            $effective[$day] = isset($storedOverrides[$day])
                ? round((float) $storedOverrides[$day], 2)
                : $defaultDailyHours;
        }

        return $effective;
    }

    /**
     * @param string[] $workWeek
     *
     * @return array<string, float>|null
     */
    private function normalizeDailyHoursByDayInput(mixed $value, array $workWeek, ?string &$error = null): ?array
    {
        $error = null;

        if ($value === null) {
            return null;
        }

        if (! is_array($value)) {
            $error = __('Advanced schedule payload is invalid.', 'timesuite');

            return null;
        }

        $activeDays = array_fill_keys($workWeek, true);
        $normalized = [];
        $defaultDailyHours = round($this->settings->getDailyHours(), 2);

        foreach ($value as $day => $hours) {
            $normalizedDays = Settings::normalizeWorkWeekDays([(string) $day]);
            $dayCode = $normalizedDays[0] ?? null;

            if ($dayCode === null || ! isset($activeDays[$dayCode])) {
                continue;
            }

            if ($hours === '' || $hours === null) {
                continue;
            }

            if (! is_numeric($hours)) {
                $error = __('Daily hours overrides must be numeric.', 'timesuite');

                return null;
            }

            $floatHours = round((float) $hours, 2);

            if ($floatHours < 1 || $floatHours > 24) {
                $error = __('Daily hours overrides must be between 1 and 24.', 'timesuite');

                return null;
            }

            if (abs($floatHours - $defaultDailyHours) < 0.00001) {
                continue;
            }

            $normalized[$dayCode] = $floatHours;
        }

        return $normalized;
    }

    private function resolveManagerName(int $managerId): ?string
    {
        if ($managerId <= 0) {
            return null;
        }

        $user = get_user_by('id', $managerId);

        if (! $user) {
            return null;
        }

        return $user->display_name ?: $user->user_login;
    }
}
