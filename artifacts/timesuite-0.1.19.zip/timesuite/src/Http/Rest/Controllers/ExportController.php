<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Domain\Org\Services\OrgService;
use Timesuite\Domain\Reports\ExcelExportService;
use Timesuite\Domain\Reports\TimesheetReportService;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use Timesuite\Http\Rest\AbstractRestController;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * REST controller for export functionality.
 *
 * Handles:
 * - Employee timesheet exports (self or team)
 * - HR summary exports (all employees)
 */
class ExportController extends AbstractRestController
{
    private const RATE_LIMIT_KEY = 'timesuite_export_count_';
    private const RATE_LIMIT_MAX = 10;
    private const RATE_LIMIT_WINDOW = 60; // seconds

    public function __construct(
        private TimesheetReportService $reportService,
        private ExcelExportService $exportService,
        private AuthorizationService $authService,
        private OrgService $orgService,
        private ApprovalLogRepository $auditLog
    ) {
    }

    public function registerRoutes(): void
    {
        // Export own timesheet
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/export/timesheet',
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'exportTimesheet'],
                'permission_callback' => [$this, 'checkExportTimesheetPermission'],
                'args' => [
                    'year' => [
                        'required' => true,
                        'validate_callback' => static fn($v): bool => (int) $v >= 2000 && (int) $v <= 2100,
                    ],
                    'month' => [
                        'required' => true,
                        'validate_callback' => static fn($v): bool => (int) $v >= 1 && (int) $v <= 12,
                    ],
                    'user_id' => [
                        'required' => false,
                        'validate_callback' => static fn($v): bool => (int) $v > 0,
                    ],
                    'format' => [
                        'required' => false,
                        'default' => 'xlsx',
                        'validate_callback' => static fn($v): bool => $v === 'xlsx',
                    ],
                ],
            ]
        );

        // HR summary export
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/export/hr-summary',
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'exportHrSummary'],
                'permission_callback' => [$this, 'checkHrExportPermission'],
                'args' => [
                    'year' => [
                        'required' => true,
                        'validate_callback' => static fn($v): bool => (int) $v >= 2000 && (int) $v <= 2100,
                    ],
                    'month' => [
                        'required' => true,
                        'validate_callback' => static fn($v): bool => (int) $v >= 1 && (int) $v <= 12,
                    ],
                    'department' => [
                        'required' => false,
                    ],
                    'format' => [
                        'required' => false,
                        'default' => 'xlsx',
                        'validate_callback' => static fn($v): bool => in_array($v, ['xlsx', 'csv'], true),
                    ],
                ],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/export/payroll-matrix',
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'exportPayrollMatrix'],
                'permission_callback' => [$this, 'checkHrExportPermission'],
                'args' => [
                    'year' => [
                        'required' => true,
                        'validate_callback' => static fn($v): bool => (int) $v >= 2000 && (int) $v <= 2100,
                    ],
                    'month' => [
                        'required' => true,
                        'validate_callback' => static fn($v): bool => (int) $v >= 1 && (int) $v <= 12,
                    ],
                    'format' => [
                        'required' => false,
                        'default' => 'xlsx',
                        'validate_callback' => static fn($v): bool => $v === 'xlsx',
                    ],
                ],
            ]
        );
    }

    /**
     * Export a single employee's timesheet.
     */
    public function exportTimesheet(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();
        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        // Rate limiting
        if (!$this->checkExportRateLimit($currentUser)) {
            return new WP_Error(
                'timesuite_rate_limit',
                __('Too many export requests. Please wait a minute and try again.', 'timesuite'),
                ['status' => 429]
            );
        }

        $year = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $targetUserId = $request->get_param('user_id') ? (int) $request->get_param('user_id') : $currentUser;
        $format = 'xlsx';

        // Check permission to export this user's data
        if ($targetUserId !== $currentUser) {
            if (!$this->canExportUser($currentUser, $targetUserId)) {
                return $this->forbiddenError(__('You do not have permission to export this user\'s timesheet.', 'timesuite'));
            }
        }

        try {
            // Generate report data
            $reportData = $this->reportService->generateEmployeeReport(
                $targetUserId,
                $year,
                $month,
                $currentUser
            );

            // Generate export file
            $export = $this->exportService->generateEmployeeExport($reportData, $format);

            // Log the export
            $this->logExport('timesheet_export', $targetUserId, $currentUser, $year, $month, [], $format);

            // Return file download response
            return $this->fileResponse($export);

        } catch (\InvalidArgumentException $e) {
            return $this->validationError($e->getMessage());
        } catch (\Exception $e) {
            return new WP_Error(
                'timesuite_export_error',
                __('Failed to generate export. Please try again.', 'timesuite'),
                ['status' => 500]
            );
        }
    }

    /**
     * Export HR summary for all employees.
     */
    public function exportHrSummary(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();
        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        // Rate limiting
        if (!$this->checkExportRateLimit($currentUser)) {
            return new WP_Error(
                'timesuite_rate_limit',
                __('Too many export requests. Please wait a minute and try again.', 'timesuite'),
                ['status' => 429]
            );
        }

        $year = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $department = $request->get_param('department');
        $format = $request->get_param('format') ?? 'xlsx';

        try {
            // Get all user IDs (employees in the system)
            $userIds = $this->getAllTimesuiteuserIds();

            if (empty($userIds)) {
                return new WP_Error(
                    'timesuite_no_data',
                    __('No employees found to export.', 'timesuite'),
                    ['status' => 404]
                );
            }

            // Generate report data
            $reportData = $this->reportService->generateHrSummaryReport(
                $userIds,
                $year,
                $month,
                $currentUser,
                $department ?: null
            );

            // Generate export file
            $export = $this->exportService->generateHrSummaryExport($reportData);

            // Log the export
            $this->logExport('hr_summary_export', null, $currentUser, $year, $month, [
                'employee_count' => count($reportData['employees']),
                'department' => $department,
            ], $format);

            // Return file download response
            return $this->fileResponse($export);

        } catch (\Exception $e) {
            return new WP_Error(
                'timesuite_export_error',
                __('Failed to generate export. Please try again.', 'timesuite'),
                ['status' => 500]
            );
        }
    }

    /**
     * Export an HR payroll matrix in wide XLSX format.
     */
    public function exportPayrollMatrix(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();
        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->checkExportRateLimit($currentUser)) {
            return new WP_Error(
                'timesuite_rate_limit',
                __('Too many export requests. Please wait a minute and try again.', 'timesuite'),
                ['status' => 429]
            );
        }

        $year = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $userIds = $this->getAllTimesuiteuserIds();

            if (empty($userIds)) {
                return new WP_Error(
                    'timesuite_no_data',
                    __('No employees found to export.', 'timesuite'),
                    ['status' => 404]
                );
            }

            $reportData = $this->reportService->generatePayrollMatrixReport(
                $userIds,
                $year,
                $month,
                $currentUser
            );

            $export = $this->exportService->generatePayrollMatrixExport($reportData);

            $this->logExport(
                'payroll_matrix_export',
                null,
                $currentUser,
                $year,
                $month,
                [
                    'employee_count' => $reportData['metadata']['employee_count'] ?? 0,
                    'missing_locked_count' => $reportData['metadata']['missing_locked_count'] ?? 0,
                ],
                'xlsx'
            );

            return $this->fileResponse($export, [
                'employee_count' => $reportData['metadata']['employee_count'] ?? 0,
                'locked_employee_count' => $reportData['metadata']['locked_employee_count'] ?? 0,
                'missing_locked_count' => $reportData['metadata']['missing_locked_count'] ?? 0,
            ]);
        } catch (\InvalidArgumentException $e) {
            return $this->validationError($e->getMessage());
        } catch (\Exception $e) {
            return new WP_Error(
                'timesuite_export_error',
                __('Failed to generate export. Please try again.', 'timesuite'),
                ['status' => 500]
            );
        }
    }

    /**
     * Permission callback for timesheet export.
     */
    public function checkExportTimesheetPermission(): bool|WP_Error
    {
        if (!is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to export timesheets.', 'timesuite'),
                ['status' => 401]
            );
        }

        // All logged-in users with basic timesheet access can export
        return current_user_can('timesuite.timesheet.view_own');
    }

    /**
     * Permission callback for HR summary export.
     */
    public function checkHrExportPermission(): bool|WP_Error
    {
        if (!is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to export HR data.', 'timesuite'),
                ['status' => 401]
            );
        }

        // Only HR and Tech Admin can export HR summary
        return $this->authService->hasOrgManagementPowers(get_current_user_id());
    }

    /**
     * Check if current user can export another user's timesheet.
     */
    private function canExportUser(int $currentUser, int $targetUser): bool
    {
        // HR/Tech Admin can export anyone
        if ($this->authService->hasOrgManagementPowers($currentUser)) {
            return true;
        }

        // Managers can export their team
        if ($this->authService->isManager($currentUser)) {
            return $this->orgService->managerCanAccessUser($currentUser, $targetUser);
        }

        return false;
    }

    /**
     * Get all user IDs in Timesuite.
     *
     * @return int[]
     */
    private function getAllTimesuiteuserIds(): array
    {
        global $wpdb;

        $results = $wpdb->get_results(
            "SELECT DISTINCT user_id FROM {$wpdb->prefix}timesuite_users_org WHERE removed_at IS NULL",
            ARRAY_A
        );

        return array_map(
            static fn (array $row): int => (int) ($row['user_id'] ?? 0),
            array_filter(is_array($results) ? $results : [], static fn (array $row): bool => ! empty($row['user_id']))
        );
    }

    /**
     * Check rate limiting for exports.
     */
    protected function checkExportRateLimit(int $userId): bool
    {
        $key = self::RATE_LIMIT_KEY . $userId;
        $count = (int) get_transient($key);

        if ($count >= self::RATE_LIMIT_MAX) {
            return false;
        }

        set_transient($key, $count + 1, self::RATE_LIMIT_WINDOW);
        return true;
    }

    /**
     * Log an export action for audit.
     */
    private function logExport(
        string $action,
        ?int $targetUserId,
        int $actorId,
        int $year,
        int $month,
        array $extra = [],
        string $format = 'xlsx'
    ): void {
        $filters = [
            'year' => (string) $year,
            'month' => (string) $month,
            'action' => $action,
            'target_user_id' => $targetUserId ? (string) $targetUserId : null,
        ];

        if (!empty($extra)) {
            $filters = array_merge($filters, array_map('strval', $extra));
        }

        $this->auditLog->logExport(
            $actorId,
            $filters,
            $format,
            1
        );
    }

    /**
     * Create a file download response.
     *
     * @param array{filename: string, content: string, mime_type: string} $export
     * @param array<string, mixed> $extra
     */
    private function fileResponse(array $export, array $extra = []): WP_REST_Response
    {
        $response = new WP_REST_Response();

        // Return JSON payload for base64 download.
        $response->header('Content-Type', 'application/json; charset=UTF-8');
        $response->header('Cache-Control', 'no-cache, no-store, must-revalidate');
        $response->header('Pragma', 'no-cache');
        $response->header('Expires', '0');

        // For binary content, we need to use a different approach
        // Return base64 encoded content that frontend will decode
        $payload = [
            'filename' => $export['filename'],
            'content' => base64_encode($export['content']),
            'mime_type' => $export['mime_type'],
        ];

        if (! empty($extra)) {
            $payload = array_merge($payload, $extra);
        }

        $response->set_data($payload);

        return $response;
    }
}
