<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Core\Access\BootstrapService;
use Timesuite\Core\Monitoring\DiagnosticsService;
use Timesuite\Core\Settings;
use Timesuite\Domain\Org\Services\OrgService;
use Timesuite\Http\Rest\AbstractRestController;
use Timesuite\Services\Notifications\EmailNotifier;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Health check endpoint for monitoring and diagnostics.
 */
class HealthController extends AbstractRestController
{
    public function __construct(
        private Settings $settings,
        private DiagnosticsService $diagnostics,
        private OrgService $orgService
    ) {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/health',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'check'],
                'permission_callback' => '__return_true', // Public endpoint
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/health/detailed',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'detailedCheck'],
                'permission_callback' => function () {
                    return $this->checkPermission('timesuite.system.view');
                },
            ]
        );

        // Access health check and cleanup
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/health/access',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'checkAccess'],
                'permission_callback' => function () {
                    return $this->checkPermission('timesuite.system.view');
                },
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/health/access/cleanup',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'cleanupAccess'],
                'permission_callback' => function () {
                    return $this->checkPermission('timesuite.system.view');
                },
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/health/diagnostics',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'diagnosticsStatus'],
                    'permission_callback' => function () {
                        return $this->checkPermission('timesuite.system.view');
                    },
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'updateDiagnostics'],
                    'permission_callback' => function () {
                        return $this->checkPermission('timesuite.system.view');
                    },
                ],
                [
                    'methods'             => WP_REST_Server::DELETABLE,
                    'callback'            => [$this, 'clearDiagnostics'],
                    'permission_callback' => function () {
                        return $this->checkPermission('timesuite.system.view');
                    },
                ],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/health/diagnostics/export',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'exportDiagnostics'],
                'permission_callback' => function () {
                    return $this->checkPermission('timesuite.system.view');
                },
            ]
        );
    }

    /**
     * Simple health check - always returns status and version.
     */
    public function check(WP_REST_Request $request): WP_REST_Response
    {
        $version = $this->getPluginVersion();

        return new WP_REST_Response([
            'status'  => 'ok',
            'version' => $version,
            'time'    => gmdate('c'),
        ], 200);
    }

    /**
     * Detailed health check - requires admin access.
     * Returns database status, settings, and system info.
     */
    public function detailedCheck(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $checks = [
            'database'   => $this->checkDatabase($wpdb),
            'tables'     => $this->checkTables($wpdb),
            'assets'     => $this->checkAssets(),
            'migrations' => $this->checkMigrations(),
            'cron'       => $this->checkCron(),
            'email'      => $this->checkEmail(),
            'timesheet_integrity' => $this->checkTimesheetIntegrity($wpdb),
        ];

        $allHealthy = array_reduce(
            $checks,
            fn (bool $carry, array $check): bool => $carry && ($check['status'] === 'ok'),
            true
        );

        // Always return 200 so the frontend can render the status page
        // The 'status' field indicates if everything is healthy or not
        return new WP_REST_Response([
            'status'   => $allHealthy ? 'ok' : 'degraded',
            'version'  => $this->getPluginVersion(),
            'time'     => gmdate('c'),
            'checks'   => $checks,
            'settings' => [
                'timezone'        => $this->settings->getTimezone() ?: wp_timezone_string(),
                'work_week'       => $this->settings->getWorkWeek(),
                'daily_hours'     => $this->settings->getDailyHours(),
                'export_version'  => $this->settings->getExportVersion(),
                'audit_retention' => $this->settings->getAuditRetentionDays(),
            ],
            'system'   => [
                'php_version' => PHP_VERSION,
                'wp_version'  => get_bloginfo('version'),
                'db_version'  => $wpdb->db_version(),
                'memory'      => size_format(memory_get_usage(true)),
                'memory_peak' => size_format(memory_get_peak_usage(true)),
            ],
            'diagnostics' => $this->diagnostics->status(),
        ], 200);
    }

    public function diagnosticsStatus(WP_REST_Request $request): WP_REST_Response
    {
        return new WP_REST_Response($this->diagnostics->status(), 200);
    }

    public function updateDiagnostics(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $enabled = filter_var($request->get_param('enabled'), FILTER_VALIDATE_BOOLEAN);

        if ($enabled) {
            $durationHours = absint($request->get_param('duration_hours') ?? 24);

            return new WP_REST_Response($this->diagnostics->enable($durationHours), 200);
        }

        return new WP_REST_Response($this->diagnostics->disable(), 200);
    }

    public function clearDiagnostics(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        return new WP_REST_Response($this->diagnostics->clear(), 200);
    }

    public function exportDiagnostics(WP_REST_Request $request): WP_REST_Response
    {
        return new WP_REST_Response([
            'filename' => sprintf('timesuite-diagnostics-%s.json', gmdate('Ymd-His')),
            'content' => (string) wp_json_encode($this->diagnostics->export(), JSON_PRETTY_PRINT),
            'mime_type' => 'application/json',
        ], 200);
    }

    /**
     * Get plugin version from header.
     */
    private function getPluginVersion(): string
    {
        $pluginFile = TIMESUITE_PLUGIN_PATH . 'timesuite.php';

        if (! is_readable($pluginFile)) {
            return 'unknown';
        }

        $pluginData = get_plugin_data($pluginFile, false, false);

        return $pluginData['Version'] ?? 'unknown';
    }

    /**
     * Check database connectivity.
     *
     * @return array{status: string, message: string}
     */
    private function checkDatabase(\wpdb $wpdb): array
    {
        try {
            $result = $wpdb->get_var('SELECT 1');

            if ($result === '1') {
                return ['status' => 'ok', 'message' => 'Connected'];
            }

            return ['status' => 'error', 'message' => 'Query failed'];
        } catch (\Exception $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }

    /**
     * Check if required tables exist.
     *
     * @return array{status: string, message: string, tables?: array<string, bool>}
     */
    private function checkTables(\wpdb $wpdb): array
    {
        $requiredTables = [
            'timesuite_time_entries',
            'timesuite_periods',
            'timesuite_approvals_log',
            'timesuite_users_org',
            'timesuite_monthly_timesheets',
            'timesuite_monthly_entries',
            'timesuite_reedit_requests',
            'timesuite_comp_time_ledger',
            'timesuite_holiday_ranges',
        ];

        $missing = [];
        $tableStatus = [];

        foreach ($requiredTables as $table) {
            $fullName = $wpdb->prefix . $table;
            $exists   = $wpdb->get_var($wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $fullName
            )) === $fullName;

            $tableStatus[$table] = $exists;

            if (! $exists) {
                $missing[] = $table;
            }
        }

        if (empty($missing)) {
            return [
                'status'  => 'ok',
                'message' => 'All tables present',
                'tables'  => $tableStatus,
            ];
        }

        return [
            'status'  => 'error',
            'message' => 'Missing tables: ' . implode(', ', $missing),
            'tables'  => $tableStatus,
        ];
    }

    /**
     * Timesheet/org data-integrity scan (P3.3 — see
     * docs/timesheet-status-investigation.md). All checks are single
     * aggregate queries (COUNT/GROUP BY), not per-row loops, so this stays
     * cheap regardless of org size. Purely read-only — flags issues for a
     * human to act on, never fixes anything itself.
     *
     * @return array{status: string, message: string, issues: array<int, array<string, mixed>>}
     */
    private function checkTimesheetIntegrity(\wpdb $wpdb): array
    {
        $issues = [];

        $issues = array_merge(
            $issues,
            $this->findDuplicateActiveOrgMappings($wpdb),
            $this->findDuplicateActiveEmails($wpdb),
            $this->findOrphanedOrgMappings($wpdb),
            $this->findLegacyOnlyMonths($wpdb),
            $this->findCrossLayerStatusMismatches($wpdb)
        );

        if (! $this->settings->allowCircularManagerAssignments()) {
            $conflict = $this->orgService->getCircularManagerConflict();

            if (null !== $conflict) {
                $issues[] = [
                    'type' => 'circular_manager_chain',
                    'severity' => 'error',
                    'user_ids' => $conflict['user_ids'],
                    'suggested_action' => $conflict['message'],
                ];
            }
        }

        if (empty($issues)) {
            return ['status' => 'ok', 'message' => 'No data-integrity issues found.', 'issues' => []];
        }

        $hasError = array_reduce(
            $issues,
            static fn (bool $carry, array $issue): bool => $carry || ($issue['severity'] ?? 'warning') === 'error',
            false
        );

        return [
            'status'  => $hasError ? 'error' : 'warning',
            'message' => sprintf('%d data-integrity issue(s) found — see details below.', count($issues)),
            'issues'  => $issues,
        ];
    }

    /**
     * Same user_id with more than one "active" (removed_at IS NULL) org
     * mapping row at once — listMappings() dedupes to the latest row per
     * user for display, so it can never surface this on its own.
     *
     * @return array<int, array<string, mixed>>
     */
    private function findDuplicateActiveOrgMappings(\wpdb $wpdb): array
    {
        $orgTable = $wpdb->prefix . 'timesuite_users_org';
        $usersTable = $wpdb->users;

        $rows = $wpdb->get_results(
            "SELECT o.user_id, u.user_email, COUNT(*) AS active_count
             FROM {$orgTable} o
             LEFT JOIN {$usersTable} u ON u.ID = o.user_id
             WHERE o.removed_at IS NULL
             GROUP BY o.user_id
             HAVING COUNT(*) > 1",
            ARRAY_A
        ) ?? [];

        return array_map(static function (array $row): array {
            return [
                'type' => 'duplicate_active_org_mapping',
                'severity' => 'error',
                'user_id' => (int) $row['user_id'],
                'email' => $row['user_email'] ?? null,
                'suggested_action' => sprintf(
                    'User has %d active org mappings at once — close out all but one in Org Directory.',
                    (int) $row['active_count']
                ),
            ];
        }, $rows);
    }

    /**
     * WordPress normally enforces unique emails, but imports/direct DB
     * writes can bypass that — worth verifying rather than assuming.
     *
     * @return array<int, array<string, mixed>>
     */
    private function findDuplicateActiveEmails(\wpdb $wpdb): array
    {
        $usersTable = $wpdb->users;

        $rows = $wpdb->get_results(
            "SELECT user_email, COUNT(*) AS user_count
             FROM {$usersTable}
             GROUP BY user_email
             HAVING COUNT(*) > 1",
            ARRAY_A
        ) ?? [];

        return array_map(static function (array $row): array {
            return [
                'type' => 'duplicate_email',
                'severity' => 'error',
                'email' => $row['user_email'],
                'suggested_action' => sprintf(
                    '%d WordPress users share this email — timesheet identity resolution assumes emails are unique.',
                    (int) $row['user_count']
                ),
            ];
        }, $rows);
    }

    /**
     * Active org mapping rows pointing at a user_id or manager (org_unit_id)
     * that no longer exists in wp_users. listMappings() uses an INNER JOIN
     * to wp_users for display, so it silently excludes exactly these rows —
     * this check uses a LEFT JOIN specifically to surface them.
     *
     * @return array<int, array<string, mixed>>
     */
    private function findOrphanedOrgMappings(\wpdb $wpdb): array
    {
        $orgTable = $wpdb->prefix . 'timesuite_users_org';
        $usersTable = $wpdb->users;

        $missingUser = $wpdb->get_results(
            "SELECT o.id, o.user_id
             FROM {$orgTable} o
             LEFT JOIN {$usersTable} u ON u.ID = o.user_id
             WHERE o.removed_at IS NULL AND u.ID IS NULL",
            ARRAY_A
        ) ?? [];

        $missingManager = $wpdb->get_results(
            "SELECT o.id, o.user_id, o.org_unit_id
             FROM {$orgTable} o
             LEFT JOIN {$usersTable} u ON u.ID = o.org_unit_id
             WHERE o.removed_at IS NULL AND o.org_unit_id > 0 AND u.ID IS NULL",
            ARRAY_A
        ) ?? [];

        $issues = array_map(static function (array $row): array {
            return [
                'type' => 'orphaned_org_mapping_user',
                'severity' => 'error',
                'user_id' => (int) $row['user_id'],
                'suggested_action' => 'This org mapping points at a deleted WordPress user — remove or reassign it in Org Directory.',
            ];
        }, $missingUser);

        foreach ($missingManager as $row) {
            $issues[] = [
                'type' => 'orphaned_org_mapping_manager',
                'severity' => 'error',
                'user_id' => (int) $row['user_id'],
                'suggested_action' => sprintf(
                    'This user\'s assigned manager (ID %d) no longer exists — reassign a manager in Org Directory.',
                    (int) $row['org_unit_id']
                ),
            ];
        }

        return $issues;
    }

    /**
     * Legacy 'timesuite_month_YYYY_MM' user-meta with no corresponding row
     * in wp_timesuite_monthly_timesheets — invisible to the HR Dashboard
     * until something reads it through the legacy-fallback path. This is
     * the exact class of bug in docs/timesheet-status-investigation.md;
     * this check exists so it never has to be diagnosed by hand again.
     *
     * @return array<int, array<string, mixed>>
     */
    private function findLegacyOnlyMonths(\wpdb $wpdb): array
    {
        $metaTable = $wpdb->usermeta;
        $usersTable = $wpdb->users;
        $timesheetTable = $wpdb->prefix . 'timesuite_monthly_timesheets';

        $rows = $wpdb->get_results(
            "SELECT m.user_id, m.meta_key, u.user_email
             FROM {$metaTable} m
             LEFT JOIN {$usersTable} u ON u.ID = m.user_id
             LEFT JOIN {$timesheetTable} mt
                ON mt.user_id = m.user_id
                AND mt.year = CAST(SUBSTRING(m.meta_key, 17, 4) AS UNSIGNED)
                AND mt.month = CAST(SUBSTRING(m.meta_key, 22, 2) AS UNSIGNED)
             WHERE m.meta_key LIKE 'timesuite\\_month\\_____\\_%'
               AND mt.id IS NULL
             LIMIT 50",
            ARRAY_A
        ) ?? [];

        return array_map(static function (array $row): array {
            $yearMonth = str_replace('timesuite_month_', '', (string) $row['meta_key']);

            return [
                'type' => 'legacy_only_month',
                'severity' => 'warning',
                'user_id' => (int) $row['user_id'],
                'email' => $row['user_email'] ?? null,
                'month' => str_replace('_', '-', $yearMonth),
                'suggested_action' => 'This month exists only in legacy storage — open it once via My Timesheet, Manager View, or run the backfill migration to materialize it.',
            ];
        }, $rows);
    }

    /**
     * A month that exists in BOTH legacy user-meta AND the new table, but
     * with disagreeing status — would mean the legacy-to-new materialization
     * didn't happen cleanly, or something wrote inconsistently afterward.
     *
     * @return array<int, array<string, mixed>>
     */
    private function findCrossLayerStatusMismatches(\wpdb $wpdb): array
    {
        $metaTable = $wpdb->usermeta;
        $usersTable = $wpdb->users;
        $timesheetTable = $wpdb->prefix . 'timesuite_monthly_timesheets';

        $rows = $wpdb->get_results(
            "SELECT m.user_id, m.meta_key, u.user_email, mt.status AS new_status
             FROM {$metaTable} m
             LEFT JOIN {$usersTable} u ON u.ID = m.user_id
             INNER JOIN {$timesheetTable} mt
                ON mt.user_id = m.user_id
                AND mt.year = CAST(SUBSTRING(m.meta_key, 17, 4) AS UNSIGNED)
                AND mt.month = CAST(SUBSTRING(m.meta_key, 22, 2) AS UNSIGNED)
             WHERE m.meta_key LIKE 'timesuite\\_month\\_____\\_%'
             LIMIT 200",
            ARRAY_A
        ) ?? [];

        $issues = [];

        foreach ($rows as $row) {
            // get_user_meta() with $single=true already unserializes internally.
            $legacy = get_user_meta((int) $row['user_id'], (string) $row['meta_key'], true);
            $legacyStatus = is_array($legacy) ? ($legacy['status'] ?? null) : null;

            if (null === $legacyStatus || $legacyStatus === $row['new_status']) {
                continue;
            }

            $yearMonth = str_replace('timesuite_month_', '', (string) $row['meta_key']);

            $issues[] = [
                'type' => 'cross_layer_status_mismatch',
                'severity' => 'error',
                'user_id' => (int) $row['user_id'],
                'email' => $row['user_email'] ?? null,
                'month' => str_replace('_', '-', $yearMonth),
                'suggested_action' => sprintf(
                    'Legacy storage says "%s" but the canonical table says "%s" — investigate before trusting either.',
                    (string) $legacyStatus,
                    (string) $row['new_status']
                ),
            ];
        }

        return $issues;
    }

    /**
     * Check if frontend assets are built.
     *
     * @return array{status: string, message: string}
     */
    private function checkAssets(): array
    {
        $manifestPaths = [
            TIMESUITE_PLUGIN_PATH . 'assets/manifest.json',
            TIMESUITE_PLUGIN_PATH . 'assets/.vite/manifest.json',
        ];

        foreach ($manifestPaths as $path) {
            if (is_readable($path)) {
                return ['status' => 'ok', 'message' => 'Assets built'];
            }
        }

        // Check if in dev mode
        if (defined('TIMESUITE_VITE_DEV') && TIMESUITE_VITE_DEV) {
            return ['status' => 'ok', 'message' => 'Dev mode active'];
        }

        return ['status' => 'warning', 'message' => 'Assets not built - run npm run build'];
    }

    /**
     * Check migrations status.
     *
     * @return array{status: string, message: string, version?: string}
     */
    private function checkMigrations(): array
    {
        $dbVersion = get_option('timesuite_migrations_version', '');

        if (empty($dbVersion)) {
            return ['status' => 'warning', 'message' => 'No migrations recorded'];
        }

        return [
            'status'  => 'ok',
            'message' => 'Migrations applied',
            'version' => $dbVersion,
        ];
    }

    /**
     * Check if cron jobs are scheduled.
     *
     * @return array{status: string, message: string, next_run?: string|null}
     */
    private function checkCron(): array
    {
        $timestamp = wp_next_scheduled('timesuite_audit_cleanup');

        if (! $timestamp) {
            return ['status' => 'warning', 'message' => 'Audit cleanup not scheduled'];
        }

        return [
            'status'   => 'ok',
            'message'  => 'Cron scheduled',
            'next_run' => gmdate('c', $timestamp),
        ];
    }

    /**
     * Check email delivery status and queue health.
     *
     * @return array{status: string, message: string}
     */
    private function checkEmail(): array
    {
        $queue = get_option(EmailNotifier::QUEUE_OPTION, []);
        $queueCount = is_array($queue) ? count($queue) : 0;
        $lastFailure = get_option(EmailNotifier::LAST_FAILURE_OPTION, []);
        $lastFailureTime = is_array($lastFailure) ? ($lastFailure['time'] ?? null) : null;
        $lastFailureError = is_array($lastFailure) ? ($lastFailure['error'] ?? null) : null;
        $recentFailure = false;

        if ($lastFailureTime) {
            $failureTimestamp = strtotime((string) $lastFailureTime);
            $recentFailure = $failureTimestamp !== false && $failureTimestamp >= strtotime('-7 days');
        }

        if ($queueCount > 0 && ! wp_next_scheduled('timesuite_email_retry')) {
            return [
                'status' => 'error',
                'message' => 'Email retry cron is not scheduled.',
            ];
        }

        if ($queueCount > 0 || $recentFailure) {
            $parts = [];

            if ($queueCount > 0) {
                $parts[] = sprintf('%d queued emails pending retry', $queueCount);
            }

            if ($recentFailure) {
                $parts[] = sprintf(
                    'Last failure: %s',
                    $lastFailureError ?: 'Unknown error'
                );
            }

            return [
                'status' => 'warning',
                'message' => implode('. ', $parts),
            ];
        }

        return [
            'status' => 'ok',
            'message' => 'Email delivery healthy',
        ];
    }

    /**
     * Check access configuration health.
     *
     * Reports on:
     * - SuperAccess email validation
     * - Orphaned/corrupted role meta
     * - Tech admin status
     * - Bootstrap mode
     */
    public function checkAccess(WP_REST_Request $request): WP_REST_Response
    {
        $superAccessValidation = $this->settings->validateSuperUserEmails();
        $invalidMeta = BootstrapService::findInvalidRoleMeta();
        $techAdmins = BootstrapService::getTechAdmins();

        $issues = [];

        // Check SuperAccess
        if (! $superAccessValidation['valid']) {
            $issues[] = [
                'type' => 'warning',
                'category' => 'super_access',
                'message' => $superAccessValidation['warning'],
                'details' => $superAccessValidation['invalid_emails'],
            ];
        }

        // Check for orphaned meta
        if (! empty($invalidMeta['orphaned'])) {
            $issues[] = [
                'type' => 'error',
                'category' => 'orphaned_meta',
                'message' => sprintf(
                    __('%d orphaned role entries found (users no longer exist).', 'timesuite'),
                    count($invalidMeta['orphaned'])
                ),
                'details' => $invalidMeta['orphaned'],
                'action' => 'cleanup',
            ];
        }

        // Check for corrupted meta
        if (! empty($invalidMeta['corrupted'])) {
            $issues[] = [
                'type' => 'error',
                'category' => 'corrupted_meta',
                'message' => sprintf(
                    __('%d corrupted role entries found (invalid role values).', 'timesuite'),
                    count($invalidMeta['corrupted'])
                ),
                'details' => $invalidMeta['corrupted'],
                'action' => 'cleanup',
            ];
        }

        // Check tech admin status
        if (empty($techAdmins)) {
            $issues[] = [
                'type' => 'warning',
                'category' => 'no_tech_admin',
                'message' => __('No Technical Administrator found. Bootstrap mode should be active.', 'timesuite'),
            ];
        }

        $status = empty($issues) ? 'ok' : (
            array_reduce($issues, fn ($carry, $issue) => $carry || $issue['type'] === 'error', false)
                ? 'error'
                : 'warning'
        );

        return new WP_REST_Response([
            'status' => $status,
            'issues' => $issues,
            'tech_admins' => $techAdmins,
            'super_access' => [
                'configured' => ! empty($this->settings->getSuperUserEmails()),
                'valid' => $superAccessValidation['valid'],
                'emails' => $this->settings->getSuperUserEmailsWithValidation(),
            ],
            'bootstrap_mode' => BootstrapService::isBootstrapMode(),
            'invalid_meta_count' => [
                'orphaned' => count($invalidMeta['orphaned']),
                'corrupted' => count($invalidMeta['corrupted']),
            ],
        ], 200);
    }

    /**
     * Clean up orphaned and corrupted role meta.
     */
    public function cleanupAccess(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $result = BootstrapService::cleanupInvalidRoleMeta();

        $totalCleaned = $result['orphaned_deleted'] + $result['corrupted_deleted'];

        if ($totalCleaned === 0) {
            return new WP_REST_Response([
                'success' => true,
                'message' => __('No invalid entries found to clean up.', 'timesuite'),
                'cleaned' => $result,
            ], 200);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => sprintf(
                /* translators: %d: number of entries cleaned */
                __('Cleaned up %d invalid role entries.', 'timesuite'),
                $totalCleaned
            ),
            'cleaned' => $result,
        ], 200);
    }
}

