<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Domain\Shared\Exceptions\NotFoundException;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Timesheets\Services\HolidayRangeService;
use Timesuite\Http\Rest\AbstractRestController;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class HolidayRangesController extends AbstractRestController
{
    public function __construct(private HolidayRangeService $holidayRangeService)
    {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/holidays/ranges',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'listRanges'],
                    'permission_callback' => fn(): bool|WP_Error => $this->checkPermission('timesuite.settings.manage'),
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'createRange'],
                    'permission_callback' => fn(): bool|WP_Error => $this->checkPermission('timesuite.settings.manage'),
                ],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/holidays/ranges/(?P<id>\\d+)',
            [
                [
                    'methods'             => WP_REST_Server::DELETABLE,
                    'callback'            => [$this, 'deleteRange'],
                    'permission_callback' => fn(): bool|WP_Error => $this->checkPermission('timesuite.settings.manage'),
                ],
            ]
        );
    }

    public function listRanges(): WP_REST_Response
    {
        $ranges = $this->holidayRangeService->listRanges();

        return new WP_REST_Response(['ranges' => $ranges], 200);
    }

    public function createRange(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $payload = $request->get_json_params();

        if (! is_array($payload)) {
            return $this->validationError(__('Invalid payload.', 'timesuite'));
        }

        $startDate = isset($payload['start_date']) ? sanitize_text_field((string) $payload['start_date']) : '';
        $endDate = isset($payload['end_date']) ? sanitize_text_field((string) $payload['end_date']) : '';
        $type = isset($payload['type']) ? sanitize_text_field((string) $payload['type']) : '';

        try {
            $range = $this->holidayRangeService->createRange($startDate, $endDate, $type);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        }

        return new WP_REST_Response(['range' => $range], 201);
    }

    public function deleteRange(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $id = (int) $request->get_param('id');

        if ($id <= 0) {
            return $this->validationError(__('Invalid holiday range ID.', 'timesuite'));
        }

        try {
            $this->holidayRangeService->deleteRange($id);
        } catch (NotFoundException $exception) {
            return $this->notFoundError($exception);
        }

        return new WP_REST_Response(['deleted' => true], 200);
    }
}
