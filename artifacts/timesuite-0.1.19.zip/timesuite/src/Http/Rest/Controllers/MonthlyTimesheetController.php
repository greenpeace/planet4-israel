<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Domain\Shared\Exceptions\PersistenceException;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Timesheets\EditabilityReason;
use Timesuite\Domain\Timesheets\Repositories\ReeditRequestRepository;
use Timesuite\Domain\Timesheets\Services\DayStateService;
use Timesuite\Domain\Timesheets\Services\HolidayRangeService;
use Timesuite\Domain\Timesheets\Services\MonthlyTimesheetService;
use Timesuite\Http\Rest\AbstractRestController;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * REST controller for timesheet CRUD operations.
 *
 * Handles:
 * - Getting timesheet data for a month
 * - Saving/submitting timesheet data
 *
 * For approval workflows, see TimesheetApprovalController.
 */
class MonthlyTimesheetController extends AbstractRestController
{
    public function __construct(
        private MonthlyTimesheetService $service,
        private AuthorizationService $authService,
        private DayStateService $dayStateService,
        private HolidayRangeService $holidayRangeService,
        private ReeditRequestRepository $reeditRequestRepository,
        private ApprovalLogRepository $approvalLogRepository
    ) {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'getMonth'],
                    'permission_callback' => [$this, 'checkLoggedIn'],
                    'args'                => $this->requestArgs(),
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'saveMonth'],
                    'permission_callback' => [$this, 'checkLoggedIn'],
                ],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/undo-submit',
            [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'undoSubmit'],
                    'permission_callback' => [$this, 'checkLoggedIn'],
                ],
            ]
        );
    }

    public function getMonth(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        $targetUser = $this->resolveTargetUserId($request, $currentUser);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->canView($currentUser, $targetUser)) {
            return $this->forbiddenError($this->viewAccessDeniedMessage($currentUser, $targetUser));
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $payload = $this->service->getMonth($targetUser, $year, $month);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        }

        $canOverride = $this->hasHrPowers();
        $editability = $this->service->getEditability($year, $month, $canOverride);
        $timesheetStatus = (string) ($payload['status'] ?? 'draft');
        $isLockedStatus = $timesheetStatus === 'locked';
        $isReviewStatus = $timesheetStatus === 'submitted';
        $statusReadOnly = in_array($timesheetStatus, ['submitted', 'locked'], true);
        $latestReeditRequest = $this->reeditRequestRepository->getLatestForMonth($targetUser, $year, $month);
        $readOnly = $targetUser !== $currentUser
            || (! $canOverride && (! $editability['editable'] || $statusReadOnly));
        $readOnlyReason = null;
        // Structured companion to $readOnlyReason — see EditabilityReason for
        // why this exists as a separate, stable code rather than matching on
        // the freetext message. Defaults to whatever getEditability() already
        // determined (current/previous-month/override); overwritten below by
        // whichever more specific read-only cause actually applies.
        $readOnlyReasonCode = $editability['reason_code'];

        if ($targetUser !== $currentUser) {
            $readOnlyReason = __('Viewing a team member timesheet.', 'timesuite');
            $readOnlyReasonCode = EditabilityReason::VIEWING_ANOTHER_USER;
        } elseif (! $editability['editable']) {
            $readOnlyReason = $editability['reason'];
        } elseif ($isReviewStatus && ! $canOverride) {
            $readOnlyReason = __('This timesheet is in review. Use Undo Submit before manager decisions are made.', 'timesuite');
            $readOnlyReasonCode = EditabilityReason::SUBMITTED_UNDER_REVIEW;
        } elseif ($isLockedStatus && ! $canOverride) {
            $pendingRequest = $this->reeditRequestRepository->getPendingForMonth($targetUser, $year, $month);
            if ($pendingRequest) {
                $readOnlyReason = __('This timesheet is locked. Re-edit request is pending manager approval.', 'timesuite');
                $readOnlyReasonCode = EditabilityReason::MONTH_LOCKED_REEDIT_PENDING;
            } elseif (
                is_array($latestReeditRequest)
                && ($latestReeditRequest['status'] ?? '') === 'denied'
                && ! empty($latestReeditRequest['manager_reason'])
            ) {
                $readOnlyReason = sprintf(
                    __('Re-edit request denied: %s', 'timesuite'),
                    (string) $latestReeditRequest['manager_reason']
                );
                $readOnlyReasonCode = EditabilityReason::MONTH_LOCKED_REEDIT_DENIED;
            } else {
                $readOnlyReason = __('This timesheet is locked. Use Ask to Re-edit for manager approval.', 'timesuite');
                $readOnlyReasonCode = EditabilityReason::MONTH_LOCKED;
            }
        } elseif ('denied' === $payload['status']) {
            $readableComment = is_string($payload['denied_comment'] ?? null) && '' !== trim((string) $payload['denied_comment'])
                ? sprintf(__('Denied: %s', 'timesuite'), (string) $payload['denied_comment'])
                : __('This timesheet was denied.', 'timesuite');
            $readOnlyReason = $readableComment;
            $readOnlyReasonCode = EditabilityReason::DENIED;
        }

        // Compute day states for the calendar
        $userRole = $this->getUserRole($currentUser);
        $isPeriodLocked = ! $editability['editable'] || ($isLockedStatus && ! $canOverride);
        $dayStates = $this->computeDayStatesForMonth(
            $targetUser,
            $year,
            $month,
            $payload['status'],
            $payload['submitted_at'] ?? null,
            $payload['approved_at'] ?? null,
            $payload['denied_comment'] ?? null,
            $isPeriodLocked,
            $userRole
        );

        // Merge state info into entries
        $entriesWithState = array_map(function (array $entry) use ($dayStates): array {
            $date = $entry['date'];
            $state = $dayStates[$date] ?? [
                'state' => 'editable',
                'is_actionable' => true,
                'reason' => null,
                'metadata' => [],
            ];
            return array_merge($entry, ['day_state' => $state]);
        }, $payload['entries']);

        $payload['entries'] = $entriesWithState;
        $canUndoSubmit = $targetUser === $currentUser
            && $timesheetStatus === 'submitted'
            && $this->service->canUndoSubmit($targetUser, $year, $month);

        return new WP_REST_Response(
            [
                'timesheet'       => $payload,
                'types'           => $this->service->getDayTypes(),
                'selectable_types'=> $this->service->getSelectableDayTypes(),
                'custom_leave_keys' => $this->service->getCustomLeaveTypeKeys(),
                'part_day_sources'=> $this->service->getPartDaySources(),
                'selectable_part_day_sources' => $this->service->getSelectablePartDaySources(),
                'in_office_enabled' => $this->service->isOfficeCheckboxEnabled(),
                'daily_hours'     => $this->service->getDailyHours(),
                'read_only'       => $readOnly,
                'read_only_reason'=> $readOnlyReason,
                'read_only_reason_code' => $readOnlyReasonCode,
                'editable'        => $editability['editable'],
                'can_undo_submit' => $canUndoSubmit,
                'reedit_request'  => $this->formatReeditRequest($latestReeditRequest),
            ],
            200
        );
    }

    public function saveMonth(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request, $currentUser);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $body = $request->get_json_params();

        if (! is_array($body)) {
            return $this->validationError(__('Invalid payload.', 'timesuite'));
        }

        $year    = isset($body['year']) ? (int) $body['year'] : (int) $request->get_param('year');
        $month   = isset($body['month']) ? (int) $body['month'] : (int) $request->get_param('month');
        $entries = isset($body['entries']) && is_array($body['entries']) ? $body['entries'] : [];
        $status  = isset($body['status']) ? (string) $body['status'] : 'draft';

        // Permissions depend on action:
        // - draft saves require edit_own
        // - submission requires submit_own
        if ('submitted' === $status) {
            if (! $this->canSubmit($currentUser, $targetUser)) {
                return $this->forbiddenError(__('You can only submit your own timesheet.', 'timesuite'));
            }
        } else {
            if (! $this->canEdit($currentUser, $targetUser)) {
                return $this->forbiddenError(__('You do not have permission to edit this timesheet.', 'timesuite'));
            }
        }

        // Only "submit" actions are audit-logged (not every draft autosave,
        // which would flood the log with noise). Capture the status before
        // the write so the log records previous -> new, e.g. so a future
        // "employee says they submitted" investigation can see in one query
        // whether the write actually happened, what it produced (submitted
        // vs. auto-locked vs. rejected), and when — see
        // docs/timesheet-status-investigation.md.
        $isSubmitAttempt = 'submitted' === $status;
        $previousStatus  = $isSubmitAttempt
            ? (string) ($this->service->getMonthMeta($targetUser, $year, $month)['status'] ?? 'draft')
            : null;

        try {
            $payload = $this->service->saveMonth(
                $targetUser,
                $year,
                $month,
                $entries,
                $status,
                $currentUser,
                $this->hasHrPowers()
            );
        } catch (ValidationException $exception) {
            if ($isSubmitAttempt) {
                $this->approvalLogRepository->log(
                    'submit_failed',
                    $targetUser,
                    $currentUser,
                    [
                        'year' => $year,
                        'month' => $month,
                        'previous_status' => $previousStatus,
                        'source' => $targetUser === $currentUser ? 'my_timesheet' : 'manager_view',
                        'error' => $exception->getMessage(),
                    ]
                );
            }

            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // The transaction has already rolled back, so nothing was saved.
            // Audit-log the attempt on the same footing as a validation
            // failure -- a submission that vanished because of a database
            // fault is at least as important to be able to trace -- then hand
            // the employee a generic message. The driver detail (table, key
            // and column names) goes only to the server log.
            if ($isSubmitAttempt) {
                $this->approvalLogRepository->log(
                    'submit_failed',
                    $targetUser,
                    $currentUser,
                    [
                        'year' => $year,
                        'month' => $month,
                        'previous_status' => $previousStatus,
                        'source' => $targetUser === $currentUser ? 'my_timesheet' : 'manager_view',
                        'error' => 'persistence_failure',
                    ]
                );
            }

            return $this->persistenceError(
                $exception,
                'timesheet save',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month, 'status' => $status]
            );
        }

        if ($isSubmitAttempt) {
            $newStatus = (string) ($payload['status'] ?? 'draft');

            $this->approvalLogRepository->log(
                'submit',
                $targetUser,
                $currentUser,
                [
                    'year' => $year,
                    'month' => $month,
                    'previous_status' => $previousStatus,
                    'new_status' => $newStatus,
                    'requires_manager_review' => 'submitted' === $newStatus,
                    'source' => $targetUser === $currentUser ? 'my_timesheet' : 'manager_view',
                ]
            );
        }

        $savedStatus = (string) ($payload['status'] ?? 'draft');
        $canUndoSubmit = $targetUser === $currentUser
            && $savedStatus === 'submitted'
            && $this->service->canUndoSubmit($targetUser, $year, $month);
        $latestReeditRequest = $this->reeditRequestRepository->getLatestForMonth($targetUser, $year, $month);

        return new WP_REST_Response(
            [
                'timesheet' => $payload,
                'types'     => $this->service->getDayTypes(),
                'selectable_types' => $this->service->getSelectableDayTypes(),
                'custom_leave_keys' => $this->service->getCustomLeaveTypeKeys(),
                'part_day_sources' => $this->service->getPartDaySources(),
                'selectable_part_day_sources' => $this->service->getSelectablePartDaySources(),
                'in_office_enabled' => $this->service->isOfficeCheckboxEnabled(),
                'daily_hours' => $this->service->getDailyHours(),
                'read_only' => in_array($savedStatus, ['submitted', 'locked'], true),
                'editable'  => ! in_array($savedStatus, ['submitted', 'locked'], true),
                'can_undo_submit' => $canUndoSubmit,
                'reedit_request' => $this->formatReeditRequest($latestReeditRequest),
            ],
            200
        );
    }

    public function undoSubmit(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        if (! $this->canEdit($currentUser, $currentUser)) {
            return $this->forbiddenError(__('You do not have permission to edit this timesheet.', 'timesuite'));
        }

        if (! $this->service->canUndoSubmit($currentUser, $year, $month)) {
            return $this->validationError(
                __('Undo Submit is only available before any manager decision is made.', 'timesuite')
            );
        }

        try {
            $payload = $this->service->updateMonthStatus($currentUser, $year, $month, 'draft', $currentUser);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        }

        $this->approvalLogRepository->log(
            'undo_submit',
            $currentUser,
            $currentUser,
            ['year' => $year, 'month' => $month]
        );

        return new WP_REST_Response(
            [
                'undone' => true,
                'timesheet' => $payload,
            ],
            200
        );
    }

    private function resolveTargetUserId(WP_REST_Request $request, int $default): WP_Error|int
    {
        $userId = $request->get_param('user_id');
        $target = $userId ? (int) $userId : $default;

        if ($target <= 0) {
            return $this->validationError(__('Unknown target user.', 'timesuite'));
        }

        $user = get_user_by('id', $target);

        if (! $user) {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        return $target;
    }

    /**
     * Delegates to AuthorizationService — the single source of truth for
     * "who can do what" (see its class docblock: "Controllers should NEVER
     * implement their own authorization logic"). This controller used to
     * have its own local re-implementation of this exact check, which had
     * drifted from DirectoryController's (different) visibility check for
     * the employee dropdown — see docs/timesheet-status-investigation.md
     * (P3.4) for why that split was a latent risk.
     */
    private function canView(int $currentUser, int $targetUser): bool
    {
        return $this->authService->canViewTimesheetFor($currentUser, $targetUser);
    }

    private function canEdit(int $currentUser, int $targetUser): bool
    {
        return $this->authService->canEditTimesheetFor($currentUser, $targetUser);
    }

    private function canSubmit(int $currentUser, int $targetUser): bool
    {
        if ($currentUser !== $targetUser) {
            return false;
        }

        // Allow submit_own; fall back to edit_own to avoid blocking if caps are slightly out of sync
        return current_user_can('timesuite.timesheet.submit_own') || current_user_can('timesuite.timesheet.edit_own');
    }

    private function viewAccessDeniedMessage(int $currentUser, int $targetUser): string
    {
        if ($currentUser === $targetUser) {
            return __('Your account does not have permission to view your own timesheet. Ask HR/Technical Admin to assign you a Timesuite role.', 'timesuite');
        }

        if ($this->authService->canViewTeamTimesheets($currentUser)) {
            return __('You can only view employees assigned to you. Ask HR/Technical Admin to check the Org Directory manager assignment.', 'timesuite');
        }

        return __('You do not have permission to view another employee\'s timesheet. Ask HR/Technical Admin if you need access.', 'timesuite');
    }

    /**
     * Permission callback for logged-in users.
     *
     * @return bool|WP_Error
     */
    public function checkLoggedIn(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to access timesheets.', 'timesuite'),
                ['status' => 401]
            );
        }

        return true;
    }

    private function hasHrPowers(): bool
    {
        return $this->authService->hasOrgManagementPowers(get_current_user_id());
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function requestArgs(): array
    {
        return [
            'year' => [
                'required'          => true,
                'validate_callback' => static fn ($value): bool => (int) $value >= 2000,
            ],
            'month' => [
                'required'          => true,
                'validate_callback' => static fn ($value): bool => (int) $value >= 1 && (int) $value <= 12,
            ],
            'user_id' => [
                'required'          => false,
                'validate_callback' => static fn ($value): bool => (int) $value >= 0,
            ],
        ];
    }

    /**
     * Compute day states for a given month.
     *
     * @return array<string, array{state: string, is_actionable: bool, reason: string|null, metadata: array}>
     */
    private function computeDayStatesForMonth(
        int $userId,
        int $year,
        int $month,
        string $monthStatus,
        ?string $submittedAt,
        ?string $approvedAt,
        ?string $rejectionReason,
        bool $isPeriodLocked,
        string $userRole
    ): array {
        $workWeek = $this->dayStateService->getUserWorkWeek($userId);
        $startDate = sprintf('%04d-%02d-01', $year, $month);
        $endDate = sprintf('%04d-%02d-%02d', $year, $month, $this->daysInMonth($year, $month));
        $holidays = array_keys($this->holidayRangeService->getHolidayMapForRange($startDate, $endDate));

        // Provide entry types so DayStateService can treat weekend overrides as editable.
        $payload = $this->service->getMonth($userId, $year, $month);
        $dayEntries = [];
        foreach (($payload['entries'] ?? []) as $entry) {
            if (! is_array($entry) || empty($entry['date'])) {
                continue;
            }
            $dayEntries[(string) $entry['date']] = [
                'type' => isset($entry['type']) ? (string) $entry['type'] : null,
                'status' => isset($entry['approval_status']) ? (string) $entry['approval_status'] : null,
            ];
        }

        return $this->dayStateService->computeMonthStates(
            $year,
            $month,
            $workWeek,
            $holidays,
            $isPeriodLocked,
            $dayEntries,
            $monthStatus,
            $submittedAt,
            null, // approvedBy (could be fetched if needed)
            $approvedAt,
            $rejectionReason,
            $userRole
        );
    }

    /**
     * Get the user's role for actionability computation.
     */
    private function getUserRole(int $userId): string
    {
        $role = get_user_meta($userId, AuthorizationService::META_KEY, true);

        if (in_array($role, ['tech_admin', 'hr', 'manager', 'employee'], true)) {
            return $role;
        }

        return 'employee';
    }

    /**
     * @param array<string, mixed>|null $request
     *
     * @return array<string, mixed>|null
     */
    private function formatReeditRequest(?array $request): ?array
    {
        if (! $request) {
            return null;
        }

        return [
            'id' => (int) ($request['id'] ?? 0),
            'status' => (string) ($request['status'] ?? ''),
            'employee_reason' => (string) ($request['employee_reason'] ?? ''),
            'manager_reason' => $request['manager_reason'] ?? null,
            'requested_at' => $request['requested_at'] ?? null,
            'decided_at' => $request['decided_at'] ?? null,
        ];
    }

    private function daysInMonth(int $year, int $month): int
    {
        $date = new \DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month), new \DateTimeZone('UTC'));

        return (int) $date->format('t');
    }
}
