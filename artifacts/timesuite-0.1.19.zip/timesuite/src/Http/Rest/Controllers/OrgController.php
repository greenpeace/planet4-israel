<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Domain\Org\Services\OrgService;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Http\Rest\AbstractRestController;
use Timesuite\Http\Rest\Concerns\FileUploadValidation;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class OrgController extends AbstractRestController
{
    use FileUploadValidation;
    public function __construct(private OrgService $orgService)
    {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/org',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'listMappings'],
                    'permission_callback' => [$this, 'checkOrgViewPermission'],
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'saveMapping'],
                    'permission_callback' => [$this, 'checkOrgEditPermission'],
                ],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/org/import',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'importMappings'],
                'permission_callback' => [$this, 'checkOrgImportPermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/org/export',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'exportMappings'],
                'permission_callback' => [$this, 'checkOrgViewPermission'],
            ]
        );
    }

    /**
     * Permission callback that returns WP_Error with proper 403 response for better frontend handling.
     *
     * @return bool|WP_Error Returns true if authorized, WP_Error otherwise.
     */
    public function checkOrgViewPermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to access this resource.', 'timesuite'),
                ['status' => 401]
            );
        }

        if (! current_user_can('timesuite.org.view') && ! current_user_can('timesuite.org.edit')) {
            return new WP_Error(
                'timesuite_forbidden',
                __('You do not have permission to manage organization settings.', 'timesuite'),
                ['status' => 403]
            );
        }

        return true;
    }

    /**
     * @return bool|WP_Error
     */
    public function checkOrgEditPermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to access this resource.', 'timesuite'),
                ['status' => 401]
            );
        }

        if (! current_user_can('timesuite.org.edit')) {
            return new WP_Error(
                'timesuite_forbidden',
                __('You do not have permission to manage organization settings.', 'timesuite'),
                ['status' => 403]
            );
        }

        return true;
    }

    /**
     * @return bool|WP_Error
     */
    public function checkOrgImportPermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to access this resource.', 'timesuite'),
                ['status' => 401]
            );
        }

        if (! current_user_can('timesuite.org.import')) {
            return new WP_Error(
                'timesuite_forbidden',
                __('You do not have permission to import organization data.', 'timesuite'),
                ['status' => 403]
            );
        }

        return true;
    }

    public function listMappings(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        // Permission already checked by checkOrgPermission callback
        $department  = $request->get_param('department');

        $mappings = $this->orgService->getMappings(
            $department ? sanitize_text_field((string) $department) : null
        );

        return new WP_REST_Response(['mappings' => $mappings], 200);
    }

    public function saveMapping(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        // Permission already checked by checkOrgPermission callback
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $payload = $request->get_json_params();

        if (! is_array($payload)) {
            return $this->validationError(__('Invalid payload.', 'timesuite'));
        }

        $entry = $this->buildEntryFromParams($payload, 0);

        if (is_wp_error($entry)) {
            return $entry;
        }

        $currentUser = get_current_user_id();
        $allowSelfManager = current_user_can('timesuite.settings.manage')
            || current_user_can('timesuite.period.lock')
            || current_user_can('timesuite.org.edit');

        try {
            $diff = $this->orgService->synchronize([$entry], false, $currentUser, false, $allowSelfManager);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        }

        return new WP_REST_Response($diff, 200);
    }

    public function exportMappings(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $handle = fopen('php://temp', 'r+');

        if (! $handle) {
            return $this->serverError(__('Unable to create CSV export.', 'timesuite'));
        }

        fputcsv($handle, ['email', 'manager_email', 'department', 'active']);

        foreach ($this->orgService->getMappings() as $mapping) {
            fputcsv($handle, [
                (string) ($mapping['user_email'] ?? ''),
                (string) ($mapping['manager_email'] ?? ''),
                (string) ($mapping['department'] ?? ''),
                ! empty($mapping['active']) ? 'true' : 'false',
            ]);
        }

        rewind($handle);
        $content = stream_get_contents($handle);
        fclose($handle);

        return new WP_REST_Response([
            'filename' => 'timesuite_org_export_' . gmdate('Ymd_His') . '.csv',
            'content' => base64_encode((string) $content),
            'mime_type' => 'text/csv; charset=UTF-8',
        ], 200);
    }

    public function importMappings(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        // Permission already checked by checkOrgPermission callback
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        // Rate limit: 10 imports per minute
        $rateLimitError = $this->enforceRateLimit('org_import', 10, 60);

        if ($rateLimitError) {
            return $rateLimitError;
        }

        $fileParams = $request->get_file_params();

        if (empty($fileParams['file'])) {
            return $this->validationError(__('CSV file is required.', 'timesuite'));
        }

        $file = $fileParams['file'];
        $size = isset($file['size']) ? (int) $file['size'] : 0;

        if ($size > (2 * 1024 * 1024)) {
            return $this->validationError(__('File must be under 2MB.', 'timesuite'));
        }

        // Validate file type with MIME checking.
        $validation = $this->validateUploadedFile(
            $file,
            ['csv'],
            ['text/csv', 'text/plain', 'application/csv']
        );

        if (is_wp_error($validation)) {
            return $validation;
        }

        $tmpPath = (string) ($file['tmp_name'] ?? '');

        $rows = $this->parseCsv($tmpPath);

        if (is_wp_error($rows)) {
            return new WP_REST_Response(
                ['errors' => $rows->get_error_data()['errors'] ?? []],
                $rows->get_error_data()['status'] ?? 400
            );
        }

        $dryRun = (bool) (int) ($request->get_param('dry_run') ?? 1);
        $allowSelfManager = current_user_can('timesuite.settings.manage')
            || current_user_can('timesuite.period.lock')
            || current_user_can('timesuite.org.edit');

        try {
            $diff = $this->orgService->synchronize($rows, $dryRun, get_current_user_id(), true, $allowSelfManager);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        }

        return new WP_REST_Response($diff, 200);
    }

    private function parseCsv(string $filePath): array|WP_Error
    {
        if (! is_readable($filePath)) {
            return $this->validationError(__('Unable to read CSV.', 'timesuite'));
        }

        $contents = file_get_contents($filePath);

        if (false === $contents) {
            return $this->validationError(__('Unable to read CSV.', 'timesuite'));
        }

        $contents = $this->normalizeCsvContents($contents);

        $handle = fopen('php://temp', 'r+');

        if (! $handle) {
            return $this->validationError(__('Unable to open CSV.', 'timesuite'));
        }

        fwrite($handle, $contents);
        rewind($handle);

        $header = fgetcsv($handle);

        if (! $header) {
            fclose($handle);

            return $this->validationError(__('CSV missing header.', 'timesuite'));
        }

        $normalizedHeader = array_map('strtolower', $header);
        $expected         = ['email', 'manager_email', 'department', 'active'];

        foreach ($expected as $column) {
            if (! in_array($column, $normalizedHeader, true)) {
                fclose($handle);

                return $this->validationError(sprintf(__('Missing column: %s', 'timesuite'), $column));
            }
        }

        $rows   = [];
        $errors = [];
        $line   = 1;

        while (($data = fgetcsv($handle)) !== false) {
            ++$line;

            if ($this->rowEmpty($data)) {
                continue;
            }

            $rowAssoc = array_combine($normalizedHeader, $data);

            if (! $rowAssoc) {
                $errors[] = $this->rowError($line, 'row', __('Malformed row.', 'timesuite'));
                continue;
            }

            $entry = $this->buildEntryFromParams($rowAssoc, $line);

            if (is_wp_error($entry)) {
                $errors[] = $entry->get_error_data()['details'];
                continue;
            }

            $rows[] = $entry;
        }

        fclose($handle);

        // Derive is_manager automatically:
        // If a user is referenced as a manager_email for any row in the import,
        // mark them as a manager in the org mappings.
        $managerIds = [];

        foreach ($rows as $row) {
            if (! empty($row['manager_id'])) {
                $managerIds[(int) $row['manager_id']] = true;
            }
        }

        foreach ($rows as $idx => $row) {
            $userId = (int) ($row['user_id'] ?? 0);
            $rows[$idx]['is_manager'] = isset($managerIds[$userId]);
        }

        if (! empty($errors)) {
            return new WP_Error(
                'timesuite_org_csv_rows',
                __('Invalid rows.', 'timesuite'),
                [
                    'status' => 400,
                    'errors' => $errors,
                ]
            );
        }

        return $rows;
    }

    private function normalizeCsvContents(string $contents): string
    {
        if (0 === strncmp($contents, "\xEF\xBB\xBF", 3)) {
            $contents = substr($contents, 3);
        }

        if (0 === strncmp($contents, "\xFF\xFE", 2)) {
            $contents = $this->convertEncoding($contents, 'UTF-16LE');
        } elseif (0 === strncmp($contents, "\xFE\xFF", 2)) {
            $contents = $this->convertEncoding($contents, 'UTF-16BE');
        } elseif (false !== strpos($contents, "\0")) {
            $contents = $this->convertEncoding($contents, 'UTF-16LE');
        }

        if (0 === strncmp($contents, "\xEF\xBB\xBF", 3)) {
            $contents = substr($contents, 3);
        }

        return $contents;
    }

    private function convertEncoding(string $contents, string $fromEncoding): string
    {
        if (function_exists('mb_convert_encoding')) {
            return (string) mb_convert_encoding($contents, 'UTF-8', $fromEncoding);
        }

        if (function_exists('iconv')) {
            $converted = iconv($fromEncoding, 'UTF-8//IGNORE', $contents);

            if (false !== $converted) {
                return $converted;
            }
        }

        return $contents;
    }

    /**
     * @param array<string, mixed> $params
     */
    private function buildEntryFromParams(array $params, int $row): array|WP_Error
    {
        $email = strtolower(trim((string) ($params['email'] ?? '')));

        if ('' === $email) {
            return $this->rowErrorResponse($row, 'email', __('Employee email required.', 'timesuite'));
        }

        $user = get_user_by('email', $email);

        if (! $user) {
            return $this->rowErrorResponse($row, 'email', __('Employee not found.', 'timesuite'));
        }

        $managerEmail = strtolower(trim((string) ($params['manager_email'] ?? '')));
        $manager      = $managerEmail ? get_user_by('email', $managerEmail) : null;

        if ($managerEmail && ! $manager) {
            return $this->rowErrorResponse($row, 'manager_email', __('Manager not found.', 'timesuite'));
        }

        $employmentStartDate = $this->normalizeEmploymentStartDate($params['employment_start_date'] ?? null, $row);

        if (is_wp_error($employmentStartDate)) {
            return $employmentStartDate;
        }
        $employmentEndDate = $this->normalizeEmploymentDate(
            $params['employment_end_date'] ?? null,
            $row,
            'employment_end_date',
            __('Employment end date must use YYYY-MM-DD format.', 'timesuite')
        );

        if (is_wp_error($employmentEndDate)) {
            return $employmentEndDate;
        }

        if ($employmentStartDate !== null && $employmentEndDate !== null && $employmentEndDate < $employmentStartDate) {
            return $this->rowErrorResponse($row, 'employment_end_date', __('Employment end date cannot be before employment start date.', 'timesuite'));
        }

        return [
            'user_id'       => (int) $user->ID,
            'user_email'    => (string) $user->user_email,
            'manager_id'    => $manager ? (int) $manager->ID : null,
            'manager_email' => $manager ? (string) $manager->user_email : null,
            'department'    => sanitize_text_field((string) ($params['department'] ?? '')),
            'employment_start_date' => $employmentStartDate,
            'employment_end_date' => $employmentEndDate,
            'active'        => $this->toBool($params['active'] ?? true),
            'assignment_id' => $params['assignment_id'] ?? null,
        ];
    }

    private function normalizeEmploymentStartDate(mixed $value, int $row): string|WP_Error|null
    {
        return $this->normalizeEmploymentDate(
            $value,
            $row,
            'employment_start_date',
            __('Employment start date must use YYYY-MM-DD format.', 'timesuite')
        );
    }

    private function normalizeEmploymentDate(mixed $value, int $row, string $field, string $message): string|WP_Error|null
    {
        if ($value === null || trim((string) $value) === '') {
            return null;
        }

        $date = trim((string) $value);
        $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d', $date, new \DateTimeZone('UTC'));

        if (! $parsed instanceof \DateTimeImmutable || $parsed->format('Y-m-d') !== $date) {
            return $this->rowErrorResponse($row, $field, $message);
        }

        return $date;
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        $value = strtolower(trim((string) $value));

        if ('' === $value) {
            return false;
        }

        return in_array($value, ['1', 'true', 'yes', 'on'], true);
    }

    /**
     * @param array<int, string|null> $row
     */
    private function rowEmpty(array $row): bool
    {
        foreach ($row as $value) {
            if (null !== $value && '' !== trim($value)) {
                return false;
            }
        }

        return true;
    }

    private function rowErrorResponse(int $row, string $field, string $message): WP_Error
    {
        return new WP_Error(
            'timesuite_org_row',
            $message,
            [
                'status'  => 400,
                'details' => $this->rowError($row, $field, $message),
            ]
        );
    }

    private function rowError(int $row, string $field, string $message): array
    {
        return [
            'row'     => $row,
            'field'   => $field,
            'message' => $message,
        ];
    }
}
