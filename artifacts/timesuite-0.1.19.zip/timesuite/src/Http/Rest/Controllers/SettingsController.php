<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Core\Settings;
use Timesuite\Domain\Org\Services\OrgService;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use Timesuite\Http\Rest\AbstractRestController;
use Timesuite\Services\Notifications\EmailNotifier;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class SettingsController extends AbstractRestController
{
    public function __construct(
        private Settings $settings,
        private ?EmailNotifier $emailNotifier = null,
        private ?ApprovalLogRepository $auditLog = null,
        private ?OrgService $orgService = null
    ) {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/settings',
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [$this, 'getSettings'],
                    'permission_callback' => [$this, 'checkSettingsPermission'],
                ],
                [
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => [$this, 'updateSettings'],
                    'permission_callback' => [$this, 'checkSettingsPermission'],
                ],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/settings/user-work-week',
            [
                [
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => [$this, 'updateUserWorkWeek'],
                    'permission_callback' => [$this, 'checkSettingsPermission'],
                ],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/settings/test-email',
            [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [$this, 'sendTestEmail'],
                    'permission_callback' => [$this, 'checkSettingsPermission'],
                ],
            ]
        );
    }

    public function getSettings(): WP_REST_Response|WP_Error
    {
        return new WP_REST_Response($this->buildPayload(), 200);
    }

    public function updateSettings(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $payload = $request->get_json_params();

        if (! is_array($payload)) {
            return $this->validationError(__('Invalid payload.', 'timesuite'));
        }

        $circularValidationError = $this->validateCircularManagerSetting($payload);

        if ($circularValidationError !== null) {
            $data = $this->buildPayload();
            $data['updated'] = false;
            $data['errors'] = [
                'allow_circular_manager_assignments' => $circularValidationError,
            ];

            return new WP_REST_Response($data, 400);
        }

        $previousSettings = $this->settings->toArray();
        $result = $this->settings->update($payload);
        $changedFields = $this->resolveChangedFields($previousSettings, $this->settings->toArray(), $payload);
        $data = $this->buildPayload();
        $data['updated'] = $result['updated'];
        $data['errors'] = $result['errors'];

        if (! empty($result['errors'])) {
            return new WP_REST_Response($data, 400);
        }

        if ($this->auditLog && ! empty($changedFields)) {
            $this->auditLog->logSettingsChange(
                get_current_user_id(),
                $changedFields
            );
        }

        return new WP_REST_Response($data, 200);
    }

    /**
     * @param array<string, mixed> $before
     * @param array<string, mixed> $after
     * @param array<string, mixed> $payload
     *
     * @return string[]
     */
    private function resolveChangedFields(array $before, array $after, array $payload): array
    {
        $changed = [];

        foreach (array_keys($payload) as $field) {
            if (! array_key_exists($field, $after)) {
                continue;
            }

            $previous = $before[$field] ?? null;
            $current = $after[$field];

            if ($previous !== $current) {
                $changed[] = (string) $field;
            }
        }

        return $changed;
    }

    public function updateUserWorkWeek(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $payload = $request->get_json_params();

        if (! is_array($payload)) {
            return $this->validationError(__('Invalid payload.', 'timesuite'));
        }

        $userId = isset($payload['user_id']) ? (int) $payload['user_id'] : 0;

        if ($userId <= 0) {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        $user = get_user_by('id', $userId);

        if (! $user) {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        $useDefault = isset($payload['use_default']) && (bool) $payload['use_default'];
        $workWeek = $payload['work_week'] ?? null;

        if ($useDefault) {
            if (function_exists('delete_user_meta')) {
                delete_user_meta($userId, 'timesuite_work_week');
            }

            return new WP_REST_Response(
                [
                    'user_id' => $userId,
                    'work_week' => null,
                    'use_default' => true,
                ],
                200
            );
        }

        $normalized = $this->normalizeWorkWeek($workWeek);

        if ($normalized === null) {
            return new WP_Error('timesuite_work_week', __('Select at least one working day.', 'timesuite'), [
                'status' => 400,
                'field' => 'work_week',
            ]);
        }

        if (function_exists('update_user_meta')) {
            update_user_meta($userId, 'timesuite_work_week', $normalized);
        }

        return new WP_REST_Response(
            [
                'user_id' => $userId,
                'work_week' => $normalized,
                'use_default' => false,
            ],
            200
        );
    }

    /**
     * Send a test email to verify email configuration.
     */
    public function sendTestEmail(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        if (! $this->emailNotifier) {
            return $this->serverError(__('Email notifier not available.', 'timesuite'));
        }

        $payload = $request->get_json_params();
        $email = isset($payload['email']) ? sanitize_email((string) $payload['email']) : '';

        if ('' === $email) {
            // Default to current user's email
            $currentUser = wp_get_current_user();
            $email = $currentUser->user_email;
        }

        $result = $this->emailNotifier->sendTestEmail($email);

        if ($result['success']) {
            return new WP_REST_Response($result, 200);
        }

        return new WP_REST_Response($result, 400);
    }

    /**
     * Permission callback that returns proper WP_Error for better frontend handling.
     *
     * @return bool|WP_Error
     */
    public function checkSettingsPermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to access settings.', 'timesuite'),
                ['status' => 401]
            );
        }

        if (! current_user_can('timesuite.settings.manage')) {
            return new WP_Error(
                'timesuite_forbidden',
                __('You do not have permission to manage settings.', 'timesuite'),
                ['status' => 403]
            );
        }

        return true;
    }

    /**
     * @return array<string, mixed>
     */
    private function buildPayload(): array
    {
        $superAccessValidation = $this->settings->validateSuperUserEmails();

        return [
            'settings' => $this->settings->toArray(),
            'options'  => [
                'work_week' => Settings::WORK_WEEK_OPTIONS,
            ],
            'validation' => [
                'super_access' => [
                    'valid' => $superAccessValidation['valid'],
                    'invalid_emails' => $superAccessValidation['invalid_emails'],
                    'warning' => $superAccessValidation['warning'],
                    'details' => $this->settings->getSuperUserEmailsWithValidation(),
                ],
            ],
        ];
    }

    private function validateCircularManagerSetting(array $payload): ?string
    {
        if (! array_key_exists('allow_circular_manager_assignments', $payload)) {
            return null;
        }

        if ($this->coerceBoolean($payload['allow_circular_manager_assignments'])) {
            return null;
        }

        $conflict = $this->orgService?->getCircularManagerConflict();

        return is_array($conflict) ? (string) ($conflict['message'] ?? '') : null;
    }

    private function coerceBoolean(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_string($value)) {
            return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
        }

        return (bool) $value;
    }

    /**
     * @return string[]|null
     */
    private function normalizeWorkWeek(mixed $value): ?array
    {
        $days = Settings::normalizeWorkWeekDays($value);

        return empty($days) ? null : $days;
    }
}
