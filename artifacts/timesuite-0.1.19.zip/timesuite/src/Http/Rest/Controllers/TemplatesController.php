<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Http\Rest\AbstractRestController;
use Timesuite\Services\Template\ExcelBuilder;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class TemplatesController extends AbstractRestController
{
    public function __construct(private ExcelBuilder $excelBuilder)
    {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/templates/timesheet.xlsx',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'downloadTimesheet'],
                'permission_callback' => static fn (): bool => (bool) get_current_user_id(),
            ]
        );
    }

    public function downloadTimesheet(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        try {
            $body = $this->excelBuilder->buildTimesheetTemplate();
        } catch (\Throwable $exception) {
            return new WP_Error('timesuite_template_error', $exception->getMessage(), ['status' => 500]);
        }

        return $this->fileResponse([
            'filename' => 'timesuite_timesheet_template.xlsx',
            'content' => $body,
            'mime_type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ]);
    }

    /**
     * Create a base64-encoded file download response.
     *
     * @param array{filename: string, content: string, mime_type: string} $export
     */
    private function fileResponse(array $export): WP_REST_Response
    {
        $response = new WP_REST_Response();

        $response->header('Content-Type', 'application/json; charset=UTF-8');
        $response->header('Cache-Control', 'no-cache, no-store, must-revalidate');
        $response->header('Pragma', 'no-cache');
        $response->header('Expires', '0');

        $response->set_data([
            'filename' => $export['filename'],
            'content' => base64_encode($export['content']),
            'mime_type' => $export['mime_type'],
        ]);

        return $response;
    }
}
