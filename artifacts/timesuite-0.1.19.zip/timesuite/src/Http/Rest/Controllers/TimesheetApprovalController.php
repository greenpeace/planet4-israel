<?php

declare(strict_types=1);

namespace Timesuite\Http\Rest\Controllers;

use Timesuite\Core\Settings;
use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Domain\Org\Services\OrgService;
use Timesuite\Domain\Shared\Exceptions\ConcurrencyException;
use Timesuite\Domain\Shared\Exceptions\PersistenceException;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use Timesuite\Domain\Timesheets\Repositories\ReeditRequestRepository;
use Timesuite\Domain\Timesheets\Services\MonthlyTimesheetService;
use Timesuite\Http\Rest\AbstractRestController;
use Timesuite\Services\Notifications\EmailNotifier;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * REST controller for timesheet approval workflow operations.
 *
 * Handles:
 * - Listing timesheets pending approval
 * - Approving/denying entire timesheets
 * - Approving/denying individual days
 * - Bulk approval operations
 *
 * Uses AuthorizationService for all permission checks (single source of truth).
 */
class TimesheetApprovalController extends AbstractRestController
{
    public function __construct(
        private MonthlyTimesheetService $service,
        private OrgService $orgService,
        private AuthorizationService $authService,
        private ReeditRequestRepository $reeditRequestRepository,
        private ApprovalLogRepository $approvalLogRepository,
        private ?EmailNotifier $emailNotifier = null,
        private ?Settings $settings = null
    ) {
    }

    public function registerRoutes(): void
    {
        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/approvals',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'listApprovals'],
                'permission_callback' => [$this, 'checkViewApprovalsPermission'],
                'args'                => $this->approvalArgs(),
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/approve',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'approveTimesheet'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/deny',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'denyTimesheet'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/day/approve',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'approveDay'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/day/deny',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'denyDay'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/day/reset',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'resetDay'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/day/approve-all',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'approveAllDays'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/day/deny-all',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'denyAllDays'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/day/reset-all',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'resetAllDays'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/review/submit',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'submitReview'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/reedit-request',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'createReeditRequest'],
                'permission_callback' => [$this, 'checkLoggedInPermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/reedit-requests',
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [$this, 'listReeditRequests'],
                'permission_callback' => [$this, 'checkApprovePermission'],
                'args'                => $this->approvalArgs(),
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/reedit-request/approve',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'approveReeditRequest'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/reedit-request/deny',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'denyReeditRequest'],
                'permission_callback' => [$this, 'checkApprovePermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/lock',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'lockTimesheet'],
                'permission_callback' => [$this, 'checkLockPermission'],
            ]
        );

        register_rest_route(
            self::ROUTE_NAMESPACE,
            '/monthly-timesheets/unlock',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'unlockTimesheet'],
                'permission_callback' => [$this, 'checkLockPermission'],
            ]
        );
    }

    public function listApprovals(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            // Use AuthorizationService for consistent authorization logic
            $userIds = $this->authService->hasOrgManagementPowers($currentUser)
                ? array_values(
                    array_unique(
                        array_map(
                            static fn (array $mapping): int => (int) $mapping['user_id'],
                            array_filter(
                                $this->orgService->getMappings(),
                                static fn (array $mapping): bool => ! empty($mapping['active'])
                            )
                        )
                    )
                )
                : $this->orgService->listDirectReportIds($currentUser);

            $userIds = array_values(array_filter(
                $userIds,
                static fn (int $userId): bool => $userId !== $currentUser
            ));

            $results = [];

            foreach ($userIds as $userId) {
                $meta = $this->service->getMonthMeta($userId, $year, $month);

                if ('submitted' !== ($meta['status'] ?? 'draft')) {
                    continue;
                }

                $user = get_user_by('id', $userId);

                if (! $user) {
                    continue;
                }

                $department = get_user_meta($userId, 'timesuite_department', true);

                $results[] = [
                    'user_id' => $userId,
                    'employee_name' => $user->display_name ?: $user->user_login,
                    'employee_email' => $user->user_email,
                    'department' => is_string($department) ? $department : '',
                    'year' => $year,
                    'month' => $month,
                    'status' => $meta['status'] ?? 'draft',
                    'submitted_at' => $meta['submitted_at'] ?? null,
                ];
            }
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // A read, but it walks many employees' months and each can
            // materialize a legacy month as a side effect. There is no single
            // target -- the loop variable is out of scope by now -- so the
            // actor and the month are what gets logged.
            return $this->persistenceError(
                $exception,
                'listing approvals',
                ['actor_id' => $currentUser, 'year' => $year, 'month' => $month]
            );
        }

        return new WP_REST_Response(['timesheets' => $results], 200);
    }

    public function approveTimesheet(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->approvalAccessError($currentUser, $targetUser);
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $meta = $this->service->getMonthMeta($targetUser, $year, $month);

            $status = (string) ($meta['status'] ?? 'draft');

            if ('submitted' !== $status) {
                return $this->validationError($this->submittedRequiredMessage($status, 'approval'));
            }

            $timesheet = $this->service->updateMonthStatus($targetUser, $year, $month, 'locked', $currentUser);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        $this->approvalLogRepository->log(
            'month_locked',
            $targetUser,
            $currentUser,
            ['year' => $year, 'month' => $month]
        );

        return new WP_REST_Response(
            [
                'approved' => true,
                'timesheet' => [
                    'user_id' => $targetUser,
                    'year' => $year,
                    'month' => $month,
                    'status' => $timesheet['status'] ?? 'locked',
                ],
            ],
            200
        );
    }

    public function denyTimesheet(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->approvalAccessError($currentUser, $targetUser);
        }

        $comment = (string) $request->get_param('comment');

        if ('' === trim($comment)) {
            return $this->validationError(__('A denial reason is required.', 'timesuite'));
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $meta = $this->service->getMonthMeta($targetUser, $year, $month);

            $status = (string) ($meta['status'] ?? 'draft');

            if ('submitted' !== $status) {
                return $this->validationError($this->submittedRequiredMessage($status, 'it can be denied'));
            }

            $timesheet = $this->service->updateMonthStatus(
                $targetUser,
                $year,
                $month,
                'denied',
                $currentUser,
                $comment
            );
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        return new WP_REST_Response(
            [
                'denied' => true,
                'comment' => $comment,
                'timesheet' => [
                    'user_id' => $targetUser,
                    'year' => $year,
                    'month' => $month,
                    'status' => $timesheet['status'] ?? 'denied',
                ],
            ],
            200
        );
    }

    public function approveDay(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->approvalAccessError($currentUser, $targetUser);
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $date  = (string) $request->get_param('date');

        try {
            $timesheet = $this->service->updateDayApproval(
                $targetUser,
                $year,
                $month,
                $date,
                'approved',
                $currentUser
            );
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        if (($timesheet['status'] ?? '') === 'locked') {
            $this->approvalLogRepository->log(
                'month_locked',
                $targetUser,
                $currentUser,
                ['year' => $year, 'month' => $month]
            );
        }

        return new WP_REST_Response(['approved' => true, 'timesheet' => $timesheet], 200);
    }

    public function denyDay(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->approvalAccessError($currentUser, $targetUser);
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $date  = (string) $request->get_param('date');
        $comment = (string) $request->get_param('comment');

        if ('' === trim($comment)) {
            return $this->validationError(__('A denial reason is required.', 'timesuite'));
        }

        try {
            $timesheet = $this->service->updateDayApproval(
                $targetUser,
                $year,
                $month,
                $date,
                'denied',
                $currentUser,
                $comment ?: null
            );
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        return new WP_REST_Response(['denied' => true, 'timesheet' => $timesheet], 200);
    }

    public function resetDay(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->approvalAccessError($currentUser, $targetUser);
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $date  = (string) $request->get_param('date');

        try {
            $timesheet = $this->service->resetDayApproval(
                $targetUser,
                $year,
                $month,
                $date,
                $currentUser
            );
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        return new WP_REST_Response(['reset' => true, 'timesheet' => $timesheet], 200);
    }

    public function approveAllDays(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        // Rate limit bulk actions: 30 per minute
        $rateLimitError = $this->enforceRateLimit('bulk_approval', 30, 60);

        if ($rateLimitError) {
            return $rateLimitError;
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->approvalAccessError($currentUser, $targetUser);
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $timesheet = $this->service->approveAllDays($targetUser, $year, $month, $currentUser);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        if (($timesheet['status'] ?? '') === 'locked') {
            $this->approvalLogRepository->log(
                'month_locked',
                $targetUser,
                $currentUser,
                ['year' => $year, 'month' => $month]
            );
        }

        return new WP_REST_Response(['approved' => true, 'timesheet' => $timesheet], 200);
    }

    public function denyAllDays(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        // Rate limit bulk actions: 30 per minute
        $rateLimitError = $this->enforceRateLimit('bulk_approval', 30, 60);

        if ($rateLimitError) {
            return $rateLimitError;
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->approvalAccessError($currentUser, $targetUser);
        }

        $year    = (int) $request->get_param('year');
        $month   = (int) $request->get_param('month');
        $comment = sanitize_textarea_field((string) $request->get_param('comment'));

        try {
            $timesheet = $this->service->denyAllDays($targetUser, $year, $month, $currentUser, $comment);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        return new WP_REST_Response(['denied' => true, 'timesheet' => $timesheet], 200);
    }

    public function resetAllDays(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        // Rate limit bulk actions: 30 per minute
        $rateLimitError = $this->enforceRateLimit('bulk_approval', 30, 60);

        if ($rateLimitError) {
            return $rateLimitError;
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->approvalAccessError($currentUser, $targetUser);
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $timesheet = $this->service->resetAllApprovals($targetUser, $year, $month, $currentUser);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        return new WP_REST_Response(['reset' => true, 'timesheet' => $timesheet], 200);
    }

    public function submitReview(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->approvalAccessError($currentUser, $targetUser);
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $comment = sanitize_textarea_field((string) ($request->get_param('comment') ?? ''));

        try {
            $timesheet = $this->service->finalizeReview(
                $targetUser,
                $year,
                $month,
                $currentUser,
                $comment !== '' ? $comment : null
            );
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        $status = (string) ($timesheet['status'] ?? 'submitted');

        if ($status === 'locked') {
            $this->approvalLogRepository->log(
                'month_locked',
                $targetUser,
                $currentUser,
                ['year' => $year, 'month' => $month]
            );
        } elseif ($status === 'denied') {
            $this->approvalLogRepository->log(
                'deny',
                $targetUser,
                $currentUser,
                ['year' => $year, 'month' => $month, 'comment' => $timesheet['denied_comment'] ?? null]
            );
        }

        return new WP_REST_Response(
            [
                'submitted' => true,
                'decision' => $status === 'locked' ? 'approved' : ($status === 'denied' ? 'denied' : 'pending'),
                'timesheet' => $timesheet,
            ],
            200
        );
    }

    public function createReeditRequest(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        if (! current_user_can('timesuite.timesheet.edit_own')) {
            return $this->forbiddenError(__('You do not have permission to request re-edit.', 'timesuite'));
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $reason = sanitize_textarea_field((string) ($request->get_param('reason') ?? $request->get_param('employee_reason')));

        $reasonLength = function_exists('mb_strlen') ? mb_strlen(trim($reason)) : strlen(trim($reason));

        if ($reasonLength < 10) {
            return $this->validationError(
                __('Please provide a brief reason (at least 10 characters).', 'timesuite')
            );
        }

        try {
            $meta = $this->service->getMonthMeta($currentUser, $year, $month);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // This endpoint acts on the requesting employee's own month --
            // there is no separate target user here.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $currentUser, 'year' => $year, 'month' => $month]
            );
        }

        if ('locked' !== ($meta['status'] ?? 'draft')) {
            return $this->validationError(__('Only locked timesheets can request re-edit.', 'timesuite'));
        }

        $existing = $this->reeditRequestRepository->getPendingForMonth($currentUser, $year, $month);

        if ($existing) {
            return new WP_REST_Response(
                [
                    'created' => false,
                    'request' => $this->formatReeditRequest($existing),
                ],
                200
            );
        }

        $requestId = $this->reeditRequestRepository->createPending($currentUser, $year, $month, $currentUser, $reason);

        if ($requestId <= 0) {
            // Handle duplicate-click/network-retry races idempotently.
            $pendingAfterInsert = $this->reeditRequestRepository->getPendingForMonth($currentUser, $year, $month);

            if ($pendingAfterInsert) {
                return new WP_REST_Response(
                    [
                        'created' => false,
                        'request' => $this->formatReeditRequest($pendingAfterInsert),
                    ],
                    200
                );
            }

            return $this->serverError(__('Unable to create re-edit request.', 'timesuite'));
        }

        $created = $this->reeditRequestRepository->getById($requestId);

        if (! $created) {
            return $this->serverError(__('Unable to load re-edit request.', 'timesuite'));
        }

        $this->approvalLogRepository->log(
            'request_created',
            $currentUser,
            $currentUser,
            ['year' => $year, 'month' => $month, 'request_id' => $requestId]
        );

        $this->sendReeditRequestNotification($currentUser, $year, $month, $reason);

        return new WP_REST_Response(
            [
                'created' => true,
                'request' => $this->formatReeditRequest($created),
            ],
            201
        );
    }

    public function listReeditRequests(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');
        $targetUserParam = $request->get_param('user_id');

        $requests = [];

        if ($targetUserParam !== null && $targetUserParam !== '') {
            $targetUser = (int) $targetUserParam;

            if ($targetUser <= 0) {
                return $this->validationError(__('Unknown target user.', 'timesuite'));
            }

            if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
                return $this->forbiddenError(__('You do not have access to this re-edit request.', 'timesuite'));
            }

            $requests = $this->reeditRequestRepository->listPendingForUserMonth($targetUser, $year, $month);
        } else {
            $userIds = $this->authService->hasOrgManagementPowers($currentUser)
                ? array_values(
                    array_unique(
                        array_map(
                            static fn (array $mapping): int => (int) $mapping['user_id'],
                            array_filter(
                                $this->orgService->getMappings(),
                                static fn (array $mapping): bool => ! empty($mapping['active'])
                            )
                        )
                    )
                )
                : $this->orgService->listDirectReportIds($currentUser);

            $userIds = array_values(array_filter(
                $userIds,
                static fn (int $userId): bool => $userId > 0
            ));

            $requests = $this->reeditRequestRepository->listPendingForUsers($userIds, $year, $month);
        }

        $results = array_map(function (array $row): array {
            $userId = (int) ($row['user_id'] ?? 0);
            $user = $userId > 0 ? get_user_by('id', $userId) : null;

            return array_merge(
                $this->formatReeditRequest($row),
                [
                    'user_id' => $userId,
                    'employee_name' => $user ? ($user->display_name ?: $user->user_login) : '',
                    'employee_email' => $user ? $user->user_email : '',
                    'year' => (int) ($row['year'] ?? 0),
                    'month' => (int) ($row['month'] ?? 0),
                ]
            );
        }, $requests);

        return new WP_REST_Response(['requests' => $results], 200);
    }

    public function approveReeditRequest(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $requestId = $this->resolveReeditRequestId($request);

        if (is_wp_error($requestId)) {
            return $requestId;
        }

        $managerReason = sanitize_textarea_field((string) ($request->get_param('comment') ?? ''));
        $record = $this->reeditRequestRepository->getById($requestId);

        if (! $record) {
            return $this->notFoundError(__('Re-edit request not found.', 'timesuite'));
        }

        $targetUser = (int) ($record['user_id'] ?? 0);
        $year = (int) ($record['year'] ?? 0);
        $month = (int) ($record['month'] ?? 0);
        $status = (string) ($record['status'] ?? '');

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->forbiddenError(__('You do not have access to this re-edit request.', 'timesuite'));
        }

        if ($status === 'approved') {
            $timesheet = $this->service->getMonth($targetUser, $year, $month);

            return new WP_REST_Response(
                [
                    'approved' => true,
                    'request' => $this->formatReeditRequest($record),
                    'timesheet' => $timesheet,
                ],
                200
            );
        }

        if ($status === 'denied') {
            return $this->validationError(__('This request was already denied.', 'timesuite'));
        }

        // Approving the request and reopening the month are one fact, so they
        // are one transaction. Previously markApproved() ran first and
        // committed on its own: if the reopen then failed, the request was
        // left approved over a still-locked month -- the employee unable to
        // edit, and the manager believing they had been let back in.
        //
        // reopenLockedMonth() opens no second transaction; it joins this one.
        try {
            $timesheet = $this->service->transactional(
                function () use ($requestId, $currentUser, $managerReason, $targetUser, $year, $month) {
                    $updated = $this->reeditRequestRepository->markApproved($requestId, $currentUser, $managerReason);

                    if (! $updated) {
                        // Someone decided this request between our read and
                        // our write. Nothing has been written, so unwinding
                        // costs nothing; the caller sorts out which case it is.
                        throw new ConcurrencyException('Re-edit request was not updated.');
                    }

                    return $this->service->reopenLockedMonth($targetUser, $year, $month, $currentUser);
                }
            );
        } catch (ConcurrencyException $exception) {
            $latest = $this->reeditRequestRepository->getById($requestId);

            if ($latest && ($latest['status'] ?? '') === 'approved') {
                $timesheet = $this->service->getMonth($targetUser, $year, $month);

                return new WP_REST_Response(
                    [
                        'approved' => true,
                        'request' => $this->formatReeditRequest($latest),
                        'timesheet' => $timesheet,
                    ],
                    200
                );
            }

            return $this->serverError(__('Unable to approve re-edit request.', 'timesuite'));
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // The whole workflow rolled back together: the request is still
            // pending and the month is still locked.
            return $this->persistenceError(
                $exception,
                'approve re-edit request and reopen month',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month, 'request_id' => $requestId]
            );
        }

        $approvedRequest = $this->reeditRequestRepository->getById($requestId);

        $this->approvalLogRepository->log(
            'request_approved',
            $targetUser,
            $currentUser,
            ['year' => $year, 'month' => $month, 'request_id' => $requestId]
        );
        $this->approvalLogRepository->log(
            'month_reopened',
            $targetUser,
            $currentUser,
            ['year' => $year, 'month' => $month, 'request_id' => $requestId]
        );

        $this->sendReeditDecisionNotification($targetUser, $currentUser, $year, $month, true, $managerReason);

        return new WP_REST_Response(
            [
                'approved' => true,
                'request' => $this->formatReeditRequest($approvedRequest ?: $record),
                'timesheet' => $timesheet,
            ],
            200
        );
    }

    public function denyReeditRequest(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $requestId = $this->resolveReeditRequestId($request);

        if (is_wp_error($requestId)) {
            return $requestId;
        }

        $managerReason = sanitize_textarea_field((string) ($request->get_param('comment') ?? $request->get_param('manager_reason')));

        if (trim($managerReason) === '') {
            return $this->validationError(__('A denial reason is required.', 'timesuite'));
        }

        $record = $this->reeditRequestRepository->getById($requestId);

        if (! $record) {
            return $this->notFoundError(__('Re-edit request not found.', 'timesuite'));
        }

        $targetUser = (int) ($record['user_id'] ?? 0);
        $year = (int) ($record['year'] ?? 0);
        $month = (int) ($record['month'] ?? 0);
        $status = (string) ($record['status'] ?? '');

        if (! $this->authService->canApproveTimesheetFor($currentUser, $targetUser)) {
            return $this->forbiddenError(__('You do not have access to this re-edit request.', 'timesuite'));
        }

        if ($status === 'denied') {
            return new WP_REST_Response(
                [
                    'denied' => true,
                    'request' => $this->formatReeditRequest($record),
                ],
                200
            );
        }

        if ($status === 'approved') {
            return $this->validationError(__('This request was already approved.', 'timesuite'));
        }

        $updated = $this->reeditRequestRepository->markDenied($requestId, $currentUser, $managerReason);

        if (! $updated) {
            $latest = $this->reeditRequestRepository->getById($requestId);

            if ($latest && ($latest['status'] ?? '') === 'denied') {
                return new WP_REST_Response(
                    [
                        'denied' => true,
                        'request' => $this->formatReeditRequest($latest),
                    ],
                    200
                );
            }

            return $this->serverError(__('Unable to deny re-edit request.', 'timesuite'));
        }

        $deniedRequest = $this->reeditRequestRepository->getById($requestId);

        $this->approvalLogRepository->log(
            'request_denied',
            $targetUser,
            $currentUser,
            ['year' => $year, 'month' => $month, 'request_id' => $requestId]
        );

        $this->sendReeditDecisionNotification($targetUser, $currentUser, $year, $month, false, $managerReason);

        return new WP_REST_Response(
            [
                'denied' => true,
                'request' => $this->formatReeditRequest($deniedRequest ?: $record),
            ],
            200
        );
    }

    /**
     * Lock an approved timesheet to prevent further changes.
     *
     * Only HR admins and tech admins can lock timesheets.
     * A timesheet must be approved before it can be locked.
     */
    public function lockTimesheet(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $meta = $this->service->getMonthMeta($targetUser, $year, $month);
            $status = (string) ($meta['status'] ?? 'draft');

            if ('locked' === $status) {
                return new WP_REST_Response(
                    [
                        'locked' => true,
                        'timesheet' => [
                            'user_id' => $targetUser,
                            'year' => $year,
                            'month' => $month,
                            'status' => 'locked',
                        ],
                    ],
                    200
                );
            }

            if (! in_array($status, ['submitted', 'approved'], true)) {
                return $this->validationError($this->lockRequiresSubmittedOrApprovedMessage($status));
            }

            $timesheet = $this->service->updateMonthStatus($targetUser, $year, $month, 'locked', $currentUser);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // Timesheet writes abort rather than failing silently, and the
            // header and its days are persisted as one transaction, so a
            // failure here has already rolled back and the month is
            // unchanged. The driver detail goes to the server log only.
            return $this->persistenceError(
                $exception,
                'timesheet approval action',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        $this->approvalLogRepository->log(
            'month_locked',
            $targetUser,
            $currentUser,
            ['year' => $year, 'month' => $month]
        );

        return new WP_REST_Response(
            [
                'locked' => true,
                'timesheet' => [
                    'user_id' => $targetUser,
                    'year' => $year,
                    'month' => $month,
                    'status' => $timesheet['status'] ?? 'locked',
                ],
            ],
            200
        );
    }

    /**
     * Unlock a locked timesheet to allow modifications.
     *
     * Only HR admins and tech admins can unlock timesheets.
     */
    public function unlockTimesheet(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $currentUser = $this->ensureAuthenticated();

        if (is_wp_error($currentUser)) {
            return $currentUser;
        }

        if (! $this->verifyNonce($request)) {
            return $this->nonceError();
        }

        $targetUser = $this->resolveTargetUserId($request);

        if (is_wp_error($targetUser)) {
            return $targetUser;
        }

        $year  = (int) $request->get_param('year');
        $month = (int) $request->get_param('month');

        try {
            $meta = $this->service->getMonthMeta($targetUser, $year, $month);

            if ('locked' !== ($meta['status'] ?? 'draft')) {
                return $this->validationError(__('Only locked timesheets can be unlocked.', 'timesuite'));
            }

            $timesheet = $this->service->reopenLockedMonth($targetUser, $year, $month, $currentUser);
        } catch (ValidationException $exception) {
            return $this->validationError($exception);
        } catch (PersistenceException $exception) {
            // As above: the reopen is transactional, so a failed write leaves
            // the month exactly as it was.
            return $this->persistenceError(
                $exception,
                'unlock month',
                ['user_id' => $targetUser, 'year' => $year, 'month' => $month]
            );
        }

        $this->approvalLogRepository->log(
            'month_reopened',
            $targetUser,
            $currentUser,
            ['year' => $year, 'month' => $month, 'source' => 'hr_unlock']
        );

        return new WP_REST_Response(
            [
                'unlocked' => true,
                'timesheet' => [
                    'user_id' => $targetUser,
                    'year' => $year,
                    'month' => $month,
                    'status' => $timesheet['status'] ?? 'draft',
                ],
            ],
            200
        );
    }

    private function resolveTargetUserId(WP_REST_Request $request): WP_Error|int
    {
        $userId = $request->get_param('user_id');
        $target = $userId ? (int) $userId : 0;

        if ($target <= 0) {
            return $this->validationError(__('Unknown target user.', 'timesuite'));
        }

        $user = get_user_by('id', $target);

        if (! $user) {
            return $this->notFoundError(__('User not found.', 'timesuite'));
        }

        return $target;
    }

    private function approvalAccessError(int $currentUser, int $targetUser): WP_Error
    {
        if ($currentUser === $targetUser) {
            return $this->forbiddenError(
                __('You cannot approve your own month. Please ask your manager or another HR/Technical Admin to approve it for you.', 'timesuite')
            );
        }

        if ($this->authService->canApproveTimesheets($currentUser)) {
            return $this->forbiddenError(
                __('You can only approve employees assigned to you. Ask HR/Technical Admin to check the Org Directory manager assignment.', 'timesuite')
            );
        }

        return $this->forbiddenError(
            __('You do not have permission to approve or deny timesheets.', 'timesuite')
        );
    }

    private function submittedRequiredMessage(string $status, string $nextStep): string
    {
        if ('locked' === $status) {
            return __('This month is currently Locked. Unlock it before changing approval decisions.', 'timesuite');
        }

        if ('denied' === $status) {
            return sprintf(
                __('This month is currently %s. The employee must update and submit it again before %s.', 'timesuite'),
                $this->statusLabel($status),
                $nextStep
            );
        }

        return sprintf(
            __('This month is currently %s. The employee must submit it before %s.', 'timesuite'),
            $this->statusLabel($status),
            $nextStep
        );
    }

    private function lockRequiresSubmittedOrApprovedMessage(string $status): string
    {
        if ('locked' === $status) {
            return __('This month is already Locked.', 'timesuite');
        }

        return sprintf(
            __('This month is currently %s. It must be submitted or approved before it can be locked.', 'timesuite'),
            $this->statusLabel($status)
        );
    }

    private function statusLabel(string $status): string
    {
        return match ($status) {
            'submitted' => __('Submitted', 'timesuite'),
            'approved' => __('Approved', 'timesuite'),
            'denied' => __('Denied', 'timesuite'),
            'locked' => __('Locked', 'timesuite'),
            'draft', '' => __('Draft', 'timesuite'),
            'not_started' => __('Not started', 'timesuite'),
            default => ucwords(str_replace('_', ' ', $status)),
        };
    }

    /**
     * Permission callback for viewing approvals.
     *
     * @return bool|WP_Error
     */
    public function checkViewApprovalsPermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to view approvals.', 'timesuite'),
                ['status' => 401]
            );
        }

        $currentUser = get_current_user_id();

        // Use AuthorizationService for consistent permission checks
        if ($this->authService->canViewTeamTimesheets($currentUser)) {
            return true;
        }

        return new WP_Error(
            'timesuite_forbidden',
            __('You do not have permission to view approvals.', 'timesuite'),
            ['status' => 403]
        );
    }

    /**
     * Permission callback for approval actions.
     *
     * @return bool|WP_Error
     */
    public function checkApprovePermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to approve timesheets.', 'timesuite'),
                ['status' => 401]
            );
        }

        $currentUser = get_current_user_id();

        // Use AuthorizationService for consistent permission checks
        if ($this->authService->canApproveTimesheets($currentUser)) {
            return true;
        }

        return new WP_Error(
            'timesuite_forbidden',
            __('You do not have permission to approve or deny timesheets.', 'timesuite'),
            ['status' => 403]
        );
    }

    /**
     * Permission callback for logged-in users.
     *
     * @return bool|WP_Error
     */
    public function checkLoggedInPermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to perform this action.', 'timesuite'),
                ['status' => 401]
            );
        }

        return true;
    }

    /**
     * Permission callback for lock/unlock actions.
     *
     * Only HR admins and tech admins can lock/unlock timesheets.
     *
     * @return bool|WP_Error
     */
    public function checkLockPermission(): bool|WP_Error
    {
        if (! is_user_logged_in()) {
            return new WP_Error(
                'timesuite_unauthorized',
                __('You must be logged in to lock timesheets.', 'timesuite'),
                ['status' => 401]
            );
        }

        $currentUser = get_current_user_id();

        // Only HR admins and tech admins can lock/unlock
        if ($this->authService->hasOrgManagementPowers($currentUser)) {
            return true;
        }

        return new WP_Error(
            'timesuite_forbidden',
            __('You do not have permission to lock or unlock timesheets.', 'timesuite'),
            ['status' => 403]
        );
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function approvalArgs(): array
    {
        return [
            'year' => [
                'required'          => true,
                'validate_callback' => static fn ($value): bool => (int) $value >= 2000,
            ],
            'month' => [
                'required'          => true,
                'validate_callback' => static fn ($value): bool => (int) $value >= 1 && (int) $value <= 12,
            ],
        ];
    }

    /**
     * @param array<string, mixed> $request
     *
     * @return array<string, mixed>
     */
    private function formatReeditRequest(array $request): array
    {
        return [
            'id' => (int) ($request['id'] ?? 0),
            'status' => (string) ($request['status'] ?? ''),
            'employee_reason' => (string) ($request['employee_reason'] ?? ''),
            'manager_reason' => $request['manager_reason'] ?? null,
            'requested_at' => $request['requested_at'] ?? null,
            'decided_at' => $request['decided_at'] ?? null,
            'requested_by' => isset($request['requested_by']) ? (int) $request['requested_by'] : null,
            'decided_by' => isset($request['decided_by']) ? (int) $request['decided_by'] : null,
        ];
    }

    private function resolveReeditRequestId(WP_REST_Request $request): WP_Error|int
    {
        $requestId = (int) ($request->get_param('request_id') ?? $request->get_param('id'));

        if ($requestId <= 0) {
            return $this->validationError(__('Unknown re-edit request.', 'timesuite'));
        }

        return $requestId;
    }

    private function sendReeditRequestNotification(int $employeeId, int $year, int $month, string $reason): void
    {
        if (! $this->emailNotifier || ! $this->settings || ! $this->settings->areNotificationsEnabled()) {
            return;
        }

        $mapping = $this->orgService->getMappingForUser($employeeId);
        $managerId = (int) ($mapping['manager_id'] ?? 0);

        if ($managerId <= 0) {
            return;
        }

        $this->emailNotifier->notifyReeditRequest($employeeId, $managerId, $year, $month, $reason);
    }

    private function sendReeditDecisionNotification(
        int $employeeId,
        int $managerId,
        int $year,
        int $month,
        bool $approved,
        string $managerReason
    ): void {
        if (! $this->emailNotifier || ! $this->settings || ! $this->settings->areNotificationsEnabled()) {
            return;
        }

        $this->emailNotifier->notifyReeditDecision(
            $employeeId,
            $managerId,
            $year,
            $month,
            $approved,
            $managerReason
        );
    }
}
