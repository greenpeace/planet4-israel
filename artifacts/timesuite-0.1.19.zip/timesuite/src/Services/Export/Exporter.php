<?php

declare(strict_types=1);

namespace Timesuite\Services\Export;

use Generator;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use RuntimeException;
use Timesuite\Core\Settings;
use Timesuite\Domain\Shared\Exceptions\ValidationException;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use wpdb;
use const ARRAY_A;

class Exporter
{
    private const FORMAT_CSV = 'csv';
    private const FORMAT_XLSX = 'xlsx';

    public const VERSION_V1 = 'v1';
    public const VERSION_V2 = 'v2';

    /**
     * Batch size for chunked database queries.
     * Keeps memory usage reasonable for large datasets.
     */
    private const BATCH_SIZE = 1000;

    /**
     * Maximum date range allowed (in days) to prevent abuse.
     */
    private const MAX_DATE_RANGE_DAYS = 366;

    /**
     * Export headers by version.
     * V2 adds additional metadata fields.
     *
     * @var array<string, string[]>
     */
    private const HEADERS_BY_VERSION = [
        self::VERSION_V1 => [
            'employee_email',
            'employee_name',
            'department',
            'period_start',
            'period_end',
            'total_hours',
            'total_days',
            'overtime_hours',
            'comments',
        ],
        self::VERSION_V2 => [
            'employee_email',
            'employee_name',
            'employee_id',
            'department',
            'manager_email',
            'period_start',
            'period_end',
            'total_hours',
            'total_days',
            'overtime_hours',
            'regular_hours',
            'status',
            'submitted_at',
            'approved_at',
            'comments',
            'export_version',
            'exported_at',
        ],
    ];

    // Keep for backward compatibility
    private const HEADERS = self::HEADERS_BY_VERSION[self::VERSION_V1];

    public function __construct(
        private wpdb $wpdb,
        private Settings $settings,
        private ApprovalLogRepository $logRepository
    ) {
    }

    /**
     * @param array<string, string|null> $filters
     *
     * @return array{filename: string, content_type: string, body: string, version: string}
     */
    public function generate(array $filters, string $format, int $actorId, ?string $version = null): array
    {
        $format  = strtolower($format);
        $version = $version ?? $this->settings->getExportVersion();

        $this->validateFilters($filters);
        $this->validateFormat($format);
        $this->validateVersion($version);

        $headers = self::HEADERS_BY_VERSION[$version] ?? self::HEADERS;

        // Use streaming for CSV, batched for XLSX (XLSX needs all data for PhpSpreadsheet)
        if (self::FORMAT_CSV === $format) {
            [$body, $rowCount] = $this->buildCsvStreaming($filters, $headers, $version);
        } else {
            [$body, $rowCount] = $this->buildXlsxBatched($filters, $headers, $version);
        }

        $contentType = self::FORMAT_CSV === $format
            ? 'text/csv; charset=utf-8'
            : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

        $filename = sprintf('timesuite_export_%s_%s.%s', $version, gmdate('Ymd_His'), $format);

        $this->logRepository->logExport($actorId, $filters, $format, $rowCount);

        return [
            'filename'     => $filename,
            'content_type' => $contentType,
            'body'         => $body,
            'version'      => $version,
        ];
    }

    /**
     * Validate export filters.
     *
     * @param array<string, string|null> $filters
     *
     * @throws ValidationException
     */
    private function validateFilters(array $filters): void
    {
        // Validate date formats
        if (! empty($filters['from'])) {
            $from = $this->parseDate($filters['from']);

            if (! $from) {
                throw new ValidationException(__('Invalid "from" date format. Use YYYY-MM-DD.', 'timesuite'));
            }
        }

        if (! empty($filters['to'])) {
            $to = $this->parseDate($filters['to']);

            if (! $to) {
                throw new ValidationException(__('Invalid "to" date format. Use YYYY-MM-DD.', 'timesuite'));
            }
        }

        // Validate date range
        if (! empty($filters['from']) && ! empty($filters['to'])) {
            $from = new \DateTime($filters['from']);
            $to   = new \DateTime($filters['to']);

            if ($from > $to) {
                throw new ValidationException(__('The "from" date must be before "to" date.', 'timesuite'));
            }

            $diff = $from->diff($to);

            if ($diff->days > self::MAX_DATE_RANGE_DAYS) {
                throw new ValidationException(
                    sprintf(
                        /* translators: %d: maximum allowed days */
                        __('Date range cannot exceed %d days.', 'timesuite'),
                        self::MAX_DATE_RANGE_DAYS
                    )
                );
            }
        }

        // Sanitize text filters
        if (! empty($filters['dept']) && strlen($filters['dept']) > 255) {
            throw new ValidationException(__('Department filter is too long.', 'timesuite'));
        }

    }

    /**
     * Validate export format.
     *
     * @throws ValidationException
     */
    private function validateFormat(string $format): void
    {
        if (! in_array($format, [self::FORMAT_CSV, self::FORMAT_XLSX], true)) {
            throw new ValidationException(__('Unsupported export format. Use "csv" or "xlsx".', 'timesuite'));
        }
    }

    /**
     * Validate export version.
     *
     * @throws ValidationException
     */
    private function validateVersion(string $version): void
    {
        if (! in_array($version, [self::VERSION_V1, self::VERSION_V2], true)) {
            throw new ValidationException(__('Unsupported export version. Use "v1" or "v2".', 'timesuite'));
        }
    }

    /**
     * Parse a date string in Y-m-d format.
     */
    private function parseDate(string $date): ?string
    {
        $dt = \DateTime::createFromFormat('Y-m-d', $date);

        if (! $dt || $dt->format('Y-m-d') !== $date) {
            return null;
        }

        return $date;
    }

    /**
     * Build CSV using streaming to minimize memory usage.
     *
     * @param array<string, string|null> $filters
     * @param string[]                   $headers
     *
     * @return array{0: string, 1: int}
     */
    private function buildCsvStreaming(array $filters, array $headers, string $version): array
    {
        $stream = fopen('php://temp', 'r+');

        if (! $stream) {
            throw new RuntimeException('Unable to create CSV stream.');
        }

        fputcsv($stream, $headers, ',', '"', '');

        $rowCount = 0;

        foreach ($this->fetchRowsInBatches($filters, $version) as $row) {
            $line = [];

            foreach ($headers as $column) {
                $line[] = $row[$column] ?? '';
            }

            fputcsv($stream, $line, ',', '"', '');
            ++$rowCount;

            // Periodically flush to reduce memory pressure
            if ($rowCount % 500 === 0) {
                fflush($stream);
            }
        }

        rewind($stream);

        return [stream_get_contents($stream) ?: '', $rowCount];
    }

    /**
     * Build XLSX with batched data loading.
     *
     * @param array<string, string|null> $filters
     * @param string[]                   $headers
     *
     * @return array{0: string, 1: int}
     */
    private function buildXlsxBatched(array $filters, array $headers, string $version): array
    {
        if (! class_exists(Spreadsheet::class)) {
            throw new RuntimeException(
                __('PhpSpreadsheet is required for XLSX exports. Please run composer install.', 'timesuite')
            );
        }

        $spreadsheet = new Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();

        // Write headers
        foreach ($headers as $index => $header) {
            $columnLetter = Coordinate::stringFromColumnIndex($index + 1);
            $sheet->setCellValue($columnLetter . '1', $header);
        }

        $excelRow = 2;
        $rowCount = 0;

        foreach ($this->fetchRowsInBatches($filters, $version) as $row) {
            foreach ($headers as $index => $header) {
                $columnLetter = Coordinate::stringFromColumnIndex($index + 1);
                $sheet->setCellValue($columnLetter . $excelRow, $row[$header] ?? '');
            }

            ++$excelRow;
            ++$rowCount;
        }

        // Clear caches to free memory
        $spreadsheet->garbageCollect();

        $writer = new Xlsx($spreadsheet);
        $stream = fopen('php://temp', 'r+');

        if (! $stream) {
            throw new RuntimeException('Unable to create XLSX stream.');
        }

        $writer->save($stream);
        rewind($stream);

        // Disconnect worksheets to free memory
        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);

        return [stream_get_contents($stream) ?: '', $rowCount];
    }

    /**
     * Fetch and aggregate rows in batches using a generator.
     * This keeps memory usage constant regardless of dataset size.
     *
     * Now uses the new monthly timesheet tables.
     *
     * @param array<string, string|null> $filters
     *
     * @return Generator<int, array<string, string|int|float>>
     */
    private function fetchRowsInBatches(array $filters, string $version = self::VERSION_V1): Generator
    {
        $offset = 0;
        $groups = [];
        $workWeekCache = [];
        $dailyMinutes = (int) round($this->settings->getDailyHours() * 60);

        do {
            $records = $this->fetchBatch($filters, $offset, self::BATCH_SIZE);
            $recordCount = count($records);

            foreach ($records as $record) {
                $key = $record['timesheet_id'] . ':' . $record['user_id'];

                if (! isset($groups[$key])) {
                    // Build period start/end from year/month
                    $year = (int) $record['year'];
                    $month = (int) $record['month'];
                    $periodStart = sprintf('%04d-%02d-01', $year, $month);
                    $periodEnd = gmdate('Y-m-t', strtotime($periodStart));

                    $groups[$key] = [
                        'user_id'        => (int) $record['user_id'],
                        'employee_email' => (string) $record['user_email'],
                        'employee_name'  => (string) $record['employee_name'],
                        'department'     => (string) ($record['department'] ?? ''),
                        'period_start'   => $periodStart,
                        'period_end'     => $periodEnd,
                        'total_minutes'  => 0,
                        'days'           => [],
                        'minutes_by_date'=> [],
                        'notes'          => [],
                        'status'         => (string) ($record['status'] ?? ''),
                        'submitted_at'   => (string) ($record['submitted_at'] ?? ''),
                        'approved_at'    => (string) ($record['approved_at'] ?? ''),
                        'manager_email'  => (string) ($record['manager_email'] ?? ''),
                    ];
                }

                // Calculate duration from hours or default to daily hours for working days
                $hours = $record['hours'] !== null ? (float) $record['hours'] : 0;
                $type = (string) $record['type'];

                // Only count working/half/holiday/overtime days toward hours
                if ($type === 'working_day') {
                    $hours = $this->settings->getDailyHours();
                } elseif ($type === 'overtime') {
                    $hours = $this->settings->getDailyHours() + $hours;
                } elseif (in_array($type, ['half_working', 'half_holiday'], true) && $hours <= 0) {
                    $hours = $this->settings->getDailyHours() / 2;
                }

                $durationMinutes = (int) round($hours * 60);
                $groups[$key]['total_minutes'] += $durationMinutes;
                $groups[$key]['days'][(string) $record['work_date']] = true;
                $dateKey = (string) $record['work_date'];
                $groups[$key]['minutes_by_date'][$dateKey] = ($groups[$key]['minutes_by_date'][$dateKey] ?? 0)
                    + $durationMinutes;

                if (! empty($record['notes'])) {
                    $groups[$key]['notes'][] = (string) $record['notes'];
                }
            }

            $offset += self::BATCH_SIZE;

            // Free memory from processed records
            unset($records);
        } while ($recordCount === self::BATCH_SIZE);

        // Yield aggregated rows
        $exportedAt = gmdate('Y-m-d H:i:s');

        foreach ($groups as $group) {
            $totalDays    = count($group['days']);
            $totalMinutes = (int) $group['total_minutes'];
            $totalHours   = round($totalMinutes / 60, 2);
            $comments     = implode('; ', array_unique($group['notes']));
            $userId       = (int) ($group['user_id'] ?? 0);

            if ($userId > 0 && ! isset($workWeekCache[$userId])) {
                $stored = get_user_meta($userId, 'timesuite_work_week', true);
                $workWeekCache[$userId] = is_array($stored) && ! empty($stored)
                    ? $stored
                    : $this->settings->getWorkWeek();
            }

            $workWeek = $workWeekCache[$userId] ?? $this->settings->getWorkWeek();
            $overtimeMinutes = 0;

            foreach ($group['minutes_by_date'] as $date => $minutes) {
                $dayCode = gmdate('D', strtotime($date . ' UTC'));
                $isWorking = in_array($dayCode, $workWeek, true);
                $overtimeMinutes += $isWorking ? max(0, $minutes - $dailyMinutes) : $minutes;
            }

            $overtimeHours = round($overtimeMinutes / 60, 2);
            $regularHours  = max(0, $totalHours - $overtimeHours);

            $row = [
                'employee_email' => $group['employee_email'],
                'employee_name'  => $group['employee_name'],
                'department'     => $group['department'],
                'period_start'   => $group['period_start'],
                'period_end'     => $group['period_end'],
                'total_hours'    => $totalHours,
                'total_days'     => $totalDays,
                'overtime_hours' => $overtimeHours,
                'comments'       => $comments,
            ];

            // Add v2 fields
            if (self::VERSION_V2 === $version) {
                $row['employee_id']    = $userId;
                $row['manager_email']  = $group['manager_email'] ?? '';
                $row['regular_hours']  = $regularHours;
                $row['status']         = $group['status'] ?? '';
                $row['submitted_at']   = $group['submitted_at'] ?? '';
                $row['approved_at']    = $group['approved_at'] ?? '';
                $row['export_version'] = $version;
                $row['exported_at']    = $exportedAt;
            }

            yield $row;
        }
    }

    /**
     * Fetch a batch of records from the database.
     *
     * Now uses the new monthly timesheet tables (timesuite_monthly_timesheets and
     * timesuite_monthly_entries) instead of the legacy tables.
     *
     * @param array<string, string|null> $filters
     *
     * @return array<int, array<string, mixed>>
     */
    private function fetchBatch(array $filters, int $offset, int $limit): array
    {
        $timesheetsTable = $this->wpdb->prefix . 'timesuite_monthly_timesheets';
        $entriesTable    = $this->wpdb->prefix . 'timesuite_monthly_entries';
        $usersTable      = $this->wpdb->users ?? $this->wpdb->prefix . 'users';
        $userMetaTable   = $this->wpdb->usermeta ?? $this->wpdb->prefix . 'usermeta';
        $orgTable        = $this->wpdb->prefix . 'timesuite_users_org';

        $conditions = [];
        $values     = [];

        if (! empty($filters['from'])) {
            $conditions[] = 'me.work_date >= %s';
            $values[]     = $filters['from'];
        }

        if (! empty($filters['to'])) {
            $conditions[] = 'me.work_date <= %s';
            $values[]     = $filters['to'];
        }

        if (! empty($filters['dept'])) {
            $conditions[] = 'dept.meta_value = %s';
            $values[]     = $filters['dept'];
        }

        $where = '';

        if (! empty($conditions)) {
            $where = ' AND ' . implode(' AND ', $conditions);
        }

        $values[] = $limit;
        $values[] = $offset;

        $sql = "
            SELECT
                me.user_id,
                mt.id AS timesheet_id,
                mt.year,
                mt.month,
                mt.status,
                mt.submitted_at,
                mt.approved_at,
                u.user_email,
                COALESCE(NULLIF(u.display_name, ''), u.user_login) AS employee_name,
                dept.meta_value AS department,
                me.work_date,
                me.type,
                me.hours,
                me.notes,
                mgr.user_email AS manager_email
            FROM {$entriesTable} me
            INNER JOIN {$timesheetsTable} mt
                ON mt.id = me.timesheet_id
            INNER JOIN {$usersTable} u
                ON u.ID = me.user_id
            LEFT JOIN {$userMetaTable} dept
                ON dept.user_id = me.user_id AND dept.meta_key = 'timesuite_department'
            LEFT JOIN {$orgTable} org
                ON org.user_id = me.user_id AND org.removed_at IS NULL
            LEFT JOIN {$usersTable} mgr
                ON mgr.ID = org.org_unit_id
            WHERE mt.status IN ('submitted', 'approved', 'locked')
              AND me.type IN ('working_day', 'half_working', 'half_holiday', 'overtime')
            {$where}
            ORDER BY mt.year ASC, mt.month ASC, me.user_id ASC, me.work_date ASC
            LIMIT %d OFFSET %d
        ";

        $preparedSql = $this->wpdb->prepare($sql, $values);

        return $this->wpdb->get_results($preparedSql, ARRAY_A) ?? [];
    }
}
