<?php

declare(strict_types=1);

namespace Timesuite\Services\Template;

use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\DataValidation;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use RuntimeException;

class ExcelBuilder
{
    /**
     * Build the downloadable offline timesheet template.
     */
    public function buildTimesheetTemplate(): string
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Timesheet');

        $headers = [
            'A1' => 'employee_email',
            'B1' => 'work_date',
            'C1' => 'start_time',
            'D1' => 'end_time',
            'E1' => 'break_minutes',
            'F1' => 'project',
            'G1' => 'notes',
        ];

        foreach ($headers as $cell => $label) {
            $sheet->setCellValueExplicit($cell, $label, DataType::TYPE_STRING);
        }

        $sheet->freezePane('A2');

        $headerStyle = $sheet->getStyle('A1:G1');
        $headerStyle->getFont()->setBold(true);
        $headerStyle->getFill()
            ->setFillType(Fill::FILL_SOLID)
            ->getStartColor()
            ->setRGB('E5E5E5');

        $exampleRow = [
            'A2' => 'employee@example.com',
            'B2' => '2025-01-01',
            'C2' => '09:00',
            'D2' => '17:00',
            'E2' => 30,
            'F2' => 'Project X',
            'G2' => 'Worked on feature ABC',
        ];

        foreach ($exampleRow as $cell => $value) {
            $sheet->setCellValue($cell, $value);
        }

        $this->applyDateValidation($sheet, 'B2:B1000');
        $this->applyTimeValidation($sheet, 'C2:C1000');
        $this->applyTimeValidation($sheet, 'D2:D1000');
        $this->applyWholeNumberValidation($sheet, 'E2:E1000');

        foreach (range('A', 'G') as $column) {
            $sheet->getColumnDimension($column)->setAutoSize(true);
        }

        $stream = fopen('php://temp', 'r+');

        if (! $stream) {
            throw new RuntimeException('Unable to create template stream.');
        }

        $writer = new Xlsx($spreadsheet);
        $writer->save($stream);

        rewind($stream);

        return stream_get_contents($stream) ?: '';
    }

    private function applyDateValidation(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $range): void
    {
        $validation = $sheet->getCell('B2')->getDataValidation();
        $validation->setType(DataValidation::TYPE_DATE);
        $validation->setErrorStyle(DataValidation::STYLE_STOP);
        $validation->setAllowBlank(true);
        $validation->setShowInputMessage(true);
        $validation->setShowErrorMessage(true);
        $validation->setOperator(DataValidation::OPERATOR_BETWEEN);
        $validation->setError(__('Please enter a valid date (YYYY-MM-DD).', 'timesuite'));
        $validation->setPrompt(__('Use format YYYY-MM-DD.', 'timesuite'));
        $validation->setFormula1('DATE(2000,1,1)');
        $validation->setFormula2('DATE(2100,12,31)');

        $this->cloneValidationToRange($sheet, $range, $validation);
    }

    private function applyTimeValidation(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $range): void
    {
        $validation = $sheet->getCell('C2')->getDataValidation();
        $validation->setType(DataValidation::TYPE_TIME);
        $validation->setErrorStyle(DataValidation::STYLE_STOP);
        $validation->setAllowBlank(true);
        $validation->setShowInputMessage(true);
        $validation->setShowErrorMessage(true);
        $validation->setOperator(DataValidation::OPERATOR_BETWEEN);
        $validation->setError(__('Please enter a valid time (HH:MM).', 'timesuite'));
        $validation->setPrompt(__('Use 24h time HH:MM.', 'timesuite'));
        $validation->setFormula1('TIME(0,0,0)');
        $validation->setFormula2('TIME(23,59,0)');

        $this->cloneValidationToRange($sheet, $range, $validation);
    }

    private function applyWholeNumberValidation(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $range): void
    {
        $validation = $sheet->getCell('E2')->getDataValidation();
        $validation->setType(DataValidation::TYPE_WHOLE);
        $validation->setErrorStyle(DataValidation::STYLE_STOP);
        $validation->setAllowBlank(true);
        $validation->setShowInputMessage(true);
        $validation->setShowErrorMessage(true);
        $validation->setOperator(DataValidation::OPERATOR_GREATERTHANOREQUAL);
        $validation->setError(__('Break minutes must be zero or greater.', 'timesuite'));
        $validation->setPrompt(__('Enter minutes as a whole number.', 'timesuite'));
        $validation->setFormula1('0');

        $this->cloneValidationToRange($sheet, $range, $validation);
    }

    private function cloneValidationToRange(
        \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet,
        string $range,
        DataValidation $validation
    ): void {
        [$startCell, $endCell] = explode(':', $range);
        [$startColumn, $startRow] = $this->splitCell($startCell);
        [$endColumn, $endRow]     = $this->splitCell($endCell);

        for ($row = (int) $startRow; $row <= (int) $endRow; ++$row) {
            for ($column = $startColumn; $column <= $endColumn; $column = $this->incrementColumn($column)) {
                $target = $sheet->getCell($column . (string) $row)->getDataValidation();
                $target->setType($validation->getType());
                $target->setErrorStyle($validation->getErrorStyle());
                $target->setAllowBlank($validation->getAllowBlank());
                $target->setShowInputMessage($validation->getShowInputMessage());
                $target->setShowErrorMessage($validation->getShowErrorMessage());
                $target->setError($validation->getError());
                $target->setPrompt($validation->getPrompt());
                $target->setFormula1($validation->getFormula1());
                $target->setFormula2($validation->getFormula2());
            }
        }
    }

    /**
     * @return array{0: string, 1: string}
     */
    private function splitCell(string $cell): array
    {
        $cell = strtoupper($cell);
        $column = '';
        $row = '';

        for ($i = 0, $len = strlen($cell); $i < $len; ++$i) {
            $char = $cell[$i];

            if (ctype_alpha($char)) {
                $column .= $char;
            } else {
                $row .= $char;
            }
        }

        return [$column, $row];
    }

    private function incrementColumn(string $column): string
    {
        $letters = str_split($column);
        $index = count($letters) - 1;

        while ($index >= 0) {
            if ('Z' === $letters[$index]) {
                $letters[$index] = 'A';
                --$index;
            } else {
                $letters[$index] = chr(ord($letters[$index]) + 1);

                return implode('', $letters);
            }
        }

        return 'A' . implode('', $letters);
    }
}
