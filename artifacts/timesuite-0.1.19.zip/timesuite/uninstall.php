<?php
/**
 * Timesuite Uninstall Script
 *
 * This file runs when the plugin is DELETED (not just deactivated).
 * It removes all plugin data from the database.
 *
 * WordPress behavior:
 * - Deactivate: Plugin stops running, data preserved (can reactivate)
 * - Delete: This file runs, all data removed permanently
 *
 * @package Timesuite
 */

// Security: Only run if called by WordPress uninstall process
if (! defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/**
 * Clean up all Timesuite data.
 *
 * This is destructive and cannot be undone!
 */
function timesuite_uninstall_cleanup(): void {
    global $wpdb;

    // 1. Remove all user meta (Timesuite roles and settings)
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
            'timesuite_%'
        )
    );

    // 2. Remove custom WordPress roles
    $roles_to_remove = [
        'timesuite_employee',
        'timesuite_manager',
        'timesuite_hr',
        'timesuite_tech_admin',
    ];

    foreach ($roles_to_remove as $role) {
        remove_role($role);
    }

    // 3. Remove Timesuite capabilities from administrator role
    $admin_role = get_role('administrator');
    if ($admin_role) {
        $caps_to_remove = [
            'timesuite.timesheet.create',
            'timesuite.timesheet.edit_own',
            'timesuite.timesheet.submit_own',
            'timesuite.timesheet.view_own',
            'timesuite.timesheet.bulk_import_own',
            'timesuite.timesheet.view_team',
            'timesuite.timesheet.approve_team',
            'timesuite.timesheet.comment_team',
            'timesuite.timesheet.view_all',
            'timesuite.period.lock',
            'timesuite.export.run',
            'timesuite.export.sensitive',
            'timesuite.org.view',
            'timesuite.org.edit',
            'timesuite.org.import',
            'timesuite.org.delete',
            'timesuite.audit.view',
            'timesuite.settings.manage',
            'timesuite.settings.view',
            'timesuite.system.view',
        ];

        foreach ($caps_to_remove as $cap) {
            $admin_role->remove_cap($cap);
        }
    }

    // 4. Drop custom database tables
    // Note: Order matters due to foreign key constraints - drop child tables first
    $tables_to_drop = [
        // Monthly timesheet tables (newer structure)
        $wpdb->prefix . 'timesuite_monthly_entries',
        $wpdb->prefix . 'timesuite_reedit_requests',
        $wpdb->prefix . 'timesuite_monthly_timesheets',
        // Legacy per-entry tables
        $wpdb->prefix . 'timesuite_time_entries',
        $wpdb->prefix . 'timesuite_periods',
        // Comp time / vacation tracking
        $wpdb->prefix . 'timesuite_comp_time_ledger',
        // Audit and logging
        $wpdb->prefix . 'timesuite_approvals_log',
        // Organization structure
        $wpdb->prefix . 'timesuite_org_mappings',
        $wpdb->prefix . 'timesuite_users_org',
        // Migration tracking
        $wpdb->prefix . 'timesuite_migrations',
        // Legacy table names (in case of older installations)
        $wpdb->prefix . 'timesuite_timesheet_days',
        $wpdb->prefix . 'timesuite_timesheet_months',
    ];

    foreach ($tables_to_drop as $table) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
        $wpdb->query("DROP TABLE IF EXISTS {$table}");
    }

    // 5. Remove plugin options
    $options_to_delete = [
        'timesuite_settings',
        'timesuite_version',
        'timesuite_db_version',
    ];

    foreach ($options_to_delete as $option) {
        delete_option($option);
    }

    // 6. Remove any scheduled cron jobs
    $cron_hooks = [
        'timesuite_audit_cleanup',
    ];

    foreach ($cron_hooks as $hook) {
        $timestamp = wp_next_scheduled($hook);
        if ($timestamp) {
            wp_unschedule_event($timestamp, $hook);
        }
        // Also clear all scheduled instances
        wp_unschedule_hook($hook);
    }

    // 7. Clear any transients
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            '_transient_timesuite_%',
            '_transient_timeout_timesuite_%'
        )
    );

    // 8. Clear object cache if available
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
}

// Run cleanup
timesuite_uninstall_cleanup();
