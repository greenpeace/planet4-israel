# Changelog

All notable changes to Timesuite will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.20] - 2026-09-17

### Added
- **Payroll matrix: a `Worked Hours` summary row**, between `Payable Hours` and `Worked Days`. It totals the hours actually worked — scheduled hours on a worked day, the worked half of a half day, and overtime — and excludes every paid-but-not-worked hour (vacation, sick, time-in-lieu, other paid leave, and the unworked part of a holiday), which is what separates it from `Payable Hours`. Like the other summary rows it is written as a live formula (`=ROUND(SUM(<worked column>),2)`) over the employee's Worked column, so it follows any edit HR makes to a day.

### Fixed
- **The payroll matrix hid work done on a holiday, and its summary totals counted it anyway.** Holiday days are not scheduled work days, so the grid rendered them as `Non-working day` with empty cells, while the summary accumulator credited the hours — a half holiday with 4.5 hours worked appeared nowhere in the grid but sat inside `Payable Hours` and `Worked Days`. The file contradicted itself: on a real February 2026 export an employee's `Payable Hours` cell showed a cached 171 over a grid whose own formula recomputes to 135, so the number changed the moment Excel recalculated or anyone edited a cell. Holiday and half-holiday days now render their `HOL`/`HOL_HALF` type and the hours actually worked, and leave types the summary skips on an unscheduled day stay hidden, so every summary formula reproduces its own cached value.
- **A half holiday on a date with no holiday range behind it was paid as a full day in the grid and as nothing at all in the totals.** The cell was labelled `HOL_HALF`, which is what makes the `Payable Hours` formula credit the unworked half — but the summary skipped the day outright, so the employee's worked hours vanished from every total. There is no holiday to pay for the rest of that day, so it is now labelled `WORK_HALF` and both the grid and the totals pay exactly the hours worked. A half holiday that does sit inside a holiday range is unchanged.

## [0.1.19] - 2026-09-03

### Fixed
- **A newly created employee's initial Time-in-Lieu balance was silently discarded.** The balance is saved on a second request keyed by user id, and for a create that id only exists in the response — the form still had none. The profile saved, a success message appeared, and the entered hours simply never existed. The id now comes from the create response.
- **Time-in-Lieu credits and debits after the first one in a month were silently discarded.** The ledger's unique key was `(user_id, source_type, source_key, direction)`, but every monthly credit in a month shares all four columns and differs only by work date, so the database rejected each additional row. `CompTimeLedgerRepository::insert()` never checked the result of `wpdb::query()`, so the rejection produced no error anywhere: an employee with 9h of overtime on one date and 4.5h on another kept only the 9h, and her balance simply looked smaller than it should. The key now includes `work_date`, so one row per date is legal.
- Ledger writes no longer fail silently. Every insert and delete checks its result and raises a `PersistenceException` on failure, which aborts the surrounding submission transaction instead of leaving a month marked submitted with an incomplete ledger. Duplicate-key failures are reported as such, and unrelated database errors are not misreported as duplicates.
- Timesheet header and entry writes now throw on failure too. They previously ignored a rejected write, which meant any transaction wrapped around them could never reach its rollback.
- **Reopening a month to draft is now atomic.** Clearing time-in-lieu debits, clearing credits and persisting the draft header happen in one transaction. A failure part-way through previously left the month half-reset — debits gone, credits intact, status still submitted — a state no code path could produce deliberately.
- A failed database write now surfaces as a structured HTTP 500 with a stable `timesuite_persistence_failed` code at **every** affected boundary: timesheet submission, all five Admin Rescue actions, all eleven manager approval endpoints (approve/deny/reset day, approve/deny/reset all, approve/deny month, final review, lock, unlock), re-edit approval, and the manual Time-in-Lieu balance change. The driver's message (table, key and column names) goes to the server log only. Failed submissions are audit-logged alongside validation failures.
- **A month's header and its days are now written as one transaction.** `upsertHeader()` followed by a loop of entry writes could previously persist a header with only some of its days. Transactions are depth-counted, so a workflow that already owns one (a submission applying comp-time, a reopen clearing it) is joined rather than a second `START TRANSACTION` being issued — which in MySQL would have implicitly committed the first and silently made the outer workflow non-atomic.
- **Approving a re-edit request is now one workflow.** It previously marked the request approved and committed that, then reopened the month; if the reopen failed, the employee was left unable to edit a month their manager believed had been reopened. Both now succeed or fail together.
- **Reads no longer fatal when legacy materialization fails.** Loading a legacy-only month materializes it into the canonical table as a side effect. That write can now fail, and it sits underneath read paths as well as write ones — so a failure is logged and the read is answered from the legacy copy rather than turning a timesheet GET into a fatal. Writes still fail loudly, because they go on to persist their own changes.

### Changed
- **Manual Time-in-Lieu balance adjustments moved to their own endpoint** (`POST /directory/users/comp-time-balance`). Bundled into the directory save, the ledger write ran after the profile fields had already been written, so reporting "nothing was changed" on failure was simply untrue. Alone in a request, it is the whole operation and the claim holds. The endpoint verifies the target is an **active Timesuite employee** before writing — existing in WordPress is not the same thing, and a ledger row is keyed only by `user_id`, so an adjustment against a subscriber, a service account, or a retired employee would be accepted and then sit in the ledger with no timesheet behind it.
- The Org Directory reports **partial success honestly**: if the profile saves but the balance write fails, it says so and keeps the entered details, instead of implying the whole save failed and inviting someone to re-enter (or, on a create, re-add) the employee.
- Transaction control checks its own results. A failed `START TRANSACTION` now prevents the work from running at all rather than letting it proceed in autocommit where nothing could be rolled back, and a failed `COMMIT` rolls back and raises rather than returning success over work that was never committed.

### Added
- `wp timesuite audit-comp-time-ledger [--user-id=N] [--year=YYYY] [--month=M] [--format=table|json]` — a read-only report of months whose ledger disagrees with the timesheet it was written from (missing credit or debit rows, or a minutes total that does not match). It repairs nothing and offers no flag to do so: some balances have already been corrected by hand, and re-adding a missing credit on top of a manual correction would double it.
  - **Denied months are included.** Comp-time is applied at submission and is not cleared by a denial — only reopening to draft clears it — so a denied month still holds live ledger rows and can still be missing some.
  - **Manual adjustments are listed individually** with date, direction, minutes, actor, source key and notes, and are explicitly labelled all-time. Nothing in a manual adjustment records which month it was meant to repair, so one appearing next to a shortfall is *not* evidence that month was fixed. They are never netted off the discrepancy.
  - **Legacy-only months are counted and declared, not silently skipped.** They exist only in `user_meta` and cannot be read without materializing them, which would make the audit a writer, so the report states it is incomplete and names the backfill to run first. A clean result over a partial scan can no longer be mistaken for a clean system.

- Selecting a full **Time in lieu** day now states what it costs — "Uses 9h from your Time-in-Lieu balance" — using that date's own scheduled hours, so a custom short day correctly reads 3.5h rather than the organisation default. Previously the deduction happened silently and the amount appeared nowhere in the timesheet. A day the employee was never scheduled to work says so explicitly instead of implying hours were spent.
- Time-in-Lieu balances now show **exact hours everywhere** (`13h 30m`), on both the dashboard and the Org Directory, which share one formatter. The dashboard previously divided the balance by the *global* daily-hours setting to show a day count — wrong for anyone on a custom schedule — and then rounded the remainder to the nearest half hour, so the exact figure never reached the screen. The day equivalent is still shown, but marked approximate and stating the day length it assumed (`≈ 1.5 days at 9h/day`).

## [0.1.18] - 2026-08-30

### Fixed
- Overtime entered on an employee-specific non-working day now counts only the entered overtime hours across the timesheet UI, manager view, employee reports, and Payroll Matrix. Scheduled base hours are still included for overtime on regular working days.
- Admin Rescue can now return an Approved month to Draft, clearing its submission, approval decisions, and Time-in-Lieu ledger effects through the same audited reset path used for other reviewed months.

## [0.1.17] - 2026-07-30

### Changed
- Month-end reminder emails now state the organisation's deadline plainly: timesheets are due by the end of the month ("due tomorrow" on the second-to-last day, "due today" on the last). The previous wording only noted that the month was ending, which read as informational rather than as a deadline.
- `period_cutoff_day` is treated as a grace period for late edits, not as the deadline communicated to employees. Stating the month-end expectation keeps the message true if someone later learns of the cutoff, so the urgency is not discredited.

## [0.1.16] - 2026-07-30

### Fixed
- **Deadline reminder emails were never being sent.** The schedule derived the deadline from the reporting period (the cutoff day of the *following* month) but only ever evaluated it from inside the current month, so the gap could never fall within the 3-day window unless `period_cutoff_day` was 1-3. At the configured value of 7, no reminder had ever fired. Reminders are now driven purely by month end and fire for any cutoff value.
- Reminder scheduling no longer measures elapsed seconds divided by 86400, which lost a day across daylight-saving transitions.
- Removed a duplicate copy of the timing rule in `EmailNotifier`, which could silently veto a send that the schedule had approved.

### Changed
- Employees who have not submitted are now nudged **twice** as the month closes: on the second-to-last day ("the month ends tomorrow") and on the last day ("today is the last day"). Anyone who has already submitted is skipped, so the second nudge only reaches those still outstanding.
- Reminders are now independent of `period_cutoff_day` and of the "default to previous month before the cutoff" toggle. The cutoff governs how long a finished month stays editable for payroll; the reminder is about logging hours while they are fresh, which is a month-end concern. This also removes all cross-month date arithmetic, and with it the class of bug above.
- Reminder emails no longer state a due date, since submission remains open until the cutoff. They say the month is ending instead.

### Notes
- The two stages are tracked under separate user meta keys, so the existing `timesuite_last_reminder_period` keeps its exact meaning and format and any stored value stays valid. No migration is required.
- `MonthlyTimesheetService::sendDeadlineReminders()` now accepts an optional injectable date. Production passes nothing and uses the clock; the parameter exists so the schedule's date maths is testable, which it previously was not.

## [0.1.15] - 2026-07-30

### Fixed
- Environment detection for automated reminder emails now reads the deploy environment Planet 4 actually exposes. The 0.1.14 guard checked the `APP_ENVIRONMENT` variable, but Planet 4 names it `APP_ENV` at runtime and its PHP-FPM pools run with `clear_env = yes`, so `getenv()` could not see it during a web request. Detection now prefers the `WP_APP_ENV` constant that Planet 4 bakes into `wp-config.php`, which is unaffected by `clear_env`, and falls back to environment variables for CLI (WP-CLI cron) and to the site host as before.
- Dev and staging blocking no longer depends solely on the hostname containing `www-dev.`/`www-stage.`. A non-production environment is now detected even when the host is renamed, closing a gap where a dev site could have started emailing real employees.

### Notes
- Production behaviour is unchanged: the live site is still detected as production and continues to send reminders. Detection remains fail-open, so an install that declares no environment at all keeps sending rather than going silently quiet.

## [0.1.14] - 2026-07-16

### Changed
- Payroll Matrix now marks each employee's own non-working days in their cells, while the Date column remains a date-only reference.

### Fixed
- Dashboard links to My Timesheet now open the employee timesheet screen.
- Automated deadline reminder emails are now sent only from production, including queued retries. Other Timesuite workflow emails remain available for dev and staging testing.

## [0.1.13] - 2026-07-02

### Changed
- Improved Manager View approval errors so self-approval, missing manager assignments, and wrong month statuses explain the next step.
- Improved Admin Rescue action errors so stale or inapplicable rescue actions explain the current month state and what to do instead.

## [0.1.12] - 2026-07-02

### Added
- Added Admin Rescue tools for HR and Technical Admin users to diagnose and safely repair stuck timesheet months.
- Added a CLI-only legacy month backfill command for materializing old user-meta timesheet months into the canonical tables.
- Added cutoff-aware default-period handling so timesheet, manager, and HR views can open on the relevant prior month before cutoff.

### Changed
- Improved monthly editability reasons and manager-facing status messaging for submitted, draft, locked, and failed-load states.
- Improved Time in Lieu handling during rescue and status transitions so ledger credits/debits stay synchronized.
- Improved policy settings for previous-month cutoff visibility, independent paid-time-off and sick carryover caps, and circular manager assignment controls.

### Fixed
- Fixed a data-loss bug where an approve/deny/undo-submit/reset/finalize action could silently overwrite a month's real submission history with an empty draft, if that month had never been opened through the employee's own timesheet page first
- Fixed the HR Dashboard showing "Not submitted" for months an employee had genuinely submitted, when that month predated the current storage table
- Manager View no longer shows a misleading "Draft / 0 pending / 0 reviewed" state when an employee's timesheet fails to load — it now shows a clear error instead
- Manager View now explains when a month simply hasn't been submitted yet, instead of showing an unexplained empty calendar
- Submit attempts (success, auto-lock, and failure) are now recorded in the audit log with before/after status, so submission issues can be diagnosed from the log alone
- Fixed SuperAccess users being shown full UI access but rejected by some REST endpoints.
- Fixed local/frontend asset loading in WordPress admin by loading the Timesuite app bundle as a JavaScript module.

## [0.1.11] - 2026-06-23

### Changed
- Hide employee carryover override fields when their policy cap is disabled
- Explain that disabled caps preserve the full balance
- Clarify that blank employee overrides use the policy default

## [0.1.10] - 2026-06-22

### Changed
- Show the previous-month cutoff day only when previous-month editing is enabled
- Split paid time off and sick-day carryover caps into independent controls
- Preserve the full prior-year balance when a carryover cap is disabled
- Remove the raw Org CSV export button while retaining Org CSV import support

## [0.1.9] - 2026-06-21

### Changed
- Moved the circular manager assignment toggle into Periods and submissions
- Kept Org CSV focused on organization mappings
- Added employment start and end dates to the HR summary export

## [0.1.8] - 2026-06-21

### Added
- Optional employment start and end dates with timesheet, payroll, accrual, and CSV support
- Annual vacation and sick carryover caps with per-employee overrides
- Configurable circular manager assignment policy
- Scoped, opt-in diagnostics mode on the System Status page
- Custom leave coverage for half-working days
- Formula-based payroll matrix summary rows

### Changed
- Separated Timesuite roles from WordPress roles
- Improved manager review messaging and employee undo-submit behavior
- Restricted holiday and non-working-day choices to valid options
- Improved month-selection guidance and payroll export summaries
- Reduced audit-log overhead and improved retention handling

### Fixed
- Locale-dependent working-day detection
- Draft months appearing actionable in manager review
- Salesforce-style circular co-manager assignments when explicitly allowed
- Leave deductions for employees with custom short working days

### Added
- **Bootstrap Mode**: Automatic first-time setup when no tech admin exists
  - WordPress administrators get temporary access to set up the first Timesuite admin
  - Automatically exits bootstrap mode once configured
  - Prevents lockout when moving plugin between environments
  - All bootstrap actions logged to audit trail
- Dashboard overview screen with pending approvals and submission status
- Audit log UI for HR and administrators
- Email notifications for timesheet submissions, approvals, and denials
- Health check endpoint (`/timesuite/v1/health`) for monitoring
- Export versioning (v1/v2) with additional metadata fields
- Timezone setting for organization-wide date handling
- Optimistic locking to prevent concurrent edit conflicts
- Audit log retention policy with configurable cleanup
- More granular capabilities (org.view, org.edit, org.import, org.delete, etc.)
- Rate limiting presets for different action types
- SECURITY.md with responsible disclosure guidelines
- CHANGELOG.md for tracking releases

### Changed
- Improved error messages to be more user-friendly and actionable
- Empty states now explain what to do next
- Build-required preflight screen shows clear setup instructions
- GitHub Actions CI now runs on every push/PR

### Fixed
- TypeScript strict mode compliance for all frontend code
- Rate limiting now properly scoped per endpoint type

### Security
- CSRF protection verified on all state-changing endpoints
- Database indexes added for frequently queried columns

## [0.1.0] - 2024-12-30

### Added
- Initial release
- Employee timesheet entry with monthly calendar view
- Manager approval workflow (approve/deny/reset)
- HR period locking and payroll exports (CSV/XLSX)
- Org directory management
- Policy settings (work week, holidays, rounding, cutoffs)
- Bulk import for timesheets (XLSX) and org mappings (CSV)
- REST API for all operations
- React/Vite frontend with dark mode support
- Custom WordPress roles and capabilities
- Internationalization support (translation-ready)

[Unreleased]: https://github.com/greenpeace/timesuite/compare/v0.1.19...HEAD
[0.1.20]: https://github.com/greenpeace/timesuite/compare/v0.1.19...v0.1.20
[0.1.19]: https://github.com/greenpeace/timesuite/compare/v0.1.18...v0.1.19
[0.1.18]: https://github.com/greenpeace/timesuite/compare/v0.1.17...v0.1.18
[0.1.17]: https://github.com/greenpeace/timesuite/compare/v0.1.16...v0.1.17
[0.1.16]: https://github.com/greenpeace/timesuite/compare/v0.1.15...v0.1.16
[0.1.15]: https://github.com/greenpeace/timesuite/compare/v0.1.14...v0.1.15
[0.1.14]: https://github.com/greenpeace/timesuite/compare/v0.1.13...v0.1.14
[0.1.13]: https://github.com/greenpeace/timesuite/compare/v0.1.12...v0.1.13
[0.1.12]: https://github.com/greenpeace/timesuite/compare/v0.1.11...v0.1.12
[0.1.11]: https://github.com/greenpeace/timesuite/compare/v0.1.10...v0.1.11
[0.1.10]: https://github.com/greenpeace/timesuite/compare/v0.1.9...v0.1.10
[0.1.9]: https://github.com/greenpeace/timesuite/compare/v0.1.8...v0.1.9
[0.1.8]: https://github.com/greenpeace/timesuite/compare/v0.1.4...v0.1.8
[0.1.0]: https://github.com/greenpeace/timesuite/releases/tag/v0.1.0
