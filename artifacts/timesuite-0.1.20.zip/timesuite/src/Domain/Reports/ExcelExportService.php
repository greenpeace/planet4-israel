<?php

declare(strict_types=1);

namespace Timesuite\Domain\Reports;

/**
 * Service for generating Excel/CSV export files.
 * 
 * Supports both XLSX (using simple XML generation) and CSV formats.
 * For production environments with complex needs, consider adding PhpSpreadsheet.
 */
class ExcelExportService
{
    private const STYLE_DEFAULT = 0;
    private const STYLE_BOLD = 1;
    private const STYLE_DATE = 2;
    private const STYLE_HEADER_LOCKED = 3;
    private const STYLE_HEADER_MISSING = 4;
    private const STYLE_SUBHEADER_LOCKED = 5;
    private const STYLE_SUBHEADER_MISSING = 6;
    private const STYLE_BODY_TINT = 7;
    private const STYLE_BODY_PLAIN = 8;
    private const STYLE_BODY_MISSING = 9;
    private const STYLE_BODY_TINT_SEPARATOR = 10;
    private const STYLE_BODY_PLAIN_SEPARATOR = 11;
    private const STYLE_BODY_MISSING_SEPARATOR = 12;
    private const STYLE_SUBHEADER_LOCKED_SEPARATOR = 13;
    private const STYLE_SUBHEADER_MISSING_SEPARATOR = 14;
    private const STYLE_HEADER_LOCKED_SEPARATOR = 15;
    private const STYLE_HEADER_MISSING_SEPARATOR = 16;
    private const STYLE_DATE_CONTEXT = 17;
    private const STYLE_ROW_CONTEXT = 18;
    private const STYLE_ROW_CONTEXT_SEPARATOR = 19;
    private const STYLE_DIVIDER = 20;
    private const STYLE_DIVIDER_SEPARATOR = 21;

    /**
     * Generate an employee timesheet export file.
     *
     * @param array $reportData Data from TimesheetReportService::generateEmployeeReport()
     * @param string $format 'xlsx' or 'csv'
     * @return array{filename: string, content: string, mime_type: string}
     */
    public function generateEmployeeExport(array $reportData, string $format = 'xlsx'): array
    {
        $metadata = $reportData['metadata'];
        $employeeName = $this->sanitizeFilename($metadata['employee_name']);
        $periodLabel = $metadata['period_year'] . '-' . str_pad((string) $metadata['period_month'], 2, '0', STR_PAD_LEFT);
        
        $filename = "Timesuite_Timesheet_{$employeeName}_{$periodLabel}";

        if ($format === 'csv') {
            return $this->generateEmployeeCsv($reportData, $filename);
        }

        return $this->generateEmployeeXlsx($reportData, $filename);
    }

    /**
     * Generate an HR summary export file.
     *
     * @param array $reportData Data from TimesheetReportService::generateHrSummaryReport()
     * @return array{filename: string, content: string, mime_type: string}
     */
    public function generateHrSummaryExport(array $reportData): array
    {
        $metadata = $reportData['metadata'];
        $periodLabel = $metadata['period_year'] . '-' . str_pad((string) $metadata['period_month'], 2, '0', STR_PAD_LEFT);
        
        $filename = "Timesuite_HR_Summary_{$periodLabel}";

        return $this->generateHrSummaryXlsx($reportData, $filename);
    }

    /**
     * Generate an HR payroll matrix export file.
     *
     * @param array $reportData Data from TimesheetReportService::generatePayrollMatrixReport()
     * @return array{filename: string, content: string, mime_type: string}
     */
    public function generatePayrollMatrixExport(array $reportData): array
    {
        $metadata = $reportData['metadata'];
        $periodLabel = $metadata['period_year'] . '-' . str_pad((string) $metadata['period_month'], 2, '0', STR_PAD_LEFT);
        $filename = "Timesuite_Payroll_Matrix_{$periodLabel}";
        $dataStartRow = 3;
        $dataEndRow = $dataStartRow + count($reportData['rows']) - 1;
        $leaveStandardDayHours = $this->resolvePayrollMatrixLeaveStandardDayHours($reportData);

        $rows = [];
        $styles = [];
        $headerRow = ['Date'];
        $headerStyleRow = [self::STYLE_DATE];
        $subHeaderRow = [''];
        $subHeaderStyleRow = [self::STYLE_DATE];
        $merges = [];
        $columnIndex = 1;

        foreach ($reportData['employees'] as $employeeIndex => $employee) {
            $hasLockedMonth = ! empty($employee['has_locked_month']);
            $isTintedBlock = $employeeIndex % 2 === 1;
            $headerStyle = $hasLockedMonth ? self::STYLE_HEADER_LOCKED : self::STYLE_HEADER_MISSING;
            $headerSeparatorStyle = $hasLockedMonth ? self::STYLE_HEADER_LOCKED_SEPARATOR : self::STYLE_HEADER_MISSING_SEPARATOR;
            $subHeaderStyle = $hasLockedMonth ? self::STYLE_SUBHEADER_LOCKED : self::STYLE_SUBHEADER_MISSING;
            $subHeaderSeparatorStyle = $hasLockedMonth ? self::STYLE_SUBHEADER_LOCKED_SEPARATOR : self::STYLE_SUBHEADER_MISSING_SEPARATOR;

            $headerRow[] = sprintf('%s (%s)', (string) $employee['name'], (string) $employee['email']);
            $headerRow[] = '';
            $headerRow[] = '';
            $headerStyleRow[] = $headerStyle;
            $headerStyleRow[] = $headerStyle;
            $headerStyleRow[] = $headerSeparatorStyle;
            $subHeaderRow[] = 'Worked';
            $subHeaderRow[] = 'Type';
            $subHeaderRow[] = 'Hours Off';
            $subHeaderStyleRow[] = $subHeaderStyle;
            $subHeaderStyleRow[] = $subHeaderStyle;
            $subHeaderStyleRow[] = $subHeaderSeparatorStyle;

            $startColumn = $this->getColumnLetter($columnIndex);
            $endColumn = $this->getColumnLetter($columnIndex + 2);
            $merges[] = $startColumn . '1:' . $endColumn . '1';
            $columnIndex += 3;
        }

        $rows[] = $headerRow;
        $rows[] = $subHeaderRow;
        $styles[] = $headerStyleRow;
        $styles[] = $subHeaderStyleRow;

        foreach ($reportData['rows'] as $row) {
            $sheetRow = [$row['date']];
            $isContextRow = isset($row['row_kind']) && in_array($row['row_kind'], ['holiday', 'non_working'], true);
            $styleRow = [$isContextRow ? self::STYLE_DATE_CONTEXT : self::STYLE_DATE];

            foreach ($row['cells'] as $employeeIndex => $cell) {
                $isEmployeeNonWorkingCell = ($cell['cell_kind'] ?? '') === 'non_working';

                if ($isContextRow || $isEmployeeNonWorkingCell) {
                    $baseStyle = self::STYLE_ROW_CONTEXT;
                    $separatorStyle = self::STYLE_ROW_CONTEXT_SEPARATOR;
                } else {
                    $employee = $reportData['employees'][$employeeIndex] ?? [];
                    $hasLockedMonth = ! empty($employee['has_locked_month']);
                    $isTintedBlock = $employeeIndex % 2 === 1;

                    if (! $hasLockedMonth) {
                        $baseStyle = self::STYLE_BODY_MISSING;
                        $separatorStyle = self::STYLE_BODY_MISSING_SEPARATOR;
                    } elseif ($isTintedBlock) {
                        $baseStyle = self::STYLE_BODY_TINT;
                        $separatorStyle = self::STYLE_BODY_TINT_SEPARATOR;
                    } else {
                        $baseStyle = self::STYLE_BODY_PLAIN;
                        $separatorStyle = self::STYLE_BODY_PLAIN_SEPARATOR;
                    }
                }

                $sheetRow[] = $cell['worked'];
                $sheetRow[] = $cell['type'];
                $sheetRow[] = $cell['hours_off'];
                $styleRow[] = $baseStyle;
                $styleRow[] = $baseStyle;
                $styleRow[] = $separatorStyle;
            }

            $rows[] = $sheetRow;
            $styles[] = $styleRow;
        }

        if (! empty($reportData['summary_rows']) && is_array($reportData['summary_rows'])) {
            $dividerRow = [''];
            $dividerStyleRow = [self::STYLE_DIVIDER];

            foreach ($reportData['employees'] as $_employee) {
                $dividerRow[] = '';
                $dividerRow[] = '';
                $dividerRow[] = '';
                $dividerStyleRow[] = self::STYLE_DIVIDER;
                $dividerStyleRow[] = self::STYLE_DIVIDER;
                $dividerStyleRow[] = self::STYLE_DIVIDER_SEPARATOR;
            }

            $rows[] = $dividerRow;
            $styles[] = $dividerStyleRow;

            foreach ($reportData['summary_rows'] as $summaryRow) {
                $sheetRow = [(string) ($summaryRow['label'] ?? '')];
                $styleRow = [self::STYLE_DATE];
                $columnTarget = (string) ($summaryRow['column'] ?? 'hours_off');
                $formulaKey = (string) ($summaryRow['formula_key'] ?? '');
                $values = is_array($summaryRow['values'] ?? null) ? $summaryRow['values'] : [];

                foreach ($reportData['employees'] as $employeeIndex => $employee) {
                    $userId = (int) ($employee['user_id'] ?? 0);
                    $value = $values[$userId] ?? '';
                    $hasLockedMonth = ! empty($employee['has_locked_month']);
                    $subHeaderStyle = $hasLockedMonth ? self::STYLE_SUBHEADER_LOCKED : self::STYLE_SUBHEADER_MISSING;
                    $subHeaderSeparatorStyle = $hasLockedMonth ? self::STYLE_SUBHEADER_LOCKED_SEPARATOR : self::STYLE_SUBHEADER_MISSING_SEPARATOR;

                    $workedValue = '';
                    $typeValue = '';
                    $hoursOffValue = '';

                    if ($columnTarget === 'worked') {
                        $workedValue = $value;
                    } elseif ($columnTarget === 'type') {
                        $typeValue = $value;
                    } else {
                        $hoursOffValue = $value;
                    }

                    if ($value !== '' && $formulaKey !== '') {
                        $formulaCell = $this->buildPayrollMatrixSummaryFormulaCell(
                            $formulaKey,
                            $value,
                            $employeeIndex,
                            $reportData,
                            $dataStartRow,
                            $dataEndRow,
                            $leaveStandardDayHours
                        );

                        if ($formulaCell !== null) {
                            if ($columnTarget === 'worked') {
                                $workedValue = $formulaCell;
                            } elseif ($columnTarget === 'type') {
                                $typeValue = $formulaCell;
                            } else {
                                $hoursOffValue = $formulaCell;
                            }
                        }
                    }

                    $sheetRow[] = $workedValue;
                    $sheetRow[] = $typeValue;
                    $sheetRow[] = $hoursOffValue;
                    $styleRow[] = $subHeaderStyle;
                    $styleRow[] = $subHeaderStyle;
                    $styleRow[] = $subHeaderSeparatorStyle;
                }

                $rows[] = $sheetRow;
                $styles[] = $styleRow;
            }
        }

        $content = $this->createXlsx([
            'Timesheet - ' . $metadata['period_label'] => [
                'rows' => $rows,
                'styles' => $styles,
                'merges' => $merges,
                'freeze_pane' => 'B3',
                'header_rows' => 2,
            ],
        ]);

        return [
            'filename' => $filename . '.xlsx',
            'content' => $content,
            'mime_type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ];
    }

    /**
     * @return array{formula: string, value: string|float|int}|null
     */
    private function buildPayrollMatrixSummaryFormulaCell(
        string $formulaKey,
        string|float|int $cachedValue,
        int $employeeIndex,
        array $reportData,
        int $dataStartRow,
        int $dataEndRow,
        float $leaveStandardDayHours
    ): ?array {
        $workedColumn = $this->getColumnLetter(1 + ($employeeIndex * 3));
        $typeColumn = $this->getColumnLetter(2 + ($employeeIndex * 3));
        $hoursOffColumn = $this->getColumnLetter(3 + ($employeeIndex * 3));
        $payableTerms = [];
        $workedDayTerms = [];
        $vacationTerms = [];
        $sickTerms = [];
        $otherPaidLeaveTerms = [];

        foreach ($reportData['rows'] as $rowIndex => $row) {
            $rowNumber = $dataStartRow + $rowIndex;
            $workedCell = "{$workedColumn}{$rowNumber}";
            $typeCell = "{$typeColumn}{$rowNumber}";
            $hoursOffCell = "{$hoursOffColumn}{$rowNumber}";
            $cell = is_array($row['cells'][$employeeIndex] ?? null) ? $row['cells'][$employeeIndex] : [];
            $scheduledHours = isset($cell['scheduled_hours']) && is_numeric($cell['scheduled_hours'])
                ? $this->formatFormulaNumber((float) $cell['scheduled_hours'])
                : '0';

            $payableTerms[] = "{$workedCell}+{$hoursOffCell}+IF({$typeCell}=\"HOL\",{$scheduledHours},0)+IF({$typeCell}=\"HOL_HALF\",{$scheduledHours}-{$workedCell},0)";
            $workedDayTerms[] = "IF({$workedCell}>0,1,0)";
            $vacationTerms[] = "IF({$typeCell}=\"VAC\",{$hoursOffCell},0)+IF({$typeCell}=\"VAC_HALF\",{$hoursOffCell},0)";
            $sickTerms[] = "IF({$typeCell}=\"SICK\",{$hoursOffCell},0)+IF({$typeCell}=\"SICK_HALF\",{$hoursOffCell},0)";
            $otherPaidLeaveTerms[] = "IF(AND({$typeCell}<>\"\",{$typeCell}<>\"Non-working day\",{$typeCell}<>\"VAC\",{$typeCell}<>\"VAC_HALF\",{$typeCell}<>\"SICK\",{$typeCell}<>\"SICK_HALF\",{$typeCell}<>\"COMP\",{$typeCell}<>\"COMP_HALF\",{$typeCell}<>\"HOL\",{$typeCell}<>\"HOL_HALF\"),{$hoursOffCell},0)";
        }

        $formula = match ($formulaKey) {
            'payable_hours' => 'ROUND(' . implode('+', $payableTerms) . ',2)',
            'worked_hours' => sprintf(
                'ROUND(SUM(%1$s%2$d:%1$s%3$d),2)',
                $workedColumn,
                $dataStartRow,
                $dataEndRow
            ),
            'worked_days' => implode('+', $workedDayTerms),
            'vacation_days' => sprintf(
                'ROUND((%1$s)/%2$s,2)',
                implode('+', $vacationTerms),
                $this->formatFormulaNumber($leaveStandardDayHours)
            ),
            'sick_days' => sprintf(
                'ROUND((%1$s)/%2$s,2)',
                implode('+', $sickTerms),
                $this->formatFormulaNumber($leaveStandardDayHours)
            ),
            'other_paid_leave_days' => sprintf(
                'ROUND((%1$s)/%2$s,2)',
                implode('+', $otherPaidLeaveTerms),
                $this->formatFormulaNumber($leaveStandardDayHours)
            ),
            default => null,
        };

        if ($formula === null) {
            return null;
        }

        return [
            'formula' => $formula,
            'value' => $cachedValue,
        ];
    }

    private function resolvePayrollMatrixLeaveStandardDayHours(array $reportData): float
    {
        $value = $reportData['metadata']['leave_standard_day_hours'] ?? null;

        if (is_numeric($value) && (float) $value > 0) {
            return round((float) $value, 2);
        }

        return 1.0;
    }

    /**
     * Generate employee CSV export.
     */
    private function generateEmployeeCsv(array $reportData, string $filename): array
    {
        $output = fopen('php://temp', 'r+');
        
        $metadata = $reportData['metadata'];
        $summary = $reportData['summary'];

        // Metadata header
        fputcsv($output, ['Timesuite Timesheet Export']);
        fputcsv($output, ['']);
        fputcsv($output, ['Employee', $metadata['employee_name']]);
        fputcsv($output, ['Email', $metadata['employee_email']]);
        fputcsv($output, ['Department', $metadata['department'] ?? '']);
        fputcsv($output, ['Manager', $metadata['manager_name'] ?? '']);
        fputcsv($output, ['Period', $metadata['period_label']]);
        fputcsv($output, ['Exported By', $metadata['exported_by']]);
        fputcsv($output, ['Exported At', $metadata['exported_at']]);
        fputcsv($output, ['']);

        // Daily entries header
        fputcsv($output, [
            'Date',
            'Day',
            'Day State',
            'Day Type',
            'Planned Hours',
            'Worked Hours',
            'Part-Day Hours',
            'Coverage Source',
            'In Office',
            'Notes',
            'Approval Status',
        ]);

        // Daily entries
        foreach ($reportData['daily_entries'] as $entry) {
            fputcsv($output, [
                $entry['date'],
                $entry['day_of_week'],
                $entry['day_state'],
                $entry['day_type_label'],
                $entry['planned_hours'],
                $entry['worked_hours'],
                $entry['part_day_hours'] ?? '',
                $entry['coverage_source_label'] ?? '',
                $entry['in_office'] === null ? '' : ($entry['in_office'] ? 'Yes' : 'No'),
                $entry['notes'],
                $entry['approval_status'] ?? '',
            ]);
        }

        // Summary section
        fputcsv($output, ['']);
        fputcsv($output, ['SUMMARY']);
        fputcsv($output, ['Total Working Days', $summary['total_working_days']]);
        fputcsv($output, ['Total Worked Days', $summary['total_worked_days']]);
        fputcsv($output, ['Half Days', $summary['half_day_count']]);
        fputcsv($output, ['Total Planned Hours', $summary['total_planned_hours']]);
        fputcsv($output, ['Total Worked Hours', $summary['total_worked_hours']]);
        fputcsv($output, ['']);
        fputcsv($output, ['Paid Time Off Contract (days/year)', $summary['vacation_contract_days']]);
        fputcsv($output, ['Paid Time Off Used (this period)', $summary['vacation_days_used']]);
        fputcsv($output, ['Paid Time Off Used (YTD)', $summary['vacation_used_ytd']]);
        fputcsv($output, ['Paid Time Off Remaining', $summary['vacation_remaining']]);
        fputcsv($output, ['']);
        fputcsv($output, ['Sick Days Contract (days/year)', $summary['sick_contract_days']]);
        fputcsv($output, ['Sick Days Used (this period)', $summary['sick_days_used']]);
        fputcsv($output, ['Sick Days Used (YTD)', $summary['sick_used_ytd']]);
        fputcsv($output, ['Sick Days Remaining', $summary['sick_remaining']]);
        fputcsv($output, ['']);
        fputcsv($output, ['Comp Time Balance (hours)', $summary['comp_time_balance_hours']]);
        fputcsv($output, ['']);
        fputcsv($output, ['Timesheet Status', $summary['timesheet_status']]);
        if ($summary['submitted_at']) {
            fputcsv($output, ['Submitted At', $summary['submitted_at']]);
        }
        if ($summary['approved_at']) {
            fputcsv($output, ['Approved At', $summary['approved_at']]);
        }
        if ($summary['denied_comment']) {
            fputcsv($output, ['Denial Reason', $summary['denied_comment']]);
        }

        rewind($output);
        $content = stream_get_contents($output);
        fclose($output);

        return [
            'filename' => $filename . '.csv',
            'content' => $content,
            'mime_type' => 'text/csv; charset=UTF-8',
        ];
    }

    /**
     * Generate employee XLSX export.
     * Uses simple XML-based XLSX generation (no external dependencies).
     */
    private function generateEmployeeXlsx(array $reportData, string $filename): array
    {
        $metadata = $reportData['metadata'];
        $summary = $reportData['summary'];

        // Sheet 1: Daily Details
        $sheet1Data = [];
        
        // Metadata rows
        $sheet1Data[] = ['Timesuite Timesheet Export', '', '', '', '', '', '', '', '', '', ''];
        $sheet1Data[] = ['', '', '', '', '', '', '', '', '', '', ''];
        $sheet1Data[] = ['Employee:', $metadata['employee_name'], '', 'Period:', $metadata['period_label'], '', '', '', '', '', ''];
        $sheet1Data[] = ['Email:', $metadata['employee_email'], '', 'Exported By:', $metadata['exported_by'], '', '', '', '', '', ''];
        $sheet1Data[] = ['Department:', $metadata['department'] ?? '', '', 'Exported At:', $metadata['exported_at'], '', '', '', '', '', ''];
        $sheet1Data[] = ['Manager:', $metadata['manager_name'] ?? '', '', '', '', '', '', '', '', '', ''];
        $sheet1Data[] = ['', '', '', '', '', '', '', '', '', '', ''];

        // Header row
        $sheet1Data[] = [
            'Date',
            'Day',
            'Day State',
            'Day Type',
            'Planned Hours',
            'Worked Hours',
            'Part-Day Hours',
            'Coverage Source',
            'In Office',
            'Notes',
            'Approval Status',
        ];

        // Data rows
        foreach ($reportData['daily_entries'] as $entry) {
            $sheet1Data[] = [
                $entry['date'],
                $entry['day_of_week'],
                ucfirst($entry['day_state']),
                $entry['day_type_label'],
                $entry['planned_hours'],
                $entry['worked_hours'],
                $entry['part_day_hours'] ?? '',
                $entry['coverage_source_label'] ?? '',
                $entry['in_office'] === null ? '' : ($entry['in_office'] ? 'Yes' : 'No'),
                $entry['notes'],
                $entry['approval_status'] ? ucfirst($entry['approval_status']) : '',
            ];
        }

        // Sheet 2: Summary
        $sheet2Data = [];
        $sheet2Data[] = ['Period Summary', ''];
        $sheet2Data[] = ['', ''];
        $sheet2Data[] = ['Employee', $metadata['employee_name']];
        $sheet2Data[] = ['Period', $metadata['period_label']];
        $sheet2Data[] = ['', ''];
        $sheet2Data[] = ['HOURS', ''];
        $sheet2Data[] = ['Total Working Days', $summary['total_working_days']];
        $sheet2Data[] = ['Total Worked Days', $summary['total_worked_days']];
        $sheet2Data[] = ['Half Days', $summary['half_day_count']];
        $sheet2Data[] = ['Total Planned Hours', $summary['total_planned_hours']];
        $sheet2Data[] = ['Total Worked Hours', $summary['total_worked_hours']];
        $sheet2Data[] = ['', ''];
        $sheet2Data[] = ['PAID TIME OFF', ''];
        $sheet2Data[] = ['Contract (days/year)', $summary['vacation_contract_days']];
        $sheet2Data[] = ['Used (this period)', $summary['vacation_days_used']];
        $sheet2Data[] = ['Used (YTD)', $summary['vacation_used_ytd']];
        $sheet2Data[] = ['Remaining', $summary['vacation_remaining']];
        $sheet2Data[] = ['', ''];
        $sheet2Data[] = ['SICK DAYS', ''];
        $sheet2Data[] = ['Contract (days/year)', $summary['sick_contract_days']];
        $sheet2Data[] = ['Used (this period)', $summary['sick_days_used']];
        $sheet2Data[] = ['Used (YTD)', $summary['sick_used_ytd']];
        $sheet2Data[] = ['Remaining', $summary['sick_remaining']];
        $sheet2Data[] = ['', ''];
        $sheet2Data[] = ['COMP TIME', ''];
        $sheet2Data[] = ['Balance (hours)', $summary['comp_time_balance_hours']];
        $sheet2Data[] = ['', ''];
        $sheet2Data[] = ['STATUS', ''];
        $sheet2Data[] = ['Timesheet Status', ucfirst($summary['timesheet_status'])];
        if ($summary['submitted_at']) {
            $sheet2Data[] = ['Submitted At', $summary['submitted_at']];
        }
        if ($summary['approved_at']) {
            $sheet2Data[] = ['Approved At', $summary['approved_at']];
        }
        if ($summary['denied_comment']) {
            $sheet2Data[] = ['Denial Reason', $summary['denied_comment']];
        }

        $content = $this->createXlsx([
            'Daily Details' => $sheet1Data,
            'Summary' => $sheet2Data,
        ]);

        return [
            'filename' => $filename . '.xlsx',
            'content' => $content,
            'mime_type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ];
    }

    /**
     * Generate HR summary XLSX export.
     */
    private function generateHrSummaryXlsx(array $reportData, string $filename): array
    {
        $sheetData = [];
        $sheetData[] = [
            'Name',
            'Email',
            'Department',
            'Employment Start Date',
            'Employment End Date',
            'Work Week',
            'Vacation Remaining',
            'Vacation Contract',
            'Sick Remaining',
            'Sick Contract',
            'Comp Time',
            'Manager',
            'Timesuite Role',
        ];

        foreach ($reportData['employees'] as $employee) {
            $workWeek = (string) ($employee['work_week'] ?? '');
            if (! empty($employee['has_custom_daily_hours'])) {
                $workWeek .= ($workWeek !== '' ? ' | ' : '') . 'Custom hours';
            }

            $vacationContract = (float) ($employee['vacation_contract_days'] ?? 0);
            $vacationRemaining = (float) ($employee['vacation_remaining'] ?? $vacationContract);
            $sickContract = (float) ($employee['sick_contract_days'] ?? 0);
            $sickRemaining = (float) ($employee['sick_remaining'] ?? $sickContract);
            $compTimeHours = (float) ($employee['comp_time_balance_hours'] ?? 0);
            $timesuiteRole = (string) ($employee['timesuite_role'] ?? '');

            $sheetData[] = [
                $employee['employee_name'],
                $employee['employee_email'],
                $employee['department'],
                $employee['employment_start_date'] ?: '—',
                $employee['employment_end_date'] ?: '—',
                $workWeek,
                $this->formatExportNumber($vacationRemaining),
                $this->formatExportNumber($vacationContract),
                $this->formatExportNumber($sickRemaining),
                $this->formatExportNumber($sickContract),
                $compTimeHours > 0 ? $this->formatExportNumber($compTimeHours) . 'h' : '—',
                $employee['manager_name'] ?? '—',
                $timesuiteRole !== '' ? ucwords(str_replace('_', ' ', $timesuiteRole)) : '—',
            ];
        }

        $content = $this->createXlsx([
            'Directory' => [
                'rows' => $sheetData,
                'header_rows' => 1,
            ],
        ]);

        return [
            'filename' => $filename . '.xlsx',
            'content' => $content,
            'mime_type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ];
    }

    private function formatExportNumber(float $value): string
    {
        if (abs($value - round($value)) < 0.001) {
            return (string) (int) round($value);
        }

        return rtrim(rtrim(number_format($value, 2, '.', ''), '0'), '.');
    }

    /**
     * Create an XLSX file from sheet data.
     * 
     * @param array<string, array[]|array{rows: array[], styles?: array[], merges?: string[], freeze_pane?: string, header_rows?: int}> $sheets
     */
    private function createXlsx(array $sheets): string
    {
        $tempFile = tempnam(sys_get_temp_dir(), 'xlsx');
        $zip = new \ZipArchive();
        
        if ($zip->open($tempFile, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \RuntimeException('Cannot create XLSX file');
        }

        // [Content_Types].xml
        $zip->addFromString('[Content_Types].xml', $this->getContentTypesXml(count($sheets)));

        // _rels/.rels
        $zip->addFromString('_rels/.rels', $this->getRelsXml());

        // xl/_rels/workbook.xml.rels
        $zip->addFromString('xl/_rels/workbook.xml.rels', $this->getWorkbookRelsXml(count($sheets)));

        // xl/workbook.xml
        $zip->addFromString('xl/workbook.xml', $this->getWorkbookXml(array_keys($sheets)));

        // xl/styles.xml
        $zip->addFromString('xl/styles.xml', $this->getStylesXml());

        // xl/sharedStrings.xml and xl/worksheets/sheet{n}.xml
        $allStrings = [];
        $sheetIndex = 1;
        
        foreach ($sheets as $sheetName => $sheetSpec) {
            $rows = $this->normalizeSheetSpec($sheetSpec)['rows'];
            // Collect all strings
            foreach ($rows as $row) {
                foreach ($row as $cell) {
                    if ($this->isFormulaCell($cell)) {
                        continue;
                    }

                    if (is_string($cell) && $cell !== '') {
                        if (!in_array($cell, $allStrings, true)) {
                            $allStrings[] = $cell;
                        }
                    }
                }
            }
        }

        $zip->addFromString('xl/sharedStrings.xml', $this->getSharedStringsXml($allStrings));

        // Create worksheets
        $sheetIndex = 1;
        foreach ($sheets as $sheetName => $sheetSpec) {
            $zip->addFromString(
                "xl/worksheets/sheet{$sheetIndex}.xml",
                $this->getSheetXml($this->normalizeSheetSpec($sheetSpec), $allStrings)
            );
            $sheetIndex++;
        }

        $zip->close();

        $content = file_get_contents($tempFile);
        unlink($tempFile);

        return $content;
    }

    private function getContentTypesXml(int $sheetCount): string
    {
        $sheets = '';
        for ($i = 1; $i <= $sheetCount; $i++) {
            $sheets .= '<Override PartName="/xl/worksheets/sheet' . $i . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
' . $sheets . '
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>';
    }

    private function getRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>';
    }

    private function getWorkbookRelsXml(int $sheetCount): string
    {
        $sheets = '';
        for ($i = 1; $i <= $sheetCount; $i++) {
            $sheets .= '<Relationship Id="rId' . $i . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $i . '.xml"/>';
        }

        $stylesId = $sheetCount + 1;
        $stringsId = $sheetCount + 2;

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
' . $sheets . '
<Relationship Id="rId' . $stylesId . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
<Relationship Id="rId' . $stringsId . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>';
    }

    private function getWorkbookXml(array $sheetNames): string
    {
        $sheets = '';
        $index = 1;
        foreach ($sheetNames as $name) {
            $sheets .= '<sheet name="' . $this->xmlEscape($name) . '" sheetId="' . $index . '" r:id="rId' . $index . '"/>';
            $index++;
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>
' . $sheets . '
</sheets>
<calcPr calcId="0" calcMode="auto" fullCalcOnLoad="1"/>
</workbook>';
    }

    private function getStylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="3">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
</fonts>
<fills count="10">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE5E7EB"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF0B6B50"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFB45309"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFD9EFE8"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFDE7C7"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF5FAF8"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFF7E6"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF3F4F6"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="5">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border>
<left style="thin"><color rgb="FFD1D5DB"/></left>
<right style="thin"><color rgb="FFD1D5DB"/></right>
<top style="thin"><color rgb="FFD1D5DB"/></top>
<bottom style="thin"><color rgb="FFD1D5DB"/></bottom>
<diagonal/>
</border>
<border>
<left style="thin"><color rgb="FFD1D5DB"/></left>
<right style="medium"><color rgb="FF94A3B8"/></right>
<top style="thin"><color rgb="FFD1D5DB"/></top>
<bottom style="thin"><color rgb="FFD1D5DB"/></bottom>
<diagonal/>
</border>
<border>
<left style="thin"><color rgb="FFD1D5DB"/></left>
<right style="thin"><color rgb="FFD1D5DB"/></right>
<top style="medium"><color rgb="FF94A3B8"/></top>
<bottom style="thin"><color rgb="FFD1D5DB"/></bottom>
<diagonal/>
</border>
<border>
<left style="thin"><color rgb="FFD1D5DB"/></left>
<right style="medium"><color rgb="FF94A3B8"/></right>
<top style="medium"><color rgb="FF94A3B8"/></top>
<bottom style="thin"><color rgb="FFD1D5DB"/></bottom>
<diagonal/>
</border>
</borders>
<cellStyleXfs count="1">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
</cellStyleXfs>
<cellXfs count="22">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="2" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="7" borderId="1" xfId="0" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="8" borderId="1" xfId="0" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="7" borderId="2" xfId="0" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="2" xfId="0" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="8" borderId="2" xfId="0" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="5" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="6" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="2" fillId="3" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="2" fillId="4" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="9" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="9" borderId="1" xfId="0" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="9" borderId="2" xfId="0" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="3" xfId="0" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="4" xfId="0" applyBorder="1"/>
</cellXfs>
</styleSheet>';
    }

    private function getSharedStringsXml(array $strings): string
    {
        $count = count($strings);
        $items = '';
        
        foreach ($strings as $str) {
            $items .= '<si><t>' . $this->xmlEscape($str) . '</t></si>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' . $count . '" uniqueCount="' . $count . '">
' . $items . '
</sst>';
    }

    /**
     * @param array{rows: array[], styles: array[], merges: string[], freeze_pane: ?string, header_rows: int} $sheetSpec
     */
    private function getSheetXml(array $sheetSpec, array $sharedStrings): string
    {
        $stringIndex = array_flip($sharedStrings);
        $sheetData = '';
        $rows = $sheetSpec['rows'];
        $styles = $sheetSpec['styles'];
        $headerRows = $sheetSpec['header_rows'];

        foreach ($rows as $rowIndex => $row) {
            $rowNum = $rowIndex + 1;
            $cells = '';
            
            foreach ($row as $colIndex => $value) {
                $colLetter = $this->getColumnLetter($colIndex);
                $cellRef = $colLetter . $rowNum;
                $styleId = isset($styles[$rowIndex][$colIndex]) ? (int) $styles[$rowIndex][$colIndex] : null;
                if ($styleId === null && $rowNum <= $headerRows) {
                    $styleId = self::STYLE_BOLD;
                }
                $style = ($styleId !== null && $styleId > 0) ? ' s="' . $styleId . '"' : '';

                if ($value === '' || $value === null) {
                    if ($style !== '') {
                        $cells .= '<c r="' . $cellRef . '"' . $style . '/>';
                    }
                    continue;
                }

                if ($this->isFormulaCell($value)) {
                    $formula = ltrim((string) $value['formula'], '=');
                    $cachedValue = $value['value'] ?? null;
                    $cellXml = '<c r="' . $cellRef . '"' . $style . '><f>' . $this->xmlEscape($formula) . '</f>';

                    if ($cachedValue !== '' && $cachedValue !== null && is_numeric($cachedValue)) {
                        $cellXml .= '<v>' . $this->formatFormulaNumber((float) $cachedValue) . '</v>';
                    }

                    $cells .= $cellXml . '</c>';
                } elseif (is_numeric($value)) {
                    $cells .= '<c r="' . $cellRef . '"' . $style . '><v>' . $value . '</v></c>';
                } else {
                    $strIndex = $stringIndex[$value] ?? 0;
                    $cells .= '<c r="' . $cellRef . '"' . $style . ' t="s"><v>' . $strIndex . '</v></c>';
                }
            }

            if ($cells !== '') {
                $sheetData .= '<row r="' . $rowNum . '">' . $cells . '</row>';
            }
        }

        $sheetViews = '';
        if ($sheetSpec['freeze_pane']) {
            $pane = $this->buildFreezePaneXml($sheetSpec['freeze_pane']);
            if ($pane !== '') {
                $sheetViews = '<sheetViews><sheetView workbookViewId="0">' . $pane . '</sheetView></sheetViews>';
            }
        }

        $mergeCells = '';
        if (! empty($sheetSpec['merges'])) {
            $mergeItems = '';
            foreach ($sheetSpec['merges'] as $mergeRef) {
                $mergeItems .= '<mergeCell ref="' . $this->xmlEscape($mergeRef) . '"/>';
            }

            $mergeCells = '<mergeCells count="' . count($sheetSpec['merges']) . '">' . $mergeItems . '</mergeCells>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
' . $sheetViews . '
<sheetData>
' . $sheetData . '
</sheetData>
' . $mergeCells . '
</worksheet>';
    }

    /**
     * @param array[]|array{rows: array[], styles?: array[], merges?: string[], freeze_pane?: string, header_rows?: int} $sheetSpec
     * @return array{rows: array[], styles: array[], merges: string[], freeze_pane: ?string, header_rows: int}
     */
    private function normalizeSheetSpec(array $sheetSpec): array
    {
        if (array_key_exists('rows', $sheetSpec)) {
            return [
                'rows' => is_array($sheetSpec['rows']) ? $sheetSpec['rows'] : [],
                'styles' => isset($sheetSpec['styles']) && is_array($sheetSpec['styles']) ? array_values($sheetSpec['styles']) : [],
                'merges' => isset($sheetSpec['merges']) && is_array($sheetSpec['merges']) ? array_values($sheetSpec['merges']) : [],
                'freeze_pane' => isset($sheetSpec['freeze_pane']) && is_string($sheetSpec['freeze_pane']) ? $sheetSpec['freeze_pane'] : null,
                'header_rows' => isset($sheetSpec['header_rows']) ? max(0, (int) $sheetSpec['header_rows']) : 0,
            ];
        }

        return [
            'rows' => $sheetSpec,
            'styles' => [],
            'merges' => [],
            'freeze_pane' => null,
            'header_rows' => 0,
        ];
    }

    private function buildFreezePaneXml(string $topLeftCell): string
    {
        if (! preg_match('/^([A-Z]+)(\d+)$/', strtoupper($topLeftCell), $matches)) {
            return '';
        }

        $column = $matches[1];
        $row = (int) $matches[2];
        $xSplit = max(0, $this->columnLettersToIndex($column) - 1);
        $ySplit = max(0, $row - 1);

        if ($xSplit === 0 && $ySplit === 0) {
            return '';
        }

        return '<pane xSplit="' . $xSplit . '" ySplit="' . $ySplit . '" topLeftCell="' . $this->xmlEscape($topLeftCell) . '" activePane="bottomRight" state="frozen"/>';
    }

    private function getColumnLetter(int $index): string
    {
        $letter = '';
        while ($index >= 0) {
            $letter = chr(65 + ($index % 26)) . $letter;
            $index = intval($index / 26) - 1;
        }
        return $letter;
    }

    private function columnLettersToIndex(string $letters): int
    {
        $index = 0;
        $length = strlen($letters);

        for ($i = 0; $i < $length; $i++) {
            $index = ($index * 26) + (ord($letters[$i]) - 64);
        }

        return $index;
    }

    private function isFormulaCell(mixed $value): bool
    {
        return is_array($value)
            && isset($value['formula'])
            && is_string($value['formula'])
            && $value['formula'] !== '';
    }

    private function formatFormulaNumber(float $value): string
    {
        if (abs($value - round($value)) < 0.000001) {
            return (string) (int) round($value);
        }

        return rtrim(rtrim(sprintf('%.6F', $value), '0'), '.');
    }

    private function xmlEscape(string $str): string
    {
        return htmlspecialchars($str, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    private function sanitizeFilename(string $name): string
    {
        return preg_replace('/[^a-zA-Z0-9_-]/', '_', $name);
    }
}
