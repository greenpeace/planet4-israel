<?php
/**
 * Plugin Name:       Timesuite
 * Plugin URI:        https://example.com/timesuite
 * Description:       Minimal bootstrap for the Timesuite plugin.
 * Version:           0.1.20
 * Requires at least: 6.0
 * Requires PHP:      8.1
 * Author:            Niv Reznik
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       timesuite
 *
 * @package Timesuite
 */

declare(strict_types=1);

use Timesuite\Core\Container;
use Timesuite\Core\Plugin;

if (! defined('ABSPATH')) {
    exit;
}

if (! defined('TIMESUITE_PLUGIN_PATH')) {
    define('TIMESUITE_PLUGIN_PATH', plugin_dir_path(__FILE__));
}

if (! defined('TIMESUITE_PLUGIN_URL')) {
    define('TIMESUITE_PLUGIN_URL', plugin_dir_url(__FILE__));
}

$timesuiteAutoloader = __DIR__ . '/vendor/autoload.php';

if (! is_readable($timesuiteAutoloader)) {
    add_action('admin_notices', static function (): void {
        echo '<div class="notice notice-error"><p>';
        echo esc_html__('Timesuite dependencies are missing. Run composer install.', 'timesuite');
        echo '</p></div>';
    });

    return;
}

require $timesuiteAutoloader;

require_once __DIR__ . '/src/Frontend/enqueue.php';

/**
 * Retrieve the shared plugin instance.
 */
function timesuite(): Plugin
{
    static $pluginInstance = null;

    if (null === $pluginInstance) {
        $pluginInstance = new Plugin(new Container());
    }

    return $pluginInstance;
}

register_activation_hook(__FILE__, static function (): void {
    timesuite()->onActivate();
});

register_deactivation_hook(__FILE__, static function (): void {
    timesuite()->onDeactivate();
});

add_action('plugins_loaded', static function (): void {
    timesuite()->boot();
});
