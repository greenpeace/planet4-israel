<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use Timesuite\Core\Support\EmployeeName;
use wpdb;

/**
 * Seeds Timesuite's own employee name from the WordPress display name.
 *
 * Timesuite now resolves an employee's name from its own user meta key and
 * falls back to `display_name` only when that key is unset. Without a backfill
 * the fallback would carry every existing install, which works but leaves the
 * old coupling in place: the first WordPress profile edit would still rename
 * the person across Timesuite. Copying the current display name in once makes
 * the employment record the owner of the name from the moment this runs, and
 * -- because the value copied is exactly what Timesuite is displaying today --
 * nobody sees a name change on deploy.
 *
 * Scope is every user with an org mapping, including removed ones: a mapping
 * with `removed_at` set still appears in historical exports and approval
 * history, and those names should stop drifting too. WordPress accounts with no
 * mapping are deliberately skipped -- they are not employees, Timesuite has
 * never been told what to call them, and the fallback already resolves them.
 *
 * Rows are written with INSERT ... SELECT so the work happens in the database
 * rather than in a PHP loop over every employee; an install with hundreds of
 * staff would otherwise pay for hundreds of round trips during activation.
 *
 * Idempotent in both directions:
 *   - NOT EXISTS skips anyone who already has a stored name, so a name HR has
 *     since corrected is never overwritten by a stale display name.
 *   - Blank and whitespace-only display names are skipped rather than stored,
 *     so they keep falling through to the email/login fallback instead of
 *     freezing an empty name into the employment record.
 */
class BackfillEmployeeNames extends Migration
{
    public function getVersion(): string
    {
        return '2026_10_04_000016';
    }

    public function up(wpdb $wpdb): void
    {
        $orgTable  = $wpdb->prefix . 'timesuite_users_org';
        $usersTable = $wpdb->users;
        $metaTable = $wpdb->usermeta;
        $metaKey   = EmployeeName::META_KEY;

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$metaTable} (user_id, meta_key, meta_value)
                 SELECT DISTINCT u.ID, %s, TRIM(u.display_name)
                 FROM {$orgTable} o
                 JOIN {$usersTable} u ON u.ID = o.user_id
                 WHERE TRIM(COALESCE(u.display_name, '')) <> ''
                   AND NOT EXISTS (
                       SELECT 1 FROM {$metaTable} existing
                       WHERE existing.user_id = u.ID
                         AND existing.meta_key = %s
                         AND TRIM(COALESCE(existing.meta_value, '')) <> ''
                   )",
                $metaKey,
                $metaKey
            )
        );
    }
}
