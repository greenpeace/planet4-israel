<?php

declare(strict_types=1);

namespace Timesuite\Core\Support;

/**
 * The one place that decides what an employee is called inside Timesuite.
 *
 * Timesuite used to read `wp_users.display_name` directly at every surface,
 * which made the name on a timesheet a property of the WordPress profile
 * rather than of the employment record. Anyone who edited their own profile --
 * the "Display name publicly as" dropdown is available to every logged-in user
 * -- renamed themselves across the whole of Timesuite, including inside months
 * that had already been locked and exported. Nothing recorded that it had
 * happened, so a payroll file for a closed month could disagree with the one
 * printed from it a week earlier.
 *
 * The employment record now owns the name: it lives in the user meta key below,
 * which only Timesuite reads or writes. `display_name` survives as a fallback
 * so that users who predate the backfill, and WordPress accounts that Timesuite
 * has never been told about (the administrators offered during bootstrap, for
 * instance), still resolve to something a human recognises.
 */
final class EmployeeName
{
    /**
     * Timesuite's own name for an employee. Written by the Org Directory and by
     * the backfill migration; never touched by WordPress itself.
     */
    public const META_KEY = 'timesuite_full_name';

    /**
     * Resolve the name for a loaded user.
     *
     * Typed as a plain object rather than WP_User: WordPress hands back
     * WP_User, but Timesuite's own call sites also carry lighter user-shaped
     * objects (see OrgService::formatUserLabel()), and rejecting those would
     * turn a name lookup into a fatal.
     */
    public static function forUser(?object $user): string
    {
        if (null === $user || empty($user->ID)) {
            return '';
        }

        $stored = function_exists('get_user_meta')
            ? (string) get_user_meta((int) $user->ID, self::META_KEY, true)
            : '';

        return self::firstNonEmpty(
            $stored,
            (string) ($user->display_name ?? ''),
            (string) ($user->user_email ?? ''),
            (string) ($user->user_login ?? '')
        );
    }

    /**
     * Resolve the name for a user id, loading the user if it exists.
     */
    public static function forUserId(?int $userId): string
    {
        if (! $userId || ! function_exists('get_user_by')) {
            return '';
        }

        $user = get_user_by('id', $userId);

        return is_object($user) ? self::forUser($user) : '';
    }

    /**
     * Resolve the name from a row that already carries the candidate columns,
     * so a query that joined them does not pay for a second lookup per user.
     *
     * Accepts either the resolved alias produced by self::sqlExpression() or
     * the raw columns, in the same precedence order as self::forUser().
     *
     * @param array<string, mixed> $row
     */
    public static function fromRow(array $row, string $resolvedKey = 'employee_name'): string
    {
        return self::firstNonEmpty(
            (string) ($row[$resolvedKey] ?? ''),
            (string) ($row[self::META_KEY] ?? ''),
            (string) ($row['display_name'] ?? ''),
            (string) ($row['user_email'] ?? ''),
            (string) ($row['user_login'] ?? '')
        );
    }

    /**
     * A LEFT JOIN that exposes the stored name to a query over the users table.
     *
     * Written as a join rather than a correlated subquery so that the resolved
     * name can also be used in ORDER BY without the lookup running twice.
     */
    public static function sqlJoin(string $metaTable, string $userAlias, string $joinAlias): string
    {
        return sprintf(
            'LEFT JOIN %1$s %2$s ON %2$s.user_id = %3$s.ID AND %2$s.meta_key = \'%4$s\'',
            $metaTable,
            $joinAlias,
            $userAlias,
            self::META_KEY
        );
    }

    /**
     * The SQL expression that resolves a name, matching self::forUser()'s
     * precedence. Pair it with self::sqlJoin().
     */
    public static function sqlExpression(string $joinAlias, string $userAlias): string
    {
        return sprintf(
            'COALESCE(NULLIF(TRIM(%1$s.meta_value), \'\'), NULLIF(TRIM(%2$s.display_name), \'\'), NULLIF(TRIM(%2$s.user_email), \'\'), %2$s.user_login)',
            $joinAlias,
            $userAlias
        );
    }

    /**
     * Store Timesuite's name for a user.
     */
    public static function store(int $userId, string $name): void
    {
        if (! $userId || ! function_exists('update_user_meta')) {
            return;
        }

        update_user_meta($userId, self::META_KEY, trim($name));
    }

    /**
     * The stored name only, with no fallback -- used to tell "HR has never
     * named this person" apart from "HR named them, and this is it".
     */
    public static function stored(int $userId): string
    {
        if (! $userId || ! function_exists('get_user_meta')) {
            return '';
        }

        return trim((string) get_user_meta($userId, self::META_KEY, true));
    }

    private static function firstNonEmpty(string ...$candidates): string
    {
        foreach ($candidates as $candidate) {
            $trimmed = trim($candidate);

            if ('' !== $trimmed) {
                return $trimmed;
            }
        }

        return '';
    }
}
