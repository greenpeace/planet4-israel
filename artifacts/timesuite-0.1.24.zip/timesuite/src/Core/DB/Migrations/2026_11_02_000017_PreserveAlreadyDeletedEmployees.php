<?php

declare(strict_types=1);

namespace Timesuite\Core\DB\Migrations;

use Timesuite\Core\DB\Migration;
use Timesuite\Core\Support\EmployeeAccount;
use wpdb;

/**
 * Takes in employees whose WordPress account was deleted before Timesuite
 * started preserving deleted accounts.
 *
 * From this release DeletedAccountPreserver records a deleted employee as it
 * happens. Accounts deleted earlier left an org mapping pointing at a user row
 * that no longer exists -- the "Orphaned Org Mapping User" integrity issue --
 * with their months still in the database and nothing to show them by. This
 * marks each of those as a preserved deleted account so the directory, HR
 * overview and exports can list them again.
 *
 * Their WordPress meta is already gone, so their name and email cannot be
 * recovered here; the directory shows "Former employee #<id>" until HR types
 * the name back in. The deletion time is unknown too, so it is taken from the
 * last time any of their months changed, which is what decides the last month
 * they are exported in. Rows are only added, never changed, and an account
 * that already carries a deletion time is skipped, so the migration is safe to
 * run again.
 */
class PreserveAlreadyDeletedEmployees extends Migration
{
    public function getVersion(): string
    {
        return '2026_11_02_000017';
    }

    public function up(wpdb $wpdb): void
    {
        $orgTable = $wpdb->prefix . 'timesuite_users_org';
        $monthsTable = $wpdb->prefix . 'timesuite_monthly_timesheets';
        $usersTable = $wpdb->users;
        $metaTable = $wpdb->usermeta;

        $orphans = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT o.user_id,
                        COALESCE(
                            (SELECT MAX(m.updated_at) FROM {$monthsTable} m WHERE m.user_id = o.user_id),
                            MAX(o.updated_at)
                        ) AS last_seen
                 FROM {$orgTable} o
                 LEFT JOIN {$usersTable} u ON u.ID = o.user_id
                 WHERE u.ID IS NULL
                   AND NOT EXISTS (
                       SELECT 1 FROM {$metaTable} d
                       WHERE d.user_id = o.user_id AND d.meta_key = %s
                   )
                 GROUP BY o.user_id",
                EmployeeAccount::META_DELETED_AT
            ),
            ARRAY_A
        );

        foreach (is_array($orphans) ? $orphans : [] as $orphan) {
            $userId = (int) $orphan['user_id'];

            if ($userId <= 0) {
                continue;
            }

            $lastSeen = (string) ($orphan['last_seen'] ?? '');

            $wpdb->insert(
                $metaTable,
                [
                    'user_id' => $userId,
                    'meta_key' => EmployeeAccount::META_DELETED_AT,
                    'meta_value' => '' !== $lastSeen ? $lastSeen : gmdate('Y-m-d H:i:s'),
                ],
                ['%d', '%s', '%s']
            );

            $wpdb->insert(
                $metaTable,
                ['user_id' => $userId, 'meta_key' => EmployeeAccount::META_DELETED_BY, 'meta_value' => '0'],
                ['%d', '%s', '%s']
            );
        }
    }
}
