<?php

declare(strict_types=1);

namespace Timesuite\Core\DB;

use Timesuite\Core\DB\Migrations\CreateApprovalsLog;
use Timesuite\Core\DB\Migrations\CreatePeriods;
use Timesuite\Core\DB\Migrations\CreateTimeEntries;
use Timesuite\Core\DB\Migrations\CreateUsersOrg;
use Timesuite\Core\DB\Migrations\UpdatePeriodsAddUserColumn;
use Timesuite\Core\DB\Migrations\AddBreakMinutesToTimeEntries;
use Timesuite\Core\DB\Migrations\UpdateApprovalsLogAddEntity;
use Timesuite\Core\DB\Migrations\CreateCompTimeLedger;
use Timesuite\Core\DB\Migrations\UpdateTimeEntriesAllowNullPeriod;
use Timesuite\Core\DB\Migrations\CreateMonthlyTimesheets;
use Timesuite\Core\DB\Migrations\CreateHolidayRanges;
use Timesuite\Core\DB\Migrations\CreateReeditRequests;
use Timesuite\Core\DB\Migrations\AddScheduledHoursToMonthlyEntries;
use Timesuite\Core\DB\Migrations\UpdateCompTimeLedgerUniquePerWorkDate;
use Timesuite\Core\DB\Migrations\BackfillEmployeeNames;
use Timesuite\Core\DB\Migrations\PreserveAlreadyDeletedEmployees;
use wpdb;

class MigrationsRunner
{
    public const OPTION_NAME = 'timesuite_migrations_version';

    /**
     * Where the last failed run is recorded, so the System Status page can
     * say which migration failed instead of reporting the database healthy.
     */
    public const ERROR_OPTION = 'timesuite_migrations_error';

    /**
     * MySQL named lock held while pending migrations run, so the first burst
     * of requests after a deploy does not run the same ALTER TABLE twice.
     */
    private const LOCK_NAME = 'timesuite_migrations';

    /**
     * @var class-string<Migration>[]
     */
    private const MIGRATIONS = [
        CreateUsersOrg::class,
        CreateTimeEntries::class,
        CreatePeriods::class,
        CreateApprovalsLog::class,
        UpdatePeriodsAddUserColumn::class,
        AddBreakMinutesToTimeEntries::class,
        UpdateApprovalsLogAddEntity::class,
        CreateCompTimeLedger::class,
        UpdateTimeEntriesAllowNullPeriod::class,
        CreateMonthlyTimesheets::class,
        CreateHolidayRanges::class,
        CreateReeditRequests::class,
        AddScheduledHoursToMonthlyEntries::class,
        UpdateCompTimeLedgerUniquePerWorkDate::class,
        BackfillEmployeeNames::class,
        PreserveAlreadyDeletedEmployees::class,
    ];

    public function __construct(private wpdb $wpdb)
    {
    }

    public function runAll(): void
    {
        $currentVersion = (string) get_option(self::OPTION_NAME, '');
        $migrations = $this->getMigrations();
        $latestVersion = '';

        foreach ($migrations as $migration) {
            $latestVersion = $migration->getVersion();

            if ('' !== $currentVersion && version_compare($currentVersion, $latestVersion, '>=')) {
                continue;
            }

            $this->executeMigration($migration);
            update_option(self::OPTION_NAME, $latestVersion);
            $currentVersion = $latestVersion;
        }

        // Ensure version is recorded even if no migrations ran
        // (tables may exist from manual setup or previous untracked runs)
        if ('' === $currentVersion && '' !== $latestVersion) {
            update_option(self::OPTION_NAME, $latestVersion);
        }
    }

    /**
     * The newest migration this build of the plugin ships.
     */
    public function latestVersion(): string
    {
        $migrations = $this->getMigrations();
        $last = end($migrations);

        return $last instanceof Migration ? $last->getVersion() : '';
    }

    public function appliedVersion(): string
    {
        return (string) get_option(self::OPTION_NAME, '');
    }

    /**
     * Versions shipped by this build that the database has not applied yet.
     *
     * @return string[]
     */
    public function pendingVersions(): array
    {
        $applied = $this->appliedVersion();
        $pending = [];

        foreach ($this->getMigrations() as $migration) {
            if ('' === $applied || version_compare($applied, $migration->getVersion(), '<')) {
                $pending[] = $migration->getVersion();
            }
        }

        return $pending;
    }

    /**
     * Apply whatever this build ships that the database does not have yet.
     *
     * This is what makes a plugin upgrade actually upgrade the database.
     * Migrations used to run only on a fresh install or when
     * VersionService::CURRENT_VERSION went up -- and that constant has been
     * '1.0.0' since the first release, so on every existing site the database
     * stayed at whatever the first install created. A new release that adds a
     * migration only has to register it here; nothing else needs bumping.
     *
     * Runs on every request but costs one autoloaded option read when nothing
     * is pending. A failure is recorded for the System Status page and logged,
     * never thrown: a broken migration must not take every page of the site
     * down with it, and the version is not advanced, so the next request
     * retries it.
     */
    public function runPending(): void
    {
        if ([] === $this->pendingVersions()) {
            return;
        }

        if (! $this->acquireLock()) {
            // Another request is already applying them.
            return;
        }

        try {
            $this->runAll();
            delete_option(self::ERROR_OPTION);
        } catch (\Throwable $e) {
            update_option(self::ERROR_OPTION, [
                'message' => $e->getMessage(),
                'applied_version' => $this->appliedVersion(),
                'failed_at' => gmdate('c'),
            ], false);

            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            error_log('Timesuite migration failed: ' . $e->getMessage());
        } finally {
            $this->releaseLock();
        }
    }

    private function acquireLock(): bool
    {
        if (! method_exists($this->wpdb, 'get_var')) {
            return true;
        }

        $acquired = $this->wpdb->get_var(
            $this->wpdb->prepare('SELECT GET_LOCK(%s, 0)', $this->lockName())
        );

        // NULL means the lock function itself errored; treat that as "not
        // ours" rather than racing another request through the ALTERs.
        return '1' === (string) $acquired;
    }

    private function releaseLock(): void
    {
        if (method_exists($this->wpdb, 'query')) {
            $this->wpdb->query($this->wpdb->prepare('SELECT RELEASE_LOCK(%s)', $this->lockName()));
        }
    }

    /**
     * Named locks are server-wide, so the table prefix keeps two sites on one
     * MySQL server from waiting on each other.
     */
    private function lockName(): string
    {
        return $this->wpdb->prefix . self::LOCK_NAME;
    }

    /**
     * @return Migration[]
     */
    private function getMigrations(): array
    {
        $instances = [];

        foreach (self::MIGRATIONS as $className) {
            $instances[] = new $className();
        }

        usort(
            $instances,
            static function (Migration $a, Migration $b): int {
                return strcmp($a->getVersion(), $b->getVersion());
            }
        );

        return $instances;
    }

    private function executeMigration(Migration $migration): void
    {
        if (! function_exists('dbDelta')) {
            if (defined('ABSPATH')) {
                $upgradeFile = ABSPATH . 'wp-admin/includes/upgrade.php';

                if (is_readable($upgradeFile)) {
                    require_once $upgradeFile;
                }
            }
        }

        $migration->up($this->wpdb);
    }
}
