<?php

declare(strict_types=1);

namespace Timesuite\Core\Support;

/**
 * An employee as Timesuite knows them, whether or not their WordPress account
 * still exists.
 *
 * Deleting a WordPress user used to delete the employee from Timesuite's point
 * of view: their months, entries and ledger stayed in the database, but every
 * screen looked the person up with get_user_by(), got nothing back, and skipped
 * them. They vanished from the Org Directory, the HR overview and every export
 * -- including the payroll file for the month they left in.
 *
 * DeletedAccountPreserver now keeps Timesuite's own user meta (name,
 * department, dates, work week, leave contracts) and records the account's
 * email and deletion time when WordPress deletes the user. This class is how
 * employee-facing code finds such a person again. Access checks must keep using
 * get_user_by(): a deleted account is a former employee on record, never a
 * login.
 */
final class EmployeeAccount
{
    public const META_EMAIL = 'timesuite_account_email';
    public const META_DELETED_AT = 'timesuite_account_deleted_at';
    public const META_DELETED_BY = 'timesuite_account_deleted_by';

    /**
     * The WordPress user, or -- for a preserved deleted account -- a
     * user-shaped stand-in carrying the same fields the callers read.
     */
    public static function find(int $userId): ?object
    {
        if ($userId <= 0 || ! function_exists('get_user_by')) {
            return null;
        }

        $user = get_user_by('id', $userId);

        if (is_object($user)) {
            return $user;
        }

        $deletedAt = self::deletedAt($userId);

        if ('' === $deletedAt) {
            return null;
        }

        $name = EmployeeName::stored($userId);
        $email = self::storedEmail($userId);

        return (object) [
            'ID' => $userId,
            'user_email' => $email,
            'user_login' => '',
            'display_name' => '' !== $name ? $name : self::placeholderName($userId),
            'timesuite_account_deleted' => true,
            'timesuite_account_deleted_at' => $deletedAt,
        ];
    }

    public static function isDeleted(?object $user): bool
    {
        return is_object($user) && ! empty($user->timesuite_account_deleted);
    }

    /**
     * When the WordPress account was deleted, as `Y-m-d H:i:s` UTC, or '' for
     * an account that still exists or was never preserved.
     */
    public static function deletedAt(int $userId): string
    {
        if ($userId <= 0 || ! function_exists('get_user_meta')) {
            return '';
        }

        return trim((string) get_user_meta($userId, self::META_DELETED_AT, true));
    }

    public static function storedEmail(int $userId): string
    {
        if ($userId <= 0 || ! function_exists('get_user_meta')) {
            return '';
        }

        return trim((string) get_user_meta($userId, self::META_EMAIL, true));
    }

    /**
     * Whether a month's report should list this employee.
     *
     * A live account always belongs. A deleted one belongs to every month up
     * to and including the one their account was deleted in -- that month's
     * payroll still has to pay them -- and to none after it, so a former
     * employee does not trail through every future export as an empty column.
     */
    public static function belongsToMonth(?object $user, int $year, int $month): bool
    {
        if (! is_object($user)) {
            return false;
        }

        if (! self::isDeleted($user)) {
            return true;
        }

        $deletedAt = (string) ($user->timesuite_account_deleted_at ?? '');

        if ('' === $deletedAt) {
            return true;
        }

        return substr($deletedAt, 0, 7) >= sprintf('%04d-%02d', $year, $month);
    }

    /**
     * What to call someone whose name was lost with their account -- only
     * possible for accounts deleted before Timesuite started preserving them.
     */
    public static function placeholderName(int $userId): string
    {
        return sprintf(
            /* translators: %d: user ID */
            function_exists('__') ? __('Former employee #%d', 'timesuite') : 'Former employee #%d',
            $userId
        );
    }

    /**
     * A LEFT JOIN exposing a stored meta value for the user whose id is in
     * $userIdColumn. Joins on the Timesuite-side id column rather than on
     * wp_users.ID, so it still matches after the WordPress row is gone.
     */
    public static function sqlMetaJoin(string $metaTable, string $userIdColumn, string $joinAlias, string $metaKey): string
    {
        return sprintf(
            'LEFT JOIN %1$s %2$s ON %2$s.user_id = %3$s AND %2$s.meta_key = \'%4$s\'',
            $metaTable,
            $joinAlias,
            $userIdColumn,
            $metaKey
        );
    }

    /**
     * The account's email: the live one, else the one recorded at deletion.
     */
    public static function sqlEmailExpression(string $userAlias, string $emailJoinAlias): string
    {
        return sprintf(
            'COALESCE(NULLIF(%1$s.user_email, \'\'), %2$s.meta_value, \'\')',
            $userAlias,
            $emailJoinAlias
        );
    }

    /**
     * True (1) when the WordPress row is gone, for SELECT lists.
     */
    public static function sqlDeletedExpression(string $userAlias): string
    {
        return sprintf('(%s.ID IS NULL)', $userAlias);
    }
}
