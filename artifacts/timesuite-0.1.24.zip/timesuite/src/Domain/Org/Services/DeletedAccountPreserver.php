<?php

declare(strict_types=1);

namespace Timesuite\Domain\Org\Services;

use Timesuite\Core\Access\AuthorizationService;
use Timesuite\Core\Access\Role;
use Timesuite\Core\Support\EmployeeAccount;
use Timesuite\Core\Support\EmployeeName;
use Timesuite\Domain\Shared\Repositories\ApprovalLogRepository;
use wpdb;

/**
 * Keeps an employee in Timesuite when their WordPress account is deleted.
 *
 * WordPress deletes a user's meta along with the account, and Timesuite keeps
 * an employee's name, department, dates, work week and leave contracts in user
 * meta. Without this, deleting an account left the person's months in the
 * database with nothing to describe them, and every screen skipped them.
 *
 * On `delete_user` (the account still exists) this captures the employee's
 * Timesuite meta. On `deleted_user` (WordPress has removed it) it writes that
 * meta back, plus the account's email and when and by whom it was deleted, and
 * records the deletion in the audit log. Access roles are deliberately not
 * restored: the person keeps their history, not their access, and there is no
 * account left to sign in with anyway.
 *
 * The confirmation screen WordPress shows before deleting gets a warning
 * naming what Timesuite will keep, whether the person manages anyone, and
 * whether they are the last Timesuite tech admin.
 */
class DeletedAccountPreserver
{
    public const AUDIT_ACTION = 'wp_account_deleted';

    /**
     * Meta that grants access. Everything else under the `timesuite_` prefix
     * describes the employee and is kept.
     */
    private const ACCESS_META_KEYS = [
        AuthorizationService::META_KEY,
        'timesuite_role',
    ];

    /**
     * @var array<int, array{meta: array<int, array{meta_key: string, meta_value: string}>, name: string, email: string}>
     */
    private array $captured = [];

    public function __construct(
        private wpdb $wpdb,
        private ApprovalLogRepository $approvalLogRepository
    ) {
    }

    public function register(): void
    {
        add_action('delete_user', [$this, 'capture'], 10, 3);
        add_action('deleted_user', [$this, 'restore'], 10, 3);
        add_action('delete_user_form', [$this, 'renderDeletionWarning'], 10, 2);
    }

    /**
     * Runs while the account and its meta still exist.
     */
    public function capture(int $userId, mixed $reassign = null, mixed $user = null): void
    {
        if (! $this->isEmployee($userId)) {
            return;
        }

        $user = is_object($user) ? $user : (function_exists('get_user_by') ? get_user_by('id', $userId) : null);

        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT meta_key, meta_value FROM {$this->wpdb->usermeta}
                 WHERE user_id = %d AND meta_key LIKE %s",
                $userId,
                $this->wpdb->esc_like('timesuite_') . '%'
            ),
            ARRAY_A
        );

        $meta = array_values(array_filter(
            is_array($rows) ? $rows : [],
            static fn (array $row): bool => ! in_array((string) $row['meta_key'], self::ACCESS_META_KEYS, true)
        ));

        $this->captured[$userId] = [
            'meta' => $meta,
            'name' => is_object($user) ? EmployeeName::forUser($user) : EmployeeName::stored($userId),
            'email' => is_object($user) ? (string) ($user->user_email ?? '') : '',
        ];
    }

    /**
     * Runs after WordPress has deleted the account and all its meta.
     */
    public function restore(int $userId, mixed $reassign = null, mixed $user = null): void
    {
        $captured = $this->captured[$userId] ?? null;

        if (null === $captured) {
            return;
        }

        unset($this->captured[$userId]);

        $actorId = function_exists('get_current_user_id') ? (int) get_current_user_id() : 0;
        $deletedAt = gmdate('Y-m-d H:i:s');

        // Raw inserts: the captured values are already serialized exactly as
        // WordPress stored them, and add_user_meta() would serialize them a
        // second time.
        $restored = [];

        foreach ($captured['meta'] as $row) {
            $restored[(string) $row['meta_key']] = (string) $row['meta_value'];
        }

        if ('' !== $captured['name']) {
            $restored[EmployeeName::META_KEY] = $captured['name'];
        }

        $restored[EmployeeAccount::META_EMAIL] = $captured['email'];
        $restored[EmployeeAccount::META_DELETED_AT] = $deletedAt;
        $restored[EmployeeAccount::META_DELETED_BY] = (string) $actorId;

        foreach ($restored as $key => $value) {
            $this->wpdb->insert(
                $this->wpdb->usermeta,
                ['user_id' => $userId, 'meta_key' => $key, 'meta_value' => $value],
                ['%d', '%s', '%s']
            );
        }

        if (function_exists('wp_cache_delete')) {
            wp_cache_delete($userId, 'user_meta');
        }

        $this->approvalLogRepository->log(self::AUDIT_ACTION, $userId, $actorId, [
            'employee_name' => $captured['name'],
            'employee_email' => $captured['email'],
            'reports_left_without_manager' => $this->countReports($userId),
        ]);
    }

    /**
     * Printed inside WordPress's "Delete Users" confirmation form.
     *
     * @param mixed $currentUser
     * @param int[]|mixed $userIds
     */
    public function renderDeletionWarning(mixed $currentUser = null, mixed $userIds = []): void
    {
        $userIds = array_map('intval', is_array($userIds) ? $userIds : []);
        $employees = array_values(array_filter($userIds, fn (int $id): bool => $this->isEmployee($id)));

        if ([] === $employees) {
            return;
        }

        $lines = [];

        foreach ($employees as $userId) {
            $user = function_exists('get_user_by') ? get_user_by('id', $userId) : null;
            $name = is_object($user) ? EmployeeName::forUser($user) : EmployeeName::forUserId($userId);
            $reports = $this->countReports($userId);

            $line = sprintf(
                /* translators: %s: employee name */
                __('%s is a Timesuite employee. Timesuite will keep their timesheets, history and profile; they will lose access.', 'timesuite'),
                '<strong>' . esc_html($name) . '</strong>'
            );

            if ($this->hasActiveMapping($userId)) {
                $line .= ' ' . __('They will stay in the Org Directory, marked as a deleted WordPress account.', 'timesuite');
            }

            if ($reports > 0) {
                $line .= ' ' . sprintf(
                    /* translators: %d: number of employees */
                    _n(
                        'They manage %d employee, whose months will have no approver until a new manager is set in the Org Directory.',
                        'They manage %d employees, whose months will have no approver until a new manager is set in the Org Directory.',
                        $reports,
                        'timesuite'
                    ),
                    $reports
                );
            }

            $lines[] = $line;
        }

        $remainingTechAdmins = $this->countTechAdminsExcluding($userIds);

        if (0 === $remainingTechAdmins && $this->countTechAdminsExcluding([]) > 0) {
            $lines[] = '<strong>' . esc_html__('This removes the last Timesuite tech admin. Timesuite will block everyone, employees included, until a WordPress administrator appoints a new tech admin on the Timesuite setup screen.', 'timesuite') . '</strong>';
        }

        echo '<div class="notice notice-warning inline"><p>' . implode('</p><p>', $lines) . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- names escaped above
    }

    private function isEmployee(int $userId): bool
    {
        if ($userId <= 0) {
            return false;
        }

        $table = $this->wpdb->prefix . 'timesuite_users_org';

        return (int) $this->wpdb->get_var(
            $this->wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE user_id = %d", $userId)
        ) > 0;
    }

    private function hasActiveMapping(int $userId): bool
    {
        $table = $this->wpdb->prefix . 'timesuite_users_org';

        return (int) $this->wpdb->get_var(
            $this->wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND removed_at IS NULL", $userId)
        ) > 0;
    }

    private function countReports(int $managerId): int
    {
        $table = $this->wpdb->prefix . 'timesuite_users_org';

        return (int) $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(DISTINCT user_id) FROM {$table}
                 WHERE org_unit_id = %d AND removed_at IS NULL AND user_id <> %d",
                $managerId,
                $managerId
            )
        );
    }

    /**
     * @param int[] $excluded
     */
    private function countTechAdminsExcluding(array $excluded): int
    {
        $exclusion = '';

        if ([] !== $excluded) {
            $exclusion = ' AND u.ID NOT IN (' . implode(',', array_map('intval', $excluded)) . ')';
        }

        return (int) $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->wpdb->usermeta} um
                 INNER JOIN {$this->wpdb->users} u ON u.ID = um.user_id
                 WHERE um.meta_key = %s AND um.meta_value = %s{$exclusion}",
                AuthorizationService::META_KEY,
                Role::TECH_ADMIN
            )
        );
    }
}
